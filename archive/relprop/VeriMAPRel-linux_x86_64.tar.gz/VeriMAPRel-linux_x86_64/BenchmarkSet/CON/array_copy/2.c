/* input  variables */
 int n, m;
 int a[m];
 int b[m];

/*
   MAP_specification

   specvars([n,m,a,b],[a]).
*/

void main() {

  int i=0;

  while(i < n) {
    a[i] = b[i];
    i++;
  }

  while(i < m) {
    a[i] = b[i];
    i++;
  }

}

