/* input  variables */
 int m;
 int a[m];
 int b[m];

 int j,k;

/*
   MAP_specification

   specvars([m,a,b],[a]).
*/

void main() {

  int i=0;

  while(i < m) {
    a[i] = b[i];
    i++;
  }

}

