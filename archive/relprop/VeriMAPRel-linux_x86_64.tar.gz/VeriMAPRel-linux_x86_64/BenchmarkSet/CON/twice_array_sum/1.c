/* input  variables */
 int n;
 int a[n];
/* output  variables */
 int s1;

/*
   MAP_specification

   specvars([n,a],[s1]).
*/

void main() {
  s1=0;
  w3(0);
}

void w3(int i) {
  while(i < n) {
    s1 += a[i] + a[i];
    i++;
  }
}


