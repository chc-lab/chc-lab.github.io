/* input  variables */
 int n;
 int a[n];
 int b[n];
 int max1;
/*
   MAP_specification

   specvars([n,a,b],[max1]).
*/

void main() {

  int i=0;
  max1 = b[i];
  copy_max(i);

}

void copy_max(int i) {
  while(i < n) {
    a[i] = b[i];
    if (a[i] > max1)
      max1=a[i];
    i++;
  }
}

