/* input  variables */
 int n;
 int a[n];
 int k;
/* output  variables */
 int s2;

/*
   MAP_specification

   specvars([n,a,k],[s2]).
*/

void main() {
  w1(0);
  w2(0);
}

void w1(int i) {
  while(i < n) {
    a[i] = a[i] + k;
    i++;
  }
}

void w2(int i) {
  s2=0;
  while(i < n) {
    s2 += a[i];
    i++;
  }
}

