/* input  variables */
 int n;
 int a[n];
 int k;
/* output  variables */
 int s1;

/*
   MAP_specification

   specvars([n,a,k],[s1]).
*/

void main() {
  w3(0);
}

void w3(int i) {
  s1=0;
  while(i < n) {
    s1 += a[i] + k;
    i++;
  }
}

