/* input  variables */
 int n,m;
/* output  variables */
 int s;

/*
   MAP_specification

   specvars([n,m],[s]).
*/

void main() {

  int i=0,k;
  s=0;

  while(i <= n) {
    s += i;
    i++;
  }

  k=i-1;

  while(i <= m) {
    s += k;
    i++;
  }

}

