/* input  variables */
 int size_a;
 int size_b;
 int a[size_a];
 int b[size_b];
/* output  variables */
 int s2;

/*
   MAP_specification

   specvars([size_a,a,size_b,b],[s2]).
*/

void main() {
  s2=0;
  w1();
  w2();
}

void w1() {
  int i = 0;
  while(i < size_a) {
    s2 += a[i];
    i++;
  }
}

void w2() {
  int i = 0;
  while(i < size_b) {
    s2 += b[i];
    i++;
  }
}

