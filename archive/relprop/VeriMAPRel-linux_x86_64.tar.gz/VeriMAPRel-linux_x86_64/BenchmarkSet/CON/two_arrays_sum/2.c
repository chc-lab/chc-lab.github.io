/* input  variables */
 int n;
 int a[n];
 int b[n];
/* output  variables */
 int s2;

/*
   MAP_specification

   specvars([n,a,b],[s2]).
*/

void main() {
  s2=0;
  w1(0);
  w2(0);
}

void w1(int i) {
  while(i < n) {
    s2 += a[i];
    i++;
  }
}

void w2(int i) {
  while(i < n) {
    s2 += b[i];
    i++;
  }
}

