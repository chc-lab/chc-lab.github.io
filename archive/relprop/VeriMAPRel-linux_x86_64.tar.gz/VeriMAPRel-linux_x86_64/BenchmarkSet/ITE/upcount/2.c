int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=upcount(i); 
}


/*@ pre n >= 0 @*/


int upcount(int n) {
   int m = 0;
   while(n > 0) {
      m++;
      n--;
   }
   return m+1;
}

