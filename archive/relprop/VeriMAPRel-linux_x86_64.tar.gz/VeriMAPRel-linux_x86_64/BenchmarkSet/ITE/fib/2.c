int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

/*@ rel_in n == \other n - 1 @*/

int f(int n) {
  int f = 1;  //  <---- starting at 1
  int g = 1;
  int h = 0;

  while(n > 0) {
    h = f + g;
    f = g;
    g = h;
    n --;
  }

  return g;
} 

