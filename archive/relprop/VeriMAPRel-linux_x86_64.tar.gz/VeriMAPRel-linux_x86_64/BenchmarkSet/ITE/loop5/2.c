int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f(int n) {
  int i = n;
  int j = 0;

  while (i > 0) {
    j = j + 2;
    i = i - 1;
  }
  return j;
}

