int i1,i2,o;

/*
  % MAP_specification

  specvars([i1,i2],[o]).

*/

int main() {
  o=f(i1,i2); 
}



int f(int n, int c) {
   int i;
   int j;
   int x;

   i = 0;
   j = 0;
   x = 0;

   while(i < n) {
      j = 5*i + c;
      x = x + j;
      i++;
   }
   return x;
}

