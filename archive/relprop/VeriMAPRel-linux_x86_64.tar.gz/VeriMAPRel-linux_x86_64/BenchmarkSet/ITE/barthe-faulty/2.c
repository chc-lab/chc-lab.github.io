int i1,i2,o;

/*
  % MAP_specification

  specvars([i1,i2],[o]).

*/

int main() {
  o=f(i1,i2); 
}



int f(int n, int c) {
   int i;
   int j;
   int x;

   i = 0;
   j = c;
   x = 0;

   while(i < n) {
      x = x + j;
      j = j + 5;
      if (i == 10) {
        j = 10;
      }
      i++;
   }
   return x;
}

