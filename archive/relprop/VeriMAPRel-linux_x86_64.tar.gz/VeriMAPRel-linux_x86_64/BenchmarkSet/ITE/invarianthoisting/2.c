unsigned int i,n,x,y; 

/*
  % MAP_specification

  specvars([i,n,x,y],[i]).

*/

void main(){

  x=y+1;

  while(i<n) {  
    i=i+x;
  }

}   
