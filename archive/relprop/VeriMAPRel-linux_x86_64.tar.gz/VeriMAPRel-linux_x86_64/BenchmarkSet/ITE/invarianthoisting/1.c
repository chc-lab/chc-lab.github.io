unsigned int i,n,x,y; 

/*
  % MAP_specification

  specvars([i,n,x,y],[i]).

*/

void main(){

  while(i<n) {
    x=y+1;
    i=i+x;
  }

}   
