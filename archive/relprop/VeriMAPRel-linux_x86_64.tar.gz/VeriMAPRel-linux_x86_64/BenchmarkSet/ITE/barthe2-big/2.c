int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f(int n) {
  int i = 1;
  int x = 1;

  while (i <= n) {
    x = x * 5;
    i++;
  }

  i = 1;

  while (i <= n) {
    x = x + i;
    i++;
  }
  return x;
}

