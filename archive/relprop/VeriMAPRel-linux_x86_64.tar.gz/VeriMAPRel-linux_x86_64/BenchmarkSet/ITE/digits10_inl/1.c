int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f(int n) {
  int result = 1;
  n = n/10;

  while (n > 0) {
    result++;
    n = n / 10;
    if (n > 0) {
      result++;
      n = n / 10;
      if (n > 0) {
        result++;
        n = n / 10;
        if (n > 0) {
          result++;
          n = n / 10;
        }
      }
    }
  }
  return result;
}

