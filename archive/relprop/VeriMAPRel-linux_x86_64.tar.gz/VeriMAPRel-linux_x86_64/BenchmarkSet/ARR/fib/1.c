int in1,out1;

/*
  % MAP_specification

  specvars([in1],[out1]).

*/

void main() {
  out1=fib1(in1); 
}

int fib1(int n) {
   int i1 = 2;
   int a1 = 1;
   int b = 1;
   int t;

   while(i1 < n) {
      t = a1;
      a1 = b;
      b = a1+t;
      i1++;
   }

   return b;
}

