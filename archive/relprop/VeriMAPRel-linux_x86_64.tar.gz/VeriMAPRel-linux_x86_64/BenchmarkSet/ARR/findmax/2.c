int n, result2;
int a[n];

/*
  % MAP_specification

  specvars([a,n],[result2]).

*/

void main() {

   int i2 = 1;
   int maxv = a[0];

   while(i2 < n) {
      if(a[i2] >= maxv) {
         maxv = a[i2];
      }
      i2++;
   }

   result2 = maxv;
}

