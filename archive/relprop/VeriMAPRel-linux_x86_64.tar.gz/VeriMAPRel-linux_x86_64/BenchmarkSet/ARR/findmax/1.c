int n, result1;
int a[n];

/*
  % MAP_specification

  specvars([a,n],[result1]).

*/

void main() {

   int i1 = 1;
   int max = 0;

   while(i1 < n) {
      if(a[i1] >= a[max]) {
         max = i1;
      }
      i1++;
   }

   result1 = a[max];
}

