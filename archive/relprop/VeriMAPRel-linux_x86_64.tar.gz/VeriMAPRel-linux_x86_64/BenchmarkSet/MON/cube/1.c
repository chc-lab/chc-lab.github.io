/* input  variables */
int n;

/* output  variables */
int r;


/*
  % MAP_specification

  specvars([n],[r]).

  side_effect_free_fun(g).

*/


void main() {
  r = g(n);
}

int g(int n)
{
  int r=0;
  int i=n;

  while (i > 0) {
    r += n;
    i--;
  }

  i=n;
  n=r;
  while (i > 0) {
    r += n;
    i--;
  }

  return r;
}

