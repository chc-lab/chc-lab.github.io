/* input  variables */
int n;

/* output  variables */
int r;


/*
  % MAP_specification

  specvars([n],[r]).

  side_effect_free_fun(g).

*/


void main() {
  r = g(n,0);
}

int g(int n,int s ) {
  int tmp = 0;

  if ( n <= 0) {
    tmp = s;
  } else {
    tmp = g(n-1,n+s);
  }

  return tmp;
}

