int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=triangle(i); 
}


int triangle(int n) {
  int r;
  r = f(n);
  return r;
}

int f(int n) {
  int r;
  int x;
  r = 0;
  x = 0;

  if (n <= 0) {
    r = 0;
  } else {
    r = f(n-1);
    x = r + n;
    if (x > 15) {
      x = x - 32;
    } else { if (x < 0-16) {
      x = x + 32;
    }}
    r = x;
  }
  return r;
}

