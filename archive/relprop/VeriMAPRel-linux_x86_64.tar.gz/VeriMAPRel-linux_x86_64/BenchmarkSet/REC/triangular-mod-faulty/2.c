int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=triangle(i); 
}

int triangle(int n) {
  int r;
  r = f(n, 0);
  return r;
}

int f(int n, int s) {
  int r;
  int i;
  int j;
  int x;
  x = 0;
  i = 0;
  j = 0;
  r = 0;

  if (n <= 0) {
    r = s;
  } else {
    i = n-1;
    x = n + s;
    if (x > 16) {
      x = x - 31;
    }
    j = x;
    r = f(i,j);
  }
  return r;
}

