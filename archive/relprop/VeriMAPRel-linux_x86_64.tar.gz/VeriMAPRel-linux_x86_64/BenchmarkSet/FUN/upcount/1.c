int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=upcount(i); 
}

/*
 * These two programs differ in the number of iterations of the
 * loop. This versions does one more iteration with n = 0, while
 * the other version adds one to the output value.
 *
 * Do they compute the same?
 * No, not in general.
 * But they do for non-negative integers. That's why there is 
 * the precondition in the second release. Drop it and you'll
 * get a counterexample (n=-1, e.g.)
 */
int upcount(int n) {

   int m = 0;
   while(n >= 0) {
      m++;
      n--;
   }
   return m;
}

