int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

  side_effect_free_fun(f).

*/

int main() {
  o=f(i); 
}


int f(int n) {
  int r;
  r = 0;

  if (n <= 1) {
    r = n;
  } else {
//    r = f(n - 1);
//    r = n + r;
      r = n + f(n - 1);
  }

  return r;
}

