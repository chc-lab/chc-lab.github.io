int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

  side_effect_free_fun(f).

*/

int main() {
  o=f(i); 
}


int f(int n) {
  int r;
  r = 0;

  if (n <= 1) {
    r = n;
  } else {
//    r = f(n - 2);
//    r = n + (n-1) + r;
      r = n + (n-1) + f(n - 2);

  }

  return r;
}

