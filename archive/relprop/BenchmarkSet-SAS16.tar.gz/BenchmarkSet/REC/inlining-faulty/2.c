int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}


int f(int x) {
  if (x > 1) {
    x = f(x-2);
    x = x + 2;
  }
  if (x < 2) {
    x = 0;
  }
  return x;
}

