/* input  variables */
 int m;
/* output  variables */
 int s;

/*
   MAP_specification

   specvars([m],[s]).
*/

void main() {

  int i=0;
  s=0;

  while(i <= m) {
    s += i;
    i++;
  }
}

