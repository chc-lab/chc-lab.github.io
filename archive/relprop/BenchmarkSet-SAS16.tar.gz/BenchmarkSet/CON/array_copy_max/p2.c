/* input  variables */
 int n;
 int a[n];
 int b[n];
 int max2;

/*
   MAP_specification

   specvars([n,a,b],[max2]).
*/

void main() {

  array_copy(0); 

  find_max(0);

}

void array_copy(int i) {
  
  while(i < n) {
    a[i] = b[i];
    i++;
  }
}

void find_max(int i) {

  max2 = b[0];

  while(i < n) {
    if (a[i] > max2)
      max2=a[i];
    i++;
  }
}

