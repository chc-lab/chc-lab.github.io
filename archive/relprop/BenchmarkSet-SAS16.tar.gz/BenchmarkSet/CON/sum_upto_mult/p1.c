/* input  variables */
 int m;
/* output  variables */
 int s;

#include <stdio.h>

/*
   MAP_specification

   specvars([m],[s]).
*/

void main() {

  int i=0;
  s=0;

  while(i <= m) {
    s += i;
    i++;
  }
}

