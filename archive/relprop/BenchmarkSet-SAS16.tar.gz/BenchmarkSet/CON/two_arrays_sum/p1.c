/* input  variables */
 int n;
 int a[n];
 int b[n];
/* output  variables */
 int s1;

/*
   MAP_specification

   specvars([n,a,b],[s1]).
*/

void main() {
  s1=0;
  w3(0);
}

void w3(int i) {
  while(i < n) {
    s1 += a[i] + b[i];
    i++;
  }
}

