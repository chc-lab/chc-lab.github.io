/* input  variables */
 int size_a;
 int size_b;
 int a[size_a];
 int b[size_b];
/* output  variables */
 int s1;

/*
   MAP_specification

   specvars([size_a,a,size_b,b],[s1]).
*/

void main() {
  s1=0;

  int n = size_a, i = 0;
  
  if (size_a < size_b)
    n=size_b;

  w3(0,n);
}

void w3(int i, int n) {
  while(i < n) {
    if (i < size_a)
      s1 += a[i];
    if (i < size_b)
      s1 += b[i];
    i++;
  }
}


