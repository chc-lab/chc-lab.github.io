/* input  variables */
 int n;
 int a[n];
/* output  variables */
 int s2;

/*
   MAP_specification

   specvars([n,a],[s2]).
*/

void main() {
  w1(0);
  w2(0);
}

void w1(int i) {
  while(i < n) {
    a[i] = a[i] + 1;
    i++;
  }
}

void w2(int i) {
  s2=0;
  while(i < n) {
    s2 += a[i];
    i++;
  }
}

