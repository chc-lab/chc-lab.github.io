/* input  variables */
 int n;
 int a[n];
/* output  variables */
 int s1;

/*
   MAP_specification

   specvars([n,a],[s1]).
*/

void main() {
  w3(0);
}

void w3(int i) {
  s1=0;
  while(i < n) {
    s1 += a[i] + 1;
    i++;
  }
}

