int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f(int z) {
  int y = 0;
  int x = 1;
  
  while (x < 10) {
    y = 2 + x;
    x = y + y;
  }
 
  return x*2;
}

