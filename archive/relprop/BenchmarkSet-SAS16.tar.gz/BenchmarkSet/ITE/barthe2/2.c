int i,o;


/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f(int n) {
  int j = 1;
  int x = 0;
  while (j <= n) {
    x = x + j;
    j++;
  }
  return x;
}
