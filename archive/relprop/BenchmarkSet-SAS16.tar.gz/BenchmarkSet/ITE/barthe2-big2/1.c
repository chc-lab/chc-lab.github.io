int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f(int n) {
  int i = 1;
  int x = 1;

  while (i <= n) {
    x = x * 1;
    i++;
  }

  i = 0;
  while (i <= n) {
    x = x + i;
    i++;
  }

  i = 1;
  while (i <= n) {
    x = x * 2;
    i++;
  }

  return x;
}

