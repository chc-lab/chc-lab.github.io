int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}


int f(int n) {
  int i;
  int j;
  i = 0;
  j = 0;
  while (i < n + n) {
    j++;
    i++;
  }
  return j;
}

