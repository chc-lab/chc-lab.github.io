int i1,i2,o;


/*
  % MAP_specification

  specvars([i1,i2],[o]).

*/

int f(int n, int c) {
   int i = 0;
   int j = c;
   int x = 0;

   while(i < n) {
      x = x + j;
      j = j + 5;
      i++;
   }
   return x;
}

int main() {
  o=f(i1,i2); 
}

