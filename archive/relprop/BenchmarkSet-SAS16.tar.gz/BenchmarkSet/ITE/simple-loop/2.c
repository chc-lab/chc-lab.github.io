int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f(int z) {
  int i = 1;

  while (i <= 10) {
    i++;
  }
  return i;
}

