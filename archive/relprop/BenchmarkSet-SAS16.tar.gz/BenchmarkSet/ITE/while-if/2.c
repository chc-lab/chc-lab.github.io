int i1,i2,o;

/*
  % MAP_specification

  specvars([i1,i2],[o]).

*/

int main() {
  o=f(i1,i2); 
}


int f(int t, int c) {
  int x = 0;

  while(0 < c) {
    if(0 < t) {
      x ++;
    }
    c = c - 1;
  }

  return x;
}

