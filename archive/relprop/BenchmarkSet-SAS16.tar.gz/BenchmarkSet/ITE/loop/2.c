int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f(int n) {
  int i = n;
  int j = 0;

  while (i >= 0) {
    i = i - 1;
    j++;
  }
  return j;
}

