int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f(int n) {
  int i = 0;
  int j = 0;

  while (i <= n) {
    i++;
    j++;
  }
  return j;
}

