/* input  variables */
unsigned int n;

/* output  variables */
unsigned int r;


/*
  % MAP_specification

  specvars([n],[r]).

  side_effect_free_fun(g).

*/


void main() {
  r = g(n);
}

unsigned int g(unsigned int n)
{
  unsigned int r=0;

  while (n > 0) {
    r += n;
    n--;
  }

  return r;
}

