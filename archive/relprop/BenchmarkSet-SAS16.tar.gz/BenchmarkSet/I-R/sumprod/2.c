/* input  variables */
 int x,y;

/* output  variables */
 int z;


/*
  % MAP_specification

  specvars([x,y],[z]).

  side_effect_free_fun(g).

*/


void main() {
  z = g(x,y);
}

int g(int n, int m){

  int r=0;

  while (n > 0) {
    r += m;
    n--;
  }

  return r;
}

