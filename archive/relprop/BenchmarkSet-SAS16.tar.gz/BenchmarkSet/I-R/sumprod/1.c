int x, z;

/*
  % MAP_specification

  specvars([x],[z]).

  side_effect_free_fun(f).

*/

int main() {
  z=f(x); 
}

int f(int n)
{
  int r = 0;

  if (n <= 0) {
    r = 0;
  } else {
    r = f(n - 1) + n;
  }

  return r;
}



