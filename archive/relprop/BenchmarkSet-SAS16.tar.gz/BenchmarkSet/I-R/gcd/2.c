/* input/output variables */
unsigned int x,y;  // [x>=1,y>=1].
/* x and y in the final configuration store the gcd */

/*
  % MAP_specification

  specvars([x,y],[x]).

*/


void main() {
  
   x = gcd(x,y);
  
}

unsigned gcd( unsigned m, unsigned n ) {

  if (m==n)
    return m;
  else if (m>n) {
     return gcd(m-n,n);
  } else {
     return gcd(m,n-m);
  }
}
