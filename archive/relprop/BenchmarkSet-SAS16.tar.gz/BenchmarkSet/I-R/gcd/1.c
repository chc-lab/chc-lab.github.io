/* input/output variables */
unsigned int x,y;  // [x>=1,y>=1].
/* x and y in the final configuration store the gcd */

/*
  % MAP_specification

  specvars([x,y],[x]).

*/

void main() {
  
  while (x!=y) { 
    if (x>y) {
      x=x-y;
    } else {
      y=y-x;
    }
  }
}
