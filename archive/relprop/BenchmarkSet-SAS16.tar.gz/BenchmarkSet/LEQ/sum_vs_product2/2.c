/* input  variables */
 int i1,i2;

/* output  variables */
 int o;


/*
  % MAP_specification

  specvars([i1,i2],[o]).

  side_effect_free_fun(g).

*/


void main() {
  o = g(i1,i2);
}

 int g( int i1,  int i2)
{
   int r=0;

  while (i2 > 0) {
    r += i1;
    i2--;
  }

  return r;
}

