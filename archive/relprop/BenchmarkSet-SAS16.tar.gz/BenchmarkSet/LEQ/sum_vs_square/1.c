/* input  variables */
int n;

/* output  variables */
int r;


/*
  % MAP_specification

  specvars([n],[r]).

  side_effect_free_fun(g).

*/


void main() {
  r = g(n);
}

int g(int n)
{
  int r=0;

  while (n > 0) {
    r += n;
    n--;
  }

  return r;
}

