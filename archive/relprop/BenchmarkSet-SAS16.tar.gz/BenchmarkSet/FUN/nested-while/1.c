int i1,i2,o;

/*
  % MAP_specification

  specvars([i1,i2],[o]).

*/

int main() {
  o=f(i1,i2); 
}

int f(int x, int g) {
  int i = 0;

  while (i < x) {
    i = i + 1;
    g = g - 2;
    g = g + 1;
    while(x < i) {
      x = x + 2;
      x = x - 1;
      g = g + 1;
    }
  }
  return g;
}

