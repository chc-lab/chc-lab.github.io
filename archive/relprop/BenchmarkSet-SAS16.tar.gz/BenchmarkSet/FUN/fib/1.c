int n;
int o = 1;
int i = 2;
int a = 1;
int t;

/*
  % MAP_specification

  specvars([n,o,i,a,t],[o]).

*/

int main() {
 
   while(i < n) {
      t = a;
      a = o;
      o = a+t;
      i++;
   }

}   




