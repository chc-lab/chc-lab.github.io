/*@ pre n >= 0 @*/
/*@ rel_out \result == \other \result @*/

int in2, out2;
int a[in2];

/*
  % MAP_specification

  specvars([in2],[out2]).

*/

void main() {
  out2=fib2(in2); 
}

int fib2(int n) {
   int i2 = 2;
   a[0] = 1;
   a[1] = 1;

   while(i2 < n) {
      a[i2] = a[i2-1] + a[i2-2];
      i2++;
   }

   return a[i2-1];
}

