int n;
int a[n];
int b[n];
int c[n];

/*
  % MAP_specification

  specvars([n,a,b,c],[c]).

*/

void main() {
   int i2 = 1;
   int m2 = n-1;

   c[1] = b[0];
   while(i2 <= m2-1) {
      b[i2] = a[i2];
      c[i2+1] = b[i2];
      i2++;
   }
   b[m2] = a[m2];

}


