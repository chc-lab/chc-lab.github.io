int n;
int a[n];
int b[n];
int c[n];

/*
  % MAP_specification

  specvars([n,a,b,c],[c]).

*/

void main() {
   int i1 = 1;
   int m1 = n-1;

   while(i1 <= m1) {
      b[i1] = a[i1];
      c[i1] = b[i1-1];
      i1++;
   }

}


