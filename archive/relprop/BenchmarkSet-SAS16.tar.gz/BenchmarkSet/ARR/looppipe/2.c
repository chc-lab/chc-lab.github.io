int n;
int a[n];
int b[n];
int c[n];

/*
  % MAP_specification

  specvars([n,a,b,c],[a,b,c]).

*/

void main() {
   int i2 = 0;

   a[0]++;
   b[0] += a[0];
   a[1]++;

   while(i2 < n-2) {
      a[i2+2]++;
      b[i2+1] += a[i2+1];
      c[i2] += b[i2];
      i2++;
   }

   c[i2] += b[i2];
   b[i2+1] += a[i2+1];
   c[i2+1] += b[i2+1];


}


