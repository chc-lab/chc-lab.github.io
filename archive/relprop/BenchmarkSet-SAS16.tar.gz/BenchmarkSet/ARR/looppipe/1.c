int n;
int a[n];
int b[n];
int c[n];

/*
  % MAP_specification

  specvars([n,a,b,c],[a,b,c]).

*/

void main() {
   int i1 = 0;

   while(i1 < n) {
      a[i1]++;
      b[i1] += a[i1];
      c[i1] += b[i1];
      i1++;
   }

}


