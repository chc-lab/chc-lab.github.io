int n, i1;
int a[n];

/*
  % MAP_specification

  specvars([a,n],[i1]).

*/

void main() {

   i1=0;

   while(i1 < n) {
      a[i1+1] = a[i1];
      i1++;
   }

}

