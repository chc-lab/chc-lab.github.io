int n, i2;
int a[n];

/*
  % MAP_specification

  specvars([a,n],[i2]).

*/

void main() {

   i2=0;

   while(i2 < n) {
      a[i2+1] = a[0];
      i2++;
   }

}

