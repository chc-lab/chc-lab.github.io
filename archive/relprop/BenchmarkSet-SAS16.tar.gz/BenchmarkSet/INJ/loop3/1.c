int i,o;

/*
  % MAP_specification

  specvars([i],[o]).

*/

int main() {
  o=f(i); 
}

int f (int n) {
  int i = 1;
  int j = 0;

  if (n < 1) {
    n = 1;
  }

  while (i <= n) {
    j = j + 2;
    i++;
  }

  return j;
}

