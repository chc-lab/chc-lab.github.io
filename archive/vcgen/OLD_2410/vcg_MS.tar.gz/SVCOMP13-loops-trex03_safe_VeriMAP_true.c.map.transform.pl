new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=L, B1=:=0, C1=:=D1-E1, D1=:=C, C>=0, E1=:=H, H>=0, 
          new6(s(A,B,C1,D,E,F,G,H,I,F1,K,G1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=L, B1=:=0, C1=:=D1-E1, D1=:=C, C>=0, E1=:=H, H>=0, 
          new6(s(A,B,C1,D,E,F,G,H,I,F1,K,G1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=L, B1=:=0, C1=:=D1-E1, D1=:=E, E>=0, E1=:=I, I>=0, 
          new6(s(A,B,C,D,C1,F,G,H,I,F1,K,G1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=J, B1=:=0, C1=:=D1-E1, D1=:=A, A>=0, E1=:=G, G>=0, 
          new6(s(C1,B,C,D,E,F,G,H,I,F1,K,G1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=J, B1=:=0, C1=:=D1-E1, D1=:=A, A>=0, E1=:=G, G>=0, 
          new6(s(C1,B,C,D,E,F,G,H,I,F1,K,G1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=J, B1=:=0, 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=E, E>=0, B1=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=<B1, 
          A1=:=E, E>=0, B1=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=E, E>=0, B1=:=0, 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, C>=0, B1=:=0, 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, A>=0, B1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, C>=0, B1=:=0, 
          new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=<B1, 
          A1=:=C, C>=0, B1=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, A>=0, B1=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=<B1, 
          A1=:=A, A>=0, B1=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          B1>=0, C1=:=A1, A1>=0, D1=:=1, E1=:=1, F1=:=1, G1=:=H1, I1=:=J1, 
          new6(s(A,B,C,D,C1,A1,D1,E1,F1,G1,H1,I1,J1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          B1>=0, C1=:=A1, A1>=0, 
          new5(s(A,B,C1,A1,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          B1>=0, C1=:=A1, A1>=0, 
          new4(s(C1,A1,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new1 :- new2(s,d).
correct :- \+new1.
