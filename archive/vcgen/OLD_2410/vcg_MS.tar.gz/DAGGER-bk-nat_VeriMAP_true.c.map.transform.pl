new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=1, Q=:=0, R=:=0, 
          S=:=1, T=:=U-V, U=:=W+X, W=:=Y+Z, Y=:=A1+B1, A1=:=A, B1=:=Q, Z=:=S, 
          X=:=R, V=:=1, new7(s(T,Q,R,S,E,F,C1),d(H,I,J,K,L,M,N)).
new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=Q+R, Q=:=C, R=:=B, P=:=1, 
          S=:=T-U, T=:=V+W, V=:=X+Y, X=:=A, Y=:=B, W=:=C, U=:=1, Z=:=A1+B1, 
          A1=:=D, B1=:=1, C1=:=0, D1=:=0, 
          new7(s(S,C1,D1,Z,E,F,E1),d(H,I,J,K,L,M,N)).
new22(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=0, 
          new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new22(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=0, 
          new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new22(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=E, P=:=0, 
          new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=1, Q=:=R+S, R=:=C, 
          S=:=D, T=:=0, U=:=V-W, V=:=A, W=:=1, X=:=Y+Z, Y=:=B, Z=:=1, 
          new7(s(U,X,Q,T,E,F,A1),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=Q+R, Q=:=S+T, S=:=A, 
          T=:=B, R=:=D, P=:=1, new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=0, 
          new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=B, P=:=0, 
          new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=B, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=C, P=:=0, 
          new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=C, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=D, P=:=0, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=D, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=F, P=:=0, 
          new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=F, P=:=0, 
          new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=F, P=:=0, 
          new22(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=G, P=:=0, 
          new8(s(A,B,C,D,E,Q,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=G, P=:=0, 
          new8(s(A,B,C,D,E,Q,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=G, P=:=0, 
          new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=1, 
          new7(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=B, P=:=0, 
          new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=C, P=:=0, 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=D, P=:=0, 
          new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new1 :- new2(s,d).
correct :- \+new1.
