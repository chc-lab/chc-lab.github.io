new15(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, O=:=P+Q, P=:=A, 
          Q=:=2, R=:=S+T, S=:=F, F>=0, T=:=1, 
          new7(s(O,B,C,D,E,R),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, O=:=A, 
          M=:=18446744073709551616+O, O+1=<0, N=:=P*Q, P=:=F, F>=0, Q=:=2, 
          R=:=S+T, S=:=A, T=:=2, U=:=V+W, V=:=F, F>=0, W=:=1, 
          new7(s(R,B,C,D,E,U),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, O=:=A, M=:=O, O>=0, N=:=P*Q, 
          P=:=F, F>=0, Q=:=2, R=:=S+T, S=:=A, T=:=2, U=:=V+W, V=:=F, F>=0, 
          W=:=1, new7(s(R,B,C,D,E,U),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, O=:=A, 
          M=:=18446744073709551616+O, O+1=<0, N=:=P*Q, P=:=F, F>=0, Q=:=2, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, O=:=A, 
          M=:=18446744073709551616+O, O+1=<0, N=:=P*Q, P=:=F, F>=0, Q=:=2, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, O=:=A, M=:=O, O>=0, N=:=P*Q, 
          P=:=F, F>=0, Q=:=2, new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, O=:=A, M=:=O, O>=0, N=:=P*Q, 
          P=:=F, F>=0, Q=:=2, new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=0, O=:=P+Q, P=:=A, 
          Q=:=2, R=:=S+T, S=:=F, F>=0, T=:=1, 
          new7(s(O,B,C,D,E,R),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, N>=0, O=:=M, M>=0, P=:=0, 
          new6(s(A,B,C,O,M,P),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, N>=0, O=:=M, M>=0, 
          new5(s(A,O,M,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, 
          new4(s(M,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
correct :- \+new1.
