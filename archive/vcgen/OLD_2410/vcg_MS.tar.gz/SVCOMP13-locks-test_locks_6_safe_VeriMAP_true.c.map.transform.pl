new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T>=U+1, T=:=R, U=:=1.
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T+1=<U, T=:=R, U=:=1.
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=1, O1=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,P1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=P, N1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=P, N1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=P, N1=:=0, 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T>=U+1, T=:=O, U=:=1.
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T+1=<U, T=:=O, U=:=1.
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=O, N1=:=1, O1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=0, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=0, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T>=U+1, T=:=L, U=:=1.
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T+1=<U, T=:=L, U=:=1.
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=L, N1=:=1, O1=:=0, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,O1,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=J, N1=:=0, 
          new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=J, N1=:=0, 
          new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=J, N1=:=0, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T>=U+1, T=:=I, U=:=1.
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T+1=<U, T=:=I, U=:=1.
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=I, N1=:=1, O1=:=0, 
          new34(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=G, N1=:=0, 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=G, N1=:=0, 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=G, N1=:=0, 
          new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T>=U+1, T=:=F, U=:=1.
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T+1=<U, T=:=F, U=:=1.
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=F, N1=:=1, O1=:=0, 
          new31(s(A,B,C,D,E,O1,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=D, N1=:=0, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=D, N1=:=0, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=D, N1=:=0, 
          new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T>=U+1, T=:=C, U=:=1.
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T+1=<U, T=:=C, U=:=1.
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=C, N1=:=1, O1=:=0, 
          new28(s(A,B,O1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=A, N1=:=0, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=A, N1=:=0, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=A, N1=:=0, 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=P, N1=:=0, O1=:=1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=P, N1=:=0, O1=:=1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=P, N1=:=0, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=0, O1=:=1, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=0, O1=:=1, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=0, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=J, N1=:=0, O1=:=1, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,O1,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=J, N1=:=0, O1=:=1, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,O1,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=J, N1=:=0, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=G, N1=:=0, O1=:=1, 
          new14(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=G, N1=:=0, O1=:=1, 
          new14(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=G, N1=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=D, N1=:=0, O1=:=1, 
          new11(s(A,B,C,D,E,O1,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=D, N1=:=0, O1=:=1, 
          new11(s(A,B,C,D,E,O1,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=D, N1=:=0, 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=A, N1=:=0, O1=:=1, 
          new8(s(A,B,O1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=A, N1=:=0, O1=:=1, 
          new8(s(A,B,O1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=A, N1=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=S, N1=:=0, O1=:=0, P1=:=0, Q1=:=0, R1=:=0, S1=:=0, 
          T1=:=0, 
          new6(s(A,B,O1,D,E,P1,G,H,Q1,J,K,R1,M,N,S1,P,Q,T1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=S, N1=:=0, O1=:=0, P1=:=0, Q1=:=0, R1=:=0, S1=:=0, 
          T1=:=0, 
          new6(s(A,B,O1,D,E,P1,G,H,Q1,J,K,R1,M,N,S1,P,Q,T1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=1, N1=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, O1=:=P1, Q1=:=R1, S1=:=T1, U1=:=V1, W1=:=X1, 
          new4(s(M1,N1,C,O1,P1,F,Q1,R1,I,S1,T1,L,U1,V1,O,W1,X1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new2(s,d) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new1 :- new2(s,d).
correct :- \+new1.
