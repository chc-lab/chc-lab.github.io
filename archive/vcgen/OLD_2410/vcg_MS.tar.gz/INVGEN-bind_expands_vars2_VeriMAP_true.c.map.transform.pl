new10(s(A,B,C,D,E),d(A,B,C,D,E)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=M+N, M=:=A, N=:=D, L=:=O*P, 
          O=:=E, P=:=2, Q=:=R+S, R=:=D, S=:=1, new7(s(A,B,C,Q,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=M+N, M=:=A, N=:=D, L=:=O*P, O=:=E, 
          P=:=2, new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=C, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=C, L=:=M-N, M=:=O*P, O=:=E, P=:=2, 
          N=:=B, Q=:=0, new7(s(A,B,C,Q,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=A, L=:=B, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=B, L=:=M*N, M=:=E, N=:=2, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, 
          new4(s(A,B,C,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
correct :- \+new1.
