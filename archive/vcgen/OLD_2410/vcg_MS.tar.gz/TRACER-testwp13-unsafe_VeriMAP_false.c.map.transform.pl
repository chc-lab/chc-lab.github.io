new8(s(A,B),d(A,B)).
new7(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=0, new8(s(A,B),d(C,D)).
new5(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=50, new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=H+I, H=:=B, I=:=1, 
          new5(s(A,G),d(C,D)).
new4(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=H-I, H=:=A, I=:=10, 
          new5(s(G,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=5, new4(s(A,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
correct :- \+new1.
