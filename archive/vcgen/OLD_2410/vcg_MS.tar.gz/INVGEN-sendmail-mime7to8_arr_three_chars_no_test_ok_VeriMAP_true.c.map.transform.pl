new32(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=I-J, I=:=B, J=:=1, K=:=0, 
          new4(s(A,B,K),d(D,E,F)).
new32(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=I-J, I=:=B, J=:=1, 
          new4(s(A,B,C),d(D,E,F)).
new30(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=B, I=:=J+K, J=:=C, K=:=1, 
          new32(s(A,B,I),d(D,E,F)).
new30(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=B, new10(s(A,B,C),d(D,E,F)).
new28(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=C, new30(s(A,B,C),d(D,E,F)).
new28(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=C, new10(s(A,B,C),d(D,E,F)).
new26(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=I-J, I=:=B, J=:=1, K=:=0, 
          new28(s(A,B,K),d(D,E,F)).
new26(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=I-J, I=:=B, J=:=1, 
          new28(s(A,B,C),d(D,E,F)).
new24(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=B, I=:=J+K, J=:=C, K=:=1, 
          new26(s(A,B,I),d(D,E,F)).
new24(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=B, new10(s(A,B,C),d(D,E,F)).
new22(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=C, new24(s(A,B,C),d(D,E,F)).
new22(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=C, new10(s(A,B,C),d(D,E,F)).
new20(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=I-J, I=:=B, J=:=1, K=:=0, 
          new22(s(A,B,K),d(D,E,F)).
new20(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=I-J, I=:=B, J=:=1, 
          new22(s(A,B,C),d(D,E,F)).
new18(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=B, I=:=J+K, J=:=C, K=:=1, 
          new20(s(A,B,I),d(D,E,F)).
new18(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=B, new10(s(A,B,C),d(D,E,F)).
new17(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=C, new18(s(A,B,C),d(D,E,F)).
new17(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=C, new10(s(A,B,C),d(D,E,F)).
new14(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, new7(s(A,B,C),d(D,E,F)).
new14(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, new7(s(A,B,C),d(D,E,F)).
new14(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=0, new17(s(A,B,C),d(D,E,F)).
new10(s(A,B,C),d(A,B,C)).
new9(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=B, new10(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=C, new9(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=C, new10(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new8(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=0, new14(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, new5(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, new5(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=0, new7(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=0, I=:=0, new4(s(A,B,I),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
