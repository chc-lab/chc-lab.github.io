new13(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=0, 
          new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=0, O=:=P-Q, P=:=D, 
          Q=:=1, R=:=S+T, S=:=F, T=:=1, U=:=V+W, V=:=O, W=:=R, 
          new10(s(A,U,C,O,E,R),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=0, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=0, O=:=P-Q, P=:=C, 
          Q=:=1, R=:=S+T, S=:=E, T=:=1, U=:=V+W, V=:=O, W=:=R, 
          new7(s(A,U,O,D,R,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=C, N=:=0, O=:=E, P=:=0, 
          Q=:=R+S, R=:=O, S=:=P, new10(s(A,Q,C,O,E,P),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=A, N=:=200, O=:=0, P=:=A, 
          Q=:=R+S, R=:=P, S=:=O, new7(s(A,Q,P,D,O,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=200, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=A, N=:=0, 
          new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
correct :- \+new1.
