new227(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W,X,Y)) :- 
          A1>=B1+1, A1=:=O, B1=:=M, Z=:=M.
new227(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W,X,Y)) :- 
          A1=<B1, A1=:=O, B1=:=M, Z=:=O.
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new140(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1),d(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new34(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new131(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new35(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new131(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new129(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new131(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=W, B2=:=0, 
          new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=W, B2=:=0, 
          new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=W, B2=:=0, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new129(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2)).
new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new131(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new129(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new131(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new132(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1),d(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new28(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new131(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new29(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new131(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=W, B2=:=0, 
          new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=W, B2=:=0, 
          new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=W, B2=:=0, 
          new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new129(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new131(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=N, T1=:=0, U1=:=0, V1=:=0, 
          new173(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V1,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=N, T1=:=0, U1=:=0, V1=:=1, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,V1,O,P,Q,R,S,T,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=N, T1=:=0, U1=:=0, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=N, T1=:=0, U1=:=0, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=I, T1=:=G, 
          new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1, S1=:=I, T1=:=G, U1=:=0, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=N, T1=:=0, U1=:=0, V1=:=1, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,V1,O,P,Q,R,S,U1,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=N, T1=:=0, U1=:=0, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=N, T1=:=0, U1=:=0, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=I, T1=:=G, 
          new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=<T1, S1=:=I, T1=:=G, 
          new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=B, T1=:=0, U1=:=1, V1=:=1, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V1,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=B, T1=:=0, U1=:=1, V1=:=1, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V1,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=B, T1=:=0, U1=:=0, V1=:=0, W1=:=1, 
          new182(s(A,W1,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V1,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=C, T1=:=0, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=C, T1=:=0, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=C, T1=:=0, 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=D, T1=:=0, 
          new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=D, T1=:=0, 
          new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=D, T1=:=0, 
          new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=I, X1=:=G, Y1=:=1, Z1=:=0, A2=:=1, B2=:=1, C2=:=1, 
          new158(s(A,B,Y1,Z1,A2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C2,B2,V,W,D2),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=<X1, W1=:=I, X1=:=G, Y1=:=1, Z1=:=0, A2=:=1, B2=:=1, C2=:=1, 
          new158(s(A,B,Y1,Z1,A2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C2,B2,V,W,D2),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=Z, B2=:=0, C2=:=T, 
          new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,D2,E2,C2,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=Z, B2=:=0, C2=:=T, 
          new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,D2,E2,C2,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=T, B2=:=1, C2=:=D2+E2, D2=:=V, E2=:=1, 
          new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,F2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=T, B2=:=1, C2=:=0, 
          new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,D2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=T, B2=:=1, C2=:=0, 
          new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,D2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=Y, B2=:=1, 
          new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=Y, B2=:=1, C2=:=0, 
          new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,D2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=Y, B2=:=1, C2=:=0, 
          new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,D2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new129(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new147(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=U, X1=:=0, Y1=:=1, Z1=:=1, A2=:=B2-C2, B2=:=D2, C2=:=Q, 
          E2=:=0, F2=:=1, G2=:=1, 
          new156(s(Z1,B,Y1,D,E2,F,G,H,I,J,K,L,M,N,O,P,Q,A2,S,G2,F2,V,D2,H2),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new140(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1),d(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new34(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new143(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new35(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new143(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new129(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new139(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=T, X1=:=0, Y1=:=Z1-A2, Z1=:=B2, A2=:=P, C2=:=D2-E2, 
          D2=:=F2, E2=:=L, G2=:=H2-I2, H2=:=F2, I2=:=C2, 
          new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F2,G2,C2,R,Y1,T,U,V,B2,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new132(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1),d(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new28(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new135(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new29(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new135(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=E, T1=:=0, 
          new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=E, T1=:=0, 
          new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=E, T1=:=0, 
          new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new129(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2)).
new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new131(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new140(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1),d(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new34(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new131(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new35(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new131(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=X, B2=:=0, 
          new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=X, B2=:=0, 
          new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=X, B2=:=0, 
          new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=A, B1=:=B, C1=:=C, D1=:=D, E1=:=E, F1=:=F, G1=:=G, H1=:=H, 
          I1=:=I, J1=:=J, K1=:=K, L1=:=L, M1=:=M, N1=:=N, O1=:=O, P1=:=P, 
          Q1=:=Q, R1=:=R, S1=:=S, T1=:=T, U1=:=U, V1=:=V, 
          new132(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1),d(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new28(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new131(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new29(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new131(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=W, B2=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=W, B2=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=W, B2=:=0, 
          new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=T, B2=:=0, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=T, B2=:=0, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=T, B2=:=0, 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=U, B2=:=0, 
          new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=U, B2=:=0, 
          new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=U, B2=:=0, 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=U, B2=:=0, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=U, B2=:=0, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=U, B2=:=0, 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=T, B2=:=0, 
          new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=T, B2=:=0, 
          new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=T, B2=:=0, 
          new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=1, B2=:=0, C2=:=T, 
          new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,D2,E2,C2,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new34(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new27(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new35(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new27(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new27(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=W, B2=:=0, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=W, B2=:=0, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=W, B2=:=0, 
          new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new27(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new27(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new28(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new27(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new29(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new27(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=W, B2=:=0, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=W, B2=:=0, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=W, B2=:=0, 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new27(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V)) :- 
          W>=X+1, W=:=C, X=:=0.
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V)) :- 
          W+1=<X, W=:=C, X=:=0.
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V)) :- 
          W=:=X, W=:=C, X=:=0.
new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,B,X,Y,Z,F,G,H,I,J,K,L,M,N,O,P,Q,A1,S,T,U,V)) :- 
          B1>=C1+1, B1=:=C, C1=:=0, Z=:=0, W=:=1, X=:=0, Y=:=0, A1=:=Q.
new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,B,X,Y,Z,F,G,H,I,J,K,L,M,N,O,P,Q,A1,S,T,U,V)) :- 
          B1+1=<C1, B1=:=C, C1=:=0, Z=:=0, W=:=1, X=:=0, Y=:=0, A1=:=Q.
new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,B,X,Y,Z,F,G,H,I,J,K,L,M,N,O,P,Q,A1,S,T,U,V)) :- 
          B1=:=C1, B1=:=C, C1=:=0, Z=:=0, W=:=1, X=:=0, Y=:=0, A1=:=Q.
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,W,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V)) :- 
          Y>=Z+1, Y=:=C, Z=:=0, W=:=1, X=:=1.
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,W,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V)) :- 
          Y+1=<Z, Y=:=C, Z=:=0, W=:=1, X=:=1.
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,W,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V)) :- 
          Y=:=Z, Y=:=C, Z=:=0, W=:=1, X=:=1.
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V)) :- 
          W>=X+1, W=:=N, X=:=0.
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V)) :- 
          W+1=<X, W=:=N, X=:=0.
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=N, T1=:=0, U1=:=0, V1=:=0, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V1,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=N, T1=:=0, U1=:=0, V1=:=1, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,V1,O,P,Q,R,S,T,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=N, T1=:=0, U1=:=0, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=N, T1=:=0, U1=:=0, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=I, T1=:=G, 
          new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1, S1=:=I, T1=:=G, U1=:=0, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=N, T1=:=0, U1=:=0, V1=:=1, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,V1,O,P,Q,R,S,U1,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=N, T1=:=0, U1=:=0, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=N, T1=:=0, U1=:=0, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=I, T1=:=G, 
          new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=<T1, S1=:=I, T1=:=G, 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=B, T1=:=0, U1=:=1, V1=:=1, 
          new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V1,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=B, T1=:=0, U1=:=1, V1=:=1, 
          new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V1,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=B, T1=:=0, U1=:=0, V1=:=0, W1=:=1, 
          new78(s(A,W1,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V1,U1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,U,V)) :- 
          Y>=Z+1, Y=:=A, Z=:=0, W=:=0, X=:=0.
new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,U,V)) :- 
          Y+1=<Z, Y=:=A, Z=:=0, W=:=0, X=:=0.
new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,B,W,X,Y,F,G,H,I,J,K,L,M,N,Z,A1,B1,R,C1,D1,U,V)) :- 
          E1=:=F1, E1=:=A, F1=:=0, D1=:=1, X=:=0, Y=:=1, W=:=0, C1=:=P, 
          B1=:=G1-H1, G1=:=Z, H1=:=L, A1=:=I1-J1, I1=:=Z, J1=:=B1.
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,U,V)) :- 
          Y>=Z+1, Y=:=A, Z=:=0, W=:=0, X=:=0.
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,U,V)) :- 
          Y+1=<Z, Y=:=A, Z=:=0, W=:=0, X=:=0.
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(A,B,W,X,Y,F,G,H,I,J,K,L,M,N,Z,A1,B1,R,C1,D1,U,V)) :- 
          E1=:=F1, E1=:=A, F1=:=0, D1=:=1, W=:=0, X=:=0, Y=:=1, C1=:=P, 
          B1=:=G1-H1, G1=:=Z, H1=:=L, A1=:=I1-J1, I1=:=Z, J1=:=B1.
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=C, T1=:=0, 
          new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=C, T1=:=0, 
          new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=C, T1=:=0, 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=D, T1=:=0, 
          new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=D, T1=:=0, 
          new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=D, T1=:=0, 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=I, X1=:=G, Y1=:=1, Z1=:=0, A2=:=1, B2=:=1, C2=:=1, 
          new54(s(A,B,Y1,Z1,A2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C2,B2,V,W,D2),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=<X1, W1=:=I, X1=:=G, Y1=:=1, Z1=:=0, A2=:=1, B2=:=1, C2=:=1, 
          new54(s(A,B,Y1,Z1,A2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C2,B2,V,W,D2),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y>=Z+1, Y=:=X, Z=:=0.
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y+1=<Z, Y=:=X, Z=:=0.
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y=:=Z, Y=:=X, Z=:=0.
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=I, X1=:=G, Y1=:=1, Z1=:=0, A2=:=1, B2=:=1, C2=:=1, 
          new51(s(A,B,Y1,Z1,A2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C2,B2,V,W,D2),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=<X1, W1=:=I, X1=:=G, Y1=:=1, Z1=:=0, A2=:=1, B2=:=1, C2=:=1, 
          new51(s(A,B,Y1,Z1,A2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C2,B2,V,W,D2),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y>=Z+1, Y=:=X, Z=:=0.
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y+1=<Z, Y=:=X, Z=:=0.
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y=:=Z, Y=:=X, Z=:=0.
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          A1=:=B1, A1=:=Z, B1=:=0.
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=Z, B2=:=0, C2=:=T, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,D2,E2,C2,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=Z, B2=:=0, C2=:=T, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,D2,E2,C2,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=T, B2=:=1, C2=:=D2+E2, D2=:=V, E2=:=1, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,F2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=T, B2=:=1, C2=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,D2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=T, B2=:=1, C2=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,D2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=Y, B2=:=1, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=Y, B2=:=1, C2=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,D2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=Y, B2=:=1, C2=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C2,W,X,Y,D2),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=U, X1=:=0, Y1=:=1, Z1=:=1, A2=:=B2-C2, B2=:=D2, C2=:=Q, 
          E2=:=0, F2=:=1, G2=:=1, 
          new48(s(Z1,B,Y1,D,E2,F,G,H,I,J,K,L,M,N,O,P,Q,A2,S,G2,F2,V,D2,H2),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new39(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y>=Z+1, Y=:=U, Z=:=0.
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y+1=<Z, Y=:=U, Z=:=0.
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=U, X1=:=0, Y1=:=1, Z1=:=1, A2=:=B2-C2, B2=:=D2, C2=:=Q, 
          E2=:=0, F2=:=1, G2=:=1, 
          new49(s(Z1,B,Y1,D,E2,F,G,H,I,J,K,L,M,N,O,P,Q,A2,S,G2,F2,V,D2,H2),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new34(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new36(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new35(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new36(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=T, X1=:=0, Y1=:=Z1-A2, Z1=:=B2, A2=:=P, C2=:=D2-E2, 
          D2=:=F2, E2=:=L, G2=:=H2-I2, H2=:=F2, I2=:=C2, 
          new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F2,G2,C2,R,Y1,T,U,V,B2,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new33(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y>=Z+1, Y=:=T, Z=:=0.
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y+1=<Z, Y=:=T, Z=:=0.
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=T, X1=:=0, Y1=:=Z1-A2, Z1=:=B2, A2=:=P, C2=:=D2-E2, 
          D2=:=F2, E2=:=L, G2=:=H2-I2, H2=:=F2, I2=:=C2, 
          new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F2,G2,C2,R,Y1,T,U,V,B2,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new28(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new30(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new29(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new30(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=E, T1=:=0, 
          new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=E, T1=:=0, 
          new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=E, T1=:=0, 
          new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new26(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2),d(Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,X2)), 
          new27(s(T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new34(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new27(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new35(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new27(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=X, B2=:=0, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=X, B2=:=0, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=X, B2=:=0, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new28(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new27(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, F2=:=F, G2=:=G, H2=:=H, 
          I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, N2=:=N, O2=:=O, P2=:=P, 
          Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, V2=:=V, W2=:=X2, 
          new29(s(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,Y2,Z2),d(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,X2,V3,W3)), 
          new27(s(X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,W2,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=W, B2=:=0, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=W, B2=:=0, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=W, B2=:=0, 
          new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=T, B2=:=0, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=T, B2=:=0, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=T, B2=:=0, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=U, B2=:=0, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=U, B2=:=0, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=U, B2=:=0, 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=U, B2=:=0, 
          new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=U, B2=:=0, 
          new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=U, B2=:=0, 
          new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=T, B2=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2+1=<B2, A2=:=T, B2=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2=:=B2, A2=:=T, B2=:=0, 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          A2>=B2+1, A2=:=1, B2=:=0, C2=:=T, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,D2,E2,C2,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)) :- 
          E2>=F2+1, E2=:=B1, F2=:=2, 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)) :- 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=A, D1=:=B, E1=:=C, F1=:=D, G1=:=E, H1=:=F, I1=:=G, J1=:=H, 
          K1=:=I, L1=:=J, M1=:=K, N1=:=L, O1=:=M, P1=:=N, Q1=:=O, R1=:=P, 
          S1=:=Q, T1=:=R, U1=:=S, V1=:=Z, W1=:=A1, X1=:=B1, 
          new8(s(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2),d(C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)) :- 
          E2=:=A, F2=:=B, G2=:=C, H2=:=D, I2=:=E, J2=:=F, K2=:=G, L2=:=H, 
          M2=:=I, N2=:=J, O2=:=K, P2=:=L, Q2=:=M, R2=:=N, S2=:=O, T2=:=P, 
          U2=:=Q, V2=:=R, W2=:=S, X2=:=Z, Y2=:=A1, Z2=:=B1, A3=:=B3, 
          new9(s(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,C3,D3,E3,F3),d(G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B3,B4,C4,D4,E4)), 
          new10(s(F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,T,U,V,W,X,Y,Y4,Z4,A3),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)) :- 
          Y1=:=A, Z1=:=A, A2=:=R, B2=:=R, C2=:=D2-E2, D2=:=A, E2=:=R, 
          F2=:=G2-H2, G2=:=A, H2=:=R, I2=:=B, J2=:=C, K2=:=L2-M2, L2=:=I2, 
          M2=:=J2, N2=:=D, O2=:=E, P2=:=F, 
          new227(s(A,B,C,D,E,F,G,H,I,J,K,Y1,O2,N2,P2,I2,J2,K2,S,T,Z1,A2,C2,F2,B2),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)) :- 
          Y1=:=A, Z1=:=A, A2=:=R, B2=:=R, C2=:=D2-E2, D2=:=A, E2=:=R, 
          F2=:=G2-H2, G2=:=A, H2=:=R, I2=:=B, J2=:=C, K2=:=L2-M2, L2=:=I2, 
          M2=:=J2, N2=:=D, O2=:=E, P2=:=F, 
          new228(s(A,B,C,D,E,F,G,H,I,J,K,Y1,O2,N2,P2,I2,J2,K2,S,T,Z1,A2,C2,F2,B2),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=T, D1=:=U, E1=:=V, F1=:=W, G1=:=X, H1=:=Y, I1=:=A, J1=:=B, 
          K1=:=C, L1=:=D, M1=:=E, N1=:=F, O1=:=G, P1=:=H, Q1=:=I, R1=:=J, 
          S1=:=K, T1=:=L, U1=:=M, V1=:=N, W1=:=O, X1=:=P, Y1=:=Q, Z1=:=R, 
          A2=:=S, 
          new5(s(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2),d(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)) :- 
          E2=:=T, F2=:=U, G2=:=V, H2=:=W, I2=:=X, J2=:=Y, K2=:=A, L2=:=B, 
          M2=:=C, N2=:=D, O2=:=E, P2=:=F, Q2=:=G, R2=:=H, S2=:=I, T2=:=J, 
          U2=:=K, V2=:=L, W2=:=M, X2=:=N, Y2=:=O, Z2=:=P, A3=:=Q, B3=:=R, 
          C3=:=S, 
          new6(s(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3),d(D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4)), 
          new7(s(C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,T,U,V,W,X,Y,Z,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)) :- 
          E2=:=0, F2=:=0, G2=:=0, H2=:=1, I2=:=0, J2=:=0, K2=:=0, L2=:=0, 
          M2=:=0, 
          new4(s(G2,F2,E2,I2,H2,F,G,H,I,J,K,L,M,J2,O,P,Q,R,S,T,U,V,W,X,Y,K2,L2,M2),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)).
new2(s,d) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)).
new1 :- new2(s,d).
correct :- \+new1.
