new9(s(A,B,C),d(A,B,C)).
new8(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=I-J, I=:=K-L, K=:=A, L=:=1, J=:=B, 
          H=:=A, M=:=N+O, N=:=C, O=:=1, new5(s(A,B,M),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G>=H, G=:=I-J, I=:=K-L, K=:=A, L=:=1, J=:=B, H=:=A, 
          new9(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=I-J, I=:=K-L, K=:=A, L=:=1, J=:=B, 
          new8(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=I-J, I=:=K-L, K=:=A, L=:=1, 
          J=:=B, new9(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=8, new6(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=8, I=:=J+K, J=:=B, K=:=1, 
          new4(s(A,I,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, I=:=0, new5(s(A,B,I),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, new4(s(A,G,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
