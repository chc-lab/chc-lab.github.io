new14(s(A,B,C,D),d(A,B,C,D)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=7, 
          new14(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=L+M, L=:=A, M=:=4, 
          new11(s(K,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=0, K=:=L+M, L=:=A, M=:=4, 
          new11(s(K,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=D, J=:=0, 
          new11(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=0, K=:=L+M, L=:=A, M=:=2, 
          new8(s(K,B,C,N),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=0, K=:=L+M, L=:=A, M=:=2, 
          new8(s(K,B,C,N),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=C, J=:=0, new8(s(A,B,C,K),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new5(s(K,B,N,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new5(s(K,B,N,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=B, J=:=0, new5(s(A,B,K,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, new4(s(I,J,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
