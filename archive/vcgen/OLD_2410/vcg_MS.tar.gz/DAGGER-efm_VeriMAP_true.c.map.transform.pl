new50(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=D, X=:=1, 
          Y=:=Z-A1, Z=:=A, A1=:=1, B1=:=C1-D1, C1=:=D, D1=:=1, E1=:=F1+G1, 
          F1=:=B, G1=:=1, H1=:=I1+J1, I1=:=E, J1=:=1, 
          new9(s(Y,E1,C,B1,H1,F,G,H,I,J,K1),d(L,M,N,O,P,Q,R,S,T,U,V)).
new48(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=F, X=:=1, 
          Y=:=Z-A1, Z=:=B, A1=:=1, B1=:=C1+D1, C1=:=C, D1=:=1, 
          new9(s(A,Y,B1,D,E,F,G,H,I,J,E1),d(L,M,N,O,P,Q,R,S,T,U,V)).
new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=C, X=:=1, 
          Y=:=Z-A1, Z=:=C, A1=:=1, B1=:=C1+D1, C1=:=B, D1=:=1, 
          new9(s(A,B1,Y,D,E,F,G,H,I,J,E1),d(L,M,N,O,P,Q,R,S,T,U,V)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=B, X=:=1, 
          Y=:=Z-A1, Z=:=B, A1=:=1, B1=:=C1+D1, C1=:=A, D1=:=1, E1=:=F1+G1, 
          F1=:=D, G1=:=F, H1=:=0, 
          new9(s(B1,Y,C,E1,E,H1,G,H,I,J,I1),d(L,M,N,O,P,Q,R,S,T,U,V)).
new41(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=C, X=:=1, 
          Y=:=Z-A1, Z=:=C, A1=:=1, B1=:=C1+D1, C1=:=A, D1=:=1, E1=:=F1+G1, 
          F1=:=F, G1=:=E, H1=:=0, 
          new9(s(B1,B,Y,D,H1,E1,G,H,I,J,I1),d(L,M,N,O,P,Q,R,S,T,U,V)).
new40(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=G, 
          X=:=0, new41(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new40(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=G, 
          X=:=0, new41(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new40(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=G, 
          X=:=0, new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new38(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=D, X=:=1, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=H, 
          X=:=0, new38(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=H, 
          X=:=0, new38(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=H, 
          X=:=0, new40(s(A,B,C,D,E,F,Y,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new35(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=B, X=:=1, 
          new48(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new34(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=I, 
          X=:=0, new35(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new34(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=I, 
          X=:=0, new35(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new34(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=I, 
          X=:=0, new37(s(A,B,C,D,E,F,G,Y,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new32(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=A, X=:=1, 
          new50(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new29(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y+Z, 
          Y=:=A1+B1, A1=:=A, B1=:=B, Z=:=C, X=:=1, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=Y+Z, 
          Y=:=A, Z=:=B, X=:=A1+B1, A1=:=D, B1=:=E, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y+Z, 
          Y=:=A, Z=:=B, X=:=A1+B1, A1=:=D, B1=:=E, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=Y+Z, 
          Y=:=A, Z=:=E, X=:=1, 
          new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y+Z, 
          Y=:=A, Z=:=E, X=:=1, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new23(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=B, X=:=0, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new23(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=B, 
          X=:=0, new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=C, X=:=0, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=C, 
          X=:=0, new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=D, X=:=0, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=D, 
          X=:=0, new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new17(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=E, X=:=0, 
          new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new17(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=E, 
          X=:=0, new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=<X, W=:=Y+Z, 
          Y=:=D, Z=:=E, X=:=1, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y+Z, 
          Y=:=D, Z=:=E, X=:=1, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)).
new13(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=<X, W=:=Y-Z, 
          Y=:=A1+B1, A1=:=C1+D1, C1=:=D, D1=:=E, B1=:=F, Z=:=1, X=:=0, 
          new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new13(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y-Z, 
          Y=:=A1+B1, A1=:=C1+D1, C1=:=D, D1=:=E, B1=:=F, Z=:=1, X=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=Y-Z, 
          Y=:=A1+B1, A1=:=C1+D1, C1=:=D, D1=:=E, B1=:=F, Z=:=1, X=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y-Z, 
          Y=:=A1+B1, A1=:=C1+D1, C1=:=D, D1=:=E, B1=:=F, Z=:=1, X=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, new32(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, new32(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, new34(s(A,B,C,D,E,F,G,H,Y,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new9(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=K, 
          X=:=0, new10(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new9(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=K, 
          X=:=0, new10(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new9(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=K, X=:=0, 
          new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new8(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=F, X=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,Y),d(L,M,N,O,P,Q,R,S,T,U,V)).
new7(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=E, X=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new6(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=D, X=:=1, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new5(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=C, X=:=0, 
          new6(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new4(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=B, X=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=A, X=:=1, 
          new4(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new1 :- new2(s,d).
correct :- \+new1.
