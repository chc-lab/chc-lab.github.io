new12(s(A,B,C),d(A,B,C)).
new11(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, new12(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(A,B,C)) :- D>=E, D=:=A, E=:=0.
new9(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, new10(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,B,E)) :- F+1=<G, F=:=B, G=:=0, E=:=2, D=:=1.
new7(s(A,B,C),d(D,E,F)) :- G>=H, G=:=B, H=:=0, I=:=1, new9(s(A,B,I),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H, G=:=B, H=:=0, I=:=1, new11(s(A,B,I),d(D,E,F)).
new5(s(A,B,C),d(D,B,C)) :- E=:=C, new6(s(A,E,F),d(D,G,H)).
new5(s(A,B,C),d(D,E,F)) :- G=:=C, H=:=I+J, I=:=B, J=:=1, 
          new7(s(A,G,K),d(L,M,N)), new4(s(L,H,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=10, new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=0, new4(s(G,H,C),d(D,E,F)).
new2(s(A),d(B)) :- new3(s(A,C,D),d(B,E,F)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
