new7(s(A,B,C),d(A,B,C)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=2, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=1, I=:=2, J=:=K+L, K=:=B, L=:=1, 
          new4(s(A,J,I),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=1, I=:=1, J=:=K+L, K=:=B, L=:=1, 
          new4(s(A,J,I),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=1, I=:=1, J=:=K+L, K=:=B, L=:=1, 
          new4(s(A,J,I),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, new5(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H, G=:=B, H=:=A, new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=1, H=:=0, new4(s(A,H,G),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
