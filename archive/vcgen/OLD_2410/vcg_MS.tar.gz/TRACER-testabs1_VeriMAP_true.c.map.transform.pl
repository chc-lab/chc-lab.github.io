new6(s(A,B,C),d(A,B,C)).
new4(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=0, new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, I=:=4, J=:=1, 
          new4(s(I,J,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=<H, G=:=C, H=:=0, I=:=100, J=:=2, 
          new4(s(I,J,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
