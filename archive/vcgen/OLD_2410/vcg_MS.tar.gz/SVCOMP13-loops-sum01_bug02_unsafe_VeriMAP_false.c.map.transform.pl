new10(s(A,B,C,D,E),d(A,B,C,D,E)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=M*N, M=:=C, N=:=2, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=M*N, M=:=C, N=:=2, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=B, M=:=N+O, N=:=E, O=:=2, 
          P=:=Q-R, Q=:=B, R=:=1, S=:=T+U, T=:=A, U=:=1, 
          new5(s(S,P,C,D,M),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=B, M=:=N-O, N=:=B, O=:=1, 
          P=:=Q+R, Q=:=A, R=:=1, new5(s(P,M,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=A, L=:=C, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=C, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, L>=0, M=:=K, K>=0, N=:=0, O=:=1, 
          new5(s(O,B,M,K,N),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=10, new4(s(A,K,C,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
correct :- \+new1.
