new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=G, R=:=0, S=:=T+U, 
          T=:=A, U=:=1, new8(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=G, R=:=0, S=:=T+U, 
          T=:=A, U=:=1, new8(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=G, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, V=:=W-X, W=:=E, X=:=1, 
          new8(s(S,B,C,D,V,F,G,H),d(I,J,K,L,M,N,O,P)).
new13(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)).
new12(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=E, R=:=100, 
          new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=A, R=:=100, 
          new12(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=100, R=:=E, S=:=T, 
          new14(s(A,B,C,D,E,F,S,T),d(I,J,K,L,M,N,O,P)).
new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=100, R=:=E, 
          new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=A, R=:=100, 
          new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=A, R=:=100, 
          new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=E, R=:=100, 
          new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=E, R=:=100, 
          new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=A, R=:=100, 
          new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=A, R=:=100, 
          new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, S=:=T, U=:=V, 
          new4(s(Q,R,S,T,U,V,G,H),d(I,J,K,L,M,N,O,P)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new1 :- new2(s,d).
correct :- \+new1.
