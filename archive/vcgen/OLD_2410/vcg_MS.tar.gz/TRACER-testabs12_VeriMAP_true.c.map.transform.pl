new10(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=0, new9(s(A,B),d(C,D)).
new9(s(A,B),d(A,B)).
new8(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=100, new9(s(A,B),d(C,D)).
new8(s(A,B),d(C,D)) :- E=<F, E=:=A, F=:=100, new10(s(A,B),d(C,D)).
new5(s(A,B),d(C,D)) :- new5(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=100, G=:=H+I, H=:=B, I=:=1, J=:=K+L, 
          K=:=A, L=:=1, new4(s(J,G),d(C,D)).
new4(s(A,B),d(C,D)) :- E>=F, E=:=A, F=:=100, new8(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E>=F, E=:=B, F=:=0, G=:=0, new4(s(G,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=0, new5(s(A,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
correct :- \+new1.
