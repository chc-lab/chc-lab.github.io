new386(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=K, N1=:=1, O1=:=0, 
          new389(s(A,B,C,D,E,F,O1,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new386(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=K, N1=:=1, O1=:=2, 
          new389(s(A,B,C,D,E,F,O1,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new386(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=K, N1=:=1, O1=:=2, 
          new389(s(A,B,C,D,E,F,O1,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new383(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=J, N1=:=1, O1=:=0, 
          new386(s(A,B,C,D,E,O1,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new383(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=J, N1=:=1, O1=:=2, 
          new386(s(A,B,C,D,E,O1,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new383(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=J, N1=:=1, O1=:=2, 
          new386(s(A,B,C,D,E,O1,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new380(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,T,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          U=:=V, U=:=L, V=:=1, T=:=0.
new380(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,T,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          U>=V+1, U=:=L, V=:=1, T=:=2.
new380(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,T,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          U+1=<V, U=:=L, V=:=1, T=:=2.
new377(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=K, N1=:=1, O1=:=0, 
          new380(s(A,B,C,D,E,F,O1,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new377(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=K, N1=:=1, O1=:=2, 
          new380(s(A,B,C,D,E,F,O1,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new377(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=K, N1=:=1, O1=:=2, 
          new380(s(A,B,C,D,E,F,O1,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new374(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=J, N1=:=1, O1=:=0, 
          new377(s(A,B,C,D,E,O1,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new374(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=J, N1=:=1, O1=:=2, 
          new377(s(A,B,C,D,E,O1,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new374(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=J, N1=:=1, O1=:=2, 
          new377(s(A,B,C,D,E,O1,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new368(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, O1=:=1, 
          new371(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new368(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, 
          new371(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new368(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, 
          new371(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new365(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=0, O1=:=1, 
          new368(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new365(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=0, 
          new368(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new365(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=0, 
          new368(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new362(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=P, N1=:=0, O1=:=1, 
          new365(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new362(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=P, N1=:=0, 
          new365(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new362(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=P, N1=:=0, 
          new365(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new359(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=O, N1=:=0, O1=:=1, 
          new362(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new359(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=O, N1=:=0, 
          new362(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new359(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=O, N1=:=0, 
          new362(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new356(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=N, N1=:=0, O1=:=1, 
          new359(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new356(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=N, N1=:=0, 
          new359(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new356(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=N, N1=:=0, 
          new359(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,T)) :- 
          U=:=V, U=:=S, V=:=0, T=:=1.
new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T>=U+1, T=:=S, U=:=0.
new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T+1=<U, T=:=S, U=:=0.
new350(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, O1=:=1, 
          new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new350(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, 
          new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new350(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, 
          new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=0, O1=:=1, 
          new350(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=0, 
          new350(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=0, 
          new350(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new344(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=P, N1=:=0, O1=:=1, 
          new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new344(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=P, N1=:=0, 
          new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new344(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=P, N1=:=0, 
          new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new341(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=O, N1=:=0, O1=:=1, 
          new344(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new341(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=O, N1=:=0, 
          new344(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new341(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=O, N1=:=0, 
          new344(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new338(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=N, N1=:=0, O1=:=1, 
          new341(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new338(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=N, N1=:=0, 
          new341(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new338(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=N, N1=:=0, 
          new341(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new331(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=D, P1=:=1, 
          new334(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new328(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,T,U,V,W)) :- 
          new331(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Q1),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,R1)).
new328(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, 
          new307(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W1),d(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,V1)), 
          new333(s(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,T,U,V,U1),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new327(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1>=V1+1, U1=:=V, V1=:=0, W1=:=0, 
          new328(s(A,B,C,D,E,F,W1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new327(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1+1=<V1, U1=:=V, V1=:=0, W1=:=0, 
          new328(s(A,B,C,D,E,F,W1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new327(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, U1=:=V, V1=:=0, 
          new328(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new325(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=C, P1=:=1, 
          new335(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new322(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,T,U,V,W)) :- 
          new325(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Q1),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,R1)).
new322(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, 
          new302(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W1),d(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,V1)), 
          new327(s(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,T,U,U1,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1>=V1+1, U1=:=U, V1=:=0, W1=:=0, 
          new322(s(A,B,C,D,E,W1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1+1=<V1, U1=:=U, V1=:=0, W1=:=0, 
          new322(s(A,B,C,D,E,W1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, U1=:=U, V1=:=0, 
          new322(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new319(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=B, P1=:=1, 
          new336(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new316(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,T,U,V,W)) :- 
          new319(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Q1),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,R1)).
new316(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, 
          new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W1),d(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,V1)), 
          new321(s(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,T,U1,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new315(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1>=V1+1, U1=:=T, V1=:=0, W1=:=0, 
          new316(s(A,B,C,D,W1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new315(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1+1=<V1, U1=:=T, V1=:=0, W1=:=0, 
          new316(s(A,B,C,D,W1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new315(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, U1=:=T, V1=:=0, 
          new316(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new313(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=A, P1=:=1, 
          new337(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new312(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V=:=W, V=:=M, W=:=1, U=:=1.
new312(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V>=W+1, V=:=M, W=:=1, U=:=0.
new312(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V+1=<W, V=:=M, W=:=1, U=:=0.
new311(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V=:=W, V=:=Q, W=:=1, U=:=1.
new311(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V>=W+1, V=:=Q, W=:=1, U=:=0.
new311(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V+1=<W, V=:=Q, W=:=1, U=:=0.
new310(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V=:=W, V=:=R, W=:=1, U=:=1.
new310(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V>=W+1, V=:=R, W=:=1, U=:=0.
new310(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V+1=<W, V=:=R, W=:=1, U=:=0.
new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V=:=W, V=:=S, W=:=1, U=:=1.
new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V>=W+1, V=:=S, W=:=1, U=:=0.
new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V+1=<W, V=:=S, W=:=1, U=:=0.
new308(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(A,B,C,D,E,F,G,X,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W)) :- 
          Y>=Z+1, Y=:=W, Z=:=0, X=:=0.
new308(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(A,B,C,D,E,F,G,X,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W)) :- 
          Y+1=<Z, Y=:=W, Z=:=0, X=:=0.
new308(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W)) :- 
          X=:=Y, X=:=W, Y=:=0.
new307(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V>=W+1, V=:=D, W=:=1, U=:=0.
new307(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V+1=<W, V=:=D, W=:=1, U=:=0.
new307(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=D, P1=:=1, 
          new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new304(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, 
          new307(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W1),d(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,V1)), 
          new308(s(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,T,U,V,U1),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1>=V1+1, U1=:=V, V1=:=0, W1=:=0, 
          new304(s(A,B,C,D,E,F,W1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1+1=<V1, U1=:=V, V1=:=0, W1=:=0, 
          new304(s(A,B,C,D,E,F,W1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, U1=:=V, V1=:=0, 
          new304(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new302(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V>=W+1, V=:=C, W=:=1, U=:=0.
new302(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V+1=<W, V=:=C, W=:=1, U=:=0.
new302(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=C, P1=:=1, 
          new310(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new299(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, 
          new302(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W1),d(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,V1)), 
          new303(s(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,T,U,U1,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new298(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1>=V1+1, U1=:=U, V1=:=0, W1=:=0, 
          new299(s(A,B,C,D,E,W1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new298(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1+1=<V1, U1=:=U, V1=:=0, W1=:=0, 
          new299(s(A,B,C,D,E,W1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new298(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, U1=:=U, V1=:=0, 
          new299(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V>=W+1, V=:=B, W=:=1, U=:=0.
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V+1=<W, V=:=B, W=:=1, U=:=0.
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=B, P1=:=1, 
          new311(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, 
          new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W1),d(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,V1)), 
          new298(s(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,T,U1,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1>=V1+1, U1=:=T, V1=:=0, W1=:=0, 
          new294(s(A,B,C,D,W1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1+1=<V1, U1=:=T, V1=:=0, W1=:=0, 
          new294(s(A,B,C,D,W1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, U1=:=T, V1=:=0, 
          new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new292(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V>=W+1, V=:=A, W=:=1, U=:=0.
new292(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V+1=<W, V=:=A, W=:=1, U=:=0.
new292(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=A, P1=:=1, 
          new312(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new286(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=1, O1=:=2, 
          new289(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new286(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=1, 
          new289(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new286(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=1, 
          new289(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=1, O1=:=2, 
          new286(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=1, 
          new286(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=1, 
          new286(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=P, N1=:=1, O1=:=2, 
          new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=P, N1=:=1, 
          new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=P, N1=:=1, 
          new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=O, N1=:=1, O1=:=2, 
          new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=O, N1=:=1, 
          new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=O, N1=:=1, 
          new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=N, N1=:=1, O1=:=2, 
          new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=N, N1=:=1, 
          new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=N, N1=:=1, 
          new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,T)) :- 
          U=:=V, U=:=S, V=:=1, T=:=2.
new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T>=U+1, T=:=S, U=:=1.
new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T+1=<U, T=:=S, U=:=1.
new268(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=1, O1=:=2, 
          new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new268(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=1, 
          new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new268(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=1, 
          new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=1, O1=:=2, 
          new268(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=1, 
          new268(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=1, 
          new268(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=P, N1=:=1, O1=:=2, 
          new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=P, N1=:=1, 
          new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=P, N1=:=1, 
          new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=O, N1=:=1, O1=:=2, 
          new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=O, N1=:=1, 
          new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=O, N1=:=1, 
          new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new256(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=N, N1=:=1, O1=:=2, 
          new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new256(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=N, N1=:=1, 
          new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new256(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=N, N1=:=1, 
          new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new252(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new220(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new252(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=2, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2)), 
          new251(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M1,E2,F2),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=A, N1=:=1, 
          new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=A, N1=:=1, 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=A, N1=:=1, 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=1, N1=:=0, O1=:=1, 
          new252(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=A, N1=:=0, 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=A, N1=:=0, 
          new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=A, N1=:=0, 
          new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new239(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,T,U,V,W,X)) :- 
          new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1)).
new239(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2)), 
          new185(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new233(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new220(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new233(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=2, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2)), 
          new230(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,M1,F2),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=B, N1=:=1, O1=:=1, 
          new233(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=B, N1=:=1, 
          new230(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=B, N1=:=1, 
          new230(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new227(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=B, N1=:=0, 
          new230(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new227(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=B, N1=:=0, 
          new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new227(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=B, N1=:=0, 
          new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,T,U,V,W,X)) :- 
          new227(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1)).
new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2)), 
          new188(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new220(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,M1,N1,O1,P1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,Q1,R1,S1,T1)).
new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new220(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=2, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2)), 
          new214(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=C, N1=:=1, O1=:=1, 
          new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=C, N1=:=1, 
          new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=C, N1=:=1, 
          new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new211(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=C, N1=:=0, 
          new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new211(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=C, N1=:=0, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new211(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=C, N1=:=0, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,T,U,V,W,X)) :- 
          new211(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2)), 
          new191(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)).
new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=D, N1=:=1, 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=D, N1=:=1, 
          new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=D, N1=:=1, 
          new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=D, N1=:=0, 
          new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=D, N1=:=0, 
          new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=D, N1=:=0, 
          new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,T,U,V,W,X)) :- 
          new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2)), 
          new178(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=X, X1=:=0, Y1=:=1, 
          new196(s(A,B,C,D,E,F,G,Y1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=X, X1=:=0, Y1=:=1, 
          new196(s(A,B,C,D,E,F,G,Y1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=X, X1=:=0, 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=H, X1=:=0, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,Y1),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=H, X1=:=0, 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=H, X1=:=0, 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=W, X1=:=0, Y1=:=1, 
          new208(s(A,B,C,D,E,F,Y1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=W, X1=:=0, Y1=:=1, 
          new208(s(A,B,C,D,E,F,Y1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=W, X1=:=0, 
          new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=G, X1=:=0, 
          new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,Y1,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=G, X1=:=0, 
          new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=G, X1=:=0, 
          new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=V, X1=:=0, Y1=:=1, 
          new224(s(A,B,C,D,E,Y1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=V, X1=:=0, Y1=:=1, 
          new224(s(A,B,C,D,E,Y1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=V, X1=:=0, 
          new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=F, X1=:=0, 
          new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,Y1,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=F, X1=:=0, 
          new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=F, X1=:=0, 
          new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new184(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=U, X1=:=0, Y1=:=1, 
          new239(s(A,B,C,D,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new184(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=U, X1=:=0, Y1=:=1, 
          new239(s(A,B,C,D,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new184(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=U, X1=:=0, 
          new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=E, X1=:=0, 
          new184(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,Y1,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=E, X1=:=0, 
          new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=E, X1=:=0, 
          new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=T, X1=:=0, 
          new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=T, X1=:=0, 
          new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,T,U,V,W,X)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,R1),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,S1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Y1),d(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,X1)), 
          new181(s(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,W1,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=2, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2)), 
          new174(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M1,E2,F2),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,B,C,D,U,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          V>=W+1, V=:=1, W=:=0, T=:=1, U=:=2.
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=A, N1=:=1, 
          new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=A, N1=:=1, 
          new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=A, N1=:=1, 
          new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=1, N1=:=0, O1=:=1, 
          new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=A, N1=:=0, 
          new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=A, N1=:=0, 
          new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=A, N1=:=0, 
          new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2)), 
          new114(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=2, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2)), 
          new155(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,M1,F2),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=B, N1=:=1, O1=:=1, 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=B, N1=:=1, 
          new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=B, N1=:=1, 
          new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,T,C,D,E,U,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          V>=W+1, V=:=1, W=:=0, T=:=1, U=:=2.
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=B, N1=:=0, 
          new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=B, N1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=B, N1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2)), 
          new117(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,M1,N1,O1,P1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,Q1,R1,S1,T1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=2, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2)), 
          new141(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=C, N1=:=1, O1=:=1, 
          new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=C, N1=:=1, 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=C, N1=:=1, 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,T,D,E,F,U,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          V>=W+1, V=:=1, W=:=0, T=:=1, U=:=2.
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=C, N1=:=0, 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=C, N1=:=0, 
          new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=C, N1=:=0, 
          new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2)), 
          new120(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=D, N1=:=1, 
          new133(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=D, N1=:=1, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=D, N1=:=1, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,T,E,F,G,U,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          V>=W+1, V=:=1, W=:=0, T=:=1, U=:=2.
new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=D, N1=:=0, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=D, N1=:=0, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=D, N1=:=0, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2)), 
          new108(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=X, X1=:=0, Y1=:=1, 
          new125(s(A,B,C,D,E,F,G,Y1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=X, X1=:=0, Y1=:=1, 
          new125(s(A,B,C,D,E,F,G,Y1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=X, X1=:=0, 
          new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=H, X1=:=0, 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,Y1),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=H, X1=:=0, 
          new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=H, X1=:=0, 
          new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=W, X1=:=0, Y1=:=1, 
          new136(s(A,B,C,D,E,F,Y1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=W, X1=:=0, Y1=:=1, 
          new136(s(A,B,C,D,E,F,Y1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=W, X1=:=0, 
          new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=G, X1=:=0, 
          new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,Y1,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=G, X1=:=0, 
          new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=G, X1=:=0, 
          new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=V, X1=:=0, Y1=:=1, 
          new150(s(A,B,C,D,E,Y1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=V, X1=:=0, Y1=:=1, 
          new150(s(A,B,C,D,E,Y1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=V, X1=:=0, 
          new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=F, X1=:=0, 
          new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,Y1,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=F, X1=:=0, 
          new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=F, X1=:=0, 
          new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=U, X1=:=0, Y1=:=1, 
          new163(s(A,B,C,D,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=U, X1=:=0, Y1=:=1, 
          new163(s(A,B,C,D,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=U, X1=:=0, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, W1=:=E, X1=:=0, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,Y1,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=E, X1=:=0, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=E, X1=:=0, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          Y=:=Z, Y=:=T, Z=:=0.
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1>=X1+1, W1=:=T, X1=:=0, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1+1=<X1, W1=:=T, X1=:=0, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          W1=:=X1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Y1),d(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,X1)), 
          new110(s(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,W1,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=G, P1=:=0, 
          new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=G, P1=:=0, 
          new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=F, P1=:=0, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=F, P1=:=0, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V=:=W, V=:=H, W=:=0, U=:=1.
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V>=W+1, V=:=H, W=:=0, U=:=0.
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V+1=<W, V=:=H, W=:=0, U=:=0.
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V=:=W, V=:=G, W=:=0, U=:=1.
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=G, P1=:=0, 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=G, P1=:=0, 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V=:=W, V=:=F, W=:=0, U=:=1.
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=F, P1=:=0, 
          new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=F, P1=:=0, 
          new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=1, O1=:=2, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=1, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=1, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=1, O1=:=2, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=1, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=1, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=P, N1=:=1, O1=:=2, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=P, N1=:=1, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=P, N1=:=1, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=O, N1=:=1, O1=:=2, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=O, N1=:=1, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=O, N1=:=1, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=N, N1=:=1, O1=:=2, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=N, N1=:=1, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=N, N1=:=1, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,T)) :- 
          U=:=V, U=:=S, V=:=1, T=:=2.
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T>=U+1, T=:=S, U=:=1.
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          T+1=<U, T=:=S, U=:=1.
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=1, O1=:=2, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=1, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=1, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=1, O1=:=2, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=1, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=1, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=P, N1=:=1, O1=:=2, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=P, N1=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=P, N1=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=O, N1=:=1, O1=:=2, 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=O, N1=:=1, 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=O, N1=:=1, 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=N, N1=:=1, O1=:=2, 
          new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=N, N1=:=1, 
          new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=N, N1=:=1, 
          new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=1, O1=:=2, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=1, O1=:=2, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=1, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=1, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new40(s(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,P1,Q1,R1,S1),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T1,U1,V1,W1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2)), 
          new56(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,T,N,O,P,Q,R,S)) :- 
          T=:=1.
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,V)) :- 
          W>=X+1, W=:=T, X=:=0, V=:=0.
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,V)) :- 
          W+1=<X, W=:=T, X=:=0, V=:=0.
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,V)) :- 
          W=:=X, W=:=T, X=:=0, V=:=1.
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=V, T1=:=0, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,S1),d(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,R1)), 
          new47(s(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,Q1,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,T,U)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,O1),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,P1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,S1),d(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,R1)), 
          new50(s(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,Q1,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,P1,Q1),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,R1,S1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,T1)), 
          new44(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,S1),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new53(s(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, S1=:=U, T1=:=0, U1=:=4, 
          new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=U, T1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1+1=<T1, S1=:=U, T1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U)) :- 
          V=:=W, V=:=E, W=:=0, U=:=1.
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=E, P1=:=0, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=E, P1=:=0, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=E, P1=:=0, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=E, P1=:=0, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,P1),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,Q1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=T1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1),d(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,T1)), 
          new38(s(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,T,S1,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new35(s(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,P1,Q1,R1,S1),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T1,U1,V1,W1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2)), 
          new32(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new29(s(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=3, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,S1,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)) :- 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X),d(Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,P1,Q1,R1,S1,T1),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,U1,V1,W1,X1,Y1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=2, 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T1,U1,V1,W1,X1),d(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2)), 
          new25(s(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,S1,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1>=T1+1, S1=:=1, T1=:=0, U1=:=1, 
          new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=1, O1=:=2, 
          new256(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=1, 
          new256(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=1, 
          new256(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=1, O1=:=2, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=1, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=1, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new21(s(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, 
          new292(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W1),d(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,V1)), 
          new293(s(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,U1,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,T,U,V,W)) :- 
          new313(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Q1),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,R1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)) :- 
          U1=:=V1, 
          new292(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W1),d(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,V1)), 
          new315(s(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,U1,U,V,W),d(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,P1,Q1,R1,S1),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T1,U1,V1,W1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,S1,T1,U1,V1),d(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2)), 
          new18(s(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=0, O1=:=1, 
          new338(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=0, 
          new338(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=0, 
          new338(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=0, O1=:=1, 
          new356(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=0, 
          new356(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=0, 
          new356(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new15(s(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=I, N1=:=1, O1=:=0, 
          new374(s(A,B,C,D,O1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=I, N1=:=1, O1=:=2, 
          new374(s(A,B,C,D,O1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=I, N1=:=1, O1=:=2, 
          new374(s(A,B,C,D,O1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=I, N1=:=1, O1=:=0, 
          new383(s(A,B,C,D,O1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=I, N1=:=1, O1=:=2, 
          new383(s(A,B,C,D,O1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=I, N1=:=1, O1=:=2, 
          new383(s(A,B,C,D,O1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,T,U,V)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new12(s(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)) :- 
          S1=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,S1,U,V),d(W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,T)) :- 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,N1,O1,P1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,Q1,R1,S1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,T,U,V,W,M,N,O,P,Q,R,S)) :- 
          T=:=1, U=:=1, V=:=1, W=:=1.
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,T)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2)), 
          new6(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,N1)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=0, 
          K=:=0, L=:=0, M=:=2, N=:=2, O=:=2, P=:=2, Q=:=2, R=:=2, S=:=2, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
correct :- \+new1.
