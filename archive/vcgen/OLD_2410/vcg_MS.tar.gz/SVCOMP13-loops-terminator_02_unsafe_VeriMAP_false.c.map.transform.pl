new7(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=G, R=:=0, S=:=T+U, 
          T=:=A, U=:=1, new4(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new7(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=G, R=:=0, S=:=T+U, 
          T=:=A, U=:=1, new4(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new7(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=G, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, V=:=W-X, W=:=E, X=:=1, 
          new4(s(S,B,C,D,V,F,G,H),d(I,J,K,L,M,N,O,P)).
new6(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)).
new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=100, R=:=E, S=:=T, 
          new7(s(A,B,C,D,E,F,S,T),d(I,J,K,L,M,N,O,P)).
new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=100, R=:=E, 
          new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=A, R=:=100, 
          new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=A, R=:=100, 
          new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, S=:=T, U=:=V, 
          new4(s(Q,R,S,T,U,V,G,H),d(I,J,K,L,M,N,O,P)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new1 :- new2(s,d).
correct :- \+new1.
