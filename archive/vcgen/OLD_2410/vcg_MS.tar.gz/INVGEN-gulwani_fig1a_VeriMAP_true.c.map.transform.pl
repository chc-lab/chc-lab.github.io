new7(s(A,B,C),d(A,B,C)).
new6(s(A,B,C),d(D,E,F)) :- G=<H, G=:=C, H=:=0, new7(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=0, I=:=J+K, J=:=B, K=:=C, 
          L=:=M+N, M=:=C, N=:=1, new4(s(A,I,L),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H, G=:=B, H=:=0, new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:= -50, new4(s(A,G,C),d(D,E,F)).
new2(s(A),d(B)) :- new3(s(A,C,D),d(B,E,F)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
