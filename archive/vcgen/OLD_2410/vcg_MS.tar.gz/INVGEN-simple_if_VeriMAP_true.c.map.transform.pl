new7(s(A,B,C),d(A,B,C)).
new6(s(A,B,C),d(D,E,F)) :- G=<H, G=:=C, H=:=0, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=0, I=:=J*K, J=:=2, K=:=C, 
          new4(s(A,B,I),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=0, I=:=J*K, J=:=3, K=:=C, 
          new4(s(A,B,I),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=A, new5(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=A, new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=1, new4(s(A,B,G),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
