new19(s(A,B,C),d(A,B,C)).
new14(s(A,B,C),d(D,E,F)) :- new4(s(A,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=3, I=:=5, 
          new14(s(A,I,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=3, I=:=5, 
          new14(s(A,I,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=3, new19(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=4, new13(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=4, new14(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=4, new14(s(A,B,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=1, I=:=2, J=:=4, 
          new14(s(I,J,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=1, I=:=4, 
          new14(s(A,I,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=1, I=:=4, 
          new14(s(A,I,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=3, new10(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=3, new11(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=3, new11(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=0, I=:=1, J=:=3, 
          new14(s(I,J,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=3, 
          new14(s(A,I,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, I=:=3, 
          new14(s(A,I,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=2, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=2, new8(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=2, new8(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new5(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=2, new4(s(G,H,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
