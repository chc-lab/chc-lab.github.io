new8(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O+P, O=:=C, P=:=Q*R, Q=:=2, 
          R=:=D, N=:=0, new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=0, O=:=P+Q, P=:=B, 
          Q=:=A, R=:=S-T, S=:=A, T=:=U*V, U=:=2, V=:=O, W=:=X+Y, X=:=Z*A1, 
          Z=:=2, A1=:=A, Y=:=O, new4(s(A,O,R,W,E,B1),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=0, O=:=P+Q, P=:=B, 
          Q=:=A, R=:=S-T, S=:=A, T=:=U*V, U=:=2, V=:=O, W=:=X+Y, X=:=Z*A1, 
          Z=:=2, A1=:=A, Y=:=O, new4(s(A,O,R,W,E,B1),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=0, O=:=P-Q, P=:=B, 
          Q=:=A, R=:=S-T, S=:=A, T=:=U*V, U=:=2, V=:=O, W=:=X+Y, X=:=Z*A1, 
          Z=:=2, A1=:=A, Y=:=O, new4(s(A,O,R,W,E,B1),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=0, O=:=P+Q, P=:=C, 
          Q=:=R*S, R=:=2, S=:=D, T=:=U+V, U=:=W*X, W=:= -2, X=:=C, V=:=D, 
          Y=:=Z+A1, Z=:=O, A1=:=1, new5(s(Y,T,C,D,B1,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=0, O=:=P+Q, P=:=C, 
          Q=:=R*S, R=:=2, S=:=D, T=:=U+V, U=:=W*X, W=:= -2, X=:=C, V=:=D, 
          Y=:=Z+A1, Z=:=O, A1=:=1, new5(s(Y,T,C,D,B1,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=F, N=:=0, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N=:=0, 
          new4(s(A,B,M,N,E,O),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
correct :- \+new1.
