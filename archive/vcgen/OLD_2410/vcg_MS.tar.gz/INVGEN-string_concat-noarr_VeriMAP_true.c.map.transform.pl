new15(s(A,B,C),d(A,B,C)).
new14(s(A,B,C),d(D,E,F)) :- G>=H, G=:=B, H=:=200, new15(s(A,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- new8(s(A,B,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=100, new13(s(A,B,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=100, new14(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=J+K, J=:=B, K=:=1, 
          L=:=M+N, M=:=C, N=:=1, new9(s(A,I,L),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, I=:=J+K, J=:=B, K=:=1, 
          L=:=M+N, M=:=C, N=:=1, new9(s(A,I,L),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=0, new12(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- new8(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H, G=:=B, H=:=100, new8(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=100, I=:=0, 
          new9(s(A,B,I),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=J+K, J=:=B, K=:=1, 
          new4(s(A,I,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, I=:=J+K, J=:=B, K=:=1, 
          new4(s(A,I,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=0, new7(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, new4(s(A,G,C),d(D,E,F)).
new2(s(A),d(B)) :- new3(s(A,C,D),d(B,E,F)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
