new17(s(A,B,C),d(A,B,C)).
new15(s(A,B,C,D),d(A,E,F,G)) :- H=<I, H=:=B, I=:=A, F=:=J+K, J=:=C, K=:=B, 
          G=:=L*M, L=:=D, M=:=B, E=:=N+O, N=:=B, O=:=1.
new15(s(A,B,C,D),d(A,B,C,D)) :- E>=F+1, E=:=B, F=:=A.
new11(s(A,B,C),d(A,B,C)) :- D=:=5, new9(s(D,E,F,G),d(H,I,J,K)).
new11(s(A,B,C),d(D,E,F)) :- G=:=5, H=:=I, J=:=K+L, K=:=H, L=:=5, 
          new10(s(G,M,N,O),d(P,Q,I,R)), new7(s(J,B,H),d(D,E,F)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=0, K=:=1, 
          new15(s(A,I,J,K),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=0, K=:=1, 
          new16(s(A,I,J,K),d(E,F,G,H)).
new8(s(A,B,C),d(A,B,C)) :- D=:=A, new9(s(D,E,F,G),d(H,I,J,K)).
new8(s(A,B,C),d(D,E,F)) :- G=:=A, H=:=I, J=:=K-L, K=:=H, L=:=1, 
          new10(s(G,M,N,O),d(P,Q,I,R)), new11(s(J,H,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, new17(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=J+K, J=:=A, K=:=1, 
          new7(s(I,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=0, new8(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, new4(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=0, new5(s(A,B,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
