new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=A, N=:=9, O=:=P+Q, P=:=A, 
          Q=:=1, R=:=S+T, S=:=B, T=:=3, new5(s(O,R,C,D,E,U),d(G,H,I,J,K,L)).
new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=O-P, O=:=A, P=:=7, N=:=0, 
          Q=:=R+S, R=:=A, S=:=2, T=:=U+V, U=:=B, V=:=1, 
          new5(s(Q,T,C,D,E,W),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=O-P, O=:=A, P=:=4, N=:=0, 
          Q=:=R+S, R=:=A, S=:=1, T=:=U+V, U=:=B, V=:=2, 
          new5(s(Q,T,C,D,E,W),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O-P, O=:=A, P=:=5, N=:=0, 
          new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new17(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=0, 
          new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new17(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=0, 
          new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new17(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=C, N=:=0, 
          new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=A, N=:=7, 
          new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=0, 
          new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=0, 
          new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=D, N=:=0, 
          new17(s(A,B,O,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=A, N=:=9, O=:=P+Q, P=:=A, 
          Q=:=2, R=:=S+T, S=:=B, T=:=1, new5(s(O,R,C,D,E,U),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O-P, O=:=Q*R, Q=:=3, R=:=A, 
          P=:=B, N=:=0, new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O+P, O=:=Q*R, Q=:= -1, R=:=A, 
          P=:=S*T, S=:=2, T=:=B, N=:=0, new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O+P, O=:=Q*R, Q=:= -1, 
          R=:=A, P=:=S*T, S=:=2, T=:=B, N=:=0, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=0, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=0, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=0, 
          new14(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=0, 
          new6(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=0, 
          new6(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=F, N=:=0, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=B, N=:=0, 
          new5(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
correct :- \+new1.
