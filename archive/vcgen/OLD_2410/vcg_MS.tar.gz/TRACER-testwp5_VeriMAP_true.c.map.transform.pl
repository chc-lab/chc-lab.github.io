new7(s(A,B),d(A,B)).
new5(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=50, new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=H+I, H=:=A, I=:=1, J=:=K+L, 
          K=:=G, L=:=1, M=:=N+O, N=:=J, O=:=2, P=:=Q+R, Q=:=M, R=:=3, 
          new5(s(P,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=H+I, H=:=A, I=:=2, J=:=K+L, 
          K=:=G, L=:=1, M=:=N+O, N=:=J, O=:=2, P=:=Q+R, Q=:=M, R=:=3, 
          new5(s(P,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=:=0, new4(s(E,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
correct :- \+new1.
