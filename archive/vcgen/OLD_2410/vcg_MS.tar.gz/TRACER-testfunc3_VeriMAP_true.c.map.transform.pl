new14(s(A,B,C,D),d(A,B,C,D)).
new13(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=17, 
          new14(s(A,B,C,D),d(E,F,G,H)).
new13(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=17, 
          new14(s(A,B,C,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(A,B,C,D)) :- E=:=F+G, F=:=C, G=:=3, new5(s(E,H),d(I,J)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I=:=J+K, J=:=C, K=:=3, L=:=M, 
          new6(s(I,N),d(O,M)), new13(s(A,B,C,L),d(E,F,G,H)).
new7(s(A,B,C,D),d(A,B,C,D)) :- E=:=F+G, F=:=B, G=:=2, new5(s(E,H),d(I,J)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=:=J+K, J=:=B, K=:=2, L=:=M, 
          new6(s(I,N),d(O,M)), new10(s(A,B,L,D),d(E,F,G,H)).
new6(s(A,B),d(A,C)) :- C=:=D+E, D=:=A, E=:=1.
new4(s(A,B,C,D),d(A,B,C,D)) :- E=:=F+G, F=:=A, G=:=1, new5(s(E,H),d(I,J)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=J+K, J=:=A, K=:=1, L=:=M, 
          new6(s(I,N),d(O,M)), new7(s(A,L,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=8, new4(s(I,B,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
