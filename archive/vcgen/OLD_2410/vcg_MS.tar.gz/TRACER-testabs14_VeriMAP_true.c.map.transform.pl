new10(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=10, new9(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(A,B,C)).
new8(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=10, new9(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=10, new10(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, I=:=J+K, J=:=B, K=:=1, 
          new6(s(A,I,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H, G=:=B, H=:=A, new8(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=A, I=:=J+K, J=:=C, K=:=1, 
          new4(s(A,B,I),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=A, new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=0, I=:=10, new4(s(I,G,H),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
