new76(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=B, 
          X=:=0, Y=:=8656, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new76(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=B, 
          X=:=0, Y=:=8656, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new76(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=B, 
          X=:=0, Y=:=8512, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new68(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y+Z, 
          Y=:=D, Z=:=2, X=:=0, A1=:=8576, 
          new17(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new68(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y+Z, 
          Y=:=D, Z=:=2, X=:=0, A1=:=8576, 
          new17(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new68(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=Y+Z, 
          Y=:=D, Z=:=2, X=:=0, A1=:=8560, 
          new17(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new67(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y+Z, 
          Y=:=H, H>=0, Z=:=256, X=:=0, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new65(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y+Z, 
          Y=:=D, Z=:=4, X=:=0, A1=:=8560, 
          new17(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new65(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y+Z, 
          Y=:=D, Z=:=4, X=:=0, A1=:=8560, 
          new17(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new65(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=Y+Z, 
          Y=:=D, Z=:=4, X=:=0, 
          new67(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new62(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=F, 
          X=:=0, new65(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new62(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=F, 
          X=:=0, new65(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new62(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=F, 
          X=:=0, new67(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new55(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=B, 
          X=:=0, Y=:=8656, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new46(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=M, L=:=J, M=:=5.
new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=5, new45(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=5, new45(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new45(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=B, 
          X=:=0, Y=:=8640, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new45(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=B, 
          X=:=0, Y=:=8640, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new44(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=4, Y=:=5, 
          new45(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new44(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=4, new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new44(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=4, new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new42(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8672, new44(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new41(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=2, Y=:=3, Z=:=8672, 
          new17(s(Z,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new41(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=2, Y=:=8672, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new41(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=2, Y=:=8672, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new39(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8656, new41(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new39(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8656, new42(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new39(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8656, new42(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new38(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=3, Y=:=4, 
          new55(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new38(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=3, new55(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new38(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=3, new55(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new36(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8640, new38(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new36(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8640, new39(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new36(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8640, new39(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new33(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8608, Y=:=8640, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new33(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8608, new36(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new33(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8608, new36(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new30(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8592, Y=:=8608, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new30(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8592, new33(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new30(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8592, new33(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new29(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=K, 
          X=:=2, Y=:=8466, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new29(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=K, 
          X=:=2, Y=:=8592, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new29(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=K, 
          X=:=2, Y=:=8592, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8576, new29(s(A,B,C,D,E,F,G,H,I,J,Y),d(L,M,N,O,P,Q,R,S,T,U,V)).
new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8576, new30(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8576, new30(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new24(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8560, Y=:=8576, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new24(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8560, new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new24(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8560, new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new23(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y+Z, 
          Y=:=D, Z=:=1, X=:=0, 
          new62(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new23(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y+Z, 
          Y=:=D, Z=:=1, X=:=0, 
          new62(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new23(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=Y+Z, 
          Y=:=D, Z=:=1, X=:=0, A1=:=8560, 
          new17(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8544, new23(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8544, new24(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8544, new24(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8528, Y=:=8544, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8528, new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8528, new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new17(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8512, Y=:=8528, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8512, new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8512, new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=1, Y=:=2, 
          new76(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=1, new76(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=1, new76(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8496, new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8496, new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8496, new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new11(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, Y=:=1, Z=:=8496, 
          new17(s(Z,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new11(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, Y=:=8496, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new11(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, Y=:=8496, 
          new17(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8466, new11(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8466, new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8466, new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new9(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L>=M+1, L=:=J, M=:=2.
new9(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=<X, W=:=J, X=:=2, 
          new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new8(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=<X, W=:=A, 
          X=:=8512, new9(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new8(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8512, new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new4(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=1, 
          X=:=0, new8(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, Y=:=Z, 
          A1=:=B1, C1=:=D1, E1=:=18446744073709551616+C1, C1+1=<0, F1=:=8466, 
          G1=:=0, new4(s(F1,W,X,Y,Z,A1,B1,E1,D1,G1,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, Y=:=Z, 
          A1=:=B1, C1=:=D1, E1=:=C1, C1>=0, F1=:=8466, G1=:=0, 
          new4(s(F1,W,X,Y,Z,A1,B1,E1,D1,G1,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, Y=:=Z, 
          A1=:=B1, C1=:=D1, E1=:=18446744073709551616+C1, C1+1=<0, F1=:=8466, 
          G1=:=0, new4(s(F1,W,X,Y,Z,A1,B1,E1,D1,G1,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, Y=:=Z, 
          A1=:=B1, C1=:=D1, E1=:=C1, C1>=0, F1=:=8466, G1=:=0, 
          new4(s(F1,W,X,Y,Z,A1,B1,E1,D1,G1,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new1 :- new2(s,d).
correct :- \+new1.
