new38(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=132, new38(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=L, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new35(s(A1,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=L, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new35(s(A1,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=L, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=2, 
          new35(s(A1,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new32(s(A1,B,C,D,E,F,G,H,I,J,K,D1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new32(s(A1,B,C,D,E,F,G,H,I,J,K,D1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=4, 
          new32(s(A1,B,C,D,E,F,G,H,I,J,K,D1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new29(s(A1,B,C,D,E,F,G,H,I,J,D1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new29(s(A1,B,C,D,E,F,G,H,I,J,D1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=6, 
          new29(s(A1,B,C,D,E,F,G,H,I,J,D1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new26(s(A1,B,C,D,E,F,G,H,I,D1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new26(s(A1,B,C,D,E,F,G,H,I,D1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=8, 
          new26(s(A1,B,C,D,E,F,G,H,I,D1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new23(s(A1,B,C,D,E,F,G,H,D1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new23(s(A1,B,C,D,E,F,G,H,D1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=10, 
          new23(s(A1,B,C,D,E,F,G,H,D1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new20(s(A1,B,C,D,E,F,G,D1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new20(s(A1,B,C,D,E,F,G,D1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=12, 
          new20(s(A1,B,C,D,E,F,G,D1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=F, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new17(s(A1,B,C,D,E,F,D1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=F, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new17(s(A1,B,C,D,E,F,D1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=F, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=14, 
          new17(s(A1,B,C,D,E,F,D1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new14(s(A1,B,C,D,E,D1,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new14(s(A1,B,C,D,E,D1,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=E, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=16, 
          new14(s(A1,B,C,D,E,D1,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=D, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new11(s(A1,B,C,D,D1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=D, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new11(s(A1,B,C,D,D1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=D, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=18, 
          new11(s(A1,B,C,D,D1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=C, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new8(s(A1,B,C,D1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=C, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new8(s(A1,B,C,D1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=C, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=20, 
          new8(s(A1,B,C,D1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new5(s(A1,B,D1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=1, 
          new5(s(A1,B,D1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=0, A1=:=B1+C1, B1=:=A, C1=:=22, 
          new5(s(A1,B,D1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=0, 
          new4(s(Y,Z,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new1 :- new2(s,d).
correct :- \+new1.
