new7(s(A),d(A)).
new6(s(A),d(B)) :- C>=D+1, C=:=A, D=:=1, new7(s(A),d(B)).
new6(s(A),d(B)) :- C+1=<D, C=:=A, D=:=1, new7(s(A),d(B)).
new5(s(A),d(B)) :- B=:=1.
new3(s(A),d(A)) :- new4(s(B),d(C)).
new3(s(A),d(B)) :- C=:=D, new5(s(E),d(D)), new6(s(C),d(B)).
new2(s,d) :- new3(s(A),d(B)).
new1 :- new2(s,d).
correct :- \+new1.
