new35(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=C, T=:=2, 
          U=:=V-W, V=:=B, W=:=1, X=:=Y-Z, Y=:=A1*B1, A1=:=2, B1=:=B, Z=:=2, 
          C1=:=D1-E1, D1=:=B, E1=:=1, 
          new9(s(A,C1,C,U,X,F,G,H,F1),d(J,K,L,M,N,O,P,Q,R)).
new33(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=C, T=:=3, U=:=B, 
          V=:=W*X, W=:=2, X=:=B, 
          new9(s(A,B,C,U,V,F,G,H,Y),d(J,K,L,M,N,O,P,Q,R)).
new32(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=B, T=:=1, 
          U=:=V-W, V=:=C, W=:=1, 
          new33(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new30(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=B, T=:=2, 
          new35(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new29(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=F, T=:=0, 
          new30(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new29(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=F, T=:=0, 
          new30(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new29(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=F, T=:=0, 
          new32(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new27(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=U-V, U=:=E, 
          V=:=C, T=:=0, W=:=E, X=:=Y*Z, Y=:=2, Z=:=E, 
          new9(s(A,B,C,W,X,F,G,H,A1),d(J,K,L,M,N,O,P,Q,R)).
new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=0, 
          new27(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=0, 
          new27(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=0, 
          new29(s(A,B,C,D,E,U,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new24(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=W-X, 
          W=:=C, X=:=E, V=:=1, T=:=0, Y=:=Z+A1, Z=:=E, A1=:=1, B1=:=C1+D1, 
          C1=:=E1*F1, E1=:=2, F1=:=E, D1=:=2, 
          new9(s(A,B,C,Y,B1,F,G,H,G1),d(J,K,L,M,N,O,P,Q,R)).
new21(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U-V, U=:=A, 
          V=:=C, T=:=0, new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=B, 
          V=:=1, T=:=0, new21(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U-V, U=:=B, 
          V=:=1, T=:=0, new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new17(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=C, 
          V=:=2, T=:=0, new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new17(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U-V, U=:=C, 
          V=:=2, T=:=0, new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=W+X, 
          W=:=Y*Z, Y=:= -2, Z=:=B, X=:=C, V=:=1, T=:=0, 
          new17(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U+V, U=:=W+X, 
          W=:=Y*Z, Y=:= -2, Z=:=B, X=:=C, V=:=1, T=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new14(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=U-V, U=:=W*X, 
          W=:=2, X=:=D, V=:=E, T=:=0, 
          new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=U-V, U=:=W*X, 
          W=:=2, X=:=D, V=:=E, T=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=W*X, 
          W=:=2, X=:=D, V=:=E, T=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U-V, U=:=W*X, 
          W=:=2, X=:=D, V=:=E, T=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=0, 
          new24(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=0, 
          new24(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=0, 
          new26(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new9(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=0, 
          new10(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new9(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=0, 
          new10(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new9(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=0, 
          new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new8(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=U-V, U=:=W-X, 
          W=:=Y*Z, Y=:=2, Z=:=B, X=:=A, V=:=1, T=:=0, 
          new9(s(A,B,C,D,E,F,G,H,A1),d(J,K,L,M,N,O,P,Q,R)).
new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=W*X, 
          W=:=2, X=:=B, V=:=A, T=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new6(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=U-V, U=:=E, 
          V=:=W*X, W=:=2, X=:=B, T=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new5(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=U-V, U=:=D, 
          V=:=B, T=:=0, new6(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new4(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=U-V, U=:=C, 
          V=:=A, T=:=0, new5(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=A, T=:=2, 
          new4(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new1 :- new2(s,d).
correct :- \+new1.
