new14(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=5, new16(s(A,B),d(C,D)).
new14(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=5, new16(s(A,B),d(C,D)).
new13(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, new14(s(A,B),d(C,D)).
new13(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=0, new14(s(A,B),d(C,D)).
new11(s(A,B),d(C,B)) :- D=:=E, D=:=B, E=:=15, C=:=15.
new11(s(A,B),d(C,B)) :- D>=E+1, D=:=B, E=:=15, C=:=20.
new11(s(A,B),d(C,B)) :- D+1=<E, D=:=B, E=:=15, C=:=20.
new9(s(A,B),d(C,B)) :- D=:=E, D=:=B, E=:=5, C=:=5.
new9(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=5, new11(s(A,B),d(C,D)).
new9(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=5, new11(s(A,B),d(C,D)).
new8(s(A,B),d(C,B)) :- D=:=E, D=:=B, E=:=0, C=:=0.
new8(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, new9(s(A,B),d(C,D)).
new8(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=0, new9(s(A,B),d(C,D)).
new7(s(A),d(A)).
new6(s(A),d(B)) :- C=:=D, C=:=A, D=:=15, new7(s(A),d(B)).
new5(s(A,B),d(C,D)) :- new8(s(A,E),d(C,D)).
new4(s(A,B),d(C,D)) :- new13(s(A,E),d(C,D)).
new3(s(A),d(A)) :- new4(s(B,C),d(D,E)).
new3(s(A),d(B)) :- C=:=D, new5(s(E,F),d(D,G)), new6(s(C),d(B)).
new2(s,d) :- new3(s(A),d(B)).
new1 :- new2(s,d).
correct :- \+new1.
