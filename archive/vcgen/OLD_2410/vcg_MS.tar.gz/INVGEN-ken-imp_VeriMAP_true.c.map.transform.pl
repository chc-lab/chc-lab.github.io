new9(s(A,B,C,D),d(A,B,C,D)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, 
          new9(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=0, 
          new9(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=B, new8(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=0, K=:=L-M, L=:=C, M=:=1, 
          N=:=O-P, O=:=D, P=:=1, new4(s(A,B,K,N),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=0, K=:=L-M, L=:=C, M=:=1, 
          N=:=O-P, O=:=D, P=:=1, new4(s(A,B,K,N),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=C, J=:=0, new7(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=A, J=:=B, new4(s(A,B,I,J),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
