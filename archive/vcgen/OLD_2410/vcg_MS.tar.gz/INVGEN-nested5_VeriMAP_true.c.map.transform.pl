new11(s(A,B,C,D,E),d(A,B,C,D,E)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=B, M=:=N+O, N=:=D, O=:=1, 
          new6(s(A,B,C,M,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=B, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=E, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=E, M=:=N+O, N=:=C, O=:=1, 
          new5(s(A,B,M,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=E, M=:=C, 
          new6(s(A,B,C,M,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=E, M=:=N+O, N=:=B, O=:=1, 
          new4(s(A,M,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=E, M=:=B, 
          new5(s(A,B,M,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, new4(s(A,K,C,D,E),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
