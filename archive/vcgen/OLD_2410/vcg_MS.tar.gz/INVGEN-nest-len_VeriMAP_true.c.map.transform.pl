new19(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new19(s(I,B,C),d(D,E,F)).
new19(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=J+K, J=:=B, K=:=1, 
          new4(s(A,I,C),d(D,E,F)).
new17(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new17(s(I,B,C),d(D,E,F)).
new17(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new19(s(I,B,C),d(D,E,F)).
new15(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new15(s(I,B,C),d(D,E,F)).
new15(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new17(s(I,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new13(s(I,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new15(s(I,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new11(s(I,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new13(s(I,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new9(s(I,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new11(s(I,B,C),d(D,E,F)).
new7(s(A,B,C),d(A,B,C)).
new6(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new6(s(I,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new9(s(I,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=<H, G=:=1, H=:=B, I=:=1, new6(s(I,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=1, H=:=B, new7(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=C, new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=1, new4(s(A,G,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
