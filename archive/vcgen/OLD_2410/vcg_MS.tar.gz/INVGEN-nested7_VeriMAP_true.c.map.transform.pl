new22(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=F, Q=:=R+S, 
          R=:=C, S=:=1, T=:=U+V, U=:=E, V=:=1, 
          new22(s(A,B,Q,D,T,F,G),d(H,I,J,K,L,M,N)).
new22(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=F, Q=:=R+S, R=:=B, 
          S=:=1, new5(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=C, P=:=Q+R, Q=:=F, 
          R=:=D, S=:=T+U, T=:=C, U=:=1, 
          new18(s(A,B,S,D,E,F,G),d(H,I,J,K,L,M,N)).
new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=C, P=:=Q+R, Q=:=F, R=:=D, 
          S=:=T+U, T=:=E, U=:=1, new17(s(A,B,C,D,S,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=G, Q=:=0, 
          new18(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=G, Q=:=R+S, R=:=B, 
          S=:=1, new4(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=F, Q=:=R-S, 
          R=:=C, S=:=1, T=:=U+V, U=:=E, V=:=1, 
          new12(s(A,B,Q,D,T,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=F, Q=:=R+S, R=:=B, 
          S=:=1, new4(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=F, Q=:=0, 
          new12(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=F, Q=:=R+S, R=:=B, 
          S=:=1, new4(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=G, Q=:=R+S, 
          R=:=E, S=:=1, new10(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=G, Q=:=0, 
          new17(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=5, Q=:=0, 
          new10(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=5, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, Q=:=0, 
          new22(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, Q=:=0, 
          new22(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, Q=:=R+S, R=:=B, 
          S=:=1, new5(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=Q+R, Q=:=F, 
          R=:=D, new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=B, P=:=G, Q=:=D, 
          new8(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=B, P=:=G, 
          new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=B, P=:=F, Q=:=0, 
          new5(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=B, P=:=F, 
          new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=Q+R, Q=:=F, R=:=D, 
          S=:=0, new4(s(A,S,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
