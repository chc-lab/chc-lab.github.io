new89(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=B, Q=:=R+S, R=:=D, 
          S=:=1, new12(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new89(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new87(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=D, 
          new89(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new87(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=D, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new85(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=G, 
          new87(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new85(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=G, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new81(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=B, Q=:=R+S, R=:=E, 
          S=:=1, new37(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new81(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new79(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=D, 
          new81(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new79(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=D, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new77(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=B, 
          new79(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new77(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new75(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new77(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new75(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new73(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=E, P=:=G, 
          new75(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new73(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=G, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new69(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=B, Q=:=R+S, R=:=E, 
          S=:=1, new57(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new69(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new67(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new69(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new67(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new65(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=B, 
          new67(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new65(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new63(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=D, 
          new65(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new63(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=D, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new61(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=E, P=:=G, 
          new63(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new61(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=G, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new59(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=E, 
          new61(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new59(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=E, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new57(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=E, P=:=G, 
          new59(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new57(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=G, Q=:=R+S, 
          R=:=D, S=:=1, new16(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new55(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=B, Q=:=C, 
          new57(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new55(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new53(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new55(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new53(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new51(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=G, 
          new53(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new51(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=G, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new50(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new51(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new50(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new49(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=E, 
          new73(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new49(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=E, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=B, Q=:=R+S, R=:=D, 
          S=:=1, new38(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new43(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new43(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new41(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=G, 
          new43(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new41(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=G, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=D, 
          new41(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=D, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new38(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=G, 
          new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new38(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=G, 
          new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new37(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=E, P=:=G, 
          new49(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new37(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=G, 
          new50(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new33(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=B, Q=:=R+S, R=:=D, 
          S=:=1, new18(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new33(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new31(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new33(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new31(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new29(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=G, 
          new31(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new29(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=G, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=B, Q=:=R-S, R=:=C, 
          S=:=1, new7(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new21(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=G, 
          new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new21(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=G, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new21(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new19(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=D, 
          new29(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new19(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=D, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=G, 
          new19(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=G, 
          new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=B, Q=:=F, 
          new37(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=B, Q=:=C, 
          new38(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, Q=:=F, 
          new16(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, Q=:=F, 
          new16(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, Q=:=C, 
          new18(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new14(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new85(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new14(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=B, 
          new14(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=B, 
          new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=B, Q=:=F, 
          new12(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=B, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=1, P=:=C, 
          new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=1, P=:=C, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=C, P=:=1, Q=:=R+S, R=:=C, 
          S=:=1, new9(s(A,B,C,D,E,Q,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=G, P=:=B, Q=:=G, 
          new7(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=G, P=:=B, Q=:=B, 
          new7(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=B, P=:=G, 
          new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=B, P=:=G, 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
