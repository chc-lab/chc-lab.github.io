new10(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=0, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=0, O=:=P+Q, P=:=F, 
          Q=:=1, R=:=S-T, S=:=D, T=:=1, new8(s(A,B,C,R,E,O),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=O+P, O=:=A, P=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=B, O=:=P+Q, P=:=E, 
          Q=:=1, R=:=S+T, S=:=D, T=:=1, new6(s(A,B,C,R,O,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=B, O=:=0, 
          new8(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=A, O=:=P+Q, P=:=C, 
          Q=:=1, R=:=S+T, S=:=D, T=:=1, new4(s(A,B,O,R,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=A, O=:=0, 
          new6(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N=:=0, 
          new4(s(A,B,M,N,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
correct :- \+new1.
