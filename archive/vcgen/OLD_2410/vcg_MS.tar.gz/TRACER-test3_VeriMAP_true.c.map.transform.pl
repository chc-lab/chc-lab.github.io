new10(s(A,B,C),d(A,B,C)).
new8(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=10, new10(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=10, new10(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=5, new8(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=5, new8(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, I=:=5, new5(s(I,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, I=:=5, new5(s(I,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, I=:=10, new5(s(A,I,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=0, new4(s(G,H,I),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
