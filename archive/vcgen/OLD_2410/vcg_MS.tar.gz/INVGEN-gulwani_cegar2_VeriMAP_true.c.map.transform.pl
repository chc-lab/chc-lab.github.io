new9(s(A,B,C,D),d(A,B,C,D)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=D, new9(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=0, J=:=C, new8(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=0, J=:=C, 
          new9(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, 
          new7(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, K=:=B, L=:=M+N, M=:=B, 
          N=:=1, new4(s(A,L,K,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, K=:=B, L=:=M+N, M=:=B, 
          N=:=1, new4(s(A,L,K,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, K=:=L+M, L=:=B, M=:=1, 
          new4(s(A,K,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=D, 
          new5(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=B, J=:=D, new6(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,I,J,D),d(E,F,G,H)).
new2(s(A),d(B)) :- new3(s(A,C,D,E),d(B,F,G,H)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
