new15(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=4, I=:=1, J=:=6, K=:=L+M, L=:=A, 
          M=:=1, new4(s(K,I,J),d(D,E,F)).
new15(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=4, I=:=2, J=:=K+L, K=:=A, L=:=1, 
          new4(s(J,I,C),d(D,E,F)).
new15(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=4, I=:=2, J=:=K+L, K=:=A, L=:=1, 
          new4(s(J,I,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=3, I=:=1, J=:=5, K=:=L+M, L=:=A, 
          M=:=1, new4(s(K,I,J),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=3, new15(s(A,B,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=3, new15(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=2, I=:=3, J=:=4, K=:=L+M, L=:=A, 
          M=:=1, new4(s(K,I,J),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=2, new12(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=2, new12(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(A,B,C)).
new6(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=6, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=1, I=:=2, J=:=3, K=:=L+M, L=:=A, 
          M=:=1, new4(s(K,I,J),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=1, new9(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=1, new9(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=10, new5(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=10, new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=1, new4(s(G,H,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
