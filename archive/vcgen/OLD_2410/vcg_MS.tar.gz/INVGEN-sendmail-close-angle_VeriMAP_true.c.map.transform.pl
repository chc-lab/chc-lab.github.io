new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=C, 
          new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=B, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=B, 
          new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=B, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=D, O=:=P+Q, P=:=E, 
          Q=:=1, R=:=S+T, S=:=B, T=:=1, new22(s(A,R,C,D,O,F),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=D, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=E, 
          new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=E, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=D, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=E, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=E, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=D, O=:=P+Q, P=:=E, 
          Q=:=1, new12(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=D, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=E, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=E, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=F, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=F, 
          new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=F, 
          new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=C, O=:=0, P=:=0, 
          Q=:=R-S, R=:=D, S=:=2, new6(s(A,P,C,D,O,Q),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=1, 
          new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
correct :- \+new1.
