new8(s(A,B,C,D),d(A,B,C,D)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, new8(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=0, L=:=M+N, M=:=C, 
          N=:=2, new4(s(K,B,L,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=0, K=:=0, L=:=M+N, M=:=C, 
          N=:=2, new4(s(K,B,L,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=D, J=:=0, new4(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=B, K=:=1, L=:=C, 
          new5(s(K,L,C,M),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=B, K=:=1, L=:=C, 
          new5(s(K,L,C,M),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=C, J=:=B, new7(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=K+L, K=:=B, L=:=1, 
          new4(s(I,B,J,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
