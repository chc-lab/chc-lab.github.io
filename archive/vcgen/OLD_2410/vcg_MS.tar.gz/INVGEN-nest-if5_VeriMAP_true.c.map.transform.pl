new16(s(A,B,C,D,E),d(A,B,C,D,E)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=D, M=:=N+O, N=:=B, 
          O=:=1, new12(s(A,M,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=D, M=:=N+O, N=:=C, O=:=1, 
          new4(s(A,B,M,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=1, L=:=B, M=:=N+O, N=:=B, O=:=1, 
          new8(s(A,M,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=1, L=:=B, 
          new16(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=D, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=D, M=:=E, 
          new12(s(A,M,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, M=:=E, 
          new8(s(A,M,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, M=:=E, 
          new8(s(A,M,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          new4(s(A,B,M,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=D, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=1, 
          new4(s(A,B,M,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=E, L=:=0, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
