new11(s(A),d(B)) :- C>=D+1, C=:=1, D=:=0, B=:=1.
new9(s(A),d(A)).
new7(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new4(s(A),d(B)).
new7(s(A),d(B)) :- C>=D+1, C=:=A, D=:=0, new9(s(A),d(B)).
new7(s(A),d(B)) :- C+1=<D, C=:=A, D=:=0, new9(s(A),d(B)).
new6(s(A),d(B)) :- new11(s(A),d(B)).
new5(s(A),d(B)) :- new12(s(A),d(B)).
new4(s(A),d(B)) :- new5(s(A),d(B)).
new4(s(A),d(B)) :- new6(s(A),d(C)), new7(s(C),d(B)).
new3(s(A),d(B)) :- new4(s(A),d(B)).
new2(s(A),d(B)) :- new3(s(A),d(B)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
