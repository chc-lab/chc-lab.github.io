new7(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=Q+R, Q=:=B, 
          R=:=1, S=:=T+U, T=:=E, U=:=1, new4(s(A,B,C,D,S,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=Q+R, Q=:=B, R=:=1, 
          new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=0, P=:=E, 
          new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=0, P=:=E, 
          new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=E, P=:=G, 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=B, P=:=0, Q=:=0, 
          R=:=S-T, S=:=U+V, U=:=Q, V=:=W+X, W=:=B, X=:=1, T=:=1, Y=:=Q, Z=:=R, 
          A1=:=Y, new4(s(A,B,Q,R,A1,Y,Z),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
