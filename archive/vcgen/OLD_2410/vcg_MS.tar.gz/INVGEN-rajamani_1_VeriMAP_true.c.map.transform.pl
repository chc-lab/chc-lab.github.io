new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=M*N, M=:=100, N=:=B, 
          O=:=P*Q, P=:= -1, Q=:=C, R=:=S+T, S=:=E, T=:=1, U=:=V+W, V=:=D, 
          W=:=10, new4(s(A,B,O,U,R),d(F,G,H,I,J)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=M*N, M=:=100, N=:=B, 
          O=:=P+Q, P=:=E, Q=:=1, R=:=S+T, S=:=D, T=:=10, 
          new4(s(A,B,C,R,O),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=C, L=:=M*N, M=:=10, N=:=E, 
          new16(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=C, L=:=M*N, M=:=10, N=:=E, 
          O=:=P+Q, P=:=E, Q=:=1, R=:=S+T, S=:=D, T=:=10, 
          new4(s(A,B,C,R,O),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=4, M=:=N+O, N=:=B, O=:=1, 
          P=:=Q+R, Q=:=C, R=:=1, S=:=T+U, T=:=E, U=:=1, V=:=W+X, W=:=D, X=:=10, 
          new4(s(A,M,P,V,S),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=4, M=:=N+O, N=:=E, 
          O=:=1, P=:=Q+R, Q=:=D, R=:=10, new4(s(A,B,C,P,M),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(A,B,C,D,E)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=C, L=:=2, 
          new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=4, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, M=:=N+O, N=:=B, O=:=1, 
          P=:=Q+R, Q=:=C, R=:=100, S=:=T+U, T=:=E, U=:=1, V=:=W+X, W=:=D, 
          X=:=10, new4(s(A,M,P,V,S),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, M=:=N+O, N=:=B, O=:=1, 
          P=:=Q+R, Q=:=C, R=:=100, S=:=T+U, T=:=E, U=:=1, V=:=W+X, W=:=D, 
          X=:=10, new4(s(A,M,P,V,S),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, M=:=0, N=:=0, 
          new4(s(A,K,L,M,N),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
