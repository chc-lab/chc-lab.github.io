new35(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=U-V, U=:=W-X, 
          W=:=Y*Z, Y=:=2, Z=:=C, X=:=A, V=:=E, T=:=0, A1=:=B1+C1, B1=:=A, 
          C1=:=B, D1=:=E1+F1, E1=:=E, F1=:=F, G1=:=H1+I1, H1=:=C, I1=:=D, 
          J1=:=K1+L1, K1=:=D, L1=:=1, M1=:=N1+O1, N1=:=G, O1=:=1, 
          new10(s(A1,B,G1,J1,D1,F,M1,H,P1),d(J,K,L,M,N,O,P,Q,R)).
new33(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=W-X, 
          W=:=Y*Z, Y=:=2, Z=:=C, X=:=A, V=:=E, T=:=0, A1=:=B1+C1, B1=:=A, 
          C1=:=B, D1=:=E1+F1, E1=:=E, F1=:=F, G1=:=H1+I1, H1=:=C, I1=:=D, 
          J1=:=K1-L1, K1=:=D, L1=:=1, M1=:=N1+O1, N1=:=G, O1=:=1, 
          new10(s(A1,B,G1,J1,D1,F,M1,H,P1),d(J,K,L,M,N,O,P,Q,R)).
new32(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=0, 
          new33(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new32(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=0, 
          new33(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new32(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=0, 
          new35(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new31(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=D, T=:=5, 
          new32(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new28(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U-V, U=:=B, 
          V=:=F, T=:=0, new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=W+X, 
          W=:=Y-Z, Y=:=B, Z=:=A1*B1, A1=:=2, B1=:=D, X=:=F, V=:=C1*D1, C1=:=2, 
          D1=:=G, T=:=0, new28(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U+V, U=:=W+X, 
          W=:=Y-Z, Y=:=B, Z=:=A1*B1, A1=:=2, B1=:=D, X=:=F, V=:=C1*D1, C1=:=2, 
          D1=:=G, T=:=0, new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new24(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=C, 
          V=:=W*X, W=:=5, X=:=G, T=:=75, 
          new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new24(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U+V, U=:=C, 
          V=:=W*X, W=:=5, X=:=G, T=:=75, 
          new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new22(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=D, 
          V=:=6, T=:=0, new24(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new22(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U+V, U=:=D, 
          V=:=6, T=:=0, new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=F, T=:=0, 
          new22(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=F, T=:=0, 
          new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new18(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=D, T=:=6, 
          new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new18(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=D, T=:=6, 
          new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new16(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=W*X, 
          W=:=5, X=:=G, V=:=75, T=:=C, 
          new18(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new16(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U+V, U=:=W*X, 
          W=:=5, X=:=G, V=:=75, T=:=C, 
          new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new15(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=W*X, 
          W=:=2, X=:=D, V=:=Y*Z, Y=:=2, Z=:=G, T=:=A1+B1, A1=:=B, B1=:=F, 
          new16(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=U+V, U=:=W*X, 
          W=:=2, X=:=D, V=:=Y*Z, Y=:=2, Z=:=G, T=:=A1+B1, A1=:=B, B1=:=F, 
          new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=B, T=:=5, 
          new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=B, T=:=5, 
          new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=D, 
          V=:=5, T=:=0, new31(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=0, 
          new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=0, 
          new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new9(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=D, T=:=5, 
          new10(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new8(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=D, V=:=5, 
          T=:=0, new9(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=U-V, U=:=W-X, 
          W=:=Y*Z, Y=:=2, Z=:=D, X=:=B, V=:=F, T=:=0, A1=:=0, 
          new8(s(A,B,C,D,E,F,A1,H,I),d(J,K,L,M,N,O,P,Q,R)).
new6(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=B, V=:=F, 
          T=:=0, new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new5(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=B, T=:=5, 
          new6(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new4(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=F, T=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=100, T=:=75, U=:= -50, 
          new4(s(S,B,T,D,U,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new1 :- new2(s,d).
correct :- \+new1.
