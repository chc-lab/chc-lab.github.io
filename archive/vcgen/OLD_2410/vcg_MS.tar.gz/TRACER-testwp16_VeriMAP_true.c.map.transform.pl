new8(s(A,B,C,D),d(A,B,C,D)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=1000, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=C, J=:=3, K=:=L+M, L=:=A, M=:=1, 
          N=:=O+P, O=:=K, P=:=1, new6(s(N,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=3, K=:=L+M, L=:=A, M=:=1, 
          new6(s(K,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=3, K=:=L+M, L=:=A, M=:=1, 
          new6(s(K,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=B, J=:=0, new5(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new6(s(K,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new6(s(K,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=D, K=:=D, new4(s(I,J,K,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
