new7(s(A,B,C,D,E),d(A,B,C,D,E)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=M+N, M=:=C, N=:=D, L=:=O*P, 
          O=:=3, P=:=A, new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=M+N, M=:=C, N=:=D, L=:=O*P, 
          O=:=3, P=:=A, new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          P=:=Q+R, Q=:=D, R=:=2, S=:=T+U, T=:=B, U=:=1, 
          new4(s(A,S,M,P,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          P=:=Q+R, Q=:=D, R=:=2, S=:=T+U, T=:=B, U=:=1, 
          new4(s(A,S,M,P,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=E, L=:=0, M=:=N+O, N=:=C, O=:=2, 
          P=:=Q+R, Q=:=D, R=:=1, S=:=T+U, T=:=B, U=:=1, 
          new4(s(A,S,M,P,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=A, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=A, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=0, M=:=0, N=:=0, O=:=0, 
          new4(s(A,M,N,O,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
correct :- \+new1.
