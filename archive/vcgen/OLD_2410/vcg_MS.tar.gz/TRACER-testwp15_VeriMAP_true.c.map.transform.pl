new9(s(A,B,C),d(A,B,C)).
new8(s(A,B,C),d(D,E,F)) :- G=<H, G=:=I+J, I=:=B, J=:=C, H=:=0, 
          new9(s(A,B,C),d(D,E,F)).
new7(s(A,B),d(C,B)) :- D>=E+1, D=:=B, E=:=0, C=:=3.
new7(s(A,B),d(A,C)) :- D=<E, D=:=B, E=:=0, C=:=1.
new4(s(A,B,C),d(D,B,C)) :- new6(s(A,E),d(D,F)).
new4(s(A,B,C),d(D,E,F)) :- G=:=H, new7(s(A,I),d(J,H)), new8(s(J,B,G),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=0, I=:=2, new4(s(I,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=0, I=:=0, new4(s(A,I,C),d(D,E,F)).
new2(s(A),d(B)) :- new3(s(A,C,D),d(B,E,F)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
