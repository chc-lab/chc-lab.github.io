new6(s(A,B),d(A,B)).
new4(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=50, new6(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=2, H=:=I+J, I=:=G, J=:=1, 
          K=:=L+M, L=:=H, M=:=2, new4(s(K,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=47, H=:=I+J, I=:=G, J=:=1, 
          K=:=L+M, L=:=H, M=:=2, new4(s(K,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
correct :- \+new1.
