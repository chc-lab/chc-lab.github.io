new53(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new13(s(A,B,C),d(D,E,F)).
new50(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new13(s(A,B,C),d(D,E,F)).
new47(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new13(s(A,B,C),d(D,E,F)).
new44(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=B, new47(s(A,B,C),d(D,E,F)).
new44(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=B, new13(s(A,B,C),d(D,E,F)).
new42(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=A, new44(s(A,B,C),d(D,E,F)).
new42(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new29(s(A,B,C),d(D,E,F)).
new42(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, new29(s(A,B,C),d(D,E,F)).
new40(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=A, I=:=J+K, J=:=B, K=:=1, 
          new42(s(A,I,C),d(D,E,F)).
new40(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new13(s(A,B,C),d(D,E,F)).
new37(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=B, new40(s(A,B,C),d(D,E,F)).
new37(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=B, new13(s(A,B,C),d(D,E,F)).
new34(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new13(s(A,B,C),d(D,E,F)).
new30(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=A, I=:=J+K, J=:=B, K=:=1, 
          new18(s(A,I,C),d(D,E,F)).
new30(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new13(s(A,B,C),d(D,E,F)).
new29(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=B, new30(s(A,B,C),d(D,E,F)).
new29(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=B, new13(s(A,B,C),d(D,E,F)).
new27(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=B, new34(s(A,B,C),d(D,E,F)).
new27(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=B, new13(s(A,B,C),d(D,E,F)).
new26(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new27(s(A,B,C),d(D,E,F)).
new26(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new27(s(A,B,C),d(D,E,F)).
new26(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, new29(s(A,B,C),d(D,E,F)).
new24(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new37(s(A,B,C),d(D,E,F)).
new24(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new37(s(A,B,C),d(D,E,F)).
new24(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, new29(s(A,B,C),d(D,E,F)).
new22(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new24(s(A,B,C),d(D,E,F)).
new22(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new24(s(A,B,C),d(D,E,F)).
new22(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, new26(s(A,B,C),d(D,E,F)).
new21(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=B, new50(s(A,B,C),d(D,E,F)).
new21(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=B, new13(s(A,B,C),d(D,E,F)).
new20(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=A, new21(s(A,B,C),d(D,E,F)).
new20(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new22(s(A,B,C),d(D,E,F)).
new20(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, new22(s(A,B,C),d(D,E,F)).
new18(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=1, H=:=0, new20(s(A,B,C),d(D,E,F)).
new16(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=A, I=:=J+K, J=:=B, K=:=1, 
          new18(s(A,I,C),d(D,E,F)).
new16(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new13(s(A,B,C),d(D,E,F)).
new13(s(A,B,C),d(A,B,C)).
new12(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=A, I=:=J+K, J=:=B, K=:=1, 
          new4(s(A,I,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new13(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=B, new12(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=B, new13(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=B, new16(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=B, new13(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new9(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new9(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, new11(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G=<H, G=:=0, H=:=B, new53(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=0, H=:=B, new13(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=A, new6(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, new7(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=1, H=:=0, new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=1, I=:=0, J=:=K-L, K=:=A, L=:=1, 
          new4(s(J,I,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
