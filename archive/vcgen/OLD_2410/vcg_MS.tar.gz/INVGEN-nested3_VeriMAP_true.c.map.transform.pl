new13(s(A,B,C,D),d(A,B,C,D)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=C, K=:=L+M, L=:=A, M=:=1, 
          new9(s(K,B,C,D),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=A, J=:=C, K=:=L+M, L=:=B, M=:=1, 
          new4(s(A,K,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=1, J=:=A, K=:=L+M, L=:=A, M=:=1, 
          new7(s(K,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=1, J=:=A, 
          new13(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=C, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=A, J=:=C, K=:=D, 
          new9(s(K,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=C, K=:=D, 
          new7(s(K,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=1, 
          new4(s(A,K,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=D, J=:=0, new5(s(A,B,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
