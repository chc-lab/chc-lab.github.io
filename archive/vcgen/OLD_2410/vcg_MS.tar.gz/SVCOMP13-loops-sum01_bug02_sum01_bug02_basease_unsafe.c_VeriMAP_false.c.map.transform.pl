new9(s(A,B,C,D),d(A,B,C,D)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, 
          new9(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=0, 
          new9(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=K*L, K=:=B, L=:=2, 
          new7(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=K*L, K=:=B, L=:=2, 
          new7(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=4, K=:= -10, L=:=M+N, M=:=A, 
          N=:=1, new4(s(L,B,C,K),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=4, K=:=L+M, L=:=A, M=:=1, 
          new4(s(K,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=4, K=:=L+M, L=:=A, M=:=1, 
          new4(s(K,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=A, J=:=B, K=:=L+M, L=:=D, M=:=2, 
          new5(s(A,B,C,K),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=B, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, J>=0, K=:=I, I>=0, L=:=0, M=:=1, 
          new4(s(M,K,I,L),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
