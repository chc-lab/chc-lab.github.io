new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=C, O=:=P+Q, P=:=D, 
          Q=:=1, R=:=S+T, S=:=C, T=:=1, new5(s(A,B,R,O,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=C, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, O=:=P+Q, P=:=D, 
          Q=:=1, R=:=S+T, S=:=C, T=:=1, U=:=V+W, V=:=O, W=:=1, X=:=Y+Z, Y=:=R, 
          Z=:=1, A1=:=B1+C1, B1=:=U, C1=:=1, 
          new5(s(A,B,X,A1,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O+P, O=:=C, P=:=1, N=:=B, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O+P, O=:=C, P=:=1, N=:=B, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=F, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=F, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=B, 
          new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=B, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=B, O=:=0, 
          new5(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N-O, N=:=E, O=:=4, P=:=0, 
          new4(s(A,B,P,D,E,M),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
