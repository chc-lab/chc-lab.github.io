new7(s(A,B,C,D),d(A,B,C,D)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=D, D>=0, J=:=A, A>=0, 
          new7(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, C>=0, J=:=0, K=:=L-M, L=:=C, 
          C>=0, M=:=1, N=:=O+P, O=:=D, D>=0, P=:=1, new4(s(A,B,K,N),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=C, C>=0, J=:=0, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, J>=0, K=:=I, I>=0, L=:=K, K>=0, M=:=0, 
          new4(s(K,I,L,M),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
