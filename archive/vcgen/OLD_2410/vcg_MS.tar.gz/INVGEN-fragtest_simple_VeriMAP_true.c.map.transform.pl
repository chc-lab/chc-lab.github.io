new17(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)).
new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=G, P=:=F, 
          new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=0, Q=:=R-S, R=:=E, 
          S=:=1, T=:=U-V, U=:=B, V=:=1, W=:=X+Y, X=:=G, Y=:=1, 
          new16(s(A,T,C,D,Q,F,W),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=0, 
          new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, Q=:=0, R=:=B, 
          new15(s(A,B,C,D,E,R,Q),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, Q=:=B, 
          R=:=S+T, S=:=B, T=:=1, U=:=V+W, V=:=E, W=:=1, 
          new8(s(A,R,C,Q,U,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, Q=:=B, 
          R=:=S+T, S=:=B, T=:=1, U=:=V+W, V=:=E, W=:=1, 
          new8(s(A,R,C,Q,U,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=B, P=:=C, Q=:=B, R=:=0, 
          new8(s(A,R,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=B, P=:=C, Q=:=0, 
          new8(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, Q=:=R+S, 
          R=:=B, S=:=1, new4(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, Q=:=R+S, 
          R=:=B, S=:=1, new4(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, 
          new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P=:=0, 
          new4(s(A,P,C,D,O,F,G),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
