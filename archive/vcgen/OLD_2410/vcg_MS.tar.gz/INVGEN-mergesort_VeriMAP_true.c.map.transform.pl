new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=0, A1=:=B1+C1, B1=:=B, C1=:=1, D1=:=E1+F1, E1=:=E, F1=:=1, 
          new8(s(A,A1,C,D,D1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=0, A1=:=B1+C1, B1=:=B, C1=:=1, D1=:=E1+F1, E1=:=E, F1=:=1, 
          new8(s(A,A1,C,D,D1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=0, A1=:=B1+C1, B1=:=I, C1=:=1, D1=:=E1+F1, E1=:=E, F1=:=1, 
          new8(s(A,B,C,D,D1,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=H, A1=:=B1+C1, B1=:=E, C1=:=1, 
          new17(s(A,B,C,D,A1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=E, 
          Z=:=H, A1=:=B1+C1, B1=:=L, C1=:=D1*E1, D1=:=J, E1=:=2, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,A1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=H, A1=:=B1+C1, B1=:=I, C1=:=1, D1=:=E1+F1, E1=:=E, F1=:=1, 
          new15(s(A,B,C,D,D1,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=I, 
          Z=:=H, A1=:=F, 
          new17(s(A,B,C,D,A1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=G, A1=:=B1+C1, B1=:=B, C1=:=1, D1=:=E1+F1, E1=:=E, F1=:=1, 
          new12(s(A,A1,C,D,D1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=B, 
          Z=:=G, new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=<Z, Y=:=E, 
          Z=:=C, new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=C, new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=H, new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=I, 
          Z=:=H, new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=G, new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=B, 
          Z=:=G, new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=C, A1=:=B1+C1, B1=:=C, C1=:=1, D1=:=L, E1=:=F1+G1, F1=:=L, 
          G1=:=J, H1=:=A1, I1=:=D1, J1=:=E1, K1=:=D1, 
          new8(s(A,I1,C,D,K1,D1,E1,H1,J1,J,A1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=<Z, Y=:=K, 
          Z=:=C, A1=:=L, B1=:=C1+D1, C1=:=L, D1=:=J, E1=:=K, F1=:=A1, G1=:=B1, 
          H1=:=A1, 
          new8(s(A,F1,C,D,H1,A1,B1,E1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=<Z, Y=:=A1+B1, 
          A1=:=L, B1=:=J, Z=:=C, C1=:=D1+E1, D1=:=L, E1=:=F1*G1, F1=:=J, 
          G1=:=2, new6(s(A,B,C,D,E,F,G,H,I,J,C1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, 
          Y=:=A1+B1, A1=:=L, B1=:=J, Z=:=C, C1=:=D1*E1, D1=:=J, E1=:=2, 
          new4(s(A,B,C,D,E,F,G,H,I,C1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=C, A1=:=1, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,A1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=1, 
          new4(s(A,B,C,D,E,F,G,H,I,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=0, 
          K=:=0, L=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
correct :- \+new1.
