new11(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=O+P, O=:=B, P=:=C, N=:=Q+R, 
          Q=:=S+T, S=:=E, T=:=D, R=:=F, U=:=V+W, V=:=D, W=:=1, 
          new6(s(A,B,C,U,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=O+P, O=:=B, P=:=C, N=:=Q+R, 
          Q=:=S+T, S=:=E, T=:=D, R=:=F, new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=O+P, O=:=E, P=:=F, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=O+P, O=:=E, P=:=F, 
          Q=:=R+S, R=:=C, S=:=1, new5(s(A,B,Q,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=E, O=:=C, 
          new6(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=E, O=:=P+Q, P=:=B, 
          Q=:=1, new4(s(A,O,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=E, O=:=0, 
          new5(s(A,B,O,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=F, O=:=0, 
          new4(s(A,O,C,D,E,F),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
