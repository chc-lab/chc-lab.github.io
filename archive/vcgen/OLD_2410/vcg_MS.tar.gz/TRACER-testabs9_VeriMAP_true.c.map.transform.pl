new5(s(A,B),d(A,B)).
new4(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=0, new5(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=:=99, F=:=0, new4(s(F,E),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
correct :- \+new1.
