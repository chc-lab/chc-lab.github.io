new15(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=F, R=:=0, S=:=T-U, 
          T=:=B, U=:=A, V=:=W, X=:=Y-Z, Y=:=E, Z=:=1, 
          new12(s(A,S,V,D,X,F,G,W),d(I,J,K,L,M,N,O,P)).
new15(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=F, R=:=0, S=:=T-U, 
          T=:=B, U=:=A, V=:=W, X=:=Y-Z, Y=:=E, Z=:=1, 
          new12(s(A,S,V,D,X,F,G,W),d(I,J,K,L,M,N,O,P)).
new15(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=F, R=:=0, S=:=T-U, 
          T=:=C, U=:=A, new12(s(A,B,S,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=C, R=:=0, S=:=T, 
          new15(s(A,B,C,D,E,S,T,H),d(I,J,K,L,M,N,O,P)).
new13(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)).
new12(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=B, R=:=0, 
          new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=E, R=:=1, 
          new12(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=E, R=:=1, 
          new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new9(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=E, R=:=D, S=:=T*U, 
          T=:=2, U=:=E, new9(s(A,B,C,D,S,F,G,H),d(I,J,K,L,M,N,O,P)).
new9(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=E, R=:=D, 
          new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=1, 
          new9(s(A,B,C,D,Q,F,G,H),d(I,J,K,L,M,N,O,P)).
new7(s(A,B),d(A,B)) :- C=:=2, new8(s(C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R)).
new5(s(A,B),d(A,B)) :- C=:=1, new8(s(C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R)).
new4(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=0, new5(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=0, new5(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E=:=F, E=:=A, F=:=0, new7(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=:=F, new4(s(E,F),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
correct :- \+new1.
