new18(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new16(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=<V, U=:=J, V=:=E, 
          W=:=X+Y, X=:=J, Y=:=1, 
          new18(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new16(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=J, V=:=E, 
          new8(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new15(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=<V, U=:=0, V=:=J, 
          new16(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new15(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=0, V=:=J, 
          new8(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new14(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=<V, U=:=J, V=:=E, 
          new15(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new13(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=1, V=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new11(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new9(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=A, V=:=0, 
          new11(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new9(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=A, V=:=0, 
          new11(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new9(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=0, 
          W=:=0, new13(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new8(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)).
new7(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=<V, U=:=C, V=:=E, 
          new9(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new7(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=C, V=:=E, 
          new8(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=<V, U=:=0, V=:=C, 
          new7(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=0, V=:=C, 
          new8(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=A, V=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=A, V=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new3(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=E, V=:=0, 
          W=:=0, X=:=0, Y=:=E, Z=:=0, A1=:=0, B1=:=E, C1=:=0, 
          new4(s(A,W,X,Y,E,C1,Z,A1,B1,J),d(K,L,M,N,O,P,Q,R,S,T)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H,I,J,K),d(B,L,M,N,O,P,Q,R,S,T)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
