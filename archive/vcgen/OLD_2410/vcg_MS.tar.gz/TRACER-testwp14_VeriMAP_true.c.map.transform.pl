new9(s(A,B,C),d(A,B,C)).
new7(s(A,B,C),d(D,E,F)) :- new7(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=4, new9(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=A, new6(s(A,I,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=0, new7(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=4, I=:=4, new4(s(A,B,I),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=4, I=:=5, new4(s(I,B,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
