new19(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          P=:=Q+R, Q=:=D, R=:=1, S=:=T-U, T=:=E, U=:=1, 
          new8(s(A,B,M,P,S),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=A, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=A, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=0, L=:=C, 
          new17(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=0, L=:=C, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=A, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=A, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=0, L=:=D, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=0, L=:=D, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=1, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(A,B,C,D,E)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=0, N=:=0, 
          new8(s(A,B,M,N,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, M=:=0, N=:=0, 
          new8(s(A,B,M,N,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=0, L=:=M-N, M=:=A, N=:=1, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=0, L=:=M-N, M=:=A, N=:=1, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=A, new4(s(A,B,C,D,K),d(F,G,H,I,J)).
new2(s(A,B),d(C,D)) :- new3(s(A,B,E,F,G),d(C,D,H,I,J)).
new1 :- A=:=0, B=:=0, new2(s(A,B),d(C,D)).
correct :- \+new1.
