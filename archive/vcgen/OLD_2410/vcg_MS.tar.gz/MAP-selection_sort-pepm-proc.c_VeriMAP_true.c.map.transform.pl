new23(s(A,B,C,D,E),d(A,B,C,D,E)) :- F>=G, F=:= -1, G=:=D.
new23(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:= -1, L=:=D, M=:=N+O, N=:=C, 
          O=:=1, new8(s(A,B,M,D,E),d(F,G,H,I,J)).
new22(s(A,B,C,D,E),d(A,B,C,D,E)) :- F>=G, F=:=D, G=:=A.
new22(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=A, 
          new23(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(A,B,C,D,E)) :- F>=G, F=:= -1, G=:=B.
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:= -1, L=:=B, 
          new22(s(A,B,C,D,E),d(F,G,H,I,J)).
new18(s(A,B,C,D,E),d(A,B,C,D,E)) :- F>=G, F=:=B, G=:=A.
new18(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=A, 
          new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=D, 
          new18(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=D, 
          new18(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=D, M=:=N+O, N=:=C, O=:=1, 
          new8(s(A,B,M,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=C, 
          new15(s(A,B,C,M,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, M=:=C, 
          new15(s(A,B,C,M,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=E, L=:=0, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(A,B,C,D,E)) :- F>=G, F=:= -1, G=:=D.
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:= -1, L=:=D, 
          new14(s(A,B,C,D,M),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(A,B,C,D,E)) :- F>=G, F=:=D, G=:=A.
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=A, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F>=G, F=:= -1, G=:=C.
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:= -1, L=:=C, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(A,B,C,D,E)) :- F>=G, F=:=C, G=:=A.
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=A, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=A, 
          new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=A, M=:=N+O, N=:=B, O=:=1, 
          new5(s(A,M,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=M-N, M=:=A, N=:=1, O=:=B, 
          P=:=Q+R, Q=:=B, R=:=1, new8(s(A,B,P,O,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=0, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, M=:=0, 
          new4(s(A,K,L,M,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
correct :- \+new1.
