new27(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new28(s(M,B,C,D,E),d(F,G,H,I,J)).
new27(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new28(s(M,B,C,D,E),d(F,G,H,I,J)).
new27(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, 
          new28(s(A,B,C,D,E),d(F,G,H,I,J)).
new24(s(A,B,C,D,E),d(F,B,C,D,E)) :- G>=H+1, G=:=D, H=:=0, F=:=I-J, I=:=A, J=:=1.
new24(s(A,B,C,D,E),d(F,B,C,D,E)) :- G+1=<H, G=:=D, H=:=0, F=:=I-J, I=:=A, J=:=1.
new24(s(A,B,C,D,E),d(F,B,C,D,E)) :- G=:=H, G=:=D, H=:=0, F=:=I+J, I=:=A, J=:=10.
new23(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new24(s(M,B,C,D,E),d(F,G,H,I,J)).
new23(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new24(s(M,B,C,D,E),d(F,G,H,I,J)).
new23(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, 
          new24(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=M, N=:=O, 
          new23(s(K,L,M,N,O),d(F,G,H,I,J)).
new20(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=M, N=:=O, 
          new27(s(K,L,M,N,O),d(F,G,H,I,J)).
new19(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)).
new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=B, R=:=0, 
          new19(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=B, R=:=0, S=:=T-U, 
          T=:=B, U=:=A, new14(s(A,S,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=<R, Q=:=B, R=:=0, 
          new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=E, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, new14(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=E, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, new14(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=E, R=:=0, 
          new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new11(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)) :- 
          new20(s(I,J,K,L,M),d(N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new21(s(Q,R,S,T,U),d(V,W,X,Y,Z)), 
          new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=C, R=:=0, 
          new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=C, R=:=0, 
          new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=C, R=:=0, 
          new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new8(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)) :- new20(s(I,J,K,L,M),d(N,O,P,Q,R)).
new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, S=:=T, 
          new21(s(U,V,W,X,Y),d(Z,A1,B1,C1,D1)), 
          new10(s(A,B,Q,D,S,F,R,T),d(I,J,K,L,M,N,O,P)).
new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=E, R=:=0, 
          new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=E, R=:=0, 
          new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=E, R=:=0, S=:=T, 
          U=:=V, new10(s(A,B,S,D,U,F,T,V),d(I,J,K,L,M,N,O,P)).
new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=C, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, new5(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=C, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, new5(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=C, R=:=0, 
          new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=1, R=:=S, T=:=U, 
          new4(s(Q,B,R,S,T,U,G,H),d(I,J,K,L,M,N,O,P)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new1 :- new2(s,d).
correct :- \+new1.
