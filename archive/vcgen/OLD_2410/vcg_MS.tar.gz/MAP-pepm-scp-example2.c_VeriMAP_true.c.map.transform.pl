new9(s(A,B,C,D),d(A,E,C,D)) :- E=:=F+G, F=:=B, G=:=D.
new7(s(A,B,C),d(A,B,C)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=B, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=:=A, new8(s(A,B,C,G),d(D,E,F,H)).
new5(s(A,B,C),d(D,E,F)) :- G=:=A, new9(s(A,B,C,G),d(H,I,J,K)), 
          new4(s(H,I,J),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new5(s(I,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- new4(s(A,B,C),d(D,E,F)).
new2(s(A,B,C),d(D,E,F)) :- new3(s(A,B,C),d(D,E,F)).
new1 :- A=:=0, B=:=0, C=:=0, new2(s(A,B,C),d(D,E,F)).
correct :- \+new1.
