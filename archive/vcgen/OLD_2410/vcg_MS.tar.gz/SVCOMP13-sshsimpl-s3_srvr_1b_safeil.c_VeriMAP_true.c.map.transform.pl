new36(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=8656, 
          new26(s(M,B,C,D,E),d(F,G,H,I,J)).
new36(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=8656, 
          new26(s(M,B,C,D,E),d(F,G,H,I,J)).
new36(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, M=:=8512, 
          new26(s(M,B,C,D,E),d(F,G,H,I,J)).
new29(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, M=:=8656, 
          new26(s(M,B,C,D,E),d(F,G,H,I,J)).
new26(s(A,B,C,D,E),d(F,G,H,I,J)) :- new4(s(A,B,C,D,E),d(F,G,H,I,J)).
new22(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=G, F=:=D, G=:=5.
new22(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=5, 
          new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new22(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=5, 
          new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=8640, 
          new26(s(M,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=8640, 
          new26(s(M,B,C,D,E),d(F,G,H,I,J)).
new18(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=4, M=:=5, 
          new21(s(A,B,C,M,E),d(F,G,H,I,J)).
new18(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=4, 
          new22(s(A,B,C,D,E),d(F,G,H,I,J)).
new18(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=4, 
          new22(s(A,B,C,D,E),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=2, M=:=3, 
          new18(s(A,B,C,M,E),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=2, 
          new18(s(A,B,C,D,E),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=2, 
          new18(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=8656, 
          new17(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=3, M=:=4, 
          new29(s(A,B,C,M,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=3, 
          new29(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=3, 
          new29(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=8640, 
          new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=8640, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=8640, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=8466, 
          new26(s(M,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, M=:=8466, 
          new26(s(M,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=E, L=:=0, M=:=8640, 
          new26(s(M,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=8512, 
          new11(s(A,B,C,D,M),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=8512, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=8512, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=0, M=:=2, 
          new36(s(A,B,C,M,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=0, 
          new36(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=0, 
          new36(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=8466, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=8466, 
          new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=8466, 
          new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(A,B,C,D,E)) :- F>=G+1, F=:=D, G=:=2.
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=D, L=:=2, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=A, L=:=8512, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=8512, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=1, L=:=0, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, M=:=8466, N=:=0, 
          new4(s(M,K,L,N,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
correct :- \+new1.
