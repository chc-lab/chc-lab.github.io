new200(s(A,B,C,D,E,F,G,H,I),d(A,B,C,J,E,F,G,H,I)) :- K=:=L, K=:=F, L=:=1, J=:=0.
new200(s(A,B,C,D,E,F,G,H,I),d(A,B,C,J,E,F,G,H,I)) :- K>=L+1, K=:=F, L=:=1, 
          J=:=2.
new200(s(A,B,C,D,E,F,G,H,I),d(A,B,C,J,E,F,G,H,I)) :- K+1=<L, K=:=F, L=:=1, 
          J=:=2.
new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=0, 
          U=:=1, new197(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=0, 
          new197(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=0, 
          new197(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new191(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,J)) :- K=:=L, K=:=I, L=:=0, J=:=1.
new191(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J>=K+1, J=:=I, K=:=0.
new191(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J+1=<K, J=:=I, K=:=0.
new188(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=0, 
          U=:=1, new191(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new188(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=0, 
          new191(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new188(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=0, 
          new191(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new183(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=B, V=:=1, 
          new186(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new180(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,J,K)) :- 
          new183(s(A,B,C,D,E,F,G,H,I,U),d(L,M,N,O,P,Q,R,S,T,V)).
new180(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new173(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new185(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,J,W),d(L,M,N,O,P,Q,R,S,T,U,V)).
new179(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, Y=:=0, 
          new180(s(A,B,Y,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new179(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, Y=:=0, 
          new180(s(A,B,Y,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new179(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, new180(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new177(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=1, 
          new187(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new176(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L=:=M, L=:=G, M=:=1, 
          K=:=1.
new176(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L>=M+1, L=:=G, M=:=1, 
          K=:=0.
new176(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L+1=<M, L=:=G, M=:=1, 
          K=:=0.
new175(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L=:=M, L=:=I, M=:=1, 
          K=:=1.
new175(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L>=M+1, L=:=I, M=:=1, 
          K=:=0.
new175(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L+1=<M, L=:=I, M=:=1, 
          K=:=0.
new174(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,L,E,F,G,H,I,J,K)) :- M>=N+1, M=:=K, 
          N=:=0, L=:=0.
new174(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,L,E,F,G,H,I,J,K)) :- M+1=<N, M=:=K, 
          N=:=0, L=:=0.
new174(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=M, L=:=K, 
          M=:=0.
new173(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L>=M+1, L=:=B, M=:=1, 
          K=:=0.
new173(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L+1=<M, L=:=B, M=:=1, 
          K=:=0.
new173(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=B, V=:=1, 
          new175(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new170(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new173(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new174(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,J,W),d(L,M,N,O,P,Q,R,S,T,U,V)).
new169(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, Y=:=0, 
          new170(s(A,B,Y,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new169(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, Y=:=0, 
          new170(s(A,B,Y,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new169(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, new170(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new168(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L>=M+1, L=:=A, M=:=1, 
          K=:=0.
new168(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L+1=<M, L=:=A, M=:=1, 
          K=:=0.
new168(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=1, 
          new176(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new162(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=1, 
          U=:=2, new165(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new162(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=1, 
          new165(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new162(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=1, 
          new165(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new159(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,J)) :- K=:=L, K=:=I, L=:=1, J=:=2.
new159(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J>=K+1, J=:=I, K=:=1.
new159(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J+1=<K, J=:=I, K=:=1.
new156(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=1, 
          U=:=2, new159(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new156(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=1, 
          new159(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new156(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=1, 
          new159(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new152(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,S,T),d(J,K,L,M,N,O,P,Q,R,U,V)).
new151(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new152(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new151(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=2, 
          new111(s(A,B,C,D,E,F,G,H,I),d(T,U,V,W,X,Y,Z,A1,B1)), 
          new150(s(T,U,V,W,X,Y,Z,A1,S),d(J,K,L,M,N,O,P,Q,R)).
new147(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new150(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new145(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=A, T=:=1, 
          new147(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new145(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=A, T=:=1, 
          new144(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new145(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=1, 
          new144(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new144(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=1, T=:=0, 
          U=:=1, new151(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new141(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=A, T=:=0, 
          new144(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new141(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=A, T=:=0, 
          new145(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new141(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=0, 
          new145(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new141(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new101(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new121(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new135(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=B, T=:=1, 
          new135(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=B, T=:=1, 
          new132(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=B, T=:=1, 
          new132(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new129(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=B, T=:=0, 
          new132(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new129(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=B, T=:=0, 
          new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new129(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=B, T=:=0, 
          new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new129(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new90(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new114(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=L, 
          Z=:=0, A1=:=1, 
          new126(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=L, 
          Z=:=0, A1=:=1, 
          new126(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=L, 
          Z=:=0, new114(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=D, 
          Z=:=0, new123(s(A,B,C,D,E,F,G,H,I,J,K,A1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=D, 
          Z=:=0, new114(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=D, 
          Z=:=0, new114(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=0, A1=:=1, 
          new138(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=0, A1=:=1, 
          new138(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=0, new121(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=C, 
          Z=:=0, new120(s(A,B,C,D,E,F,G,H,I,J,A1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=C, 
          Z=:=0, new121(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=C, 
          Z=:=0, new121(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new118(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new118(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,V),d(M,N,O,P,Q,R,S,T,U,W)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, 
          new37(s(A,B,C,D,E,F,G,H,I,A1),d(B1,C1,D1,E1,F1,G1,H1,I1,J1,Z)), 
          new117(s(B1,C1,D1,E1,F1,G1,H1,I1,J1,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new111(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,S,T),d(J,K,L,M,N,O,P,Q,R,U,V)).
new110(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=2, 
          new111(s(A,B,C,D,E,F,G,H,I),d(T,U,V,W,X,Y,Z,A1,B1)), 
          new109(s(T,U,V,W,X,Y,Z,A1,S),d(J,K,L,M,N,O,P,Q,R)).
new109(s(A,B,C,D,E,F,G,H,I),d(J,B,K,D,E,F,G,H,I)) :- L>=M+1, L=:=1, M=:=0, 
          J=:=1, K=:=2.
new106(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new109(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new104(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=A, T=:=1, 
          new106(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new104(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=A, T=:=1, 
          new103(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new104(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=1, 
          new103(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new103(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=1, T=:=0, 
          U=:=1, new110(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new101(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=A, T=:=0, 
          new103(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new101(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=A, T=:=0, 
          new104(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new101(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=0, 
          new104(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new101(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new82(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new93(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=B, T=:=1, 
          new95(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new93(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=B, T=:=1, 
          new92(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new93(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=B, T=:=1, 
          new92(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new92(s(A,B,C,D,E,F,G,H,I),d(A,J,C,K,E,F,G,H,I)) :- L>=M+1, L=:=1, M=:=0, 
          J=:=1, K=:=2.
new90(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=B, T=:=0, 
          new92(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new90(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=B, T=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new90(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=B, T=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new90(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new76(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=L, 
          Z=:=0, A1=:=1, 
          new87(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=L, 
          Z=:=0, A1=:=1, 
          new87(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=L, 
          Z=:=0, new76(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new82(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=D, 
          Z=:=0, new84(s(A,B,C,D,E,F,G,H,I,J,K,A1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new82(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=D, 
          Z=:=0, new76(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new82(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=D, 
          Z=:=0, new76(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=0, A1=:=1, 
          new98(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=0, A1=:=1, 
          new98(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=0, new82(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new79(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=C, 
          Z=:=0, new81(s(A,B,C,D,E,F,G,H,I,J,A1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new79(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=C, 
          Z=:=0, new82(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new79(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=C, 
          Z=:=0, new82(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- M=:=N, M=:=J, 
          N=:=0.
new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new79(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new79(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new76(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, 
          new37(s(A,B,C,D,E,F,G,H,I,A1),d(B1,C1,D1,E1,F1,G1,H1,I1,J1,Z)), 
          new78(s(B1,C1,D1,E1,F1,G1,H1,I1,J1,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L=:=M, L=:=D, M=:=0, 
          K=:=1.
new72(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L>=M+1, L=:=D, M=:=0, 
          K=:=0.
new72(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L+1=<M, L=:=D, M=:=0, 
          K=:=0.
new66(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=1, U=:=2, 
          new69(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new66(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new66(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new63(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,J)) :- K=:=L, K=:=I, L=:=1, J=:=2.
new63(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J>=K+1, J=:=I, K=:=1.
new63(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J+1=<K, J=:=I, K=:=1.
new60(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=1, U=:=2, 
          new63(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new60(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=1, 
          new63(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new60(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=1, 
          new63(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new58(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new60(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new58(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new58(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new57(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new66(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new57(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=1, 
          new66(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new57(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=1, 
          new66(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new57(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new58(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new40(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,V,W),d(M,N,O,P,Q,R,S,T,U,X,Y)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new56(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new52(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,J,H,I)) :- J=:=1.
new47(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,L)) :- M>=N+1, M=:=J, 
          N=:=0, L=:=0.
new47(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,L)) :- M+1=<N, M=:=J, 
          N=:=0, L=:=0.
new47(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,L)) :- M=:=N, M=:=J, 
          N=:=0, L=:=1.
new44(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=L, 
          Z=:=0, new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new37(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new47(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new42(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,J,K)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,U),d(L,M,N,O,P,Q,R,S,T,V)).
new42(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new37(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new50(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new42(s(A,B,C,D,E,F,G,H,I,V,W),d(M,N,O,P,Q,R,S,T,U,X,Y)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, 
          new43(s(A,B,C,D,E,F,G,H,I,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,Z)), 
          new44(s(C1,D1,E1,F1,G1,H1,I1,J1,K1,J,K,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new51(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new52(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new53(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=0, A1=:=4, 
          new39(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=0, new40(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=0, new40(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new37(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,K)) :- L=:=M, L=:=C, M=:=0, 
          K=:=1.
new37(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=C, V=:=0, 
          new72(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new37(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=C, V=:=0, 
          new72(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new36(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=C, V=:=0, 
          new74(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new36(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=C, V=:=0, 
          new74(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,V),d(M,N,O,P,Q,R,S,T,U,W)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, 
          new37(s(A,B,C,D,E,F,G,H,I,A1),d(B1,C1,D1,E1,F1,G1,H1,I1,J1,Z)), 
          new38(s(B1,C1,D1,E1,F1,G1,H1,I1,J1,J,Y,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new19(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new20(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new35(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,V,W),d(M,N,O,P,Q,R,S,T,U,X,Y)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new32(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new13(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new14(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new29(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=3, 
          new26(s(A,B,C,D,E,F,G,H,I,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new76(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new23(s(A,B,C,D,E,F,G,H,I,V,W,X),d(M,N,O,P,Q,R,S,T,U,Y,Z,A1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, 
          new24(s(A,B,C,D,E,F,G,H,I,Z,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)), 
          new25(s(C1,D1,E1,F1,G1,H1,I1,J1,K1,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=1, 
          Z=:=0, A1=:=1, 
          new22(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new156(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=1, 
          new156(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=1, 
          new156(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new162(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=1, 
          new162(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=1, 
          new162(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new19(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new20(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new21(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new17(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new168(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new169(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new16(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,J,K)) :- 
          new177(s(A,B,C,D,E,F,G,H,I,U),d(L,M,N,O,P,Q,R,S,T,V)).
new16(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new168(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new179(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,V,W),d(M,N,O,P,Q,R,S,T,U,X,Y)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new18(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=0, U=:=1, 
          new188(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=0, 
          new188(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=0, 
          new188(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=0, U=:=1, 
          new194(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=0, 
          new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=0, 
          new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new13(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new14(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new15(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=E, T=:=1, U=:=0, 
          new200(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=E, T=:=1, 
          U=:=2, new200(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=E, T=:=1, 
          U=:=2, new200(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=E, T=:=1, U=:=0, 
          new203(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=E, T=:=1, 
          U=:=2, new203(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=E, T=:=1, 
          U=:=2, new203(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new10(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new11(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new12(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new6(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,J)) :- 
          new7(s(A,B,C,D,E,F,G,H,I,T,U,V),d(K,L,M,N,O,P,Q,R,S,W,X,Y)).
new5(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,J,K,G,H,I)) :- J=:=1, K=:=1.
new3(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,J)) :- 
          new4(s(A,B,C,D,E,F,G,H,I),d(K,L,M,N,O,P,Q,R,S)).
new3(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- 
          new5(s(A,B,C,D,E,F,G,H,I),d(U,V,W,X,Y,Z,A1,B1,C1)), 
          new6(s(U,V,W,X,Y,Z,A1,B1,C1,J),d(K,L,M,N,O,P,Q,R,S,T)).
new2(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,S),d(J,K,L,M,N,O,P,Q,R,T)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, 
          new2(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
correct :- \+new1.
