new13(s(A,B,C,D),d(A,B,C,D)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=L+M, L=:=C, M=:=1, 
          N=:=O-P, O=:=D, P=:=1, new10(s(A,B,K,N),d(E,F,G,H)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=D, J=:=0, 
          new13(s(A,B,C,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=A, 
          new11(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=B, K=:=L+M, L=:=C, M=:=1, 
          N=:=O-P, O=:=D, P=:=1, new8(s(A,B,K,N),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=B, K=:=0, 
          new10(s(A,B,K,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=B, K=:=L+M, L=:=C, M=:=1, 
          N=:=O+P, O=:=D, P=:=1, new6(s(A,B,K,N),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=B, K=:=0, 
          new8(s(A,B,K,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=A, K=:=L+M, L=:=C, M=:=1, 
          N=:=O+P, O=:=D, P=:=1, new4(s(A,B,K,N),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=A, K=:=0, 
          new6(s(A,B,K,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,B,I,J),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
