new62(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=E, O=:=P+Q, P=:=E, 
          Q=:=1, new18(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new62(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=E, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new61(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=C, 
          new62(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new61(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new55(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=E, O=:=P+Q, P=:=E, 
          Q=:=1, new39(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new55(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=E, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=C, 
          new55(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=F, 
          new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=F, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new48(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=D, 
          new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new48(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=F, N=:=D, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new46(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=P+Q, P=:=F, 
          Q=:=1, new48(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new46(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=P+Q, P=:=F, 
          Q=:=1, new48(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new46(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, O=:=P+Q, P=:=E, 
          Q=:=1, new39(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new44(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=E, 
          new46(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new44(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=E, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=C, 
          new44(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new41(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=O-P, O=:=D, P=:=1, 
          new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new39(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new41(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new39(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new41(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new37(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=E, 
          new39(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new37(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=E, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new35(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=C, 
          new37(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new35(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new33(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=0, 
          new35(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new33(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=0, 
          new35(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=O+P, O=:=E, P=:=1, N=:=Q-R, 
          Q=:=C, R=:=1, S=:=T+U, T=:=E, U=:=1, V=:=S, 
          new33(s(A,V,C,D,S,F),d(G,H,I,J,K,L)).
new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O+P, O=:=E, P=:=1, N=:=Q-R, 
          Q=:=C, R=:=1, S=:=T+U, T=:=E, U=:=1, V=:=S, 
          new33(s(A,V,C,D,S,F),d(G,H,I,J,K,L)).
new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=O+P, O=:=E, P=:=1, 
          new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=O+P, O=:=E, P=:=1, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O+P, O=:=E, P=:=1, N=:=C, 
          new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O+P, O=:=E, P=:=1, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=E, 
          new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=E, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=C, 
          new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new61(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=E, 
          new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=E, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=C, 
          new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=E, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=0, N=:=O-P, O=:=E, P=:=1, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=0, N=:=O-P, O=:=E, P=:=1, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O-P, O=:=E, P=:=1, N=:=C, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O-P, O=:=E, P=:=1, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O-P, O=:=C, P=:=1, N=:=B, 
          Q=:=B, new9(s(A,B,C,D,Q,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=B, N=:=0, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=0, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=B, N=:=0, 
          new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=0, 
          new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
correct :- \+new1.
