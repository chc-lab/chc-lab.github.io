new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new5(s(M,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new5(s(M,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=C, L=:=0, M=:=N+O, N=:=B, 
          O=:=C, new15(s(A,M,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=0, M=:=N+O, N=:=B, 
          O=:=C, new15(s(A,M,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=C, L=:=0, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(A,B,C,D,E)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, 
          new12(s(A,B,M,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=D, M=:=N-O, N=:=B, O=:=C, 
          new8(s(A,M,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=D, 
          new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=0, M=:=0, 
          new5(s(M,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=D, L=:=0, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, M=:=0, N=:=O, 
          new4(s(K,L,M,N,O),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
correct :- \+new1.
