new12(s(A),d(B)) :- B=:=C-D, C=:=A, D=:=1.
new10(s(A,B,C),d(D,B,C)) :- new11(s(A),d(D)).
new10(s(A,B,C),d(D,E,F)) :- new12(s(A),d(G)), new4(s(G,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,B,C)) :- new11(s(A),d(D)).
new8(s(A,B,C),d(D,E,F)) :- new12(s(A),d(G)), new4(s(G,B,C),d(D,E,F)).
new7(s(A,B,C),d(A,B,C)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=0, new8(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=0, new8(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=0, new10(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=J, new5(s(A,I,J),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=0, new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- new4(s(G,B,C),d(D,E,F)).
new2(s(A),d(B)) :- new3(s(A,C,D),d(B,E,F)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
