new7(s(A,B),d(A,B)).
new6(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=0, new7(s(A,B),d(C,D)).
new6(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=0, new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E=:=F, E=:=A, F=:=0, new6(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=0, new4(s(G,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=1, new4(s(G,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
correct :- \+new1.
