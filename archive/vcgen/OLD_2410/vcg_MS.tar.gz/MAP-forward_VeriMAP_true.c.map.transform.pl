new8(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G>=H+1, G=:=I+J, I=:=D, J=:=E, H=:=K*L, 
          K=:=3, L=:=C.
new8(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G+1=<H, G=:=I+J, I=:=D, J=:=E, H=:=K*L, 
          K=:=3, L=:=C.
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=0, O=:=P+Q, P=:=D, 
          Q=:=1, R=:=S+T, S=:=E, T=:=2, U=:=V+W, V=:=B, W=:=1, 
          new4(s(A,U,C,O,R,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=0, O=:=P+Q, P=:=D, 
          Q=:=1, R=:=S+T, S=:=E, T=:=2, U=:=V+W, V=:=B, W=:=1, 
          new4(s(A,U,C,O,R,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=F, N=:=0, O=:=P+Q, P=:=D, 
          Q=:=2, R=:=S+T, S=:=E, T=:=1, U=:=V+W, V=:=B, W=:=1, 
          new4(s(A,U,C,O,R,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=C, 
          new7(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=B, N=:=C, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=0, O=:=0, P=:=0, Q=:=0, 
          new4(s(A,O,C,P,Q,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
correct :- \+new1.
