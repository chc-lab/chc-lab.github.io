new11(s(A,B,C),d(A,B,C)) :- D>=E+1, D=:=B, E=:=A.
new9(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=J-K, J=:=A, K=:=1, 
          L=:=M-N, M=:=B, N=:=1, new9(s(I,L,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=0, new11(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- new6(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          L=:=M+N, M=:=B, N=:=1, new5(s(I,L,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, new9(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=0, new5(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=0, new4(s(G,H,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
correct :- \+new1.
