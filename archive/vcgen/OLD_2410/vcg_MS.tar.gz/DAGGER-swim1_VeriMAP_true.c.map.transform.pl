new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=G, F1=:=1, G1=:=H1-I1, H1=:=A, I1=:=1, J1=:=K1+L1, 
          K1=:=B, L1=:=1, M1=:=N1-O1, N1=:=G, O1=:=1, 
          new8(s(G1,J1,C,D,E,F,M1,H,I,J,K,L,M,N,P1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=F, F1=:=1, G1=:=H1-I1, H1=:=C, I1=:=1, J1=:=K1+L1, 
          K1=:=D, L1=:=1, M1=:=N1-O1, N1=:=F, O1=:=1, 
          new8(s(A,B,G1,J1,E,M1,G,H,I,J,K,L,M,N,P1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=E, F1=:=1, G1=:=H1-I1, H1=:=E, I1=:=1, J1=:=K1+L1, 
          K1=:=F, L1=:=1, 
          new8(s(A,B,C,D,G1,J1,G,H,I,J,K,L,M,N,M1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=D, F1=:=1, G1=:=H1-I1, H1=:=D, I1=:=1, J1=:=K1+L1, 
          K1=:=E, L1=:=1, M1=:=N1+O1, N1=:=G, O1=:=1, 
          new8(s(A,B,C,G1,J1,F,M1,H,I,J,K,L,M,N,P1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=J, F1=:=0, 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=J, F1=:=0, 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=J, F1=:=0, 
          new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=C, F1=:=1, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=K, F1=:=0, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=K, F1=:=0, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=K, F1=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,G1,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=B, F1=:=1, G1=:=H1-I1, H1=:=B, I1=:=1, J1=:=K1+L1, 
          K1=:=C, L1=:=1, M1=:=N1+O1, N1=:=F, O1=:=1, 
          new8(s(A,G1,J1,D,E,M1,G,H,I,J,K,L,M,N,P1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=L, F1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=L, F1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=L, F1=:=0, 
          new48(s(A,B,C,D,E,F,G,H,I,J,G1,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=A, F1=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=M, F1=:=0, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=M, F1=:=0, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=M, F1=:=0, 
          new45(s(A,B,C,D,E,F,G,H,I,J,K,G1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=F, F1=:=1, G1=:=H1+I1, H1=:=A, I1=:=1, J1=:=K1-L1, 
          K1=:=F, L1=:=1, 
          new8(s(G1,B,C,D,E,J1,G,H,I,J,K,L,M,N,M1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=M1+N1, M1=:=A, 
          N1=:=B, L1=:=D, J1=:=F, H1=:=G, F1=:=1, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=M1+N1, M1=:=A, 
          N1=:=B, L1=:=D, J1=:=E, H1=:=F, F1=:=1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=M1+N1, M1=:=A, 
          N1=:=B, L1=:=D, J1=:=E, H1=:=F, F1=:=1, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=B, L1=:=C, J1=:=D, 
          H1=:=G, F1=:=1, 
          new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=B, L1=:=C, J1=:=D, 
          H1=:=G, F1=:=1, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=A, F1=:=0, 
          new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=A, F1=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=B, F1=:=0, 
          new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=B, F1=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=C, F1=:=0, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=C, F1=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=D, F1=:=0, 
          new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=E, F1=:=0, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=E, F1=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=F, F1=:=0, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=F, F1=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=G, F1=:=0, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=G, F1=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=<F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=M1+N1, M1=:=A, 
          N1=:=B, L1=:=D, J1=:=E, H1=:=F, F1=:=H, 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=M1+N1, M1=:=A, 
          N1=:=B, L1=:=D, J1=:=E, H1=:=F, F1=:=H, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=M1+N1, M1=:=A, 
          N1=:=B, L1=:=D, J1=:=E, H1=:=F, F1=:=H, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=M1+N1, M1=:=A, 
          N1=:=B, L1=:=D, J1=:=E, H1=:=F, F1=:=H, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=B, L1=:=C, J1=:=D, 
          H1=:=G, F1=:=I, 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=B, L1=:=C, J1=:=D, 
          H1=:=G, F1=:=I, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=B, L1=:=C, J1=:=D, 
          H1=:=G, F1=:=I, 
          new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=B, L1=:=C, J1=:=D, 
          H1=:=G, F1=:=I, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=G1+H1, G1=:=I1+J1, I1=:=K1+L1, K1=:=B, L1=:=C, J1=:=D, 
          H1=:=G, F1=:=I, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, 
          new42(s(A,B,C,D,E,F,G,H,I,J,K,L,G1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=O, F1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,G1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=O, F1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,G1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=I, F1=:=1, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,G1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=H, F1=:=1, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=G, F1=:=I, 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=F, F1=:=H, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=0, F1=:=0, G1=:=0, H1=:=0, I1=:=0, 
          new4(s(E1,F1,G1,H1,I1,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new2(s,d) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new1 :- new2(s,d).
correct :- \+new1.
