new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=M*N, M=:=2, N=:=B, 
          O=:=P+Q, P=:=D, Q=:=1, new8(s(A,B,C,O,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=M*N, M=:=2, N=:=B, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(A,B,C,D,E)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=D, L=:=E, M=:=N+O, N=:=C, O=:=1, 
          new5(s(A,B,M,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=E, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=E, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=E, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=E, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=E, M=:=N+O, N=:=C, O=:=1, 
          new5(s(A,B,M,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, M=:=C, 
          new8(s(A,B,C,M,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, M=:=C, 
          new8(s(A,B,C,M,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=E, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=E, M=:=N+O, N=:=B, O=:=1, 
          new4(s(A,M,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=E, M=:=N*O, N=:=2, O=:=B, 
          new5(s(A,B,M,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=E, M=:=0, 
          new4(s(A,M,C,D,E),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
