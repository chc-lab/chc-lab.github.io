new16(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new16(s(K,B,C,D),d(E,F,G,H)).
new16(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new16(s(K,B,C,D),d(E,F,G,H)).
new15(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=0, K=:=4, 
          new16(s(A,B,C,K),d(E,F,G,H)).
new15(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=C, J=:=0, K=:=5, 
          new16(s(A,B,C,K),d(E,F,G,H)).
new11(s(A,B,C,D),d(A,B,C,D)) :- E=:=F, E=:=B, F=:=0.
new11(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new11(s(K,B,C,D),d(E,F,G,H)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new11(s(K,B,C,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=0, K=:=4, 
          new11(s(A,B,C,K),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=C, J=:=0, K=:=5, 
          new11(s(A,B,C,K),d(E,F,G,H)).
new9(s(A,B),d(A,B)).
new8(s(A,B),d(C,D)) :- E=:=F, E=:=B, F=:=2, new9(s(A,B),d(C,D)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, new10(s(I,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, new15(s(I,B,C,D),d(E,F,G,H)).
new4(s(A,B),d(A,B)) :- new6(s(C,D,E,F),d(G,H,I,J)).
new4(s(A,B),d(C,D)) :- new7(s(E,F,G,H),d(I,J,K,L)), new8(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=0, G=:=1, new4(s(A,G),d(C,D)).
new3(s(A,B),d(C,D)) :- E=<F, E=:=A, F=:=0, G=:=2, new4(s(A,G),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
correct :- \+new1.
