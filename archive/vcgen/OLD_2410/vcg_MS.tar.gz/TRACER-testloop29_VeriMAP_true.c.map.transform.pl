new7(s(A),d(A)).
new6(s(A),d(B)) :- C>=D+1, C=:=A, D=:=50, new7(s(A),d(B)).
new6(s(A),d(B)) :- C+1=<D, C=:=A, D=:=50, new7(s(A),d(B)).
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=50, new6(s(A),d(B)).
new5(s(A),d(B)) :- C>=D+1, C=:=A, D=:=50, new4(s(A),d(B)).
new5(s(A),d(B)) :- C+1=<D, C=:=A, D=:=50, new4(s(A),d(B)).
new4(s(A),d(B)) :- C+1=<D, C=:=A, D=:=100, E=:=F+G, F=:=A, G=:=1, 
          new5(s(E),d(B)).
new4(s(A),d(B)) :- C>=D, C=:=A, D=:=100, new6(s(A),d(B)).
new3(s(A),d(B)) :- C=:=0, new4(s(C),d(B)).
new2(s,d) :- new3(s(A),d(B)).
new1 :- new2(s,d).
correct :- \+new1.
