new7(s(A,B),d(A,B)).
new6(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=B, new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=B, G=:=H+I, H=:=A, I=:=1, 
          new4(s(G,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E>=F, E=:=A, F=:=B, new6(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=:=0, F=:=100, new4(s(E,F),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
correct :- \+new1.
