new36(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=B, K=:=L+M, L=:=D, M=:=1, 
          new23(s(A,B,C,K),d(E,F,G,H)).
new36(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=D, J=:=B, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new35(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=0, J=:=D, 
          new36(s(A,B,C,D),d(E,F,G,H)).
new35(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=0, J=:=D, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new33(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=B, new8(s(A,B,C,D),d(E,F,G,H)).
new33(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=B, 
          new35(s(A,B,C,D),d(E,F,G,H)).
new30(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new30(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new30(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, K=:=L+M, L=:=C, M=:=1, 
          new33(s(A,B,K,D),d(E,F,G,H)).
new27(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, K=:=0, L=:=0, 
          new23(s(A,B,L,K),d(E,F,G,H)).
new27(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, K=:=0, L=:=0, 
          new23(s(A,B,L,K),d(E,F,G,H)).
new27(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, 
          new30(s(A,B,C,D),d(E,F,G,H)).
new23(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new19(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new19(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new19(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, 
          new23(s(A,B,C,D),d(E,F,G,H)).
new17(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=B, K=:=L+M, L=:=D, M=:=1, 
          new19(s(A,B,C,K),d(E,F,G,H)).
new17(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=D, J=:=B, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new16(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=0, J=:=D, 
          new17(s(A,B,C,D),d(E,F,G,H)).
new16(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=0, J=:=D, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=B, new8(s(A,B,C,D),d(E,F,G,H)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=B, 
          new16(s(A,B,C,D),d(E,F,G,H)).
new12(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new12(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new12(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, 
          new27(s(A,B,C,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(A,B,C,D)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=D, J=:=B, new10(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=0, J=:=D, new9(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=0, J=:=D, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new12(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new12(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, K=:=L+M, L=:=C, M=:=1, 
          new14(s(A,B,K,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, new8(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, 
          new5(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,B,I,J),d(E,F,G,H)).
new2(s(A),d(B)) :- new3(s(A,C,D,E),d(B,F,G,H)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
