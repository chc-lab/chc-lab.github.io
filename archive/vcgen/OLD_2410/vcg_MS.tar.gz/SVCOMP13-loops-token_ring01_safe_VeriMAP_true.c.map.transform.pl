new224(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,M,E,F,G,H,I,J,K,L)) :- N=:=O, N=:=F, 
          O=:=1, M=:=0.
new224(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,M,E,F,G,H,I,J,K,L)) :- N>=O+1, N=:=F, 
          O=:=1, M=:=2.
new224(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,M,E,F,G,H,I,J,K,L)) :- N+1=<O, N=:=F, 
          O=:=1, M=:=2.
new218(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=0, A1=:=1, 
          new221(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new221(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new221(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=0, A1=:=1, 
          new218(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new218(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new218(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,M,K,L)) :- N=:=O, N=:=J, 
          O=:=0, M=:=1.
new212(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- M>=N+1, M=:=J, 
          N=:=0.
new212(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- M+1=<N, M=:=J, 
          N=:=0.
new209(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=0, A1=:=1, 
          new212(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new212(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new212(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=0, A1=:=1, 
          new209(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new209(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new209(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=B, B1=:=1, 
          new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new201(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new191(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new203(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new197(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new198(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new197(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new198(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new197(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, 
          new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new194(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O=:=P, 
          O=:=I, P=:=1, N=:=1.
new194(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O>=P+1, 
          O=:=I, P=:=1, N=:=0.
new194(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O+1=<P, 
          O=:=I, P=:=1, N=:=0.
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O=:=P, 
          O=:=J, P=:=1, N=:=1.
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O>=P+1, 
          O=:=J, P=:=1, N=:=0.
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O+1=<P, 
          O=:=J, P=:=1, N=:=0.
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,O,E,F,G,H,I,J,K,L,M,N)) :- 
          P>=Q+1, P=:=N, Q=:=0, O=:=0.
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,O,E,F,G,H,I,J,K,L,M,N)) :- 
          P+1=<Q, P=:=N, Q=:=0, O=:=0.
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)) :- O=:=P, 
          O=:=N, P=:=0.
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O>=P+1, 
          O=:=B, P=:=1, N=:=0.
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O+1=<P, 
          O=:=B, P=:=1, N=:=0.
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=B, B1=:=1, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new191(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new192(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new188(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new188(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, 
          new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O>=P+1, 
          O=:=A, P=:=1, N=:=0.
new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O+1=<P, 
          O=:=A, P=:=1, N=:=0.
new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new194(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new183(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new183(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new183(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new180(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new180(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new180(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,M,K,L)) :- N=:=O, N=:=J, 
          O=:=1, M=:=2.
new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- M>=N+1, M=:=J, 
          N=:=1.
new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- M+1=<N, M=:=J, 
          N=:=1.
new171(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new174(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new171(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new171(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new171(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new163(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new157(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=1, new160(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=1, new157(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=1, new157(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=1, 
          Z=:=0, A1=:=B1, C1=:=1, 
          new166(s(A,B,C,D,E,F,G,H,I,C1,B1,A1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=0, new157(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=0, new158(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=0, new158(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new154(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new110(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new130(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z),d(M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new141(s(Z,A1,B1,C1,D1,E1,F1,G1,Y,I1,J1,K1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new142(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=1, A1=:=B1+C1, B1=:=K, C1=:=1, D1=:=1, 
          new144(s(A,B,C,D,E,F,G,H,D1,J,A1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new142(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=1, new141(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new142(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=1, new141(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=0, new141(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=0, new142(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=0, new142(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new123(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=O, F1=:=0, G1=:=1, 
          new135(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=O, F1=:=0, G1=:=1, 
          new135(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=D, F1=:=0, 
          new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,G1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=D, F1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, G1=:=1, 
          new151(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, G1=:=1, 
          new151(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=C, F1=:=0, 
          new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,G1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=C, F1=:=0, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=C, F1=:=0, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=M, F1=:=0, 
          new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=M, F1=:=0, 
          new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,B1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1)), 
          new126(s(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- V=:=2, M=:=1, 
          O=:=2, new104(s(A,B,C,D,E,F,G,H,I,J,K,L),d(Y,N,Z,P,Q,R,S,T,U,A1,W,X)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new112(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=1, new115(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=1, new112(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=1, new112(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=1, 
          Z=:=0, A1=:=B1, C1=:=1, 
          new121(s(A,B,C,D,E,F,G,H,I,C1,B1,A1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=0, new112(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=0, new113(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=0, new113(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new110(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new88(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new104(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z),d(M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new98(s(Z,A1,B1,C1,D1,E1,F1,G1,Y,I1,J1,K1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=1, A1=:=B1+C1, B1=:=K, C1=:=1, D1=:=1, 
          new101(s(A,B,C,D,E,F,G,H,D1,J,A1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=1, new98(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=1, new98(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,M,C,N,E,F,G,H,I,J,K,L)) :- O>=P+1, O=:=1, 
          P=:=0, M=:=1, N=:=2.
new96(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=0, new98(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=0, new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=0, new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new82(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=O, F1=:=0, G1=:=1, 
          new93(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=O, F1=:=0, G1=:=1, 
          new93(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new82(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=D, F1=:=0, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,G1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=D, F1=:=0, 
          new82(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new82(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, G1=:=1, 
          new107(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, G1=:=1, 
          new107(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, 
          new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=C, F1=:=0, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,G1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=C, F1=:=0, 
          new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=C, F1=:=0, 
          new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)) :- 
          P=:=Q, P=:=M, Q=:=0.
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=M, F1=:=0, 
          new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=M, F1=:=0, 
          new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new82(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1)), 
          new84(s(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O=:=P, 
          O=:=D, P=:=0, N=:=1.
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O>=P+1, 
          O=:=D, P=:=0, N=:=0.
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O+1=<P, 
          O=:=D, P=:=0, N=:=0.
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new75(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new72(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,M,K,L)) :- N=:=O, N=:=J, 
          O=:=1, M=:=2.
new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- M>=N+1, M=:=J, 
          N=:=1.
new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- M+1=<N, M=:=J, 
          N=:=1.
new63(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new66(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new63(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new63(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new63(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new60(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new60(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new60(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new69(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new58(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new40(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new56(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new52(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,M,H,I,J,K,L)) :- M=:=1.
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,O)) :- P>=Q+1, 
          P=:=M, Q=:=0, O=:=0.
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,O)) :- P+1=<Q, 
          P=:=M, Q=:=0, O=:=0.
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,O)) :- P=:=Q, 
          P=:=M, Q=:=0, O=:=1.
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new47(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new50(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new42(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,F1)), 
          new44(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,N,E1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new53(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, G1=:=4, 
          new39(s(A,B,C,D,E,F,G,H,I,J,K,L,G1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O=:=P, 
          O=:=C, P=:=0, N=:=1.
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, B1=:=0, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=0, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, B1=:=0, 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=0, 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,B1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1)), 
          new38(s(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,M,E1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new35(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new32(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new29(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=3, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new82(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1,D1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,E1,F1,G1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=2, 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1)), 
          new25(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=1, F1=:=0, G1=:=1, 
          new22(s(A,B,C,D,E,F,G,H,I,J,K,L,G1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new168(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new168(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new168(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new177(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new177(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new177(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new21(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new187(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new197(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new18(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=0, A1=:=1, 
          new206(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=0, new206(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=0, new206(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=0, A1=:=1, 
          new215(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=0, new215(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=0, new215(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new15(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=E, 
          Z=:=1, A1=:=0, 
          new224(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=1, A1=:=2, 
          new224(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=1, A1=:=2, 
          new224(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=E, 
          Z=:=1, A1=:=0, 
          new227(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=1, A1=:=2, 
          new227(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=1, A1=:=2, 
          new227(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new12(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,M)) :- 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,Z,A1,B1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,C1,D1,E1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,M,N,G,H,I,J,K,L)) :- M=:=1, N=:=1.
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,M)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L),d(N,O,P,Q,R,S,T,U,V,W,X,Y)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)), 
          new6(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X,Z)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, J=:=2, 
          K=:=0, L=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
correct :- \+new1.
