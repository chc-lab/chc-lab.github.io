new7(s(A,B,C,D,E),d(A,B,C,D,E)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=C, L=:=D, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=D, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          P=:=0, Q>=R+1, Q=:=B, R=:=0, S=:=T+U, T=:=E, U=:=1, 
          new4(s(A,P,M,D,S),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          P=:=0, Q+1=<R, Q=:=B, R=:=0, S=:=T+U, T=:=E, U=:=1, 
          new4(s(A,P,M,D,S),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, M=:=N+O, N=:=D, O=:=1, 
          P=:=1, Q=:=R, Q=:=B, R=:=0, S=:=T+U, T=:=E, U=:=1, 
          new4(s(A,P,C,M,S),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=M*N, M=:=2, N=:=A, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=E, L=:=M*N, M=:=2, N=:=A, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=100, L=:=D, M=:=0, 
          new4(s(K,B,L,D,M),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
correct :- \+new1.
