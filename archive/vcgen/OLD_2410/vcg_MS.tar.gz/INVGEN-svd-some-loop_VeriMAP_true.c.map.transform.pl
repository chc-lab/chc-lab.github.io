new61(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=P+Q, P=:=E, 
          Q=:=1, new16(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new61(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new59(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=D, 
          new61(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new59(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=D, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new59(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, O=:=P+Q, P=:=F, 
          Q=:=1, new31(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=E, 
          new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=E, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new49(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=F, N=:=B, 
          new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new49(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=P+Q, P=:=F, 
          Q=:=1, new34(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=D, 
          new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=D, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new41(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new41(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new39(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=E, 
          new41(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new39(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=E, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new37(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=F, N=:=B, 
          new39(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new37(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new35(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=F, 
          new37(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new35(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=F, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new34(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=F, N=:=B, 
          new35(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new34(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=B, O=:=P+Q, P=:=E, 
          Q=:=1, new30(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new33(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=F, 
          new49(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new33(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=F, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=F, N=:=B, 
          new33(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=B, O=:=C, 
          new34(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, O=:=C, 
          new31(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, O=:=C, 
          new18(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=E, 
          new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=E, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=P+Q, P=:=E, 
          Q=:=1, new18(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=D, 
          new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=D, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=E, 
          new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=E, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, O=:=C, 
          new30(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=D, P=:=Q-R, 
          Q=:=D, R=:=1, new4(s(A,B,O,P,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=D, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=D, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=D, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=D, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=C, 
          new16(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=C, 
          new16(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, O=:=C, 
          new18(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=B, 
          new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=B, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=1, O=:=P+Q, P=:=D, 
          Q=:=1, new5(s(A,B,O,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=B, 
          new4(s(A,B,C,M,E,F),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
