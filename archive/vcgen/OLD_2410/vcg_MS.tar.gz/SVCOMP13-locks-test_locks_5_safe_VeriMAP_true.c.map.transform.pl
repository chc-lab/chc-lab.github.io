new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q>=R+1, Q=:=O, R=:=1.
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q+1=<R, Q=:=O, R=:=1.
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=O, H1=:=1, I1=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,J1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=0, 
          new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=0, 
          new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=0, 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q>=R+1, Q=:=L, R=:=1.
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q+1=<R, Q=:=L, R=:=1.
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=L, H1=:=1, I1=:=0, 
          new34(s(A,B,C,D,E,F,G,H,I,J,K,I1,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=J, H1=:=0, 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=J, H1=:=0, 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=J, H1=:=0, 
          new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q>=R+1, Q=:=I, R=:=1.
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q+1=<R, Q=:=I, R=:=1.
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=I, H1=:=1, I1=:=0, 
          new31(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=G, H1=:=0, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=G, H1=:=0, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=G, H1=:=0, 
          new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q>=R+1, Q=:=F, R=:=1.
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q+1=<R, Q=:=F, R=:=1.
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=F, H1=:=1, I1=:=0, 
          new28(s(A,B,C,D,E,I1,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=D, H1=:=0, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=D, H1=:=0, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=D, H1=:=0, 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q>=R+1, Q=:=C, R=:=1.
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          Q+1=<R, Q=:=C, R=:=1.
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=C, H1=:=1, I1=:=0, 
          new25(s(A,B,I1,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=A, H1=:=0, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=A, H1=:=0, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=A, H1=:=0, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=0, I1=:=1, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=0, I1=:=1, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=0, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=J, H1=:=0, I1=:=1, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,I1,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=J, H1=:=0, I1=:=1, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,I1,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=J, H1=:=0, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=G, H1=:=0, I1=:=1, 
          new14(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=G, H1=:=0, I1=:=1, 
          new14(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=G, H1=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=D, H1=:=0, I1=:=1, 
          new11(s(A,B,C,D,E,I1,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=D, H1=:=0, I1=:=1, 
          new11(s(A,B,C,D,E,I1,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=D, H1=:=0, 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=A, H1=:=0, I1=:=1, 
          new8(s(A,B,I1,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=A, H1=:=0, I1=:=1, 
          new8(s(A,B,I1,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=A, H1=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=P, H1=:=0, I1=:=0, J1=:=0, K1=:=0, L1=:=0, M1=:=0, 
          new6(s(A,B,I1,D,E,J1,G,H,K1,J,K,L1,M,N,M1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=P, H1=:=0, I1=:=0, J1=:=0, K1=:=0, L1=:=0, M1=:=0, 
          new6(s(A,B,I1,D,E,J1,G,H,K1,J,K,L1,M,N,M1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=1, H1=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, I1=:=J1, K1=:=L1, M1=:=N1, O1=:=P1, 
          new4(s(G1,H1,C,I1,J1,F,K1,L1,I,M1,N1,L,O1,P1,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new2(s,d) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new1 :- new2(s,d).
correct :- \+new1.
