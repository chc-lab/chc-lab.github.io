new11(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=Q-R, Q=:=D, R=:=B, 
          P=:=S*T, S=:=2, T=:=E, U=:=V+W, V=:=D, W=:=1, 
          new6(s(A,B,C,U,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=Q-R, Q=:=D, R=:=B, 
          P=:=S*T, S=:=2, T=:=E, new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=D, P=:=C, 
          new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=D, P=:=C, Q=:=R+S, R=:=C, 
          S=:=1, new5(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=C, P=:=Q*R, Q=:=3, 
          R=:=B, S=:=B, new6(s(A,B,C,S,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=C, P=:=Q*R, Q=:=3, R=:=B, 
          S=:=T+U, T=:=B, U=:=1, new4(s(A,S,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=B, P=:=E, Q=:=R*S, 
          R=:=2, S=:=B, new5(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=Q*R, Q=:=3, R=:=E, 
          P=:=S+T, S=:=G, T=:=F, U=:=0, new4(s(A,U,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
