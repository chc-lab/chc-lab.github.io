new10(s(A,B),d(A,B)).
new9(s(A,B),d(C,D)) :- E=:=F, E=:=A, F=:=10, new10(s(A,B),d(C,D)).
new7(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=10, new4(s(A,B),d(C,D)).
new7(s(A,B),d(C,D)) :- E>=F, E=:=B, F=:=10, new9(s(A,B),d(C,D)).
new6(s(A),d(B)) :- B=:=C+D, C=:=A, D=:=1.
new4(s(A,B),d(C,B)) :- new5(s(A),d(C)).
new4(s(A,B),d(C,D)) :- E=:=F, new6(s(A),d(F)), new7(s(F,E),d(C,D)).
new3(s(A,B),d(C,D)) :- new4(s(A,B),d(C,D)).
new2(s(A),d(B)) :- new3(s(A,C),d(B,D)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
