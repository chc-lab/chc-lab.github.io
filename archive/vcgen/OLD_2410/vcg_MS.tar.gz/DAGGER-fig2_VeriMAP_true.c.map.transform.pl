new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=B, Q=:=R*S, 
          R=:= -1, S=:=A, T=:=U*V, U=:= -1, V=:=B, 
          new4(s(Q,T,C,D,E,F,W),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=B, 
          new4(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new14(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=C, 
          new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new14(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=C, 
          new4(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=4, Q=:=R+S, R=:=A, 
          S=:=1, T=:=U+V, U=:=B, V=:=3, W=:=X+Y, X=:=C, Y=:=10, Z=:=A1+B1, 
          A1=:=D, B1=:=10, new4(s(Q,T,W,Z,E,F,C1),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=4, 
          new4(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=E, P=:=0, 
          new14(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=Q*R, Q=:=3, R=:=A, 
          P=:=B, new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=F, P=:=0, Q=:=R+S, 
          R=:=A, S=:=1, T=:=U+V, U=:=B, V=:=2, 
          new4(s(Q,T,C,D,E,F,W),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=F, P=:=0, Q=:=R+S, 
          R=:=A, S=:=1, T=:=U+V, U=:=B, V=:=2, 
          new4(s(Q,T,C,D,E,F,W),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=F, P=:=0, 
          new11(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=G, P=:=0, 
          new5(s(A,B,C,D,E,Q,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=G, P=:=0, 
          new5(s(A,B,C,D,E,Q,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=G, P=:=0, 
          new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P=:=O, Q=:=P, R=:=Q, 
          new4(s(R,Q,P,O,E,F,S),d(H,I,J,K,L,M,N)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new1 :- new2(s,d).
correct :- \+new1.
