new13(s(A,B,C,D),d(A,B,C,D)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=L+M, L=:=C, M=:=1, 
          N=:=O-P, O=:=D, P=:=1, new10(s(A,B,K,N),d(E,F,G,H)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=D, J=:=0, 
          new13(s(A,B,C,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=K*L, K=:=20, L=:=A, 
          new11(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=K+L, K=:=M*N, M=:=6, N=:=B, 
          L=:=128, O=:=P+Q, P=:=C, Q=:=1, R=:=S-T, S=:=D, T=:=1, 
          new8(s(A,B,O,R),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=K+L, K=:=M*N, M=:=6, N=:=B, 
          L=:=128, O=:=0, new10(s(A,B,O,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=K+L, K=:=M*N, M=:=6, N=:=B, 
          L=:=128, O=:=P+Q, P=:=C, Q=:=1, R=:=S+T, S=:=D, T=:=1, 
          new6(s(A,B,O,R),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=K+L, K=:=M*N, M=:=6, N=:=B, 
          L=:=128, O=:=0, new8(s(A,B,O,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=K*L, K=:=20, L=:=A, M=:=N+O, 
          N=:=C, O=:=1, P=:=Q+R, Q=:=D, R=:=1, new4(s(A,B,M,P),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=K*L, K=:=20, L=:=A, M=:=0, 
          new6(s(A,B,M,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,B,I,J),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
