new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=H, D1=:=1, E1=:=0, 
          new296(s(A,B,C,D,E1,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=H, D1=:=1, E1=:=2, 
          new296(s(A,B,C,D,E1,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=H, D1=:=1, E1=:=2, 
          new296(s(A,B,C,D,E1,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,O,G,H,I,J,K,L,M,N)) :- P=:=Q, 
          P=:=I, Q=:=1, O=:=0.
new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,O,G,H,I,J,K,L,M,N)) :- 
          P>=Q+1, P=:=I, Q=:=1, O=:=2.
new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,O,G,H,I,J,K,L,M,N)) :- 
          P+1=<Q, P=:=I, Q=:=1, O=:=2.
new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=H, D1=:=1, E1=:=0, 
          new290(s(A,B,C,D,E1,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=H, D1=:=1, E1=:=2, 
          new290(s(A,B,C,D,E1,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=H, D1=:=1, E1=:=2, 
          new290(s(A,B,C,D,E1,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, E1=:=1, 
          new284(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, 
          new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, 
          new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=L, D1=:=0, E1=:=1, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,E1,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=L, D1=:=0, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=L, D1=:=0, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new275(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=K, D1=:=0, E1=:=1, 
          new278(s(A,B,C,D,E,F,G,H,I,J,E1,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new275(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=K, D1=:=0, 
          new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new275(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=K, D1=:=0, 
          new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new272(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,O)) :- P=:=Q, 
          P=:=N, Q=:=0, O=:=1.
new272(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)) :- 
          O>=P+1, O=:=N, P=:=0.
new272(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)) :- 
          O+1=<P, O=:=N, P=:=0.
new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, E1=:=1, 
          new272(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, 
          new272(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, 
          new272(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new266(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=L, D1=:=0, E1=:=1, 
          new269(s(A,B,C,D,E,F,G,H,I,J,K,E1,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new266(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=L, D1=:=0, 
          new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new266(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=L, D1=:=0, 
          new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=K, D1=:=0, E1=:=1, 
          new266(s(A,B,C,D,E,F,G,H,I,J,E1,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=K, D1=:=0, 
          new266(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=K, D1=:=0, 
          new266(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=C, F1=:=1, 
          new260(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,G1)).
new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,J1)), 
          new259(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,O,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new253(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=0, K1=:=0, 
          new254(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new253(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=0, K1=:=0, 
          new254(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new253(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=0, 
          new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=B, F1=:=1, 
          new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,G1)).
new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,J1)), 
          new253(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,O,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new247(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=0, K1=:=0, 
          new248(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new247(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=0, K1=:=0, 
          new248(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new247(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=0, 
          new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=A, F1=:=1, 
          new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q=:=R, Q=:=J, R=:=1, P=:=1.
new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q>=R+1, Q=:=J, R=:=1, P=:=0.
new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q+1=<R, Q=:=J, R=:=1, P=:=0.
new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q=:=R, Q=:=M, R=:=1, P=:=1.
new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q>=R+1, Q=:=M, R=:=1, P=:=0.
new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q+1=<R, Q=:=M, R=:=1, P=:=0.
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q=:=R, Q=:=N, R=:=1, P=:=1.
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q>=R+1, Q=:=N, R=:=1, P=:=0.
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q+1=<R, Q=:=N, R=:=1, P=:=0.
new241(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,R,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          S>=T+1, S=:=Q, T=:=0, R=:=0.
new241(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,R,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          S+1=<T, S=:=Q, T=:=0, R=:=0.
new241(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=S, R=:=Q, S=:=0.
new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q>=R+1, Q=:=C, R=:=1, P=:=0.
new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q+1=<R, Q=:=C, R=:=1, P=:=0.
new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=C, F1=:=1, 
          new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,J1)), 
          new241(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,O,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=0, K1=:=0, 
          new237(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=0, K1=:=0, 
          new237(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=0, 
          new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q>=R+1, Q=:=B, R=:=1, P=:=0.
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q+1=<R, Q=:=B, R=:=1, P=:=0.
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=B, F1=:=1, 
          new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new232(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,J1)), 
          new236(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,O,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=0, K1=:=0, 
          new232(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=0, K1=:=0, 
          new232(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=0, 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new230(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q>=R+1, Q=:=A, R=:=1, P=:=0.
new230(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q+1=<R, Q=:=A, R=:=1, P=:=0.
new230(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=A, F1=:=1, 
          new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=1, E1=:=2, 
          new227(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=1, 
          new227(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=1, 
          new227(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new221(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=L, D1=:=1, E1=:=2, 
          new224(s(A,B,C,D,E,F,G,H,I,J,K,E1,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new221(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=L, D1=:=1, 
          new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new221(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=L, D1=:=1, 
          new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=K, D1=:=1, E1=:=2, 
          new221(s(A,B,C,D,E,F,G,H,I,J,E1,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=K, D1=:=1, 
          new221(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=K, D1=:=1, 
          new221(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,O)) :- P=:=Q, 
          P=:=N, Q=:=1, O=:=2.
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)) :- 
          O>=P+1, O=:=N, P=:=1.
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)) :- 
          O+1=<P, O=:=N, P=:=1.
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=1, E1=:=2, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=1, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=1, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=L, D1=:=1, E1=:=2, 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,E1,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=L, D1=:=1, 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=L, D1=:=1, 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=K, D1=:=1, E1=:=2, 
          new209(s(A,B,C,D,E,F,G,H,I,J,E1,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=K, D1=:=1, 
          new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=K, D1=:=1, 
          new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=2, 
          new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1)), 
          new201(s(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,C1,Q1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=A, D1=:=1, 
          new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=A, D1=:=1, 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=A, D1=:=1, 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=1, D1=:=0, E1=:=1, 
          new202(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=A, D1=:=0, 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=A, D1=:=0, 
          new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=A, D1=:=0, 
          new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q,R)) :- 
          new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)), 
          new153(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,C1,D1,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,F1,G1,H1)).
new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=2, 
          new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1)), 
          new179(s(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=B, D1=:=1, E1=:=1, 
          new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=B, D1=:=1, 
          new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=B, D1=:=1, 
          new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new176(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=B, D1=:=0, 
          new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new176(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=B, D1=:=0, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new176(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=B, D1=:=0, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new173(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q,R)) :- 
          new176(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new173(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)), 
          new156(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=C, D1=:=1, 
          new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=C, D1=:=1, 
          new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=C, D1=:=1, 
          new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=C, D1=:=0, 
          new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=C, D1=:=0, 
          new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=C, D1=:=0, 
          new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q,R)) :- 
          new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)), 
          new146(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=0, M1=:=1, 
          new161(s(A,B,C,D,E,M1,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=0, M1=:=1, 
          new161(s(A,B,C,D,E,M1,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=0, 
          new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=F, L1=:=0, 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=F, L1=:=0, 
          new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=F, L1=:=0, 
          new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=1, 
          new173(s(A,B,C,D,M1,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=1, 
          new173(s(A,B,C,D,M1,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=E, L1=:=0, 
          new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=E, L1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=E, L1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=P, L1=:=0, M1=:=1, 
          new189(s(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=P, L1=:=0, M1=:=1, 
          new189(s(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=P, L1=:=0, 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=D, L1=:=0, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,M1,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=D, L1=:=0, 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=D, L1=:=0, 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=0, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=0, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q,R)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,G1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,H1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,L1)), 
          new149(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,K1,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=2, 
          new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1)), 
          new142(s(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,C1,Q1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,B,C,P,E,F,G,H,I,J,K,L,M,N)) :- 
          Q>=R+1, Q=:=1, R=:=0, O=:=1, P=:=2.
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=A, D1=:=1, 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=A, D1=:=1, 
          new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=A, D1=:=1, 
          new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=1, D1=:=0, E1=:=1, 
          new143(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=A, D1=:=0, 
          new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=A, D1=:=0, 
          new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=A, D1=:=0, 
          new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)), 
          new98(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,C1,D1,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,F1,G1,H1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=2, 
          new128(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1)), 
          new122(s(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=B, D1=:=1, E1=:=1, 
          new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=B, D1=:=1, 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=B, D1=:=1, 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,O,C,D,P,F,G,H,I,J,K,L,M,N)) :- 
          Q>=R+1, Q=:=1, R=:=0, O=:=1, P=:=2.
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=B, D1=:=0, 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=B, D1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=B, D1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)), 
          new101(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=C, D1=:=1, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=C, D1=:=1, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=C, D1=:=1, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,O,D,E,P,G,H,I,J,K,L,M,N)) :- 
          Q>=R+1, Q=:=1, R=:=0, O=:=1, P=:=2.
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=C, D1=:=0, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=C, D1=:=0, 
          new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=C, D1=:=0, 
          new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)), 
          new92(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=0, M1=:=1, 
          new106(s(A,B,C,D,E,M1,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=0, M1=:=1, 
          new106(s(A,B,C,D,E,M1,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=0, 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=F, L1=:=0, 
          new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=F, L1=:=0, 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=F, L1=:=0, 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=1, 
          new117(s(A,B,C,D,M1,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=1, 
          new117(s(A,B,C,D,M1,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=E, L1=:=0, 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=E, L1=:=0, 
          new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=E, L1=:=0, 
          new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=P, L1=:=0, M1=:=1, 
          new131(s(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=P, L1=:=0, M1=:=1, 
          new131(s(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=P, L1=:=0, 
          new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=D, L1=:=0, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,M1,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=D, L1=:=0, 
          new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=D, L1=:=0, 
          new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)) :- 
          S=:=T, S=:=O, T=:=0.
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=0, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=0, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,L1)), 
          new94(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,K1,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=E, F1=:=0, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=E, F1=:=0, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q=:=R, Q=:=F, R=:=0, P=:=1.
new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q>=R+1, Q=:=F, R=:=0, P=:=0.
new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q+1=<R, Q=:=F, R=:=0, P=:=0.
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q=:=R, Q=:=E, R=:=0, P=:=1.
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=E, F1=:=0, 
          new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=E, F1=:=0, 
          new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=1, E1=:=2, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=1, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=1, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=L, D1=:=1, E1=:=2, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,E1,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=L, D1=:=1, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=L, D1=:=1, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=K, D1=:=1, E1=:=2, 
          new75(s(A,B,C,D,E,F,G,H,I,J,E1,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=K, D1=:=1, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=K, D1=:=1, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,O)) :- P=:=Q, 
          P=:=N, Q=:=1, O=:=2.
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)) :- O>=P+1, 
          O=:=N, P=:=1.
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)) :- O+1=<P, 
          O=:=N, P=:=1.
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=1, E1=:=2, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=L, D1=:=1, E1=:=2, 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,E1,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=L, D1=:=1, 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=L, D1=:=1, 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=K, D1=:=1, E1=:=2, 
          new63(s(A,B,C,D,E,F,G,H,I,J,E1,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=K, D1=:=1, 
          new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=K, D1=:=1, 
          new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=J, D1=:=1, E1=:=2, 
          new60(s(A,B,C,D,E,F,G,H,I,E1,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=J, D1=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=J, D1=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=J, D1=:=1, E1=:=2, 
          new72(s(A,B,C,D,E,F,G,H,I,E1,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=J, D1=:=1, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=J, D1=:=1, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new40(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1,G1,H1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,I1,J1,K1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,J1,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new56(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,O,K,L,M,N)) :- O=:=1.
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q)) :- 
          R>=S+1, R=:=O, S=:=0, Q=:=0.
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q)) :- 
          R+1=<S, R=:=O, S=:=0, Q=:=0.
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q)) :- 
          R=:=S, R=:=O, S=:=0, Q=:=1.
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=Q, J1=:=0, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,H1)), 
          new47(s(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,G1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,O,P)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,F1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,H1)), 
          new50(s(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,G1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1,G1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,H1,I1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,L1),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,J1)), 
          new44(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,O,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new53(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=0, K1=:=4, 
          new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P)) :- 
          Q=:=R, Q=:=D, R=:=0, P=:=1.
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=D, F1=:=0, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=D, F1=:=0, 
          new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,G1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,J1)), 
          new38(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,O,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new35(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1,G1,H1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,I1,J1,K1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,J1,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new32(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new29(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=3, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1,G1,H1,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,J1,K1,L1,M1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=2, 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,J1,K1,L1,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new25(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,I1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=1, J1=:=0, K1=:=1, 
          new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=J, D1=:=1, E1=:=2, 
          new206(s(A,B,C,D,E,F,G,H,I,E1,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=J, D1=:=1, 
          new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=J, D1=:=1, 
          new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=J, D1=:=1, E1=:=2, 
          new218(s(A,B,C,D,E,F,G,H,I,E1,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=J, D1=:=1, 
          new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=J, D1=:=1, 
          new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new21(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new230(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,J1)), 
          new231(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,I1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,G1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new230(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,J1)), 
          new247(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,I1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1,G1,H1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,I1,J1,K1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,J1,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new18(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=J, D1=:=0, E1=:=1, 
          new263(s(A,B,C,D,E,F,G,H,I,E1,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=J, D1=:=0, 
          new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=J, D1=:=0, 
          new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=J, D1=:=0, E1=:=1, 
          new275(s(A,B,C,D,E,F,G,H,I,E1,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=J, D1=:=0, 
          new275(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=J, D1=:=0, 
          new275(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new15(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=G, D1=:=1, E1=:=0, 
          new287(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=G, D1=:=1, E1=:=2, 
          new287(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=G, D1=:=1, E1=:=2, 
          new287(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=G, D1=:=1, E1=:=0, 
          new293(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=G, D1=:=1, E1=:=2, 
          new293(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=G, D1=:=1, E1=:=2, 
          new293(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P,Q)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new12(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,O)) :- 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,E1,F1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,G1,H1,I1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,O,P,Q,J,K,L,M,N)) :- O=:=1, 
          P=:=1, Q=:=1.
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,O)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)), 
          new6(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,D1)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=2, 
          K=:=2, L=:=2, M=:=2, N=:=2, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
correct :- \+new1.
