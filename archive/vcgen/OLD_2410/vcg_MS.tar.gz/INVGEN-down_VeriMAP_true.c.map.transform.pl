new9(s(A,B,C,D),d(A,B,C,D)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, K=:=L-M, L=:=D, M=:=1, 
          N=:=O-P, O=:=B, P=:=1, new6(s(A,N,C,K),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=B, J=:=0, new9(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, 
          new7(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=A, K=:=L+M, L=:=C, M=:=1, 
          N=:=O+P, O=:=B, P=:=1, new4(s(A,N,K,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=A, K=:=A, 
          new6(s(A,B,C,K),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,I,J,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
