new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=D, B1=:=C, C1=:=D1+E1, D1=:=D, E1=:=1, 
          new31(s(A,B,C,C1,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=D, B1=:=C, C1=:=D1+E1, D1=:=E, E1=:=1, 
          new6(s(A,B,C,D,C1,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=0, C1=:=I, D1=:=E1+F1, E1=:=M, F1=:=L, G1=:=H1+I1, 
          H1=:=I, I1=:=1, 
          new18(s(A,B,C,D,E,F,G,H,G1,C1,K,L,D1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=0, C1=:=I, D1=:=E1+F1, E1=:=M, F1=:=L, G1=:=H1+I1, 
          H1=:=I, I1=:=1, 
          new18(s(A,B,C,D,E,F,G,H,G1,C1,K,L,D1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=0, C1=:=D1+E1, D1=:=M, E1=:=L, F1=:=G1+H1, G1=:=I, 
          H1=:=1, 
          new18(s(A,B,C,D,E,F,G,H,F1,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=0, C1=:=I, D1=:=E1+F1, E1=:=I, F1=:=1, 
          new20(s(A,B,C,D,E,F,G,H,D1,C1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=0, C1=:=I, D1=:=E1+F1, E1=:=I, F1=:=1, 
          new20(s(A,B,C,D,E,F,G,H,D1,C1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=0, C1=:=D1+E1, D1=:=I, E1=:=1, 
          new20(s(A,B,C,D,E,F,G,H,C1,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=C1-D1, C1=:=C, D1=:=E, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=I, B1=:=C1-D1, C1=:=C, D1=:=E, E1=:=F1+G1, F1=:=J, G1=:=E, 
          new13(s(A,B,C,D,E,F,E1,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=C1-D1, C1=:=C, D1=:=E, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=I, B1=:=C1-D1, C1=:=C, D1=:=E, E1=:=F1+G1, F1=:=J, G1=:=E, 
          new13(s(A,B,C,D,E,F,E1,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=L, B1=:=1, C1=:=1, D1=:=E1+F1, E1=:=C1, F1=:=L, G1=:=1, 
          new18(s(A,B,C,D,E,F,G,H,G1,J,K,L,D1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=L, B1=:=1, C1=:=1, D1=:=E1+F1, E1=:=C1, F1=:=L, G1=:=1, 
          new18(s(A,B,C,D,E,F,G,H,G1,J,K,L,D1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=L, B1=:=1, C1=:=0, D1=:=1, 
          new20(s(A,B,C,D,E,F,G,H,D1,C1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, E1=:=0, F1=:=G1+H1, G1=:=E1, 
          H1=:=E, 
          new13(s(A,B,C,D,E,F,F1,H,I,E1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=0, C1=:=F, 
          new31(s(A,B,C,C1,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=0, C1=:=F, 
          new31(s(A,B,C,C1,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=0, C1=:=D1+E1, D1=:=E, E1=:=1, 
          new6(s(A,B,C,D,C1,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, E1=:= -1, F1=:=G1+H1, G1=:=E1, 
          H1=:=E, 
          new13(s(A,B,C,D,E,F,F1,H,I,E1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=C, B1=:=B, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=<B1, 
          A1=:=0, B1=:=C, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=0, B1=:=C, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=E, B1=:=H, C1=:=D1+E1, D1=:=E, E1=:=1, F1=:=E, G1=:=1, 
          new11(s(A,B,C,D,E,C1,G,H,I,J,F1,G1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=E, B1=:=H, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=H, B1=:=0, C1=:=0, 
          new6(s(A,B,C,D,C1,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=H, B1=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=<B1, 
          A1=:=0, B1=:=C, C1=:=D1-E1, D1=:=C, E1=:=1, 
          new5(s(A,B,C,D,E,F,G,C1,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=B, 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new2(s(A),d(B)) :- 
          new3(s(A,C,D,E,F,G,H,I,J,K,L,M,N),d(B,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
