new17(s(A,B,C,D,E),d(A,B,C,D,E)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=N+O, N=:=D, 
          O=:=1, P=:=Q-R, Q=:=E, R=:=1, new14(s(A,B,C,M,P),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=E, L=:=0, 
          new17(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=A, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=B, M=:=N+O, N=:=D, 
          O=:=1, P=:=Q-R, Q=:=E, R=:=1, new12(s(A,B,C,M,P),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=B, M=:=0, 
          new14(s(A,B,C,M,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=C, M=:=N+O, N=:=D, 
          O=:=1, P=:=Q-R, Q=:=E, R=:=1, new10(s(A,B,C,M,P),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=C, M=:=0, 
          new12(s(A,B,C,M,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=C, M=:=N+O, N=:=D, O=:=1, 
          P=:=Q+R, Q=:=E, R=:=1, new8(s(A,B,C,M,P),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=C, M=:=0, 
          new10(s(A,B,C,M,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=B, M=:=N+O, N=:=D, O=:=1, 
          P=:=Q+R, Q=:=E, R=:=1, new6(s(A,B,C,M,P),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=B, M=:=0, 
          new8(s(A,B,C,M,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=A, M=:=N+O, N=:=D, O=:=1, 
          P=:=Q+R, Q=:=E, R=:=1, new4(s(A,B,C,M,P),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=A, M=:=0, 
          new6(s(A,B,C,M,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, 
          new4(s(A,B,C,K,L),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
correct :- \+new1.
