new18(s(A,B,C,D),d(A,B,C,D)).
new16(s(A,B,C,D),d(A,E,F,G)) :- H=<I, H=:=B, I=:=A, F=:=J+K, J=:=C, K=:=B, 
          G=:=L*M, L=:=D, M=:=B, E=:=N+O, N=:=B, O=:=1.
new16(s(A,B,C,D),d(A,B,C,D)) :- E>=F+1, E=:=B, F=:=A.
new12(s(A,B,C,D),d(A,B,C,D)) :- E=:=5, new10(s(E,F,G,H),d(I,J,K,L)).
new12(s(A,B,C,D),d(E,F,G,H)) :- I=:=5, J=:=K, L=:=M+N, M=:=J, N=:=5, 
          new11(s(I,O,P,Q),d(R,S,K,T)), new7(s(L,B,J,D),d(E,F,G,H)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=0, K=:=1, 
          new16(s(A,I,J,K),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=0, K=:=1, 
          new17(s(A,I,J,K),d(E,F,G,H)).
new9(s(A,B,C,D),d(A,B,C,D)) :- E=:=A, new10(s(E,F,G,H),d(I,J,K,L)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I=:=A, J=:=K, L=:=M-N, M=:=J, N=:=1, 
          new11(s(I,O,P,Q),d(R,S,K,T)), new12(s(L,J,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=A, J=:=0, new18(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new7(s(K,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new7(s(K,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=D, J=:=0, new9(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new4(s(A,B,C,K),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=A, J=:=0, new5(s(A,B,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
correct :- \+new1.
