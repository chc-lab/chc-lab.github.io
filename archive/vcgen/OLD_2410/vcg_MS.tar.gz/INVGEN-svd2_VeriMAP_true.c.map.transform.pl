new24(s(A,B,C,D,E,F),d(A,B,C,D,E,F)).
new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=C, N=:=B, O=:=P+Q, P=:=E, 
          Q=:=1, new20(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=B, 
          new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=1, N=:=C, 
          new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=1, N=:=C, 
          new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, O=:=P+Q, P=:=D, 
          Q=:=1, new16(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new17(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, O=:=P+Q, P=:=E, 
          Q=:=1, new17(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new17(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, O=:=F, 
          new20(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=F, 
          new17(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, O=:=F, 
          new12(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=P+Q, P=:=D, 
          Q=:=1, new12(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, O=:=C, P=:=Q-R, 
          Q=:=C, R=:=1, new4(s(A,B,P,D,E,O),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=P+Q, P=:=D, 
          Q=:=1, new10(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, O=:=F, 
          new16(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=F, 
          new10(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=F, 
          new10(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, O=:=F, 
          new12(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=B, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=B, O=:=C, P=:=Q-R, 
          Q=:=C, R=:=1, new4(s(A,B,P,D,E,O),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=1, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=0, O=:=B, 
          new4(s(A,B,O,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=F, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
correct :- \+new1.
