new25(s(A,B,C),d(A,B,C)).
new19(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=A, V=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new19(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=A, V=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new19(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=0, 
          new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new13(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=1, L+1=<M, L=:=J, 
          M=:=N+O, N=:=B, O=:=1, new9(s(A,B,K),d(A,B,P)).
new13(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=0, L>=M, L=:=J, 
          M=:=N+O, N=:=B, O=:=1, new9(s(A,B,K),d(A,B,P)).
new13(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=1, V+1=<W, V=:=J, 
          W=:=X+Y, X=:=B, Y=:=1, new10(s(A,B,U),d(A,B,Z)), 
          new19(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new13(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, V>=W, V=:=J, 
          W=:=X+Y, X=:=B, Y=:=1, new10(s(A,B,U),d(A,B,Z)), 
          new19(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new10(s(A,B,C),d(A,B,C)) :- D>=E+1, D=:=C, E=:=0.
new10(s(A,B,C),d(A,B,C)) :- D+1=<E, D=:=C, E=:=0.
new10(s(A,B,C),d(A,B,D)) :- E=:=F, E=:=C, F=:=0, new24(s(A,B,C),d(A,B,D)).
new9(s(A,B,C),d(A,B,D)) :- E=:=F, E=:=C, F=:=0, new25(s(A,B,C),d(A,B,D)).
new8(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=1, L=<M, L=:=0, 
          M=:=J, new9(s(A,B,K),d(A,B,N)).
new8(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=0, 
          M=:=J, new9(s(A,B,K),d(A,B,N)).
new8(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=1, V=<W, V=:=0, 
          W=:=J, new10(s(A,B,U),d(A,B,X)), 
          new13(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new8(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, V>=W+1, V=:=0, 
          W=:=J, new10(s(A,B,U),d(A,B,X)), 
          new13(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new6(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V, U=:=W+X, W=:=G, 
          X=:=J, V=:=H, new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new6(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=W+X, W=:=G, 
          X=:=J, V=:=H, Y=:=Z+A1, Z=:=J, A1=:=1, 
          new8(s(A,B,C,D,E,F,G,H,I,Y),d(K,L,M,N,O,P,Q,R,S,T)).
new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new3(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=B, V=:=0, 
          W=:=0, X=:=0, Y=:=Z-A1, Z=:=B1+C1, B1=:=B, C1=:=1, A1=:=1, D1=:=W, 
          E1=:=W, F1=:=Y, G1=:=X, H1=:=0, 
          new4(s(A,B,W,X,Y,D1,E1,F1,G1,H1),d(K,L,M,N,O,P,Q,R,S,T)).
new3(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=<V, U=:=B, V=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new2(s(A,B),d(C,D)) :- new3(s(A,B,E,F,G,H,I,J,K,L),d(C,D,M,N,O,P,Q,R,S,T)).
new1 :- A=:=0, B=:=0, new2(s(A,B),d(C,D)).
inv1 :- \+new1.
