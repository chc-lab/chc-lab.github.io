new61(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F+1=<G, F=:=D, G=:=B, 
          new11(s(A,E),d(A,H)).
new61(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G, F=:=D, G=:=B, new11(s(A,E),d(A,H)).
new61(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J+1=<K, J=:=D, K=:=B, L=:=M+N, M=:=D, 
          N=:=1, new12(s(A,I),d(A,O)), new44(s(A,B,C,L),d(E,F,G,H)).
new61(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K, J=:=D, K=:=B, L=:=M+N, M=:=D, 
          N=:=1, new12(s(A,I),d(A,O)), new44(s(A,B,C,L),d(E,F,G,H)).
new56(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=0, G=:=D, new11(s(A,E),d(A,H)).
new56(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=0, G=:=D, 
          new11(s(A,E),d(A,H)).
new56(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=<K, J=:=0, K=:=D, 
          new12(s(A,I),d(A,L)), new61(s(A,B,C,D),d(E,F,G,H)).
new56(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K+1, J=:=0, K=:=D, 
          new12(s(A,I),d(A,L)), new61(s(A,B,C,D),d(E,F,G,H)).
new54(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=B, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new54(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=B, 
          new56(s(A,B,C,D),d(E,F,G,H)).
new51(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new51(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new51(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, K=:=L+M, L=:=C, M=:=1, 
          new54(s(A,B,K,D),d(E,F,G,H)).
new48(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, K=:=0, L=:=0, 
          new44(s(A,B,L,K),d(E,F,G,H)).
new48(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, K=:=0, L=:=0, 
          new44(s(A,B,L,K),d(E,F,G,H)).
new48(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, 
          new51(s(A,B,C,D),d(E,F,G,H)).
new44(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new40(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new40(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new40(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, 
          new44(s(A,B,C,D),d(E,F,G,H)).
new34(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F+1=<G, F=:=D, G=:=B, 
          new11(s(A,E),d(A,H)).
new34(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G, F=:=D, G=:=B, new11(s(A,E),d(A,H)).
new34(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J+1=<K, J=:=D, K=:=B, L=:=M+N, M=:=D, 
          N=:=1, new12(s(A,I),d(A,O)), new40(s(A,B,C,L),d(E,F,G,H)).
new34(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K, J=:=D, K=:=B, L=:=M+N, M=:=D, 
          N=:=1, new12(s(A,I),d(A,O)), new40(s(A,B,C,L),d(E,F,G,H)).
new29(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=0, G=:=D, new11(s(A,E),d(A,H)).
new29(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=0, G=:=D, 
          new11(s(A,E),d(A,H)).
new29(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=<K, J=:=0, K=:=D, 
          new12(s(A,I),d(A,L)), new34(s(A,B,C,D),d(E,F,G,H)).
new29(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K+1, J=:=0, K=:=D, 
          new12(s(A,I),d(A,L)), new34(s(A,B,C,D),d(E,F,G,H)).
new27(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=B, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new27(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=B, 
          new29(s(A,B,C,D),d(E,F,G,H)).
new25(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new25(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new25(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, 
          new48(s(A,B,C,D),d(E,F,G,H)).
new24(s(A,B),d(A,B)).
new15(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F+1=<G, F=:=D, G=:=B, 
          new11(s(A,E),d(A,H)).
new15(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G, F=:=D, G=:=B, new11(s(A,E),d(A,H)).
new15(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J+1=<K, J=:=D, K=:=B, L=:=M+N, M=:=D, 
          N=:=1, new12(s(A,I),d(A,O)), new6(s(A,B,C,L),d(E,F,G,H)).
new15(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K, J=:=D, K=:=B, L=:=M+N, M=:=D, 
          N=:=1, new12(s(A,I),d(A,O)), new6(s(A,B,C,L),d(E,F,G,H)).
new12(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new12(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new12(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new23(s(A,B),d(A,C)).
new11(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new24(s(A,B),d(A,C)).
new10(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=0, G=:=D, new11(s(A,E),d(A,H)).
new10(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=0, G=:=D, 
          new11(s(A,E),d(A,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=<K, J=:=0, K=:=D, 
          new12(s(A,I),d(A,L)), new15(s(A,B,C,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K+1, J=:=0, K=:=D, 
          new12(s(A,I),d(A,L)), new15(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new25(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new25(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, K=:=L+M, L=:=C, M=:=1, 
          new27(s(A,B,K,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- new7(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, 
          new5(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=B, J=:=0, new6(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,B,I,J),d(E,F,G,H)).
new2(s(A),d(B)) :- new3(s(A,C,D,E),d(B,F,G,H)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
