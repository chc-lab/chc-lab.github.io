new23(s(A),d(A)).
new17(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new17(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new17(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new22(s(A),d(B)).
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new23(s(A),d(B)).
new13(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new10(s(I,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, new11(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G=:=H+I, H=:=B, I=:=1, new4(s(A,G,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- new13(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=1, 
          new10(s(I,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, new11(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=1, F=:=B, new16(s(D),d(G)).
new8(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=1, F=:=B, new16(s(D),d(G)).
new8(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=B, J=:=K+L, K=:=A, L=:=1, 
          new17(s(G),d(M)), new6(s(J,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=B, J=:=K+L, K=:=A, L=:=1, 
          new17(s(G),d(M)), new6(s(J,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, new8(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, new9(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=C, I=:=1, new6(s(I,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=1, new4(s(A,G,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
