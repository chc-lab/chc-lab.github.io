new25(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new24(s(K,B,C,D),d(E,F,G,H)).
new25(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new24(s(K,B,C,D),d(E,F,G,H)).
new24(s(A,B,C,D),d(E,F,G,H)) :- new25(s(A,B,C,D),d(E,F,G,H)).
new22(s(A,B,C,D),d(E,F,G,H)) :- new24(s(A,B,C,D),d(E,F,G,H)).
new21(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=0, K=:=4, 
          new22(s(A,B,C,K),d(E,F,G,H)).
new21(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=C, J=:=0, K=:=5, 
          new22(s(A,B,C,K),d(E,F,G,H)).
new18(s(A,B,C,D),d(A,B,C,D)) :- E=:=F, E=:=B, F=:=0.
new18(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new17(s(K,B,C,D),d(E,F,G,H)).
new18(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new17(s(K,B,C,D),d(E,F,G,H)).
new17(s(A,B,C,D),d(E,F,G,H)) :- new18(s(A,B,C,D),d(E,F,G,H)).
new15(s(A,B,C,D),d(E,F,G,H)) :- new17(s(A,B,C,D),d(E,F,G,H)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=0, K=:=4, 
          new15(s(A,B,C,K),d(E,F,G,H)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=C, J=:=0, K=:=5, 
          new15(s(A,B,C,K),d(E,F,G,H)).
new13(s(A),d(A)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new13(s(A),d(B)).
new9(s(A,B),d(A,B)) :- C=:=1, D>=E+1, D=:=B, E=:=2, new10(s(C),d(F)).
new9(s(A,B),d(A,B)) :- C=:=1, D+1=<E, D=:=B, E=:=2, new10(s(C),d(F)).
new9(s(A,B),d(A,B)) :- C=:=0, D=:=E, D=:=B, E=:=2, new10(s(C),d(F)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, new14(s(I,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, new21(s(I,B,C,D),d(E,F,G,H)).
new6(s(A,B),d(A,B)) :- new7(s(C,D,E,F),d(G,H,I,J)).
new6(s(A,B),d(C,D)) :- new8(s(E,F,G,H),d(I,J,K,L)), new9(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- new6(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=0, G=:=1, new4(s(A,G),d(C,D)).
new3(s(A,B),d(C,D)) :- E=<F, E=:=A, F=:=0, G=:=3, new4(s(A,G),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
