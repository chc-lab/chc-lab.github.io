new32(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H, G=:=D, H=:=I*J, I=:=2, J=:=B, 
          new16(s(A,F),d(A,K)).
new32(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=D, H=:=I*J, I=:=2, 
          J=:=B, new16(s(A,F),d(A,K)).
new32(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M, L=:=D, M=:=N*O, N=:=2, O=:=B, 
          P=:=Q+R, Q=:=D, R=:=1, new17(s(A,K),d(A,S)), 
          new13(s(A,B,C,P,E),d(F,G,H,I,J)).
new32(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=D, M=:=N*O, N=:=2, 
          O=:=B, P=:=Q+R, Q=:=D, R=:=1, new17(s(A,K),d(A,S)), 
          new13(s(A,B,C,P,E),d(F,G,H,I,J)).
new31(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=E, 
          new32(s(A,B,C,D,E),d(F,G,H,I,J)).
new31(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=E, 
          new26(s(A,B,C,D,E),d(F,G,H,I,J)).
new30(s(A,B),d(A,B)).
new26(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L+M, L=:=C, M=:=1, 
          new8(s(A,B,K,D,E),d(F,G,H,I,J)).
new20(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G=<H, G=:=D, H=:=E, 
          new16(s(A,F),d(A,I)).
new20(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H+1, G=:=D, H=:=E, 
          new16(s(A,F),d(A,I)).
new20(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L=<M, L=:=D, M=:=E, 
          new17(s(A,K),d(A,N)), new26(s(A,B,C,D,E),d(F,G,H,I,J)).
new20(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=D, M=:=E, 
          new17(s(A,K),d(A,N)), new26(s(A,B,C,D,E),d(F,G,H,I,J)).
new17(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new17(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new17(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new29(s(A,B),d(A,C)).
new16(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new30(s(A,B),d(A,C)).
new15(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H, G=:=D, H=:=E, 
          new16(s(A,F),d(A,I)).
new15(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=D, H=:=E, 
          new16(s(A,F),d(A,I)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M, L=:=D, M=:=E, 
          new17(s(A,K),d(A,N)), new20(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=D, M=:=E, 
          new17(s(A,K),d(A,N)), new20(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- new31(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, M=:=C, 
          new13(s(A,B,C,M,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, M=:=C, 
          new13(s(A,B,C,M,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=E, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=E, M=:=N+O, N=:=B, O=:=1, 
          new4(s(A,M,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=E, M=:=N*O, N=:=2, O=:=B, 
          new8(s(A,B,M,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=E, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=E, M=:=0, 
          new4(s(A,M,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=E, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=E, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
