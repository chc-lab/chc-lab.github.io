new17(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N-O, N=:=B, O=:=1, P=:=Q+R, Q=:=A, 
          R=:=1, new5(s(P,M,C,D,E,F),d(G,H,I,J,K,L)).
new16(s(A),d(A)).
new15(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new16(s(A),d(B)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=0, O=:=1, 
          new9(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=0, O=:=0, 
          new9(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=0, O=:=0, 
          new9(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=F, new15(s(G),d(H)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=O*P, O=:=C, P=:=2, 
          Q=:=1, new9(s(A,B,C,D,E,Q),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=O*P, O=:=C, P=:=2, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=O*P, O=:=C, P=:=2, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=B, O=:=P+Q, P=:=E, 
          Q=:=2, new17(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=A, N=:=B, 
          new17(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=A, N=:=C, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=C, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, N>=0, O=:=M, M>=0, P=:=0, Q=:=1, 
          new5(s(Q,B,O,M,P,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=10, 
          new4(s(A,M,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
inv1 :- \+new1.
