new44(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=0, M=:=N-O, N=:=A, 
          O=:=1, new47(s(M,B,C,D,E),d(F,G,H,I,J)).
new44(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=0, M=:=N-O, N=:=A, 
          O=:=1, new47(s(M,B,C,D,E),d(F,G,H,I,J)).
new44(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=0, M=:=N+O, N=:=A, 
          O=:=10, new47(s(M,B,C,D,E),d(F,G,H,I,J)).
new43(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new44(s(M,B,C,D,E),d(F,G,H,I,J)).
new43(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new44(s(M,B,C,D,E),d(F,G,H,I,J)).
new43(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, 
          new44(s(A,B,C,D,E),d(F,G,H,I,J)).
new42(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, new43(s(A,B,C,K,L),d(F,G,H,I,J)).
new41(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, new42(s(A,K,L,D,E),d(F,G,H,I,J)).
new38(s(A,B,C,D,E),d(A,B,C,D,E)).
new35(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=0, M=:=N-O, N=:=A, 
          O=:=1, new38(s(M,B,C,D,E),d(F,G,H,I,J)).
new35(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=0, M=:=N-O, N=:=A, 
          O=:=1, new38(s(M,B,C,D,E),d(F,G,H,I,J)).
new35(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=0, M=:=N+O, N=:=A, 
          O=:=10, new38(s(M,B,C,D,E),d(F,G,H,I,J)).
new34(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new35(s(M,B,C,D,E),d(F,G,H,I,J)).
new34(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, new35(s(M,B,C,D,E),d(F,G,H,I,J)).
new34(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, 
          new35(s(A,B,C,D,E),d(F,G,H,I,J)).
new33(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, new34(s(A,B,C,K,L),d(F,G,H,I,J)).
new32(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, new33(s(A,K,L,D,E),d(F,G,H,I,J)).
new30(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, new32(s(K,B,C,D,E),d(F,G,H,I,J)).
new29(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, new41(s(K,B,C,D,E),d(F,G,H,I,J)).
new28(s(A),d(A)).
new26(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new28(s(A),d(B)).
new25(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)) :- I=:=1, J=<K, J=:=B, K=:=0, 
          new26(s(I),d(L)).
new25(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)) :- I=:=0, J>=K+1, J=:=B, K=:=0, 
          new26(s(I),d(L)).
new23(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=B, R=:=0, S=:=T-U, 
          T=:=B, U=:=A, new22(s(A,S,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new23(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=<R, Q=:=B, R=:=0, 
          new25(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new22(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new23(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new19(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new22(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=E, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, new19(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=E, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, new19(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=E, R=:=0, 
          new19(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new16(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)) :- 
          new29(s(I,J,K,L,M),d(N,O,P,Q,R)).
new16(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new30(s(Q,R,S,T,U),d(V,W,X,Y,Z)), 
          new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new15(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=C, R=:=0, 
          new16(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new15(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=C, R=:=0, 
          new16(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new15(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=C, R=:=0, 
          new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new15(s(A,B,C,D,Q,F,G,R),d(I,J,K,L,M,N,O,P)).
new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new14(s(A,B,Q,D,E,F,R,H),d(I,J,K,L,M,N,O,P)).
new12(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new10(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)) :- 
          new29(s(I,J,K,L,M),d(N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new30(s(Q,R,S,T,U),d(V,W,X,Y,Z)), 
          new12(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new7(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=E, R=:=0, 
          new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new7(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=E, R=:=0, 
          new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new7(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=E, R=:=0, 
          new12(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=C, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, new7(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=C, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, new7(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=C, R=:=0, 
          new7(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new6(s(A,B,C,D,Q,R,G,H),d(I,J,K,L,M,N,O,P)).
new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new5(s(A,B,Q,R,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=1, 
          new4(s(Q,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new1 :- new2(s,d).
inv1 :- \+new1.
