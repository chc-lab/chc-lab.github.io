new12(s(A),d(A)).
new9(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new12(s(A),d(B)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F>=G+1, F=:=D, D>=0, G=:=A, A>=0, 
          new9(s(E),d(H)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F+1=<G, F=:=D, D>=0, G=:=A, A>=0, 
          new9(s(E),d(H)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F=:=G, F=:=D, D>=0, G=:=A, A>=0, 
          new9(s(E),d(H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, C>=0, J=:=0, K=:=L-M, L=:=C, 
          C>=0, M=:=1, N=:=O+P, O=:=D, D>=0, P=:=1, new5(s(A,B,K,N),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=C, C>=0, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- new6(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, J>=0, K=:=I, I>=0, L=:=K, K>=0, M=:=0, 
          new5(s(K,I,L,M),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- new4(s(A,B,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
