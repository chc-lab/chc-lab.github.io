new11(s(A),d(A)).
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new11(s(A),d(B)).
new7(s(A),d(A)) :- B=:=1, C=:=D, C=:=A, D=:=1, new8(s(B),d(E)).
new7(s(A),d(A)) :- B=:=0, C>=D+1, C=:=A, D=:=1, new8(s(B),d(E)).
new7(s(A),d(A)) :- B=:=0, C+1=<D, C=:=A, D=:=1, new8(s(B),d(E)).
new6(s(A),d(B)) :- B=:=1.
new4(s(A),d(A)) :- new5(s(B),d(C)).
new4(s(A),d(B)) :- C=:=D, new6(s(E),d(D)), new7(s(C),d(B)).
new3(s(A),d(B)) :- new4(s(A),d(B)).
new2(s,d) :- new3(s(A),d(B)).
new1 :- new2(s,d).
inv1 :- \+new1.
