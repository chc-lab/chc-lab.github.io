new22(s(A),d(B)) :- new22(s(A),d(B)).
new21(s(A),d(A)).
new19(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new21(s(A),d(B)).
new18(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H>=I, H=:=C, I=:=0, 
          new19(s(G),d(J)).
new18(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H+1=<I, H=:=C, I=:=0, 
          new19(s(G),d(J)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=0, O=:=P-Q, P=:=D, 
          Q=:=1, R=:=S+T, S=:=F, T=:=1, U=:=V+W, V=:=O, W=:=R, 
          new15(s(A,U,C,O,E,R),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=0, 
          new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=0, O=:=P-Q, P=:=C, 
          Q=:=1, R=:=S+T, S=:=E, T=:=1, U=:=V+W, V=:=O, W=:=R, 
          new11(s(A,U,O,D,R,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=C, N=:=0, O=:=E, P=:=0, 
          Q=:=R+S, R=:=O, S=:=P, new15(s(A,Q,C,O,E,P),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=A, O=:=200, P=:=0, 
          Q=:=A, R=:=S+T, S=:=Q, T=:=P, new5(s(M),d(U)), 
          new11(s(A,R,Q,D,P,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=A, O=:=200, P=:=0, 
          Q=:=A, R=:=S+T, S=:=Q, T=:=P, new5(s(M),d(U)), 
          new11(s(A,R,Q,D,P,F),d(G,H,I,J,K,L)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new22(s(A),d(B)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N>=O, N=:=A, O=:=0, 
          new5(s(M),d(P)), new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N+1=<O, N=:=A, O=:=0, 
          new5(s(M),d(P)), new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
inv1 :- \+new1.
