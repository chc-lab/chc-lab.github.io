new29(s(A,B),d(A,C)) :- new29(s(A,B),d(A,C)).
new26(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=D, M=:=N+O, N=:=B, 
          O=:=1, new11(s(A,M,C,D,E),d(F,G,H,I,J)).
new26(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=D, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new25(s(A,B),d(A,B)).
new19(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new19(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new19(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new24(s(A,B),d(A,C)).
new18(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new25(s(A,B),d(A,C)).
new16(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G=<H, G=:=1, H=:=B, 
          new18(s(A,F),d(A,I)).
new16(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H+1, G=:=1, H=:=B, 
          new18(s(A,F),d(A,I)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L=<M, L=:=1, M=:=B, N=:=O+P, O=:=B, 
          P=:=1, new19(s(A,K),d(A,Q)), new14(s(A,N,C,D,E),d(F,G,H,I,J)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=1, M=:=B, N=:=O+P, 
          O=:=B, P=:=1, new19(s(A,K),d(A,Q)), new14(s(A,N,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=D, 
          new16(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=D, M=:=N+O, N=:=C, O=:=1, 
          new7(s(A,B,M,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=E, new14(s(A,K,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- new26(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, M=:=E, 
          new11(s(A,M,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, M=:=E, 
          new11(s(A,M,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=D, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new5(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new5(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new29(s(A,B),d(A,C)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M+1, L=:=E, M=:=0, N=:=1, 
          new5(s(A,K),d(A,O)), new7(s(A,B,N,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=<M, L=:=E, M=:=0, N=:=1, 
          new5(s(A,K),d(A,O)), new7(s(A,B,N,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- new4(s(A,B,C,D,E),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
