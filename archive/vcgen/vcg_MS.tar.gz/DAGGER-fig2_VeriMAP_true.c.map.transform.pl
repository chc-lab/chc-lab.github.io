new21(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=B, Q=:=R*S, 
          R=:= -1, S=:=A, T=:=U*V, U=:= -1, V=:=B, 
          new4(s(Q,T,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new21(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=B, 
          new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=C, 
          new21(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=C, 
          new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=4, Q=:=R+S, R=:=A, 
          S=:=1, T=:=U+V, U=:=B, V=:=3, W=:=X+Y, X=:=C, Y=:=10, Z=:=A1+B1, 
          A1=:=D, B1=:=10, new4(s(Q,T,W,Z,E,F,G),d(H,I,J,K,L,M,N)).
new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=4, 
          new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=0, 
          new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=0, 
          new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=E, P=:=0, 
          new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new17(s(A,B,C,D,O,F,G),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=F, P=:=0, Q=:=R+S, 
          R=:=A, S=:=1, T=:=U+V, U=:=B, V=:=2, 
          new4(s(Q,T,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=F, P=:=0, Q=:=R+S, 
          R=:=A, S=:=1, T=:=U+V, U=:=B, V=:=2, 
          new4(s(Q,T,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=F, P=:=0, 
          new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A),d(A)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new12(s(A),d(B)).
new9(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I>=J, I=:=K*L, K=:=3, L=:=A, 
          J=:=B, new10(s(H),d(M)).
new9(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I+1=<J, I=:=K*L, K=:=3, 
          L=:=A, J=:=B, new10(s(H),d(M)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new13(s(A,B,C,D,E,O,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=G, P=:=0, 
          new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=G, P=:=0, 
          new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=G, P=:=0, 
          new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new6(s(A,B,C,D,E,F,O),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P=:=O, Q=:=P, R=:=Q, 
          new4(s(R,Q,P,O,E,F,G),d(H,I,J,K,L,M,N)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new1 :- new2(s,d).
inv1 :- \+new1.
