new29(s(A),d(A)).
new23(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new23(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new23(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new28(s(A),d(B)).
new22(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new29(s(A),d(B)).
new21(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H+1, G=:=E, H=:=0, 
          new22(s(F),d(I)).
new21(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G=<H, G=:=E, H=:=0, new22(s(F),d(I)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M+1, L=:=E, M=:=0, N=:=O+P, 
          O=:=D, P=:=1, Q=:=R-S, R=:=E, S=:=1, new23(s(K),d(T)), 
          new19(s(A,B,C,N,Q),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=<M, L=:=E, M=:=0, N=:=O+P, O=:=D, 
          P=:=1, Q=:=R-S, R=:=E, S=:=1, new23(s(K),d(T)), 
          new19(s(A,B,C,N,Q),d(F,G,H,I,J)).
new20(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=A, 
          new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new19(s(A,B,C,D,E),d(F,G,H,I,J)) :- new20(s(A,B,C,D,E),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=B, M=:=N+O, N=:=D, 
          O=:=1, P=:=Q-R, Q=:=E, R=:=1, new16(s(A,B,C,M,P),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=B, M=:=0, 
          new19(s(A,B,C,M,E),d(F,G,H,I,J)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- new17(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=C, M=:=N+O, N=:=D, 
          O=:=1, P=:=Q-R, Q=:=E, R=:=1, new13(s(A,B,C,M,P),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=C, M=:=0, 
          new16(s(A,B,C,M,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=C, M=:=N+O, N=:=D, 
          O=:=1, P=:=Q+R, Q=:=E, R=:=1, new10(s(A,B,C,M,P),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=C, M=:=0, 
          new13(s(A,B,C,M,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=B, M=:=N+O, N=:=D, O=:=1, 
          P=:=Q+R, Q=:=E, R=:=1, new7(s(A,B,C,M,P),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=B, M=:=0, 
          new10(s(A,B,C,M,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=A, M=:=N+O, N=:=D, O=:=1, 
          P=:=Q+R, Q=:=E, R=:=1, new4(s(A,B,C,M,P),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=A, M=:=0, 
          new7(s(A,B,C,M,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, 
          new4(s(A,B,C,K,L),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
