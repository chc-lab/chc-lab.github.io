new19(s(A,B),d(A,C)) :- new19(s(A,B),d(A,C)).
new14(s(A,B),d(A,B)).
new12(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new14(s(A,B),d(A,C)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H, G=:=D, H=:=0, 
          new12(s(A,F),d(A,I)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=D, H=:=0, 
          new12(s(A,F),d(A,I)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M, L=:=D, M=:=0, N=:=O+P, O=:=C, 
          P=:=1, new5(s(A,K),d(A,Q)), new7(s(A,B,N,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=D, M=:=0, N=:=O+P, 
          O=:=C, P=:=1, new5(s(A,K),d(A,Q)), new7(s(A,B,N,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=C, L=:=B, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=C, L=:=B, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new5(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new5(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new19(s(A,B),d(A,C)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L=<M, L=:=C, M=:=B, 
          new5(s(A,K),d(A,N)), new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=C, M=:=B, 
          new5(s(A,K),d(A,N)), new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, 
          new4(s(A,B,C,K,L),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
