new19(s(A),d(A)).
new17(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new19(s(A),d(B)).
new14(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=A, G=:=7, new17(s(E),d(H)).
new14(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=A, G=:=7, new17(s(E),d(H)).
new13(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=L+M, L=:=A, M=:=4, 
          new14(s(K,B,C,D),d(E,F,G,H)).
new13(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=0, K=:=L+M, L=:=A, M=:=4, 
          new14(s(K,B,C,D),d(E,F,G,H)).
new13(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=D, J=:=0, 
          new14(s(A,B,C,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- new13(s(A,B,C,I),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=0, K=:=L+M, L=:=A, M=:=2, 
          new10(s(K,B,C,D),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=0, K=:=L+M, L=:=A, M=:=2, 
          new10(s(K,B,C,D),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=C, J=:=0, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- new9(s(A,B,I,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new6(s(K,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new6(s(K,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=B, J=:=0, new6(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,I,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, new4(s(I,B,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
