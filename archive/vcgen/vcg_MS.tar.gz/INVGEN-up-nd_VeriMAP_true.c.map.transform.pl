new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=D, 
          O=:=B, new4(s(A,B,C,M,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=B, L=:=0, M=:=N+O, N=:=D, O=:=1, 
          new4(s(A,B,C,M,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(A,B,C,D,E)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=D, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=0, M=:=N+O, N=:=E, O=:=1, 
          P=:=Q-R, Q=:=D, R=:=1, new7(s(A,B,C,P,M),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=A, 
          new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- new12(s(A,K,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=A, M=:=N+O, N=:=C, O=:=1, 
          new6(s(A,B,M,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=A, M=:=0, 
          new7(s(A,B,C,D,M),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, 
          new4(s(A,B,K,L,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
