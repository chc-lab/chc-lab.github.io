new19(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=4, I=:=1, J=:=6, 
          new12(s(A,I,J),d(D,E,F)).
new19(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=4, I=:=2, 
          new12(s(A,I,C),d(D,E,F)).
new19(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=4, I=:=2, 
          new12(s(A,I,C),d(D,E,F)).
new16(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=3, I=:=1, J=:=5, 
          new12(s(A,I,J),d(D,E,F)).
new16(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=3, new19(s(A,B,C),d(D,E,F)).
new16(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=3, new19(s(A,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=2, I=:=3, J=:=4, 
          new12(s(A,I,J),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=2, new16(s(A,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=2, new16(s(A,B,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G=:=H+I, H=:=A, I=:=1, new4(s(G,B,C),d(D,E,F)).
new11(s(A),d(A)).
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new11(s(A),d(B)).
new7(s(A,B,C),d(A,B,C)) :- D=:=1, E>=F+1, E=:=C, F=:=6, new8(s(D),d(G)).
new7(s(A,B,C),d(A,B,C)) :- D=:=1, E+1=<F, E=:=C, F=:=6, new8(s(D),d(G)).
new7(s(A,B,C),d(A,B,C)) :- D=:=0, E=:=F, E=:=C, F=:=6, new8(s(D),d(G)).
new6(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=1, I=:=2, J=:=3, 
          new12(s(A,I,J),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=1, new13(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=1, new13(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=10, new6(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=10, new7(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=1, new4(s(G,H,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
