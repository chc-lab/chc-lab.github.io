new18(s(A),d(B)) :- new18(s(A),d(B)).
new17(s(A),d(A)).
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new17(s(A),d(B)).
new13(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=0, I=:=0, 
          new12(s(A,B,I),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G>=H, G=:=B, H=:=0, I=:=1, new12(s(A,B,I),d(D,E,F)).
new12(s(A,B,C),d(A,B,C)) :- D=:=C, new16(s(D),d(E)).
new11(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=100, I=:=0, 
          new12(s(A,B,I),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=100, new13(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=100, I=:=J+K, J=:=B, K=:=1, 
          L=:=M+N, M=:=A, N=:=1, new7(s(L,I,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=100, new11(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- new9(s(A,B,C),d(D,E,F)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new18(s(A),d(B)).
new4(s(A,B,C),d(D,E,F)) :- G=:=1, H>=I, H=:=B, I=:=0, J=:=0, new5(s(G),d(K)), 
          new7(s(J,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=:=0, H+1=<I, H=:=B, I=:=0, J=:=0, new5(s(G),d(K)), 
          new7(s(J,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- new4(s(A,B,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
