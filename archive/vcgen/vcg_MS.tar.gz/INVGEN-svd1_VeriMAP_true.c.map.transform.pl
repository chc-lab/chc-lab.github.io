new179(s(A,B),d(A,C)) :- new179(s(A,B),d(A,C)).
new171(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=F, I=:=B, 
          new14(s(A,G),d(A,J)).
new171(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=F, I=:=B, 
          new14(s(A,G),d(A,J)).
new171(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=F, O=:=B, P=:=Q+R, 
          Q=:=D, R=:=1, new15(s(A,M),d(A,S)), 
          new40(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new171(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=F, O=:=B, P=:=Q+R, 
          Q=:=D, R=:=1, new15(s(A,M),d(A,S)), 
          new40(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new165(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=F, 
          new14(s(A,G),d(A,J)).
new165(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=F, 
          new14(s(A,G),d(A,J)).
new165(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=F, 
          new15(s(A,M),d(A,P)), new171(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new165(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=F, 
          new15(s(A,M),d(A,P)), new171(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new159(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new159(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new159(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=C, O=:=B, 
          new15(s(A,M),d(A,P)), new165(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new159(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=C, O=:=B, 
          new15(s(A,M),d(A,P)), new165(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new153(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new153(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new153(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new159(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new153(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new159(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new147(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=D, I=:=B, 
          new14(s(A,G),d(A,J)).
new147(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=D, I=:=B, 
          new14(s(A,G),d(A,J)).
new147(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=D, O=:=B, 
          new15(s(A,M),d(A,P)), new153(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new147(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=D, O=:=B, 
          new15(s(A,M),d(A,P)), new153(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new135(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=D, I=:=B, 
          new14(s(A,G),d(A,J)).
new135(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=D, I=:=B, 
          new14(s(A,G),d(A,J)).
new135(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=D, O=:=B, P=:=Q+R, 
          Q=:=E, R=:=1, new15(s(A,M),d(A,S)), 
          new75(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new135(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=D, O=:=B, P=:=Q+R, 
          Q=:=E, R=:=1, new15(s(A,M),d(A,S)), 
          new75(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new129(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new14(s(A,G),d(A,J)).
new129(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new14(s(A,G),d(A,J)).
new129(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, 
          new15(s(A,M),d(A,P)), new135(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new129(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, 
          new15(s(A,M),d(A,P)), new135(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new123(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=E, I=:=B, 
          new14(s(A,G),d(A,J)).
new123(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=E, I=:=B, 
          new14(s(A,G),d(A,J)).
new123(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=E, O=:=B, 
          new15(s(A,M),d(A,P)), new129(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new123(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=E, O=:=B, 
          new15(s(A,M),d(A,P)), new129(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new111(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new111(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new111(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=C, O=:=B, P=:=Q+R, 
          Q=:=E, R=:=1, new15(s(A,M),d(A,S)), 
          new79(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new111(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=C, O=:=B, P=:=Q+R, 
          Q=:=E, R=:=1, new15(s(A,M),d(A,S)), 
          new79(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new105(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new105(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new105(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new111(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new105(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new111(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new99(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=D, I=:=B, 
          new14(s(A,G),d(A,J)).
new99(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=D, I=:=B, 
          new14(s(A,G),d(A,J)).
new99(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=D, O=:=B, 
          new15(s(A,M),d(A,P)), new105(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new99(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=D, O=:=B, 
          new15(s(A,M),d(A,P)), new105(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new93(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new14(s(A,G),d(A,J)).
new93(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new14(s(A,G),d(A,J)).
new93(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, 
          new15(s(A,M),d(A,P)), new99(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new93(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, 
          new15(s(A,M),d(A,P)), new99(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new87(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=E, I=:=B, 
          new14(s(A,G),d(A,J)).
new87(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=E, I=:=B, 
          new14(s(A,G),d(A,J)).
new87(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=E, O=:=B, 
          new15(s(A,M),d(A,P)), new93(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new87(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=E, O=:=B, 
          new15(s(A,M),d(A,P)), new93(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new81(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=E, 
          new14(s(A,G),d(A,J)).
new81(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=E, 
          new14(s(A,G),d(A,J)).
new81(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=E, 
          new15(s(A,M),d(A,P)), new87(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new81(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=E, 
          new15(s(A,M),d(A,P)), new87(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new80(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new81(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new80(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, O=:=P+Q, P=:=D, 
          Q=:=1, new73(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new79(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new80(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new78(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=E, 
          new14(s(A,G),d(A,J)).
new78(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=E, 
          new14(s(A,G),d(A,J)).
new78(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=E, 
          new15(s(A,M),d(A,P)), new123(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new78(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=E, 
          new15(s(A,M),d(A,P)), new123(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new77(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new78(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new77(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, O=:=F, 
          new79(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new75(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new77(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new74(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=F, 
          new75(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new74(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, 
          new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new73(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new74(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new72(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new14(s(A,G),d(A,J)).
new72(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new14(s(A,G),d(A,J)).
new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, 
          new15(s(A,M),d(A,P)), new147(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, 
          new15(s(A,M),d(A,P)), new147(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new71(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, 
          new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new71(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, O=:=F, 
          new73(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new63(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new63(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new63(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=C, O=:=B, P=:=Q+R, 
          Q=:=D, R=:=1, new15(s(A,M),d(A,S)), 
          new43(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new63(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=C, O=:=B, P=:=Q+R, 
          Q=:=D, R=:=1, new15(s(A,M),d(A,S)), 
          new43(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new57(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new57(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new63(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new63(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=D, I=:=B, 
          new14(s(A,G),d(A,J)).
new51(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=D, I=:=B, 
          new14(s(A,G),d(A,J)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=D, O=:=B, 
          new15(s(A,M),d(A,P)), new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=D, O=:=B, 
          new15(s(A,M),d(A,P)), new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new45(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new14(s(A,G),d(A,J)).
new45(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new14(s(A,G),d(A,J)).
new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, 
          new15(s(A,M),d(A,P)), new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, 
          new15(s(A,M),d(A,P)), new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new44(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, 
          new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new44(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new44(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=F, 
          new43(s(A,B,C,M,E,F),d(G,H,I,J,K,L)).
new40(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new71(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new39(s(A,B),d(A,B)).
new30(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new30(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=C, O=:=B, P=:=C, 
          Q=:=R-S, R=:=C, S=:=1, new15(s(A,M),d(A,T)), 
          new7(s(A,B,Q,D,E,P),d(G,H,I,J,K,L)).
new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=C, O=:=B, P=:=C, 
          Q=:=R-S, R=:=C, S=:=1, new15(s(A,M),d(A,T)), 
          new7(s(A,B,Q,D,E,P),d(G,H,I,J,K,L)).
new24(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new24(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new18(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=C, I=:=B, 
          new14(s(A,G),d(A,J)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=C, O=:=B, 
          new15(s(A,M),d(A,P)), new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=C, O=:=B, 
          new15(s(A,M),d(A,P)), new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new15(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new15(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new15(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new38(s(A,B),d(A,C)).
new14(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new39(s(A,B),d(A,C)).
new13(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new13(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=C, 
          new14(s(A,G),d(A,J)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=C, 
          new15(s(A,M),d(A,P)), new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=F, 
          new40(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=F, 
          new40(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=B, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=B, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=1, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new5(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new5(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new179(s(A,B),d(A,C)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N>=O+1, N=:=F, O=:=0, P=:=B, 
          new5(s(A,M),d(A,Q)), new7(s(A,B,P,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N=<O, N=:=F, O=:=0, P=:=B, 
          new5(s(A,M),d(A,Q)), new7(s(A,B,P,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
