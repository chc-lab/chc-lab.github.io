new229(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=1, G1=:=0, 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,G1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new229(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=1, G1=:=2, 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,G1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new229(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=1, G1=:=2, 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,G1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)).
new223(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=1, G1=:=0, 
          new226(s(A,B,C,D,E,F,G,H,I,J,K,G1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new223(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=1, G1=:=2, 
          new226(s(A,B,C,D,E,F,G,H,I,J,K,G1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new223(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=1, G1=:=2, 
          new226(s(A,B,C,D,E,F,G,H,I,J,K,G1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=B, F1=:=0, G1=:=2, H1=:=1, 
          new219(s(A,B,C,D,E,F,G1,H1,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=B, F1=:=0, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=B, F1=:=0, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,E1,F1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,G1,H1)).
new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=2, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,F1,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)), 
          new217(s(H1,I1,J1,E1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, G1=:=H1+I1, H1=:=E, I1=:=1, J1=:=0, K1=:=1, 
          new214(s(F1,J1,C,K1,G1,E1,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=H, F1=:=1, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=H, F1=:=1, 
          new207(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=H, F1=:=1, 
          new207(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new207(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=H, F1=:=0, 
          new207(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=H, F1=:=0, 
          new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=H, F1=:=0, 
          new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q,R)) :- 
          new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1)).
new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1)), 
          new139(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=P, L1=:=0, M1=:=1, 
          new201(s(A,B,C,D,E,F,M1,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=P, L1=:=0, M1=:=1, 
          new201(s(A,B,C,D,E,F,M1,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=P, L1=:=0, 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=0, 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=C, H1=:=1, I1=:=1, 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=C, H1=:=1, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=C, H1=:=1, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=0, 
          new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=D, H1=:=1, I1=:=1, 
          new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=D, H1=:=1, 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=D, H1=:=1, 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=Q, J1=:=0, K1=:=0, 
          new182(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=Q, J1=:=0, K1=:=0, 
          new182(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=Q, J1=:=0, 
          new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=1, 
          new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=1, 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=1, 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new176(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,P,Q)) :- 
          new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,H1)).
new176(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,J1)), 
          new181(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=0, K1=:=0, 
          new176(s(A,B,C,D,E,F,K1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=0, K1=:=0, 
          new176(s(A,B,C,D,E,F,K1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=0, 
          new176(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new173(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=H, H1=:=1, 
          new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new173(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=H, H1=:=1, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new173(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=H, H1=:=1, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=B, H1=:=1, I1=:=2, J1=:=1, K1=:=P, 
          new170(s(A,B,C,D,E,F,G,H,I,J,K,I1,J1,N,K1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=B, H1=:=1, 
          new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=B, H1=:=1, 
          new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)).
new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)).
new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=E, H1=:=J, 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=E, H1=:=J, 
          new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=E, H1=:=J, 
          new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=F, H1=:=K, 
          new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=F, H1=:=K, 
          new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=F, H1=:=K, 
          new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,P,Q)) :- 
          new173(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,H1)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,J1)), 
          new175(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,P)) :- 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,F1,G1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,H1,I1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=2, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,H1,I1),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new160(s(J1,K1,G1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=A, H1=:=G1, I1=:=J1+K1, J1=:=J, K1=:=1, L1=:=1, M1=:=1, 
          new157(s(A,L1,M1,D,E,F,G,H,I,I1,H1,L,M,N,O,G1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=1, I1=:=O, 
          new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=1, 
          new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=1, 
          new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=0, 
          new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=0, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=0, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q,R)) :- 
          new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,H1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,I1)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2)), 
          new130(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=1, 
          new145(s(A,B,C,D,E,F,G,H,I,J,K,M1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=1, 
          new145(s(A,B,C,D,E,F,G,H,I,J,K,M1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=L, L1=:=0, 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=L, L1=:=0, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=L, L1=:=0, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new138(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=G, L1=:=0, 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=G, L1=:=0, 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=G, L1=:=0, 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=0, 
          new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=0, 
          new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=0, 
          new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q,R)) :- 
          new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,H1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,I1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,L1)), 
          new134(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=B, F1=:=0, G1=:=2, H1=:=1, 
          new126(s(A,B,C,D,E,F,G1,H1,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=B, F1=:=0, 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=B, F1=:=0, 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new124(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=2, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,F1,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1)), 
          new124(s(H1,I1,J1,E1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, G1=:=H1+I1, H1=:=E, I1=:=1, J1=:=0, K1=:=1, 
          new122(s(F1,J1,C,K1,G1,E1,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=H, F1=:=1, 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=H, F1=:=1, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=H, F1=:=1, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new124(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=H, F1=:=0, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=H, F1=:=0, 
          new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=H, F1=:=0, 
          new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1)), 
          new54(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=P, L1=:=0, M1=:=1, 
          new110(s(A,B,C,D,E,F,M1,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=P, L1=:=0, M1=:=1, 
          new110(s(A,B,C,D,E,F,M1,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=P, L1=:=0, 
          new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=0, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=C, H1=:=1, I1=:=1, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=C, H1=:=1, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=C, H1=:=1, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=0, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=D, H1=:=1, I1=:=1, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=D, H1=:=1, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=D, H1=:=1, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new91(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=Q, J1=:=0, K1=:=0, 
          new91(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=Q, J1=:=0, K1=:=0, 
          new91(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=Q, J1=:=0, 
          new91(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=1, 
          new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=1, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=1, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,J1)), 
          new90(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=0, K1=:=0, 
          new86(s(A,B,C,D,E,F,K1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=0, K1=:=0, 
          new86(s(A,B,C,D,E,F,K1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=0, 
          new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=H, H1=:=1, 
          new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=H, H1=:=1, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=H, H1=:=1, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=B, H1=:=1, I1=:=2, J1=:=1, K1=:=P, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,I1,J1,N,K1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=B, H1=:=1, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=B, H1=:=1, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=E, H1=:=J, 
          new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=E, H1=:=J, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=E, H1=:=J, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=F, H1=:=K, 
          new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=F, H1=:=K, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=F, H1=:=K, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,J1)), 
          new85(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new71(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=2, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,H1,I1),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new73(s(J1,K1,G1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=A, H1=:=G1, I1=:=J1+K1, J1=:=J, K1=:=1, L1=:=1, M1=:=1, 
          new71(s(A,L1,M1,D,E,F,G,H,I,I1,H1,L,M,N,O,G1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=1, I1=:=O, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=1, 
          new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=1, 
          new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=0, 
          new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=0, 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=0, 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2)), 
          new46(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,M1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,M1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=L, L1=:=0, 
          new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=L, L1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=L, L1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=G, L1=:=0, 
          new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=G, L1=:=0, 
          new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=G, L1=:=0, 
          new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=0, 
          new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=0, 
          new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=0, 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,L1)), 
          new49(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=L, H1=:=0, I1=:=1, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=L, H1=:=0, I1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=L, H1=:=0, I1=:=0, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=0, K1=:=0, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=0, K1=:=0, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=0, K1=:=1, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=G, H1=:=0, I1=:=1, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=G, H1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=G, H1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=L, H1=:=0, I1=:=1, 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=L, H1=:=0, I1=:=0, 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=L, H1=:=0, I1=:=0, 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=0, K1=:=0, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=0, K1=:=0, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=0, K1=:=1, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=G, H1=:=0, I1=:=1, 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=G, H1=:=0, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=G, H1=:=0, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=Q, J1=:=0, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=Q, J1=:=0, 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=Q, J1=:=0, 
          new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,J1)), 
          new24(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,P,Q)) :- 
          new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,H1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,J1)), 
          new36(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,P,Q)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1,H1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,I1,J1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,L1),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,J1)), 
          new19(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,P,Q)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1,H1,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,J1,K1,L1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1,J1,K1),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2)), 
          new16(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=I, F1=:=1, G1=:=0, 
          new223(s(A,B,C,D,E,F,G1,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=I, F1=:=1, G1=:=2, 
          new223(s(A,B,C,D,E,F,G1,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=I, F1=:=1, G1=:=2, 
          new223(s(A,B,C,D,E,F,G1,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=I, F1=:=1, G1=:=0, 
          new229(s(A,B,C,D,E,F,G1,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=I, F1=:=1, G1=:=2, 
          new229(s(A,B,C,D,E,F,G1,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=I, F1=:=1, G1=:=2, 
          new229(s(A,B,C,D,E,F,G1,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,P,Q)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1)), 
          new12(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,P)) :- 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,F1,G1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,H1,I1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,P,Q,R,S,F,G,T,U,V,K,L,W,X,O)) :- 
          P=:=1, R=:=2, Q=:=R, S=:=0, T=:=0, U=:=1, V=:=0, W=:=0, X=:=1.
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,P)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1)), 
          new7(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,E1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,F1)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=0, 
          K=:=0, L=:=0, M=:=0, N=:=0, O=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
inv1 :- \+new1.
