new13(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=0, L=:=M+N, M=:=C, 
          N=:=1, new4(s(K,B,L,D),d(E,F,G,H)).
new13(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=0, K=:=0, L=:=M+N, M=:=C, 
          N=:=1, new4(s(K,B,L,D),d(E,F,G,H)).
new13(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=D, J=:=0, 
          new4(s(A,B,C,D),d(E,F,G,H)).
new12(s(A),d(A)).
new9(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new12(s(A),d(B)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F>=G+1, F=:=A, G=:=0, new9(s(E),d(H)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F+1=<G, F=:=A, G=:=0, new9(s(E),d(H)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F=:=G, F=:=A, G=:=0, new9(s(E),d(H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- new13(s(A,B,C,I),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=B, K=:=1, L=:=C, 
          new6(s(K,L,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=B, K=:=1, L=:=C, 
          new6(s(K,L,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=C, J=:=B, new8(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=K+L, K=:=B, L=:=1, 
          new4(s(I,B,J,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
