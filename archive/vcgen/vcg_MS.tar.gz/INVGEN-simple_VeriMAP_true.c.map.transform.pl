new15(s(A),d(B)) :- new15(s(A),d(B)).
new14(s(A),d(A)).
new12(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new14(s(A),d(B)).
new11(s(A,B),d(A,B)) :- C=:=1, D=<E, D=:=A, E=:=B, new12(s(C),d(F)).
new11(s(A,B),d(A,B)) :- C=:=0, D>=E+1, D=:=A, E=:=B, new12(s(C),d(F)).
new9(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=B, G=:=H+I, H=:=A, I=:=1, 
          new7(s(G,B),d(C,D)).
new9(s(A,B),d(C,D)) :- E>=F, E=:=A, F=:=B, new11(s(A,B),d(C,D)).
new7(s(A,B),d(C,D)) :- new9(s(A,B),d(C,D)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new15(s(A),d(B)).
new4(s(A,B),d(C,D)) :- E=:=1, F>=G+1, F=:=B, G=:=0, new5(s(E),d(H)), 
          new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E=:=0, F=<G, F=:=B, G=:=0, new5(s(E),d(H)), 
          new7(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=:=0, new4(s(E,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
