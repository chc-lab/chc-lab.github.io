new20(s(A,B),d(A,B)).
new14(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new14(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new14(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new19(s(A,B),d(A,C)).
new13(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new20(s(A,B),d(A,C)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H, G=:=D, H=:=B, 
          new13(s(A,F),d(A,I)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=D, H=:=B, 
          new13(s(A,F),d(A,I)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M, L=:=D, M=:=B, N=:=O+P, O=:=D, 
          P=:=1, new14(s(A,K),d(A,Q)), new8(s(A,B,C,N,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=D, M=:=B, N=:=O+P, 
          O=:=D, P=:=1, new14(s(A,K),d(A,Q)), new8(s(A,B,C,N,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=E, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=E, M=:=N+O, N=:=C, O=:=1, 
          new6(s(A,B,M,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=E, M=:=C, 
          new8(s(A,B,C,M,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=E, M=:=N+O, N=:=B, O=:=1, 
          new4(s(A,M,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=E, M=:=B, 
          new6(s(A,B,M,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, new4(s(A,K,C,D,E),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
