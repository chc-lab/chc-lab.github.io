new22(s(A,B),d(A,B)).
new16(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new16(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new16(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new21(s(A,B),d(A,C)).
new15(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new22(s(A,B),d(A,C)).
new13(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=K-L, K=:=D, L=:=B, 
          J=:=M*N, M=:=2, N=:=E, new15(s(A,H),d(A,O)).
new13(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=K-L, K=:=D, 
          L=:=B, J=:=M*N, M=:=2, N=:=E, new15(s(A,H),d(A,O)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=R-S, R=:=D, S=:=B, 
          Q=:=T*U, T=:=2, U=:=E, V=:=W+X, W=:=D, X=:=1, new16(s(A,O),d(A,Y)), 
          new10(s(A,B,C,V,E,F,G),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=R-S, R=:=D, 
          S=:=B, Q=:=T*U, T=:=2, U=:=E, V=:=W+X, W=:=D, X=:=1, 
          new16(s(A,O),d(A,Y)), new10(s(A,B,C,V,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=D, P=:=C, 
          new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=D, P=:=C, Q=:=R+S, R=:=C, 
          S=:=1, new7(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=C, P=:=Q*R, Q=:=3, 
          R=:=B, S=:=B, new10(s(A,B,C,S,E,F,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=C, P=:=Q*R, Q=:=3, R=:=B, 
          S=:=T+U, T=:=B, U=:=1, new4(s(A,S,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=B, P=:=E, Q=:=R*S, 
          R=:=2, S=:=B, new7(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=B, P=:=E, 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=Q*R, Q=:=3, R=:=E, 
          P=:=S+T, S=:=G, T=:=F, U=:=0, new4(s(A,U,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=Q*R, Q=:=3, R=:=E, 
          P=:=S+T, S=:=G, T=:=F, new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
