new30(s(A,B),d(A,B)).
new21(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H, G=:=C, H=:=B, 
          new17(s(A,F),d(A,I)).
new21(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=C, H=:=B, 
          new17(s(A,F),d(A,I)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M, L=:=C, M=:=B, 
          new18(s(A,K),d(A,N)), new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=C, M=:=B, 
          new18(s(A,K),d(A,N)), new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new18(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new18(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new18(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new29(s(A,B),d(A,C)).
new17(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new30(s(A,B),d(A,C)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L+M, L=:=D, M=:=1, 
          new8(s(A,B,C,K,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H, G=:=D, H=:=C, 
          new17(s(A,F),d(A,I)).
new13(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=D, H=:=C, 
          new17(s(A,F),d(A,I)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M, L=:=D, M=:=C, 
          new18(s(A,K),d(A,N)), new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=D, M=:=C, 
          new18(s(A,K),d(A,N)), new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=E, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=E, M=:=N+O, N=:=C, O=:=1, 
          new6(s(A,B,M,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=E, M=:=C, 
          new8(s(A,B,C,M,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=E, M=:=N+O, N=:=B, O=:=1, 
          new4(s(A,M,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=E, M=:=B, 
          new6(s(A,B,M,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, new4(s(A,K,C,D,E),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
