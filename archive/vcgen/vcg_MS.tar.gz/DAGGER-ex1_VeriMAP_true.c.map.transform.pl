new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N-O, N=:=A, O=:=P*Q, P=:=2, Q=:=B, 
          R=:=S+T, S=:=U*V, U=:=2, V=:=A, T=:=B, 
          new4(s(A,B,M,R,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=0, O=:=P+Q, P=:=B, 
          Q=:=A, new14(s(A,O,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=0, O=:=P+Q, P=:=B, 
          Q=:=A, new14(s(A,O,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=0, O=:=P-Q, P=:=B, 
          Q=:=A, new14(s(A,O,C,D,E,F),d(G,H,I,J,K,L)).
new12(s(A),d(A)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new12(s(A),d(B)).
new9(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H>=I, H=:=J+K, J=:=C, K=:=L*M, 
          L=:=2, M=:=D, I=:=0, new10(s(G),d(N)).
new9(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H+1=<I, H=:=J+K, J=:=C, K=:=L*M, 
          L=:=2, M=:=D, I=:=0, new10(s(G),d(N)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new13(s(A,B,C,D,M,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=0, O=:=P+Q, P=:=C, 
          Q=:=R*S, R=:=2, S=:=D, T=:=U+V, U=:=W*X, W=:= -2, X=:=C, V=:=D, 
          Y=:=Z+A1, Z=:=O, A1=:=1, new7(s(Y,T,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=0, O=:=P+Q, P=:=C, 
          Q=:=R*S, R=:=2, S=:=D, T=:=U+V, U=:=W*X, W=:= -2, X=:=C, V=:=D, 
          Y=:=Z+A1, Z=:=O, A1=:=1, new7(s(Y,T,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=F, N=:=0, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new6(s(A,B,C,D,E,M),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N=:=0, 
          new4(s(A,B,M,N,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
inv1 :- \+new1.
