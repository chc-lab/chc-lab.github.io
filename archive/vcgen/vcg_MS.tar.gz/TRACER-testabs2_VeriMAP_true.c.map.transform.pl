new9(s(A),d(A)).
new7(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new9(s(A),d(B)).
new5(s(A,B,C),d(A,B,C)) :- D=:=1, E>=F+1, E=:=A, F=:=0, new7(s(D),d(G)).
new5(s(A,B,C),d(A,B,C)) :- D=:=0, E=<F, E=:=A, F=:=0, new7(s(D),d(G)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, I=:=4, J=:=1, 
          new5(s(I,J,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=<H, G=:=C, H=:=0, I=:=100, J=:=2, 
          new5(s(I,J,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=1, H=:=4, new4(s(H,B,G),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
