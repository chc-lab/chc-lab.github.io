new18(s(A),d(B)) :- new18(s(A),d(B)).
new15(s(A,B,C,D),d(E,F,G,H)) :- I=:=J+K, J=:=C, K=:=1, L=:=M+N, M=:=B, N=:=1, 
          new7(s(A,L,I,D),d(E,F,G,H)).
new14(s(A),d(A)).
new12(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new14(s(A),d(B)).
new11(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=D, G=:=0, new12(s(E),d(H)).
new11(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=D, G=:=0, new12(s(E),d(H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=1, K=:=1, 
          new15(s(A,B,C,K),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=B, J=:=1, K=:=0, 
          new15(s(A,B,C,K),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=A, 
          new10(s(A,B,C,D),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=B, J=:=A, new11(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- new9(s(A,B,C,D),d(E,F,G,H)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new18(s(A),d(B)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J>=K+1, J=:=A, K=:=1, new5(s(I),d(L)), 
          new7(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=<K, J=:=A, K=:=1, new5(s(I),d(L)), 
          new7(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, K=:=0, new4(s(A,I,J,K),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
