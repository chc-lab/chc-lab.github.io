new48(s(A,B,C,D,E),d(F,G,H,I,J)) :- new30(s(A,B,C,D,E),d(F,G,H,I,J)).
new45(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=8656, 
          new48(s(M,B,C,D,E),d(F,G,H,I,J)).
new45(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=8656, 
          new48(s(M,B,C,D,E),d(F,G,H,I,J)).
new45(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, M=:=8512, 
          new48(s(M,B,C,D,E),d(F,G,H,I,J)).
new41(s(A,B,C,D,E),d(F,G,H,I,J)) :- new30(s(A,B,C,D,E),d(F,G,H,I,J)).
new40(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=8466, 
          new41(s(M,B,C,D,E),d(F,G,H,I,J)).
new40(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, M=:=8466, 
          new41(s(M,B,C,D,E),d(F,G,H,I,J)).
new40(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=E, L=:=0, M=:=8640, 
          new41(s(M,B,C,D,E),d(F,G,H,I,J)).
new34(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new34(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new34(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, M=:=8656, 
          new30(s(M,B,C,D,E),d(F,G,H,I,J)).
new30(s(A,B,C,D,E),d(F,G,H,I,J)) :- new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new27(s(A,B,C,D,E),d(A,B,C,D,E)).
new25(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=5, 
          new27(s(A,B,C,D,E),d(F,G,H,I,J)).
new25(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=5, 
          new24(s(A,B,C,D,E),d(F,G,H,I,J)).
new25(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=5, 
          new24(s(A,B,C,D,E),d(F,G,H,I,J)).
new24(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=8640, 
          new30(s(M,B,C,D,E),d(F,G,H,I,J)).
new24(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=8640, 
          new30(s(M,B,C,D,E),d(F,G,H,I,J)).
new24(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=4, M=:=5, 
          new24(s(A,B,C,M,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=4, 
          new25(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=4, 
          new25(s(A,B,C,D,E),d(F,G,H,I,J)).
new18(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=2, M=:=3, 
          new21(s(A,B,C,M,E),d(F,G,H,I,J)).
new18(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=2, 
          new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new18(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=2, 
          new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=8656, 
          new18(s(A,B,C,D,E),d(F,G,H,I,J)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=8656, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=8656, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=3, M=:=4, 
          new34(s(A,B,C,M,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=3, 
          new34(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=3, 
          new34(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=8640, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=8640, 
          new16(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=8640, 
          new16(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- new40(s(A,B,C,D,K),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=8512, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=8512, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=8512, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=0, M=:=2, 
          new45(s(A,B,C,M,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=0, 
          new45(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=0, 
          new45(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=8466, 
          new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=8466, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=8466, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=2, 
          new27(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=D, L=:=2, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=A, L=:=8512, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=8512, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, M=:=8466, N=:=0, 
          new5(s(M,K,L,N,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- new4(s(A,B,C,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
