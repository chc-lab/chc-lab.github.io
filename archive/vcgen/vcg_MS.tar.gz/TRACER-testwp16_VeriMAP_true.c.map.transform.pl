new11(s(A),d(A)).
new9(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new11(s(A),d(B)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=A, G=:=1000, new9(s(E),d(H)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=A, G=:=1000, new9(s(E),d(H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I=:=J+K, J=:=A, K=:=1, 
          new8(s(I,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=C, J=:=3, K=:=L+M, L=:=A, M=:=1, 
          new6(s(K,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=3, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=3, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=B, J=:=0, new5(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=0, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=0, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=D, K=:=D, new4(s(I,J,K,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
