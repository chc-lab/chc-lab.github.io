new11(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new6(s(I,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=J+K, J=:=B, K=:=1, 
          new4(s(A,I,C),d(D,E,F)).
new10(s(A),d(A)).
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new10(s(A),d(B)).
new7(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=1, F=:=B, new8(s(D),d(G)).
new7(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=1, F=:=B, new8(s(D),d(G)).
new6(s(A,B,C),d(D,E,F)) :- new11(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=C, I=:=1, new6(s(I,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H, G=:=B, H=:=C, new7(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=1, new4(s(A,G,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
