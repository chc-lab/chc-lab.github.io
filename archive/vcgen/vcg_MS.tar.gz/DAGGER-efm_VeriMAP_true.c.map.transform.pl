new95(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=D, X=:=1, 
          Y=:=Z-A1, Z=:=A, A1=:=1, B1=:=C1-D1, C1=:=D, D1=:=1, E1=:=F1+G1, 
          F1=:=B, G1=:=1, H1=:=I1+J1, I1=:=E, J1=:=1, 
          new9(s(Y,E1,C,B1,H1,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new93(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=F, X=:=1, 
          Y=:=Z-A1, Z=:=B, A1=:=1, B1=:=C1+D1, C1=:=C, D1=:=1, 
          new9(s(A,Y,B1,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new91(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=C, X=:=1, 
          Y=:=Z-A1, Z=:=C, A1=:=1, B1=:=C1+D1, C1=:=B, D1=:=1, 
          new9(s(A,B1,Y,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new88(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=B, X=:=1, 
          Y=:=Z-A1, Z=:=B, A1=:=1, B1=:=C1+D1, C1=:=A, D1=:=1, E1=:=F1+G1, 
          F1=:=D, G1=:=F, H1=:=0, 
          new9(s(B1,Y,C,E1,E,H1,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new86(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=C, X=:=1, 
          Y=:=Z-A1, Z=:=C, A1=:=1, B1=:=C1+D1, C1=:=A, D1=:=1, E1=:=F1+G1, 
          F1=:=F, G1=:=E, H1=:=0, 
          new9(s(B1,B,Y,D,H1,E1,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new85(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=G, 
          X=:=0, new86(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new85(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=G, 
          X=:=0, new86(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new85(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=G, 
          X=:=0, new88(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new84(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new85(s(A,B,C,D,E,F,W,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new82(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=D, X=:=1, 
          new91(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new81(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=H, 
          X=:=0, new82(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new81(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=H, 
          X=:=0, new82(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new81(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=H, 
          X=:=0, new84(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new80(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new81(s(A,B,C,D,E,F,G,W,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new78(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=B, X=:=1, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new77(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=I, 
          X=:=0, new78(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new77(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=I, 
          X=:=0, new78(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new77(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=I, 
          X=:=0, new80(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new76(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new77(s(A,B,C,D,E,F,G,H,W,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new74(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=A, X=:=1, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new73(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, new74(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new73(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, new74(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new73(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, new76(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new72(s(A),d(A)).
new67(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M>=N, 
          M=:=O+P, O=:=Q+R, Q=:=A, R=:=B, P=:=C, N=:=1, new15(s(L),d(S)).
new67(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M+1=<N, 
          M=:=O+P, O=:=Q+R, Q=:=A, R=:=B, P=:=C, N=:=1, new15(s(L),d(S)).
new61(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M>=N, 
          M=:=O+P, O=:=A, P=:=B, N=:=Q+R, Q=:=D, R=:=E, new15(s(L),d(S)).
new61(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M+1=<N, 
          M=:=O+P, O=:=A, P=:=B, N=:=Q+R, Q=:=D, R=:=E, new15(s(L),d(S)).
new61(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=1, X>=Y, 
          X=:=Z+A1, Z=:=A, A1=:=B, Y=:=B1+C1, B1=:=D, C1=:=E, 
          new16(s(W),d(D1)), 
          new67(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new61(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=0, X+1=<Y, 
          X=:=Z+A1, Z=:=A, A1=:=B, Y=:=B1+C1, B1=:=D, C1=:=E, 
          new16(s(W),d(D1)), 
          new67(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new55(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M>=N, 
          M=:=O+P, O=:=A, P=:=E, N=:=1, new15(s(L),d(Q)).
new55(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M+1=<N, 
          M=:=O+P, O=:=A, P=:=E, N=:=1, new15(s(L),d(Q)).
new55(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=1, X>=Y, 
          X=:=Z+A1, Z=:=A, A1=:=E, Y=:=1, new16(s(W),d(B1)), 
          new61(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new55(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=0, X+1=<Y, 
          X=:=Z+A1, Z=:=A, A1=:=E, Y=:=1, new16(s(W),d(B1)), 
          new61(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new49(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M>=N, M=:=B, 
          N=:=0, new15(s(L),d(O)).
new49(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M+1=<N, 
          M=:=B, N=:=0, new15(s(L),d(O)).
new49(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=1, X>=Y, X=:=B, 
          Y=:=0, new16(s(W),d(Z)), 
          new55(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new49(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=0, X+1=<Y, 
          X=:=B, Y=:=0, new16(s(W),d(Z)), 
          new55(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M>=N, M=:=C, 
          N=:=0, new15(s(L),d(O)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M+1=<N, 
          M=:=C, N=:=0, new15(s(L),d(O)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=1, X>=Y, X=:=C, 
          Y=:=0, new16(s(W),d(Z)), 
          new49(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=0, X+1=<Y, 
          X=:=C, Y=:=0, new16(s(W),d(Z)), 
          new49(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M>=N, M=:=D, 
          N=:=0, new15(s(L),d(O)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M+1=<N, 
          M=:=D, N=:=0, new15(s(L),d(O)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=1, X>=Y, X=:=D, 
          Y=:=0, new16(s(W),d(Z)), 
          new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=0, X+1=<Y, 
          X=:=D, Y=:=0, new16(s(W),d(Z)), 
          new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new31(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M>=N, M=:=E, 
          N=:=0, new15(s(L),d(O)).
new31(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M+1=<N, 
          M=:=E, N=:=0, new15(s(L),d(O)).
new31(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=1, X>=Y, X=:=E, 
          Y=:=0, new16(s(W),d(Z)), 
          new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new31(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=0, X+1=<Y, 
          X=:=E, Y=:=0, new16(s(W),d(Z)), 
          new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new25(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M=<N, 
          M=:=O+P, O=:=D, P=:=E, N=:=1, new15(s(L),d(Q)).
new25(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M>=N+1, 
          M=:=O+P, O=:=D, P=:=E, N=:=1, new15(s(L),d(Q)).
new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=1, X=<Y, 
          X=:=Z+A1, Z=:=D, A1=:=E, Y=:=1, new16(s(W),d(B1)), 
          new31(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=0, X>=Y+1, 
          X=:=Z+A1, Z=:=D, A1=:=E, Y=:=1, new16(s(W),d(B1)), 
          new31(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new19(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M=<N, 
          M=:=O-P, O=:=Q+R, Q=:=S+T, S=:=D, T=:=E, R=:=F, P=:=1, N=:=0, 
          new15(s(L),d(U)).
new19(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M>=N+1, 
          M=:=O-P, O=:=Q+R, Q=:=S+T, S=:=D, T=:=E, R=:=F, P=:=1, N=:=0, 
          new15(s(L),d(U)).
new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=1, X=<Y, 
          X=:=Z-A1, Z=:=B1+C1, B1=:=D1+E1, D1=:=D, E1=:=E, C1=:=F, A1=:=1, 
          Y=:=0, new16(s(W),d(F1)), 
          new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=0, X>=Y+1, 
          X=:=Z-A1, Z=:=B1+C1, B1=:=D1+E1, D1=:=D, E1=:=E, C1=:=F, A1=:=1, 
          Y=:=0, new16(s(W),d(F1)), 
          new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new16(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new16(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new71(s(A),d(B)).
new15(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new72(s(A),d(B)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=1, M>=N, 
          M=:=O-P, O=:=Q+R, Q=:=S+T, S=:=D, T=:=E, R=:=F, P=:=1, N=:=0, 
          new15(s(L),d(U)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)) :- L=:=0, M+1=<N, 
          M=:=O-P, O=:=Q+R, Q=:=S+T, S=:=D, T=:=E, R=:=F, P=:=1, N=:=0, 
          new15(s(L),d(U)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=1, X>=Y, 
          X=:=Z-A1, Z=:=B1+C1, B1=:=D1+E1, D1=:=D, E1=:=E, C1=:=F, A1=:=1, 
          Y=:=0, new16(s(W),d(F1)), 
          new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=0, X+1=<Y, 
          X=:=Z-A1, Z=:=B1+C1, B1=:=D1+E1, D1=:=D, E1=:=E, C1=:=F, A1=:=1, 
          Y=:=0, new16(s(W),d(F1)), 
          new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new73(s(A,B,C,D,E,F,G,H,I,W,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new11(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=K, 
          X=:=0, new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new11(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=K, 
          X=:=0, new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new11(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=K, 
          X=:=0, new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,W),d(L,M,N,O,P,Q,R,S,T,U,V)).
new9(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new8(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=F, X=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new7(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=E, X=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new6(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=D, X=:=1, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new5(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=C, X=:=0, 
          new6(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new4(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=B, X=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X, W=:=A, X=:=1, 
          new4(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new1 :- new2(s,d).
inv1 :- \+new1.
