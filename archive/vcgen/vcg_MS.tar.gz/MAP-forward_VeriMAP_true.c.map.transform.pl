new17(s(A),d(B)) :- new17(s(A),d(B)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N+O, N=:=B, O=:=1, 
          new7(s(A,M,C,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=0, O=:=P+Q, P=:=D, 
          Q=:=1, R=:=S+T, S=:=E, T=:=2, new13(s(A,B,C,O,R,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=0, O=:=P+Q, P=:=D, 
          Q=:=1, R=:=S+T, S=:=E, T=:=2, new13(s(A,B,C,O,R,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=F, N=:=0, O=:=P+Q, P=:=D, 
          Q=:=2, R=:=S+T, S=:=E, T=:=1, new13(s(A,B,C,O,R,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G>=H+1, G=:=I+J, I=:=D, J=:=E, H=:=K*L, 
          K=:=3, L=:=C.
new11(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G+1=<H, G=:=I+J, I=:=D, J=:=E, H=:=K*L, 
          K=:=3, L=:=C.
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new12(s(A,B,C,D,E,M),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=C, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=B, N=:=C, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new17(s(A),d(B)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N>=O, N=:=C, O=:=0, P=:=0, Q=:=0, 
          R=:=0, new5(s(M),d(S)), new7(s(A,P,C,Q,R,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N+1=<O, N=:=C, O=:=0, P=:=0, 
          Q=:=0, R=:=0, new5(s(M),d(S)), new7(s(A,P,C,Q,R,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
inv1 :- \+new1.
