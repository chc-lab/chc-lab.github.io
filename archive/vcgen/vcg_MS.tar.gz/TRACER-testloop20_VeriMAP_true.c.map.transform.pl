new32(s(A,B,C),d(D,E,F)) :- G=:=3, new14(s(A,G,C),d(D,E,F)).
new28(s(A,B,C),d(D,E,F)) :- G=:=4, new14(s(A,G,C),d(D,E,F)).
new27(s(A),d(A)).
new18(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new18(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new18(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new26(s(A),d(B)).
new17(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new27(s(A),d(B)).
new14(s(A,B,C),d(D,E,F)) :- new4(s(A,B,C),d(D,E,F)).
new13(s(A,B,C),d(A,B,C)) :- D=:=1, E>=F+1, E=:=A, F=:=3, new17(s(D),d(G)).
new13(s(A,B,C),d(A,B,C)) :- D=:=1, E+1=<F, E=:=A, F=:=3, new17(s(D),d(G)).
new13(s(A,B,C),d(A,B,C)) :- D=:=0, E=:=F, E=:=A, F=:=3, new17(s(D),d(G)).
new13(s(A,B,C),d(D,E,F)) :- G=:=1, H>=I+1, H=:=A, I=:=3, J=:=5, 
          new18(s(G),d(K)), new14(s(A,J,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G=:=1, H+1=<I, H=:=A, I=:=3, J=:=5, 
          new18(s(G),d(K)), new14(s(A,J,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=I, H=:=A, I=:=3, J=:=5, 
          new18(s(G),d(K)), new14(s(A,J,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=4, new13(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=4, new14(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=4, new14(s(A,B,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=1, I=:=2, 
          new28(s(I,B,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=1, new28(s(A,B,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=1, new28(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=3, new10(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=3, new11(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=3, new11(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=0, I=:=1, new32(s(I,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, new32(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, new32(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=2, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=2, new8(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=2, new8(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new5(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=2, new4(s(G,H,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
