new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=A, P1=:=1, Q1=:=R1-S1, R1=:=A, S1=:=1, T1=:=U1+V1, 
          U1=:=B, V1=:=1, W1=:=1, 
          new4(s(Q1,T1,C,W1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=D, P1=:=0, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=A, P1=:=1, Q1=:=R1-S1, R1=:=A, S1=:=1, T1=:=U1+V1, 
          U1=:=B, V1=:=1, W1=:=1, 
          new4(s(Q1,T1,C,D,W1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=E, P1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=C, P1=:=1, Q1=:=R1-S1, R1=:=C, S1=:=1, T1=:=0, 
          new4(s(A,B,Q1,D,T1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=E, P1=:=1, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=A, P1=:=1, Q1=:=R1-S1, R1=:=A, S1=:=1, T1=:=U1+V1, 
          U1=:=B, V1=:=1, W1=:=1, 
          new4(s(Q1,T1,C,D,E,W1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=F, P1=:=0, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=C, P1=:=1, Q1=:=R1-S1, R1=:=C, S1=:=1, T1=:=0, 
          new4(s(A,B,Q1,D,E,T1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new83(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=F, P1=:=1, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=A, P1=:=1, Q1=:=R1-S1, R1=:=A, S1=:=1, T1=:=U1+V1, 
          U1=:=B, V1=:=1, W1=:=X1+Y1, X1=:=G, Y1=:=1, 
          new4(s(Q1,T1,C,D,E,F,W1,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=G, P1=:=0, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=C, P1=:=1, Q1=:=R1-S1, R1=:=C, S1=:=1, T1=:=U1-V1, 
          U1=:=G, V1=:=1, 
          new4(s(A,B,Q1,D,E,F,T1,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=G, P1=:=1, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=H, P1=:=0, Q1=:=R1+S1, R1=:=A, S1=:=1, T1=:=1, 
          new4(s(Q1,B,C,D,E,F,G,T1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=B, P1=:=1, Q1=:=R1-S1, R1=:=B, S1=:=1, T1=:=2, 
          new4(s(A,Q1,C,D,E,F,G,T1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=H, P1=:=1, 
          new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=H, P1=:=2, Q1=:=R1+S1, R1=:=C, S1=:=1, T1=:=3, 
          new4(s(A,B,Q1,D,E,F,G,T1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=C, P1=:=0, Q1=:=0, 
          new4(s(A,B,C,D,E,F,G,Q1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=H, P1=:=3, 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=C, P1=:=1, Q1=:=R1-S1, R1=:=C, S1=:=1, T1=:=0, 
          new4(s(A,B,Q1,T1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=D, P1=:=1, 
          new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=D, P1=:=1, 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=H, P1=:=3, 
          new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=I, P1=:=0, 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=I, P1=:=0, 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=I, P1=:=0, 
          new63(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new60(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=H, P1=:=2, 
          new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=J, P1=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=J, P1=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=J, P1=:=0, 
          new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new55(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new56(s(A,B,C,D,E,F,G,H,I,O1,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=H, P1=:=1, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=K, P1=:=0, 
          new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=K, P1=:=0, 
          new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=K, P1=:=0, 
          new55(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new52(s(A,B,C,D,E,F,G,H,I,J,O1,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=H, P1=:=0, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=L, P1=:=0, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=L, P1=:=0, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=L, P1=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new48(s(A,B,C,D,E,F,G,H,I,J,K,O1,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=G, P1=:=1, 
          new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=M, P1=:=0, 
          new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=M, P1=:=0, 
          new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=M, P1=:=0, 
          new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=G, P1=:=0, 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=N, P1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=N, P1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=N, P1=:=0, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=F, P1=:=1, 
          new83(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=O, P1=:=0, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=O, P1=:=0, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=O, P1=:=0, 
          new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=F, P1=:=0, 
          new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=P, P1=:=0, 
          new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=P, P1=:=0, 
          new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=P, P1=:=0, 
          new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=E, P1=:=1, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=Q, P1=:=0, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=Q, P1=:=0, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=Q, P1=:=0, 
          new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=E, P1=:=0, 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=R, P1=:=0, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=R, P1=:=0, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=R, P1=:=0, 
          new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=D, P1=:=0, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=S, P1=:=0, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=S, P1=:=0, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=S, P1=:=0, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new19(s(A),d(A)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V>=W, V=:=H, W=:=C, new10(s(U),d(X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V+1=<W, V=:=H, W=:=C, new10(s(U),d(X)).
new11(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new11(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new18(s(A),d(B)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new19(s(A),d(B)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V=<W, V=:=H, W=:=3, new10(s(U),d(X)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V>=W+1, V=:=H, W=:=3, new10(s(U),d(X)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1=<Q1, P1=:=H, Q1=:=3, new11(s(O1),d(R1)), 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1>=Q1+1, P1=:=H, Q1=:=3, new11(s(O1),d(R1)), 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=T, P1=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=T, P1=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=T, P1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,O1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1=:=0, Q1=:=0, R1=:=0, S1=:=0, T1=:=0, U1=:=0, V1=:=0, 
          new4(s(O1,P1,Q1,R1,S1,T1,U1,V1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new2(s,d) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new1 :- new2(s,d).
inv1 :- \+new1.
