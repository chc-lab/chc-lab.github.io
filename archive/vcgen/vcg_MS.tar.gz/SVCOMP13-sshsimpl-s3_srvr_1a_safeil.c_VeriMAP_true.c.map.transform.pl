new98(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=8496, 
          new21(s(W,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new94(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new91(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=B, 
          X=:=0, Y=:=8656, 
          new94(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new91(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=B, 
          X=:=0, Y=:=8656, 
          new94(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new91(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=B, 
          X=:=0, Y=:=8512, 
          new94(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new83(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=8576, 
          new77(s(W,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new82(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y+Z, 
          Y=:=D, Z=:=2, X=:=0, 
          new83(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new82(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y+Z, 
          Y=:=D, Z=:=2, X=:=0, 
          new83(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new82(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=Y+Z, 
          Y=:=D, Z=:=2, X=:=0, A1=:=8560, 
          new77(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new81(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y+Z, 
          Y=:=H, H>=0, Z=:=256, X=:=0, 
          new82(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new79(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y+Z, 
          Y=:=D, Z=:=4, X=:=0, A1=:=8560, 
          new77(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new79(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y+Z, 
          Y=:=D, Z=:=4, X=:=0, A1=:=8560, 
          new77(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new79(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=Y+Z, 
          Y=:=D, Z=:=4, X=:=0, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new77(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new75(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=F, 
          X=:=0, new79(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new75(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=F, 
          X=:=0, new79(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new75(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=F, 
          X=:=0, new81(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new71(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new70(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=K, 
          X=:=2, Y=:=8466, 
          new71(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new70(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=K, 
          X=:=2, Y=:=8592, 
          new71(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new70(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=K, 
          X=:=2, Y=:=8592, 
          new71(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new64(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=B, 
          X=:=0, new49(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new64(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=B, 
          X=:=0, new49(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new64(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=B, 
          X=:=0, Y=:=8656, 
          new21(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new60(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=8672, 
          new21(s(W,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new54(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)).
new52(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=5, new54(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new52(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=5, new51(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new52(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=5, new51(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new51(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=B, 
          X=:=0, Y=:=8640, 
          new21(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new51(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=B, 
          X=:=0, Y=:=8640, 
          new21(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new51(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=B, 
          X=:=0, new49(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new48(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=4, Y=:=5, 
          new51(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new48(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=4, new52(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new48(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=4, new52(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8672, new48(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8672, new49(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8672, new49(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new45(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=2, Y=:=3, 
          new60(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new45(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=2, new60(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new45(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=2, new60(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8656, new45(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8656, new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8656, new46(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new42(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=3, Y=:=4, 
          new64(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new42(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=3, new64(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new42(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=3, new64(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new40(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8640, new42(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new40(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8640, new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new40(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8640, new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8608, Y=:=8640, 
          new21(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8608, new40(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8608, new40(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new34(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8592, Y=:=8608, 
          new21(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new34(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8592, new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new34(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8592, new37(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new33(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new70(s(A,B,C,D,E,F,G,H,I,J,W),d(L,M,N,O,P,Q,R,S,T,U,V)).
new31(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8576, new33(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new31(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8576, new34(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new31(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8576, new34(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new28(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8560, Y=:=8576, 
          new21(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new28(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8560, new31(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new28(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8560, new31(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=Y+Z, 
          Y=:=D, Z=:=1, X=:=0, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=Y+Z, 
          Y=:=D, Z=:=1, X=:=0, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=Y+Z, 
          Y=:=D, Z=:=1, X=:=0, A1=:=8560, 
          new77(s(A1,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8544, new27(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8544, new28(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8544, new28(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new22(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8528, Y=:=8544, 
          new21(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new22(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8528, new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new22(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8528, new25(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new21(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new8(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8512, Y=:=8528, 
          new21(s(Y,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8512, new22(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8512, new22(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=1, Y=:=2, 
          new91(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=1, new91(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=1, new91(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new16(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8496, new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new16(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8496, new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new16(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8496, new19(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, Y=:=1, 
          new98(s(A,B,C,D,E,F,G,H,I,Y,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, new98(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, new98(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=A, 
          X=:=8466, new15(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8466, new16(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=A, 
          X=:=8466, new16(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new13(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=2, new54(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new13(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=<X, W=:=J, X=:=2, 
          new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=<X, W=:=A, 
          X=:=8512, new13(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=A, 
          X=:=8512, new14(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new8(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new12(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new7(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          Y=:=18446744073709551616+W, W+1=<0, Z=:=8466, A1=:=0, 
          new8(s(Z,B,C,D,E,F,G,Y,X,A1,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new7(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, Y=:=W, W>=0, 
          Z=:=8466, A1=:=0, 
          new8(s(Z,B,C,D,E,F,G,Y,X,A1,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new7(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          Y=:=18446744073709551616+W, W+1=<0, Z=:=8466, A1=:=0, 
          new8(s(Z,B,C,D,E,F,G,Y,X,A1,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new7(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, Y=:=W, W>=0, 
          Z=:=8466, A1=:=0, 
          new8(s(Z,B,C,D,E,F,G,Y,X,A1,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new6(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new7(s(A,B,C,D,E,W,X,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new5(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new6(s(A,B,C,W,X,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new4(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new5(s(A,W,X,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new1 :- new2(s,d).
inv1 :- \+new1.
