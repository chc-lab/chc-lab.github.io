new120(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=B, F=:=A, new13(s(D),d(G)).
new120(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=B, F=:=A, new13(s(D),d(G)).
new120(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=B, I=:=A, new14(s(G),d(J)), 
          new5(s(A,B,C),d(D,E,F)).
new120(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=B, I=:=A, new14(s(G),d(J)), 
          new5(s(A,B,C),d(D,E,F)).
new108(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=B, F=:=A, new13(s(D),d(G)).
new108(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=B, F=:=A, new13(s(D),d(G)).
new108(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=B, I=:=A, new14(s(G),d(J)), 
          new5(s(A,B,C),d(D,E,F)).
new108(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=B, I=:=A, new14(s(G),d(J)), 
          new5(s(A,B,C),d(D,E,F)).
new96(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=B, F=:=A, new13(s(D),d(G)).
new96(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=B, F=:=A, new13(s(D),d(G)).
new96(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=B, I=:=A, new14(s(G),d(J)), 
          new5(s(A,B,C),d(D,E,F)).
new96(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=B, I=:=A, new14(s(G),d(J)), 
          new5(s(A,B,C),d(D,E,F)).
new89(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=0, F=:=B, new13(s(D),d(G)).
new89(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=0, F=:=B, new13(s(D),d(G)).
new89(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, new14(s(G),d(J)), 
          new96(s(A,B,C),d(D,E,F)).
new89(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, new14(s(G),d(J)), 
          new96(s(A,B,C),d(D,E,F)).
new87(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=A, new89(s(A,B,C),d(D,E,F)).
new87(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new48(s(A,B,C),d(D,E,F)).
new87(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, new48(s(A,B,C),d(D,E,F)).
new81(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=B, F=:=A, new13(s(D),d(G)).
new81(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=B, F=:=A, new13(s(D),d(G)).
new81(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new14(s(G),d(M)), new87(s(A,J,C),d(D,E,F)).
new81(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new14(s(G),d(M)), new87(s(A,J,C),d(D,E,F)).
new74(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=0, F=:=B, new13(s(D),d(G)).
new74(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=0, F=:=B, new13(s(D),d(G)).
new74(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, new14(s(G),d(J)), 
          new81(s(A,B,C),d(D,E,F)).
new74(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, new14(s(G),d(J)), 
          new81(s(A,B,C),d(D,E,F)).
new66(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=B, F=:=A, new13(s(D),d(G)).
new66(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=B, F=:=A, new13(s(D),d(G)).
new66(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=B, I=:=A, new14(s(G),d(J)), 
          new5(s(A,B,C),d(D,E,F)).
new66(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=B, I=:=A, new14(s(G),d(J)), 
          new5(s(A,B,C),d(D,E,F)).
new54(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=B, F=:=A, new13(s(D),d(G)).
new54(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=B, F=:=A, new13(s(D),d(G)).
new54(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new14(s(G),d(M)), new37(s(A,J,C),d(D,E,F)).
new54(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new14(s(G),d(M)), new37(s(A,J,C),d(D,E,F)).
new49(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=0, F=:=B, new13(s(D),d(G)).
new49(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=0, F=:=B, new13(s(D),d(G)).
new49(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, new14(s(G),d(J)), 
          new54(s(A,B,C),d(D,E,F)).
new49(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, new14(s(G),d(J)), 
          new54(s(A,B,C),d(D,E,F)).
new48(s(A,B,C),d(D,E,F)) :- new49(s(A,B,C),d(D,E,F)).
new46(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=0, F=:=B, new13(s(D),d(G)).
new46(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=0, F=:=B, new13(s(D),d(G)).
new46(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, new14(s(G),d(J)), 
          new66(s(A,B,C),d(D,E,F)).
new46(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, new14(s(G),d(J)), 
          new66(s(A,B,C),d(D,E,F)).
new45(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new46(s(A,B,C),d(D,E,F)).
new45(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new46(s(A,B,C),d(D,E,F)).
new45(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, new48(s(A,B,C),d(D,E,F)).
new43(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new74(s(A,B,C),d(D,E,F)).
new43(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new74(s(A,B,C),d(D,E,F)).
new43(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, new48(s(A,B,C),d(D,E,F)).
new41(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new43(s(A,B,C),d(D,E,F)).
new41(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new43(s(A,B,C),d(D,E,F)).
new41(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, new45(s(A,B,C),d(D,E,F)).
new40(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=0, F=:=B, new13(s(D),d(G)).
new40(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=0, F=:=B, new13(s(D),d(G)).
new40(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, new14(s(G),d(J)), 
          new108(s(A,B,C),d(D,E,F)).
new40(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, new14(s(G),d(J)), 
          new108(s(A,B,C),d(D,E,F)).
new39(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=A, new40(s(A,B,C),d(D,E,F)).
new39(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new41(s(A,B,C),d(D,E,F)).
new39(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, new41(s(A,B,C),d(D,E,F)).
new37(s(A,B,C),d(D,E,F)) :- new39(s(A,B,C),d(D,E,F)).
new31(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=B, F=:=A, new13(s(D),d(G)).
new31(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=B, F=:=A, new13(s(D),d(G)).
new31(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new14(s(G),d(M)), new37(s(A,J,C),d(D,E,F)).
new31(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new14(s(G),d(M)), new37(s(A,J,C),d(D,E,F)).
new26(s(A),d(A)).
new17(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=B, F=:=A, new13(s(D),d(G)).
new17(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=B, F=:=A, new13(s(D),d(G)).
new17(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new14(s(G),d(M)), new4(s(A,J,C),d(D,E,F)).
new17(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new14(s(G),d(M)), new4(s(A,J,C),d(D,E,F)).
new14(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new14(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new14(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new25(s(A),d(B)).
new13(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new26(s(A),d(B)).
new12(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=0, F=:=B, new13(s(D),d(G)).
new12(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=0, F=:=B, new13(s(D),d(G)).
new12(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, new14(s(G),d(J)), 
          new17(s(A,B,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, new14(s(G),d(J)), 
          new17(s(A,B,C),d(D,E,F)).
new10(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=0, F=:=B, new13(s(D),d(G)).
new10(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=0, F=:=B, new13(s(D),d(G)).
new10(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, new14(s(G),d(J)), 
          new31(s(A,B,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, new14(s(G),d(J)), 
          new31(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new10(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new10(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, new12(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=0, F=:=B, new13(s(D),d(G)).
new7(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=0, F=:=B, new13(s(D),d(G)).
new7(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, new14(s(G),d(J)), 
          new120(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, new14(s(G),d(J)), 
          new120(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=A, new7(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=A, new8(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, new8(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=1, I=:=0, J=:=K-L, K=:=A, L=:=1, 
          new4(s(J,I,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=1, new5(s(A,B,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
