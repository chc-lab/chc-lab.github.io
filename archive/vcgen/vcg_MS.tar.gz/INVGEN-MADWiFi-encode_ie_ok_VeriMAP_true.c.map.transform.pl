new33(s(A),d(A)).
new24(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=J+K, J=:=A, K=:=1, 
          I=:=E, new20(s(G),d(L)).
new24(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=J+K, J=:=A, K=:=1, 
          I=:=E, new20(s(G),d(L)).
new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=P+Q, P=:=A, Q=:=1, 
          O=:=E, R=:=S+T, S=:=A, T=:=2, U=:=V+W, V=:=B, W=:=1, 
          new21(s(M),d(X)), new13(s(R,U,C,D,E,F),d(G,H,I,J,K,L)).
new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=P+Q, P=:=A, Q=:=1, 
          O=:=E, R=:=S+T, S=:=A, T=:=2, U=:=V+W, V=:=B, W=:=1, 
          new21(s(M),d(X)), new13(s(R,U,C,D,E,F),d(G,H,I,J,K,L)).
new21(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new21(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new21(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new32(s(A),d(B)).
new20(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new33(s(A),d(B)).
new18(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=A, 
          new20(s(G),d(J)).
new18(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=A, 
          new20(s(G),d(J)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=A, 
          new21(s(M),d(P)), new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=A, 
          new21(s(M),d(P)), new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=2, 
          new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=2, 
          new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=F, 
          new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=B, N=:=F, 
          new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=O*P, O=:=2, P=:=F, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=O*P, O=:=2, P=:=F, 
          Q=:=0, new13(s(A,Q,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=C, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=C, O=:=0, P=:=D, 
          Q=:=R-S, R=:=D, S=:=C, T=:=U+V, U=:=O, V=:=C, 
          new11(s(T,B,C,Q,P,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=0, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=F, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=0, 
          new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=0, 
          new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=C, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
inv1 :- \+new1.
