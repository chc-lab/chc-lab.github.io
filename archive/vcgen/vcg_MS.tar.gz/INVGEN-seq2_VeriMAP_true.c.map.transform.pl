new16(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=0, 
          new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=0, Q=:=R+S, 
          R=:=G, S=:=1, T=:=U-V, U=:=D, V=:=1, 
          new13(s(A,B,C,T,E,F,Q),d(H,I,J,K,L,M,N)).
new14(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=G, P=:=A, 
          new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new14(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=<I, H=:=D, I=:=0.
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=0, Q=:=R+S, 
          R=:=F, S=:=1, T=:=U-V, U=:=D, V=:=1, 
          new10(s(A,B,C,T,E,Q,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=F, P=:=B, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=F, P=:=B, Q=:=0, 
          new13(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=B, Q=:=R+S, 
          R=:=E, S=:=1, T=:=U+V, U=:=D, V=:=1, 
          new7(s(A,B,C,T,Q,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=B, Q=:=0, 
          new10(s(A,B,C,D,E,Q,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=C, P=:=A, Q=:=R+S, 
          R=:=C, S=:=1, T=:=U+V, U=:=D, V=:=1, 
          new4(s(A,B,Q,T,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=C, P=:=A, Q=:=0, 
          new7(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P=:=0, 
          new4(s(A,B,O,P,E,F,G),d(H,I,J,K,L,M,N)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new1 :- new2(s,d).
inv1 :- \+new1.
