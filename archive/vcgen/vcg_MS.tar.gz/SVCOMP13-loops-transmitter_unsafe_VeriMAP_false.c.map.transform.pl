new286(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=F, T=:=1, 
          U=:=0, new289(s(A,B,C,U,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new286(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=F, T=:=1, 
          U=:=2, new289(s(A,B,C,U,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new286(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=F, T=:=1, 
          U=:=2, new289(s(A,B,C,U,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new283(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new280(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=F, T=:=1, 
          U=:=0, new283(s(A,B,C,U,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new280(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=F, T=:=1, 
          U=:=2, new283(s(A,B,C,U,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new280(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=F, T=:=1, 
          U=:=2, new283(s(A,B,C,U,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new274(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=0, 
          U=:=1, new277(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new274(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=0, 
          new277(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new274(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=0, 
          new277(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new271(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=0, 
          U=:=1, new274(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new271(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=0, 
          new274(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new271(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=0, 
          new274(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new268(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new265(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=0, 
          U=:=1, new268(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new265(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=0, 
          new268(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new265(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=0, 
          new268(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new262(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=0, 
          U=:=1, new265(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new262(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=0, 
          new265(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new262(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=0, 
          new265(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new256(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, 
          new258(s(A,B,C,D,E,F,G,H,I,U),d(K,L,M,N,O,P,Q,R,S,T)).
new255(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=G, V=:=1, 
          W=:=1, new258(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new255(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=G, V=:=1, 
          new256(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new255(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=G, V=:=1, 
          new256(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new249(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, 
          new251(s(A,B,C,D,E,F,G,H,I,U),d(K,L,M,N,O,P,Q,R,S,T)).
new248(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=I, V=:=1, 
          W=:=1, new251(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new248(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=I, V=:=1, 
          new249(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new248(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=I, V=:=1, 
          new249(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new244(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=K, 
          X=:=0, Y=:=0, 
          new245(s(A,B,C,Y,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new244(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=K, 
          X=:=0, Y=:=0, 
          new245(s(A,B,C,Y,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new244(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=K, 
          X=:=0, new245(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new242(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=B, V=:=1, 
          new248(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new242(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=B, V=:=1, 
          new249(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new242(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=B, V=:=1, 
          new249(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new239(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,J,K)) :- 
          new242(s(A,B,C,D,E,F,G,H,I,U),d(L,M,N,O,P,Q,R,S,T,V)).
new239(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new217(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new244(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,J,W),d(L,M,N,O,P,Q,R,S,T,U,V)).
new238(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, Y=:=0, 
          new239(s(A,B,Y,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new238(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, Y=:=0, 
          new239(s(A,B,Y,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new238(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, new239(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new236(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=1, 
          new255(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new236(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=A, V=:=1, 
          new256(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new236(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=A, V=:=1, 
          new256(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new232(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)).
new230(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, 
          new232(s(A,B,C,D,E,F,G,H,I,U),d(K,L,M,N,O,P,Q,R,S,T)).
new229(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=G, V=:=1, 
          W=:=1, new232(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new229(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=G, V=:=1, 
          new230(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new229(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=G, V=:=1, 
          new230(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new225(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)).
new223(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, 
          new225(s(A,B,C,D,E,F,G,H,I,U),d(K,L,M,N,O,P,Q,R,S,T)).
new222(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=I, V=:=1, 
          W=:=1, new225(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new222(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=I, V=:=1, 
          new223(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new222(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=I, V=:=1, 
          new223(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new219(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)).
new218(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=K, 
          X=:=0, Y=:=0, 
          new219(s(A,B,C,Y,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new218(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=K, 
          X=:=0, Y=:=0, 
          new219(s(A,B,C,Y,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new218(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=K, 
          X=:=0, new219(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new217(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=B, V=:=1, 
          new222(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new217(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=B, V=:=1, 
          new223(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new217(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=B, V=:=1, 
          new223(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new214(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new217(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new218(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,J,W),d(L,M,N,O,P,Q,R,S,T,U,V)).
new213(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, Y=:=0, 
          new214(s(A,B,Y,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new213(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, Y=:=0, 
          new214(s(A,B,Y,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new213(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, new214(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new212(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=1, 
          new229(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new212(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=A, V=:=1, 
          new230(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new212(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=A, V=:=1, 
          new230(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new206(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=1, 
          U=:=2, new209(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new206(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=1, 
          new209(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new206(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=1, 
          new209(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new203(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=1, 
          U=:=2, new206(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new203(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=1, 
          new206(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new203(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=1, 
          new206(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new200(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new197(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=1, 
          U=:=2, new200(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new197(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=1, 
          new200(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new197(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=1, 
          new200(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=1, 
          U=:=2, new197(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=1, 
          new197(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=1, 
          new197(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new190(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,S,T),d(J,K,L,M,N,O,P,Q,R,U,V)).
new189(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new190(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new189(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=2, 
          new141(s(A,B,C,D,E,F,G,H,I),d(T,U,V,W,X,Y,Z,A1,B1)), 
          new184(s(T,U,V,W,X,Y,Z,A1,S),d(J,K,L,M,N,O,P,Q,R)).
new188(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, 
          new189(s(A,B,C,D,E,F,G,H,S),d(J,K,L,M,N,O,P,Q,R)).
new184(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T=:=2, 
          new187(s(S,B,T,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new182(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=A, T=:=1, 
          new184(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new182(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=A, T=:=1, 
          new181(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new182(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=1, 
          new181(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new181(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new188(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new178(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=A, T=:=0, 
          new181(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new178(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=A, T=:=0, 
          new182(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new178(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=0, 
          new182(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new178(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new130(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new153(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=0, A1=:=1, 
          new175(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=0, A1=:=1, 
          new175(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=0, new153(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new172(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T=:=2, 
          new173(s(A,S,C,T,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new171(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new168(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- 
          new171(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new166(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=B, T=:=1, 
          new168(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new166(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=B, T=:=1, 
          new165(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new166(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=B, T=:=1, 
          new165(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new165(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new172(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new162(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=B, T=:=0, 
          new165(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new162(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=B, T=:=0, 
          new166(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new162(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=B, T=:=0, 
          new166(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new159(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new162(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new159(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new116(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new144(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=L, 
          Z=:=0, A1=:=1, 
          new159(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=L, 
          Z=:=0, A1=:=1, 
          new159(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=L, 
          Z=:=0, new144(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=D, 
          Z=:=0, new155(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=D, 
          Z=:=0, new144(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=D, 
          Z=:=0, new144(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new174(s(A,B,C,D,E,F,G,H,I,J,Y,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new149(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=C, 
          Z=:=0, new152(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new149(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=C, 
          Z=:=0, new153(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new149(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=C, 
          Z=:=0, new153(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new149(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new149(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=0, new151(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,V),d(M,N,O,P,Q,R,S,T,U,W)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, 
          new38(s(A,B,C,D,E,F,G,H,I,A1),d(B1,C1,D1,E1,F1,G1,H1,I1,J1,Z)), 
          new148(s(B1,C1,D1,E1,F1,G1,H1,I1,J1,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new145(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new141(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,S,T),d(J,K,L,M,N,O,P,Q,R,U,V)).
new140(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=2, 
          new141(s(A,B,C,D,E,F,G,H,I),d(T,U,V,W,X,Y,Z,A1,B1)), 
          new135(s(T,U,V,W,X,Y,Z,A1,S),d(J,K,L,M,N,O,P,Q,R)).
new139(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, 
          new140(s(A,B,C,D,E,F,G,H,S),d(J,K,L,M,N,O,P,Q,R)).
new138(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new135(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T=:=2, 
          new138(s(S,B,T,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=A, T=:=1, 
          new135(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=A, T=:=1, 
          new132(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=1, 
          new132(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new132(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new139(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new130(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=A, T=:=0, 
          new132(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new130(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=A, T=:=0, 
          new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new130(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=0, 
          new133(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new130(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new107(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=0, A1=:=1, 
          new127(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=0, A1=:=1, 
          new127(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=0, new107(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new125(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new124(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T=:=2, 
          new125(s(A,S,C,T,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new119(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=B, T=:=1, 
          new121(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new119(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=B, T=:=1, 
          new118(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new119(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=B, T=:=1, 
          new118(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new118(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new124(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new116(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=B, T=:=0, 
          new118(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new116(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=B, T=:=0, 
          new119(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new116(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=B, T=:=0, 
          new119(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new116(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new99(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=L, 
          Z=:=0, A1=:=1, 
          new113(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=L, 
          Z=:=0, A1=:=1, 
          new113(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=L, 
          Z=:=0, new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new112(s(A,B,C,D,E,F,G,H,I,J,K,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new107(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=D, 
          Z=:=0, new109(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new107(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=D, 
          Z=:=0, new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new107(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=D, 
          Z=:=0, new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new126(s(A,B,C,D,E,F,G,H,I,J,Y,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new105(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=C, 
          Z=:=0, new106(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=C, 
          Z=:=0, new107(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=C, 
          Z=:=0, new107(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new103(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new103(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=0, new105(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, 
          new38(s(A,B,C,D,E,F,G,H,I,A1),d(B1,C1,D1,E1,F1,G1,H1,I1,J1,Z)), 
          new102(s(B1,C1,D1,E1,F1,G1,H1,I1,J1,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new94(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=D, V=:=0, 
          W=:=1, new93(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new94(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=D, V=:=0, 
          W=:=0, new93(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new94(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=D, V=:=0, 
          W=:=0, new93(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new88(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=D, V=:=0, 
          W=:=1, new87(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new88(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=D, V=:=0, 
          W=:=0, new87(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new88(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=D, V=:=0, 
          W=:=0, new87(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new87(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)).
new81(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=1, U=:=2, 
          new84(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new81(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=1, 
          new84(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new81(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=1, 
          new84(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new78(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=1, U=:=2, 
          new81(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new78(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=1, 
          new81(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new78(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=1, 
          new81(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new75(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)).
new72(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=1, U=:=2, 
          new75(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new72(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=1, 
          new75(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new72(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=1, 
          new75(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new69(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=1, U=:=2, 
          new72(s(A,B,C,D,E,F,G,U,I),d(J,K,L,M,N,O,P,Q,R)).
new69(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=1, 
          new72(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new69(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=1, 
          new72(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new67(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new69(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new67(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new67(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new66(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new78(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new66(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=1, 
          new78(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new66(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=1, 
          new78(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new66(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new67(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new41(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,V,W),d(M,N,O,P,Q,R,S,T,U,X,Y)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new65(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new61(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,J,H,I)) :- J=:=1.
new56(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, Y=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,Y),d(L,M,N,O,P,Q,R,S,T,U,V)).
new56(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, Y=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,Y),d(L,M,N,O,P,Q,R,S,T,U,V)).
new56(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, Y=:=1, 
          new57(s(A,B,C,D,E,F,G,H,I,J,Y),d(L,M,N,O,P,Q,R,S,T,U,V)).
new51(s(A,B,C,D,E,F,G,H,I,J,K),d(A,B,C,D,E,F,G,H,I,J,K)).
new50(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W>=X+1, W=:=J, 
          X=:=0, Y=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,J,Y),d(L,M,N,O,P,Q,R,S,T,U,V)).
new50(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W+1=<X, W=:=J, 
          X=:=0, Y=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,J,Y),d(L,M,N,O,P,Q,R,S,T,U,V)).
new50(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, W=:=J, 
          X=:=0, Y=:=1, 
          new51(s(A,B,C,D,E,F,G,H,I,J,Y),d(L,M,N,O,P,Q,R,S,T,U,V)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=L, 
          Z=:=0, new46(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=L, 
          Z=:=0, new46(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=L, 
          Z=:=0, new22(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new44(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new38(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new50(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,J,K)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,U),d(L,M,N,O,P,Q,R,S,T,V)).
new43(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new38(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new56(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new43(s(A,B,C,D,E,F,G,H,I,V,W),d(M,N,O,P,Q,R,S,T,U,X,Y)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, 
          new44(s(A,B,C,D,E,F,G,H,I,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,Z)), 
          new45(s(C1,D1,E1,F1,G1,H1,I1,J1,K1,J,K,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new60(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new61(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new62(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=0, A1=:=4, 
          new40(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=0, new41(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=0, new41(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new38(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=C, V=:=0, 
          W=:=1, new87(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new38(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=C, V=:=0, 
          new88(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new38(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=C, V=:=0, 
          new88(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new37(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=C, V=:=0, 
          W=:=1, new93(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new37(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=C, V=:=0, 
          new94(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new37(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=C, V=:=0, 
          new94(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,V),d(M,N,O,P,Q,R,S,T,U,W)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, 
          new38(s(A,B,C,D,E,F,G,H,I,A1),d(B1,C1,D1,E1,F1,G1,H1,I1,J1,Z)), 
          new39(s(B1,C1,D1,E1,F1,G1,H1,I1,J1,J,Y,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new20(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new21(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new36(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,V,W),d(M,N,O,P,Q,R,S,T,U,X,Y)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new33(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new14(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new15(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new30(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=3, 
          new27(s(A,B,C,D,E,F,G,H,I,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new144(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new24(s(A,B,C,D,E,F,G,H,I,V,W,X),d(M,N,O,P,Q,R,S,T,U,Y,Z,A1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, 
          new25(s(A,B,C,D,E,F,G,H,I,Z,A1,B1),d(C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)), 
          new26(s(C1,D1,E1,F1,G1,H1,I1,J1,K1,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=1, 
          new23(s(A,B,C,D,E,F,G,H,I,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new21(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new194(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new21(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=1, 
          new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new21(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=1, 
          new194(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new203(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=1, 
          new203(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=1, 
          new203(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new20(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new21(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new22(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new18(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new212(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new213(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new17(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,J,K)) :- 
          new236(s(A,B,C,D,E,F,G,H,I,U),d(L,M,N,O,P,Q,R,S,T,V)).
new17(s(A,B,C,D,E,F,G,H,I,J,K),d(L,M,N,O,P,Q,R,S,T,U,V)) :- W=:=X, 
          new212(s(A,B,C,D,E,F,G,H,I,Y),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,X)), 
          new238(s(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K),d(L,M,N,O,P,Q,R,S,T,U,V)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,V,W),d(M,N,O,P,Q,R,S,T,U,X,Y)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,Y,Z),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new19(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=0, U=:=1, 
          new262(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=0, 
          new262(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=0, 
          new262(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=0, U=:=1, 
          new271(s(A,B,C,D,E,F,U,H,I),d(J,K,L,M,N,O,P,Q,R)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=0, 
          new271(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=0, 
          new271(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new14(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new15(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new16(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=E, T=:=1, U=:=0, 
          new280(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=E, T=:=1, 
          U=:=2, new280(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=E, T=:=1, 
          U=:=2, new280(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=E, T=:=1, U=:=0, 
          new286(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=E, T=:=1, 
          U=:=2, new286(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=E, T=:=1, 
          U=:=2, new286(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,J,K,L)) :- 
          new11(s(A,B,C,D,E,F,G,H,I),d(M,N,O,P,Q,R,S,T,U)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new12(s(A,B,C,D,E,F,G,H,I),d(Y,Z,A1,B1,C1,D1,E1,F1,G1)), 
          new13(s(Y,Z,A1,B1,C1,D1,E1,F1,G1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new7(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,J)) :- 
          new8(s(A,B,C,D,E,F,G,H,I,T,U,V),d(K,L,M,N,O,P,Q,R,S,W,X,Y)).
new6(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,J,K,G,H,I)) :- J=:=1, K=:=1.
new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,J)) :- 
          new5(s(A,B,C,D,E,F,G,H,I),d(K,L,M,N,O,P,Q,R,S)).
new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- 
          new6(s(A,B,C,D,E,F,G,H,I),d(U,V,W,X,Y,Z,A1,B1,C1)), 
          new7(s(U,V,W,X,Y,Z,A1,B1,C1,J),d(K,L,M,N,O,P,Q,R,S,T)).
new3(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new2(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,S),d(J,K,L,M,N,O,P,Q,R,T)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, 
          new2(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
inv1 :- \+new1.
