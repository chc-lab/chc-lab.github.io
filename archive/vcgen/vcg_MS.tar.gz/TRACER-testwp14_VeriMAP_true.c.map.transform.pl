new14(s(A),d(B)) :- new14(s(A),d(B)).
new13(s(A),d(A)).
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new13(s(A),d(B)).
new9(s(A,B,C),d(A,B,C)) :- D=:=1, E>=F+1, E=:=B, F=:=4, new11(s(D),d(G)).
new9(s(A,B,C),d(A,B,C)) :- D=:=0, E=<F, E=:=B, F=:=4, new11(s(D),d(G)).
new7(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new7(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new7(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new14(s(A),d(B)).
new6(s(A,B,C),d(D,E,F)) :- G=:=1, H>=I+1, H=:=A, I=:=0, J=:=A, new7(s(G),d(K)), 
          new9(s(A,J,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G=:=0, H=<I, H=:=A, I=:=0, J=:=A, new7(s(G),d(K)), 
          new9(s(A,J,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=4, I=:=4, new4(s(A,B,I),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=4, I=:=5, new4(s(I,B,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
