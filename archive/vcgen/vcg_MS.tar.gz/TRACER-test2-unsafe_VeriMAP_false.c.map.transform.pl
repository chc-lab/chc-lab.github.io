new25(s(A),d(B)) :- new25(s(A),d(B)).
new24(s(A),d(A)).
new22(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new24(s(A),d(B)).
new19(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=B, J=:=A, K=:=L+M, L=:=C, M=:=B, 
          N=:=O*P, O=:=D, P=:=B, Q=:=R+S, R=:=B, S=:=1, 
          new20(s(A,Q,K,N),d(E,F,G,H)).
new19(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=A, 
          new20(s(A,B,C,D),d(E,F,G,H)).
new17(s(A,B,C,D),d(A,B,C,D)).
new16(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=B, J=:=A, K=:=L+M, L=:=C, M=:=B, 
          N=:=O*P, O=:=D, P=:=B, Q=:=R+S, R=:=B, S=:=1, 
          new17(s(A,Q,K,N),d(E,F,G,H)).
new16(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=A, 
          new17(s(A,B,C,D),d(E,F,G,H)).
new12(s(A,B,C),d(A,B,C)) :- D=:=5, new10(s(D,E,F,G),d(H,I,J,K)).
new12(s(A,B,C),d(D,E,F)) :- G=:=5, H=:=I, J=:=K+L, K=:=H, L=:=5, 
          new11(s(G,M,N,O),d(P,Q,I,R)), new8(s(J,B,H),d(D,E,F)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=0, K=:=1, 
          new16(s(A,I,J,K),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=0, K=:=1, 
          new19(s(A,I,J,K),d(E,F,G,H)).
new9(s(A,B,C),d(A,B,C)) :- D=:=A, new10(s(D,E,F,G),d(H,I,J,K)).
new9(s(A,B,C),d(D,E,F)) :- G=:=A, H=:=I, J=:=K-L, K=:=H, L=:=1, 
          new11(s(G,M,N,O),d(P,Q,I,R)), new12(s(J,H,C),d(D,E,F)).
new8(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=A, F=:=0, new22(s(D),d(G)).
new8(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=A, F=:=0, new22(s(D),d(G)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=J+K, J=:=A, K=:=1, 
          new8(s(I,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=0, new9(s(A,B,C),d(D,E,F)).
new4(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new4(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new4(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new25(s(A),d(B)).
new3(s(A,B,C),d(D,E,F)) :- G=:=1, H>=I+1, H=:=A, I=:=0, new4(s(G),d(J)), 
          new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=<I, H=:=A, I=:=0, new4(s(G),d(J)), 
          new6(s(A,B,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
