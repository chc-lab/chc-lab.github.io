new17(s(A),d(A)).
new11(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new11(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new16(s(A),d(B)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new17(s(A),d(B)).
new9(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F>=G+1, F=:=C, G=:=0, new10(s(E),d(H)).
new9(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F=<G, F=:=C, G=:=0, new10(s(E),d(H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J>=K+1, J=:=C, K=:=0, L=:=M+N, M=:=D, 
          N=:=1, O=:=P-Q, P=:=C, Q=:=1, new11(s(I),d(R)), 
          new7(s(A,B,O,L),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=<K, J=:=C, K=:=0, L=:=M+N, M=:=D, 
          N=:=1, O=:=P-Q, P=:=C, Q=:=1, new11(s(I),d(R)), 
          new7(s(A,B,O,L),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=A, 
          new9(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- new8(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=A, K=:=L+M, L=:=B, M=:=1, 
          N=:=O+P, O=:=C, P=:=1, new4(s(A,K,N,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=B, J=:=A, K=:=0, 
          new7(s(A,B,C,K),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,I,J,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
