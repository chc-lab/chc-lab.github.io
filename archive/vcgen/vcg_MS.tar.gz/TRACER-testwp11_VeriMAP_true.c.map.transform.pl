new15(s(A),d(A)).
new14(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new15(s(A),d(B)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=B, P=:=5, Q=:=0, 
          new10(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=B, P=:=5, Q=:=1, 
          new10(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=G, new14(s(H),d(I)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=10, Q=:=0, 
          new10(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=A, P=:=10, 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=0, Q=:=5, 
          new8(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=0, Q=:=6, 
          new8(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=F, P=:=0, Q=:=4, 
          new6(s(Q,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=F, P=:=0, Q=:=5, 
          new6(s(Q,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=0, Q=:=2, 
          new4(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=E, P=:=0, Q=:=3, 
          new4(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new1 :- new2(s,d).
inv1 :- \+new1.
