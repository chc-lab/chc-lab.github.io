new10(s(A,B,C,D),d(A,B,C,D)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=C, J=:=0, new10(s(A,B,C,D),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=0, K=:=L+M, L=:=D, M=:=2, 
          N=:=O-P, O=:=C, P=:=1, new7(s(A,B,N,K),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=A, 
          new9(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- new8(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=A, K=:=L+M, L=:=B, M=:=2, 
          N=:=O+P, O=:=C, P=:=1, new4(s(A,K,N,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=B, J=:=A, K=:=0, 
          new7(s(A,B,C,K),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,I,J,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
