new108(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=D, 
          new15(s(A,G),d(A,J)).
new108(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=D, 
          new15(s(A,G),d(A,J)).
new108(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, new16(s(A,M),d(A,S)), 
          new6(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new108(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, new16(s(A,M),d(A,S)), 
          new6(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new102(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new102(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new102(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=D, O=:=E, 
          new16(s(A,M),d(A,P)), new108(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new102(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=D, O=:=E, 
          new16(s(A,M),d(A,P)), new108(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new96(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=D, 
          new15(s(A,G),d(A,J)).
new96(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=D, 
          new15(s(A,G),d(A,J)).
new96(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, S=:=T+U, T=:=C, U=:=1, new16(s(A,M),d(A,V)), 
          new102(s(A,B,S,P,E,F),d(G,H,I,J,K,L)).
new96(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, S=:=T+U, T=:=C, U=:=1, new16(s(A,M),d(A,V)), 
          new102(s(A,B,S,P,E,F),d(G,H,I,J,K,L)).
new90(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new90(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new90(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=D, O=:=E, 
          new16(s(A,M),d(A,P)), new96(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new90(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=D, O=:=E, 
          new16(s(A,M),d(A,P)), new96(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new84(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new84(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new84(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=C, 
          new16(s(A,M),d(A,P)), new90(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new84(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=C, 
          new16(s(A,M),d(A,P)), new90(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new78(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=C, I=:=B, 
          new15(s(A,G),d(A,J)).
new78(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=C, I=:=B, 
          new15(s(A,G),d(A,J)).
new78(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=C, O=:=B, 
          new16(s(A,M),d(A,P)), new84(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new78(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=C, O=:=B, 
          new16(s(A,M),d(A,P)), new84(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new72(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=D, 
          new15(s(A,G),d(A,J)).
new72(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=D, 
          new15(s(A,G),d(A,J)).
new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, S=:=T+U, T=:=C, U=:=1, new16(s(A,M),d(A,V)), 
          new78(s(A,B,S,P,E,F),d(G,H,I,J,K,L)).
new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, S=:=T+U, T=:=C, U=:=1, new16(s(A,M),d(A,V)), 
          new78(s(A,B,S,P,E,F),d(G,H,I,J,K,L)).
new66(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new66(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new66(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=D, O=:=E, 
          new16(s(A,M),d(A,P)), new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new66(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=D, O=:=E, 
          new16(s(A,M),d(A,P)), new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new60(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new60(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=C, 
          new16(s(A,M),d(A,P)), new66(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=C, 
          new16(s(A,M),d(A,P)), new66(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new55(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=C, I=:=B, 
          new15(s(A,G),d(A,J)).
new55(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=C, I=:=B, 
          new15(s(A,G),d(A,J)).
new55(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=C, O=:=B, 
          new16(s(A,M),d(A,P)), new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new55(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=C, O=:=B, 
          new16(s(A,M),d(A,P)), new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new55(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new45(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new45(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=C, 
          new16(s(A,M),d(A,P)), new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=C, 
          new16(s(A,M),d(A,P)), new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new40(s(A,B),d(A,B)).
new31(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=D, 
          new15(s(A,G),d(A,J)).
new31(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=D, 
          new15(s(A,G),d(A,J)).
new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, S=:=T+U, T=:=C, U=:=1, new16(s(A,M),d(A,V)), 
          new6(s(A,B,S,P,E,F),d(G,H,I,J,K,L)).
new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, S=:=T+U, T=:=C, U=:=1, new16(s(A,M),d(A,V)), 
          new6(s(A,B,S,P,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new25(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=D, O=:=E, 
          new16(s(A,M),d(A,P)), new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=D, O=:=E, 
          new16(s(A,M),d(A,P)), new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new19(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new19(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=C, 
          new16(s(A,M),d(A,P)), new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=C, 
          new16(s(A,M),d(A,P)), new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new16(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new16(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new16(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new39(s(A,B),d(A,C)).
new15(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new40(s(A,B),d(A,C)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=C, I=:=B, 
          new15(s(A,G),d(A,J)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=C, I=:=B, 
          new15(s(A,G),d(A,J)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=C, O=:=B, 
          new16(s(A,M),d(A,P)), new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=C, O=:=B, 
          new16(s(A,M),d(A,P)), new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=J+K, J=:=C, K=:=1, 
          I=:=B, new15(s(A,G),d(A,L)).
new13(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=J+K, J=:=C, K=:=1, 
          I=:=B, new15(s(A,G),d(A,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=P+Q, P=:=C, Q=:=1, 
          O=:=B, new16(s(A,M),d(A,R)), new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=P+Q, P=:=C, Q=:=1, 
          O=:=B, new16(s(A,M),d(A,R)), new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O+P, O=:=C, P=:=1, N=:=B, 
          new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O+P, O=:=C, P=:=1, N=:=B, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=F, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=F, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=B, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=B, O=:=0, 
          new6(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N-O, N=:=E, O=:=4, P=:=0, 
          new4(s(A,B,P,D,E,M),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
