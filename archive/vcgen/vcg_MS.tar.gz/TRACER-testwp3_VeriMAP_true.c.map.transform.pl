new9(s(A),d(A)).
new7(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new9(s(A),d(B)).
new6(s(A,B),d(A,B)) :- C=:=1, D=<E, D=:=A, E=:=50, new7(s(C),d(F)).
new6(s(A,B),d(A,B)) :- C=:=0, D>=E+1, D=:=A, E=:=50, new7(s(C),d(F)).
new4(s(A,B),d(C,D)) :- E=:=F+G, F=:=A, G=:=1, H=:=I+J, I=:=E, J=:=2, 
          new6(s(H,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=2, new4(s(G,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=47, new4(s(G,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
