new60(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=B, I=:=C, 
          new15(s(G),d(J)).
new60(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=B, I=:=C, 
          new15(s(G),d(J)).
new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=B, O=:=C, 
          new16(s(M),d(P)), new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=B, O=:=C, 
          new16(s(M),d(P)), new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new54(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, 
          new15(s(G),d(J)).
new54(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, 
          new15(s(G),d(J)).
new54(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=B, 
          new16(s(M),d(P)), new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new54(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=B, 
          new16(s(M),d(P)), new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new48(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=E, I=:=D, 
          new15(s(G),d(J)).
new48(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=E, I=:=D, 
          new15(s(G),d(J)).
new48(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=E, O=:=D, P=:=Q+R, 
          Q=:=E, R=:=1, S=:=T+U, T=:=B, U=:=1, new16(s(M),d(V)), 
          new54(s(A,S,C,D,P,F),d(G,H,I,J,K,L)).
new48(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=E, O=:=D, P=:=Q+R, 
          Q=:=E, R=:=1, S=:=T+U, T=:=B, U=:=1, new16(s(M),d(V)), 
          new54(s(A,S,C,D,P,F),d(G,H,I,J,K,L)).
new42(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new42(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=E, 
          new16(s(M),d(P)), new48(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=E, 
          new16(s(M),d(P)), new48(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new40(s(A),d(A)).
new31(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=E, I=:=D, 
          new15(s(G),d(J)).
new31(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=E, I=:=D, 
          new15(s(G),d(J)).
new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=E, O=:=D, P=:=Q+R, 
          Q=:=E, R=:=1, new16(s(M),d(S)), new5(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=E, O=:=D, P=:=Q+R, 
          Q=:=E, R=:=1, new16(s(M),d(S)), new5(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new25(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=E, 
          new16(s(M),d(P)), new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=E, 
          new16(s(M),d(P)), new31(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new19(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=E, I=:=D, 
          new15(s(G),d(J)).
new19(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=E, I=:=D, 
          new15(s(G),d(J)).
new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=E, O=:=D, P=:=Q+R, 
          Q=:=E, R=:=1, new16(s(M),d(S)), new25(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=E, O=:=D, P=:=Q+R, 
          Q=:=E, R=:=1, new16(s(M),d(S)), new25(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new16(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new16(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new39(s(A),d(B)).
new15(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new40(s(A),d(B)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=E, 
          new16(s(M),d(P)), new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=E, 
          new16(s(M),d(P)), new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=F, 
          new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=F, 
          new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=F, 
          new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=C, O=:=0, P=:=0, 
          Q=:=R-S, R=:=D, S=:=2, new8(s(A,P,C,D,O,Q),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=C, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=0, 
          new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=C, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=1, 
          new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=1, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
inv1 :- \+new1.
