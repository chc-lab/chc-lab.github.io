new7(s(A),d(A)).
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new7(s(A),d(B)).
new4(s(A,B),d(A,B)) :- C=:=1, D>=E, D=:=A, E=:=0, new5(s(C),d(F)).
new4(s(A,B),d(A,B)) :- C=:=0, D+1=<E, D=:=A, E=:=0, new5(s(C),d(F)).
new3(s(A,B),d(C,D)) :- E=:=99, F=:=0, new4(s(F,E),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
