new63(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=C, T=:=2, 
          U=:=V-W, V=:=B, W=:=1, X=:=Y-Z, Y=:=A1*B1, A1=:=2, B1=:=B, Z=:=2, 
          C1=:=D1-E1, D1=:=B, E1=:=1, 
          new9(s(A,C1,C,U,X,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new61(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=C, T=:=3, U=:=B, 
          V=:=W*X, W=:=2, X=:=B, 
          new9(s(A,B,C,U,V,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new60(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=B, T=:=1, 
          U=:=V-W, V=:=C, W=:=1, 
          new61(s(A,B,U,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new58(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=B, T=:=2, 
          new63(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new57(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=F, T=:=0, 
          new58(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new57(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=F, T=:=0, 
          new58(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new57(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=F, T=:=0, 
          new60(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new56(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new57(s(A,B,C,D,E,S,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new54(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=U-V, U=:=E, 
          V=:=C, T=:=0, W=:=E, X=:=Y*Z, Y=:=2, Z=:=E, 
          new9(s(A,B,C,W,X,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new53(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=0, 
          new54(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new53(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=0, 
          new54(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new53(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=0, 
          new56(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new52(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new53(s(A,B,C,D,E,F,S,H,I),d(J,K,L,M,N,O,P,Q,R)).
new50(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=W-X, 
          W=:=C, X=:=E, V=:=1, T=:=0, Y=:=Z+A1, Z=:=E, A1=:=1, B1=:=C1+D1, 
          C1=:=E1*F1, E1=:=2, F1=:=E, D1=:=2, 
          new9(s(A,B,C,Y,B1,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new49(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=0, 
          new50(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new49(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=0, 
          new50(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new49(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=0, 
          new52(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new48(s(A),d(A)).
new43(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M-N, 
          M=:=A, N=:=C, L=:=0, new15(s(J),d(O)).
new43(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M-N, 
          M=:=A, N=:=C, L=:=0, new15(s(J),d(O)).
new37(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M-N, 
          M=:=B, N=:=1, L=:=0, new15(s(J),d(O)).
new37(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M-N, 
          M=:=B, N=:=1, L=:=0, new15(s(J),d(O)).
new37(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=V-W, 
          V=:=B, W=:=1, U=:=0, new16(s(S),d(X)), 
          new43(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new37(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=V-W, 
          V=:=B, W=:=1, U=:=0, new16(s(S),d(X)), 
          new43(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new31(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M-N, 
          M=:=C, N=:=2, L=:=0, new15(s(J),d(O)).
new31(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M-N, 
          M=:=C, N=:=2, L=:=0, new15(s(J),d(O)).
new31(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=V-W, 
          V=:=C, W=:=2, U=:=0, new16(s(S),d(X)), 
          new37(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new31(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=V-W, 
          V=:=C, W=:=2, U=:=0, new16(s(S),d(X)), 
          new37(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new25(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M+N, 
          M=:=O+P, O=:=Q*R, Q=:= -2, R=:=B, P=:=C, N=:=1, L=:=0, 
          new15(s(J),d(S)).
new25(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M+N, 
          M=:=O+P, O=:=Q*R, Q=:= -2, R=:=B, P=:=C, N=:=1, L=:=0, 
          new15(s(J),d(S)).
new25(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=V+W, 
          V=:=X+Y, X=:=Z*A1, Z=:= -2, A1=:=B, Y=:=C, W=:=1, U=:=0, 
          new16(s(S),d(B1)), new31(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new25(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=V+W, 
          V=:=X+Y, X=:=Z*A1, Z=:= -2, A1=:=B, Y=:=C, W=:=1, U=:=0, 
          new16(s(S),d(B1)), new31(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new19(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K=<L, K=:=M-N, 
          M=:=O*P, O=:=2, P=:=D, N=:=E, L=:=0, new15(s(J),d(Q)).
new19(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K>=L+1, K=:=M-N, 
          M=:=O*P, O=:=2, P=:=D, N=:=E, L=:=0, new15(s(J),d(Q)).
new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T=<U, T=:=V-W, 
          V=:=X*Y, X=:=2, Y=:=D, W=:=E, U=:=0, new16(s(S),d(Z)), 
          new25(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T>=U+1, T=:=V-W, 
          V=:=X*Y, X=:=2, Y=:=D, W=:=E, U=:=0, new16(s(S),d(Z)), 
          new25(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new16(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new16(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new47(s(A),d(B)).
new15(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new48(s(A),d(B)).
new14(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M-N, 
          M=:=O*P, O=:=2, P=:=D, N=:=E, L=:=0, new15(s(J),d(Q)).
new14(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M-N, 
          M=:=O*P, O=:=2, P=:=D, N=:=E, L=:=0, new15(s(J),d(Q)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=V-W, 
          V=:=X*Y, X=:=2, Y=:=D, W=:=E, U=:=0, new16(s(S),d(Z)), 
          new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=V-W, 
          V=:=X*Y, X=:=2, Y=:=D, W=:=E, U=:=0, new16(s(S),d(Z)), 
          new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new49(s(A,B,C,D,E,F,G,S,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=0, 
          new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=0, 
          new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=0, 
          new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new11(s(A,B,C,D,E,F,G,H,S),d(J,K,L,M,N,O,P,Q,R)).
new9(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new8(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=U-V, U=:=W-X, 
          W=:=Y*Z, Y=:=2, Z=:=B, X=:=A, V=:=1, T=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=W*X, 
          W=:=2, X=:=B, V=:=A, T=:=0, 
          new8(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new6(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=U-V, U=:=E, 
          V=:=W*X, W=:=2, X=:=B, T=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new5(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=U-V, U=:=D, 
          V=:=B, T=:=0, new6(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new4(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=U-V, U=:=C, 
          V=:=A, T=:=0, new5(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=A, T=:=2, 
          new4(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new1 :- new2(s,d).
inv1 :- \+new1.
