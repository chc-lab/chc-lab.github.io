new11(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=0, I=:=J-K, J=:=B, K=:=1, 
          L=:=M*N, M=:=2, N=:=C, new6(s(A,I,L),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=0, new4(s(A,B,C),d(D,E,F)).
new10(s(A),d(A)).
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new10(s(A),d(B)).
new7(s(A,B,C),d(A,B,C)) :- D=:=1, E>=F+1, E=:=C, F=:=0, new8(s(D),d(G)).
new7(s(A,B,C),d(A,B,C)) :- D=:=0, E=<F, E=:=C, F=:=0, new8(s(D),d(G)).
new6(s(A,B,C),d(D,E,F)) :- new11(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=A, new6(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=A, new7(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=1, H=:=10, new4(s(A,H,G),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
