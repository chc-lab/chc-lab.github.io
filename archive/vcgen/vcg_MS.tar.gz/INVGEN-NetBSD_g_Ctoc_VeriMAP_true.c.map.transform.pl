new48(s(A,B,C),d(A,B,C)).
new42(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=C, 
          O=:=1, P=:=Q+R, Q=:=D, R=:=1, new6(s(A,B,M,P,E),d(F,G,H,I,J)).
new42(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=0, M=:=N+O, N=:=C, 
          O=:=1, P=:=Q+R, Q=:=D, R=:=1, new6(s(A,B,M,P,E),d(F,G,H,I,J)).
new42(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          P=:=Q+R, Q=:=D, R=:=1, S=:=T-U, T=:=E, U=:=1, 
          new14(s(A,B,M,P,S),d(F,G,H,I,J)).
new36(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G+1=<H, G=:=C, H=:=A, 
          new7(s(A,B,F),d(A,B,I)).
new36(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H, G=:=C, H=:=A, 
          new7(s(A,B,F),d(A,B,I)).
new36(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L+1=<M, L=:=C, M=:=A, 
          new8(s(A,B,K),d(A,B,N)), new42(s(A,B,C,D,E),d(F,G,H,I,J)).
new36(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M, L=:=C, M=:=A, 
          new8(s(A,B,K),d(A,B,N)), new42(s(A,B,C,D,E),d(F,G,H,I,J)).
new30(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G=<H, G=:=0, H=:=C, 
          new7(s(A,B,F),d(A,B,I)).
new30(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H+1, G=:=0, H=:=C, 
          new7(s(A,B,F),d(A,B,I)).
new30(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L=<M, L=:=0, M=:=C, 
          new8(s(A,B,K),d(A,B,N)), new36(s(A,B,C,D,E),d(F,G,H,I,J)).
new30(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=0, M=:=C, 
          new8(s(A,B,K),d(A,B,N)), new36(s(A,B,C,D,E),d(F,G,H,I,J)).
new24(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G+1=<H, G=:=D, H=:=A, 
          new7(s(A,B,F),d(A,B,I)).
new24(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H, G=:=D, H=:=A, 
          new7(s(A,B,F),d(A,B,I)).
new24(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L+1=<M, L=:=D, M=:=A, 
          new8(s(A,B,K),d(A,B,N)), new30(s(A,B,C,D,E),d(F,G,H,I,J)).
new24(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M, L=:=D, M=:=A, 
          new8(s(A,B,K),d(A,B,N)), new30(s(A,B,C,D,E),d(F,G,H,I,J)).
new18(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G=<H, G=:=0, H=:=D, 
          new7(s(A,B,F),d(A,B,I)).
new18(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H+1, G=:=0, H=:=D, 
          new7(s(A,B,F),d(A,B,I)).
new18(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L=<M, L=:=0, M=:=D, 
          new8(s(A,B,K),d(A,B,N)), new24(s(A,B,C,D,E),d(F,G,H,I,J)).
new18(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=0, M=:=D, 
          new8(s(A,B,K),d(A,B,N)), new24(s(A,B,C,D,E),d(F,G,H,I,J)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=E, L=:=0, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, 
          new18(s(A,B,C,D,E),d(F,G,H,I,J)).
new16(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, 
          new18(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- new16(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=E, L=:=0, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=0, N=:=0, 
          new14(s(A,B,M,N,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, M=:=0, N=:=0, 
          new14(s(A,B,M,N,E),d(F,G,H,I,J)).
new8(s(A,B,C),d(A,B,C)) :- D>=E+1, D=:=C, E=:=0.
new8(s(A,B,C),d(A,B,C)) :- D+1=<E, D=:=C, E=:=0.
new8(s(A,B,C),d(A,B,D)) :- E=:=F, E=:=C, F=:=0, new47(s(A,B,C),d(A,B,D)).
new7(s(A,B,C),d(A,B,D)) :- E=:=F, E=:=C, F=:=0, new48(s(A,B,C),d(A,B,D)).
new5(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G=<H, G=:=0, H=:=I-J, I=:=A, J=:=1, 
          new7(s(A,B,F),d(A,B,K)).
new5(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H+1, G=:=0, H=:=I-J, I=:=A, J=:=1, 
          new7(s(A,B,F),d(A,B,K)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L=<M, L=:=0, M=:=N-O, N=:=A, O=:=1, 
          new8(s(A,B,K),d(A,B,P)), new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=0, M=:=N-O, N=:=A, O=:=1, 
          new8(s(A,B,K),d(A,B,P)), new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=A, L=:=0, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=A, new4(s(A,B,C,D,K),d(F,G,H,I,J)).
new2(s(A,B),d(C,D)) :- new3(s(A,B,E,F,G),d(C,D,H,I,J)).
new1 :- A=:=0, B=:=0, new2(s(A,B),d(C,D)).
inv1 :- \+new1.
