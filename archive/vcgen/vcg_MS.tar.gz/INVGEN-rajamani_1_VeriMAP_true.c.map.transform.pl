new25(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=M*N, M=:=100, N=:=B, 
          O=:=P*Q, P=:= -1, Q=:=C, new19(s(A,B,O,D,E),d(F,G,H,I,J)).
new25(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=M*N, M=:=100, N=:=B, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new24(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=C, L=:=M*N, M=:=10, N=:=E, 
          new25(s(A,B,C,D,E),d(F,G,H,I,J)).
new24(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=C, L=:=M*N, M=:=10, N=:=E, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new22(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=4, M=:=N+O, N=:=B, O=:=1, 
          P=:=Q+R, Q=:=C, R=:=1, new19(s(A,M,P,D,E),d(F,G,H,I,J)).
new22(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=4, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, 
          new22(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, 
          new22(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new24(s(A,B,C,D,E),d(F,G,H,I,J)).
new19(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L+M, L=:=E, M=:=1, N=:=O+P, O=:=D, 
          P=:=10, new4(s(A,B,C,N,K),d(F,G,H,I,J)).
new18(s(A,B),d(A,B)).
new12(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new12(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new12(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new17(s(A,B),d(A,C)).
new11(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new18(s(A,B),d(A,C)).
new9(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H+1, G=:=C, H=:=2, 
          new11(s(A,F),d(A,I)).
new9(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G=<H, G=:=C, H=:=2, 
          new11(s(A,F),d(A,I)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M+1, L=:=C, M=:=2, 
          new12(s(A,K),d(A,N)), new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=<M, L=:=C, M=:=2, 
          new12(s(A,K),d(A,N)), new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=4, 
          new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=4, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, M=:=N+O, N=:=B, O=:=1, 
          P=:=Q+R, Q=:=C, R=:=100, new19(s(A,M,P,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, M=:=N+O, N=:=B, O=:=1, 
          P=:=Q+R, Q=:=C, R=:=100, new19(s(A,M,P,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=0, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=A, L=:=0, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, M=:=0, N=:=0, 
          new4(s(A,K,L,M,N),d(F,G,H,I,J)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F),d(B,G,H,I,J)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
