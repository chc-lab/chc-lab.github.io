new32(s(A),d(B)) :- new32(s(A),d(B)).
new28(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=G, T=:=0, 
          U=:=V+W, V=:=A, W=:=1, 
          new14(s(U,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new28(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=G, T=:=0, 
          U=:=V+W, V=:=A, W=:=1, 
          new14(s(U,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new28(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=G, T=:=0, 
          U=:=V-W, V=:=A, W=:=1, X=:=Y-Z, Y=:=E, Z=:=1, 
          new14(s(U,B,C,D,X,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, 
          new28(s(A,B,C,D,E,F,S,T,I),d(J,K,L,M,N,O,P,Q,R)).
new25(s(A),d(A)).
new24(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new25(s(A),d(B)).
new21(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=E, T=:=100, 
          U=:=1, new20(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new21(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=E, T=:=100, 
          U=:=0, new20(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=I, new24(s(J),d(K)).
new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=A, T=:=100, 
          U=:=1, new20(s(A,B,C,D,E,F,G,H,U),d(J,K,L,M,N,O,P,Q,R)).
new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=100, 
          new21(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new18(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new19(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new17(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=100, T=:=E, 
          new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new17(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=100, T=:=E, 
          new18(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new16(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=A, T=:=100, 
          new17(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new16(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=A, T=:=100, 
          new18(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new16(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T+1=<U, T=:=E, 
          U=:=100, new8(s(S),d(V)), 
          new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T>=U, T=:=E, 
          U=:=100, new8(s(S),d(V)), 
          new14(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new8(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new8(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new32(s(A),d(B)).
new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T+1=<U, T=:=A, 
          U=:=100, new8(s(S),d(V)), 
          new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T>=U, T=:=A, U=:=100, 
          new8(s(S),d(V)), new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new6(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, 
          new7(s(A,B,C,D,S,T,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new5(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, 
          new6(s(A,B,S,T,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new4(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, 
          new5(s(S,T,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new4(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new1 :- new2(s,d).
inv1 :- \+new1.
