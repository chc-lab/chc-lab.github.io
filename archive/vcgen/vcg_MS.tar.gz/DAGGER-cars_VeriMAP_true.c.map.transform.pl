new73(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=U-V, U=:=W-X, 
          W=:=Y*Z, Y=:=2, Z=:=C, X=:=A, V=:=E, T=:=0, A1=:=B1+C1, B1=:=A, 
          C1=:=B, D1=:=E1+F1, E1=:=E, F1=:=F, G1=:=H1+I1, H1=:=C, I1=:=D, 
          J1=:=K1+L1, K1=:=D, L1=:=1, M1=:=N1+O1, N1=:=G, O1=:=1, 
          new10(s(A1,B,G1,J1,D1,F,M1,H,I),d(J,K,L,M,N,O,P,Q,R)).
new71(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=W-X, 
          W=:=Y*Z, Y=:=2, Z=:=C, X=:=A, V=:=E, T=:=0, A1=:=B1+C1, B1=:=A, 
          C1=:=B, D1=:=E1+F1, E1=:=E, F1=:=F, G1=:=H1+I1, H1=:=C, I1=:=D, 
          J1=:=K1-L1, K1=:=D, L1=:=1, M1=:=N1+O1, N1=:=G, O1=:=1, 
          new10(s(A1,B,G1,J1,D1,F,M1,H,I),d(J,K,L,M,N,O,P,Q,R)).
new70(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=H, T=:=0, 
          new71(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new70(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=H, T=:=0, 
          new71(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new70(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=H, T=:=0, 
          new73(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new69(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new70(s(A,B,C,D,E,F,G,S,I),d(J,K,L,M,N,O,P,Q,R)).
new68(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=D, T=:=5, 
          new69(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new67(s(A),d(A)).
new62(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M-N, 
          M=:=B, N=:=F, L=:=0, new16(s(J),d(O)).
new62(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M-N, 
          M=:=B, N=:=F, L=:=0, new16(s(J),d(O)).
new56(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M+N, 
          M=:=O+P, O=:=Q-R, Q=:=B, R=:=S*T, S=:=2, T=:=D, P=:=F, N=:=U*V, 
          U=:=2, V=:=G, L=:=0, new16(s(J),d(W)).
new56(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M+N, 
          M=:=O+P, O=:=Q-R, Q=:=B, R=:=S*T, S=:=2, T=:=D, P=:=F, N=:=U*V, 
          U=:=2, V=:=G, L=:=0, new16(s(J),d(W)).
new56(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=V+W, 
          V=:=X+Y, X=:=Z-A1, Z=:=B, A1=:=B1*C1, B1=:=2, C1=:=D, Y=:=F, 
          W=:=D1*E1, D1=:=2, E1=:=G, U=:=0, new17(s(S),d(F1)), 
          new62(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new56(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=V+W, 
          V=:=X+Y, X=:=Z-A1, Z=:=B, A1=:=B1*C1, B1=:=2, C1=:=D, Y=:=F, 
          W=:=D1*E1, D1=:=2, E1=:=G, U=:=0, new17(s(S),d(F1)), 
          new62(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new50(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M+N, 
          M=:=C, N=:=O*P, O=:=5, P=:=G, L=:=75, new16(s(J),d(Q)).
new50(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M+N, 
          M=:=C, N=:=O*P, O=:=5, P=:=G, L=:=75, new16(s(J),d(Q)).
new50(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=V+W, 
          V=:=C, W=:=X*Y, X=:=5, Y=:=G, U=:=75, new17(s(S),d(Z)), 
          new56(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new50(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=V+W, 
          V=:=C, W=:=X*Y, X=:=5, Y=:=G, U=:=75, new17(s(S),d(Z)), 
          new56(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new44(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M+N, 
          M=:=D, N=:=6, L=:=0, new16(s(J),d(O)).
new44(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M+N, 
          M=:=D, N=:=6, L=:=0, new16(s(J),d(O)).
new44(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=V+W, 
          V=:=D, W=:=6, U=:=0, new17(s(S),d(X)), 
          new50(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new44(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=V+W, 
          V=:=D, W=:=6, U=:=0, new17(s(S),d(X)), 
          new50(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new38(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=F, L=:=0, 
          new16(s(J),d(M)).
new38(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=F, 
          L=:=0, new16(s(J),d(M)).
new38(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=F, U=:=0, 
          new17(s(S),d(V)), new44(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new38(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=F, 
          U=:=0, new17(s(S),d(V)), 
          new44(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new32(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K=<L, K=:=D, L=:=6, 
          new16(s(J),d(M)).
new32(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K>=L+1, K=:=D, 
          L=:=6, new16(s(J),d(M)).
new32(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T=<U, T=:=D, U=:=6, 
          new17(s(S),d(V)), new38(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new32(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T>=U+1, T=:=D, 
          U=:=6, new17(s(S),d(V)), 
          new38(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new26(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M+N, 
          M=:=O*P, O=:=5, P=:=G, N=:=75, L=:=C, new16(s(J),d(Q)).
new26(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M+N, 
          M=:=O*P, O=:=5, P=:=G, N=:=75, L=:=C, new16(s(J),d(Q)).
new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=V+W, 
          V=:=X*Y, X=:=5, Y=:=G, W=:=75, U=:=C, new17(s(S),d(Z)), 
          new32(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=V+W, 
          V=:=X*Y, X=:=5, Y=:=G, W=:=75, U=:=C, new17(s(S),d(Z)), 
          new32(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K>=L, K=:=M+N, 
          M=:=O*P, O=:=2, P=:=D, N=:=Q*R, Q=:=2, R=:=G, L=:=S+T, S=:=B, T=:=F, 
          new16(s(J),d(U)).
new20(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K+1=<L, K=:=M+N, 
          M=:=O*P, O=:=2, P=:=D, N=:=Q*R, Q=:=2, R=:=G, L=:=S+T, S=:=B, T=:=F, 
          new16(s(J),d(U)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T>=U, T=:=V+W, 
          V=:=X*Y, X=:=2, Y=:=D, W=:=Z*A1, Z=:=2, A1=:=G, U=:=B1+C1, B1=:=B, 
          C1=:=F, new17(s(S),d(D1)), 
          new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T+1=<U, T=:=V+W, 
          V=:=X*Y, X=:=2, Y=:=D, W=:=Z*A1, Z=:=2, A1=:=G, U=:=B1+C1, B1=:=B, 
          C1=:=F, new17(s(S),d(D1)), 
          new26(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new17(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new17(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new17(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new66(s(A),d(B)).
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new67(s(A),d(B)).
new15(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=1, K=<L, K=:=B, L=:=5, 
          new16(s(J),d(M)).
new15(s(A,B,C,D,E,F,G,H,I),d(A,B,C,D,E,F,G,H,I)) :- J=:=0, K>=L+1, K=:=B, 
          L=:=5, new16(s(J),d(M)).
new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=1, T=<U, T=:=B, U=:=5, 
          new17(s(S),d(V)), new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=0, T>=U+1, T=:=B, 
          U=:=5, new17(s(S),d(V)), 
          new20(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=D, 
          V=:=5, T=:=0, new68(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T+1, S=:=I, T=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S+1=<T, S=:=I, T=:=0, 
          new13(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new12(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=I, T=:=0, 
          new15(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new12(s(A,B,C,D,E,F,G,H,S),d(J,K,L,M,N,O,P,Q,R)).
new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- 
          new11(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new9(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=D, T=:=5, 
          new10(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new8(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U+V, U=:=D, V=:=5, 
          T=:=0, new9(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=T, S=:=U-V, U=:=W-X, 
          W=:=Y*Z, Y=:=2, Z=:=D, X=:=B, V=:=F, T=:=0, A1=:=0, 
          new8(s(A,B,C,D,E,F,A1,H,I),d(J,K,L,M,N,O,P,Q,R)).
new6(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=U-V, U=:=B, V=:=F, 
          T=:=0, new7(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new5(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=<T, S=:=B, T=:=5, 
          new6(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new4(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S>=T, S=:=F, T=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)) :- S=:=100, T=:=75, U=:= -50, 
          new4(s(S,B,T,D,U,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H,I),d(J,K,L,M,N,O,P,Q,R)).
new1 :- new2(s,d).
inv1 :- \+new1.
