new16(s(A),d(A)).
new13(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new16(s(A),d(B)).
new12(s(A,B,C),d(A,B,C)) :- D=:=1, E>=F+1, E=:=B, F=:=0, new13(s(D),d(G)).
new12(s(A,B,C),d(A,B,C)) :- D=:=1, E+1=<F, E=:=B, F=:=0, new13(s(D),d(G)).
new12(s(A,B,C),d(A,B,C)) :- D=:=0, E=:=F, E=:=B, F=:=0, new13(s(D),d(G)).
new10(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=J-K, J=:=A, K=:=1, 
          L=:=M-N, M=:=B, N=:=1, new9(s(I,L,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=0, new12(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- new10(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, I=:=J+K, J=:=A, K=:=1, 
          L=:=M+N, M=:=B, N=:=1, new4(s(I,L,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, I=:=J+K, J=:=A, K=:=1, 
          L=:=M+N, M=:=B, N=:=1, new4(s(I,L,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=C, H=:=0, new9(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- new6(s(A,B,G),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=0, new4(s(G,H,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
