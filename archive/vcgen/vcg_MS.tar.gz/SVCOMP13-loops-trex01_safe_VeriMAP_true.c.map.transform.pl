new51(s(A),d(A)).
new47(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, S=:=T-U, T=:=E, U=:=1, 
          new39(s(A,B,Q,D,S,F,G,R),d(I,J,K,L,M,N,O,P)).
new46(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=F, R=:=0, S=:=T-U, 
          T=:=B, U=:=A, new47(s(A,S,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new46(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=F, R=:=0, S=:=T-U, 
          T=:=B, U=:=A, new47(s(A,S,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new46(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=F, R=:=0, S=:=T-U, 
          T=:=C, U=:=A, new39(s(A,B,S,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new44(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new46(s(A,B,C,D,E,Q,R,H),d(I,J,K,L,M,N,O,P)).
new42(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=C, R=:=0, 
          new44(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new42(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=<R, Q=:=C, R=:=0, 
          new43(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new41(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=B, R=:=0, 
          new42(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new41(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=<R, Q=:=B, R=:=0, 
          new43(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new39(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new41(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new35(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new51(s(A),d(B)).
new34(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)) :- I=:=1, J>=K, J=:=E, K=:=1, 
          new35(s(I),d(L)).
new34(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)) :- I=:=0, J+1=<K, J=:=E, K=:=1, 
          new35(s(I),d(L)).
new34(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=1, R>=S, R=:=E, S=:=1, 
          new16(s(Q),d(T)), new39(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new34(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=0, R+1=<S, R=:=E, S=:=1, 
          new16(s(Q),d(T)), new39(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new32(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=E, R=:=D, S=:=T*U, 
          T=:=2, U=:=E, new31(s(A,B,C,D,S,F,G,H),d(I,J,K,L,M,N,O,P)).
new32(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=E, R=:=D, 
          new34(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new31(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new32(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new26(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, S=:=T-U, T=:=E, U=:=1, 
          new18(s(A,B,Q,D,S,F,G,R),d(I,J,K,L,M,N,O,P)).
new25(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=F, R=:=0, S=:=T-U, 
          T=:=B, U=:=A, new26(s(A,S,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new25(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=F, R=:=0, S=:=T-U, 
          T=:=B, U=:=A, new26(s(A,S,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new25(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=F, R=:=0, S=:=T-U, 
          T=:=C, U=:=A, new18(s(A,B,S,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new23(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new25(s(A,B,C,D,E,Q,R,H),d(I,J,K,L,M,N,O,P)).
new22(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)).
new21(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=C, R=:=0, 
          new23(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new21(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=<R, Q=:=C, R=:=0, 
          new22(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new20(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=B, R=:=0, 
          new21(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new20(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=<R, Q=:=B, R=:=0, 
          new22(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new20(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new16(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new16(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new30(s(A),d(B)).
new15(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=1, R>=S, R=:=E, S=:=1, 
          new16(s(Q),d(T)), new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new15(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=0, R+1=<S, R=:=E, S=:=1, 
          new16(s(Q),d(T)), new18(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=E, R=:=D, S=:=T*U, 
          T=:=2, U=:=E, new12(s(A,B,C,D,S,F,G,H),d(I,J,K,L,M,N,O,P)).
new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=E, R=:=D, 
          new15(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new12(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new13(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=1, 
          new12(s(A,B,C,D,Q,F,G,H),d(I,J,K,L,M,N,O,P)).
new9(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=1, 
          new31(s(A,B,C,D,Q,F,G,H),d(I,J,K,L,M,N,O,P)).
new8(s(A,B),d(A,B)) :- C=:=2, new9(s(C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R)).
new8(s(A,B),d(C,D)) :- E=:=2, new10(s(E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T)), 
          new11(s(A,B),d(C,D)).
new6(s(A,B),d(A,B)) :- C=:=1, new9(s(C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R)).
new6(s(A,B),d(C,D)) :- E=:=1, new10(s(E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T)), 
          new11(s(A,B),d(C,D)).
new5(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=0, new6(s(A,B),d(C,D)).
new5(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=0, new6(s(A,B),d(C,D)).
new5(s(A,B),d(C,D)) :- E=:=F, E=:=A, F=:=0, new8(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E=:=F, new5(s(E,F),d(C,D)).
new3(s(A,B),d(C,D)) :- new4(s(A,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
