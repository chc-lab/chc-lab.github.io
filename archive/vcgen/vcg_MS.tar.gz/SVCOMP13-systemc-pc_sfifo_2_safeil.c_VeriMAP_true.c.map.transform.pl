new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=1, K1=:=0, 
          new293(s(A,B,K1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=1, 
          new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=1, 
          new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=0, K1=:=0, 
          new290(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=0, 
          new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1)), 
          new285(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,R,S,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          S=:=0, R=:=0.
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=1, K1=:=0, 
          new281(s(A,B,K1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=1, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=1, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=0, K1=:=0, 
          new278(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=0, 
          new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1)), 
          new274(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=1, K1=:=0, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=1, K1=:=2, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=1, K1=:=2, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=1, K1=:=0, 
          new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=1, K1=:=2, 
          new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=1, K1=:=2, 
          new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=D, J1=:=0, K1=:=1, 
          new258(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=D, J1=:=0, 
          new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=D, J1=:=0, 
          new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new252(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=D, J1=:=0, K1=:=1, 
          new252(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=D, J1=:=0, 
          new252(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=D, J1=:=0, 
          new252(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=C, L1=:=1, M1=:=1, 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=C, L1=:=1, 
          new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=C, L1=:=1, 
          new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=D, L1=:=1, M1=:=1, 
          new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=D, L1=:=1, 
          new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=D, L1=:=1, 
          new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=S, N1=:=0, O1=:=0, 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=S, N1=:=0, O1=:=0, 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=S, N1=:=0, 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new229(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=O, L1=:=1, 
          new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new229(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=1, 
          new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new229(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=1, 
          new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new229(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,L1)).
new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,N1)), 
          new231(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,R,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, O1=:=0, 
          new226(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, O1=:=0, 
          new226(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, 
          new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new223(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=J, L1=:=1, 
          new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new223(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=J, L1=:=1, 
          new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new223(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=J, L1=:=1, 
          new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new219(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new219(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=C, L1=:=1, M1=:=1, 
          new219(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=C, L1=:=1, 
          new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=C, L1=:=1, 
          new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=D, L1=:=1, M1=:=1, 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=D, L1=:=1, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=D, L1=:=1, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=S, N1=:=0, O1=:=0, 
          new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=S, N1=:=0, O1=:=0, 
          new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=S, N1=:=0, 
          new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=O, L1=:=1, 
          new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=1, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=1, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,N1)), 
          new205(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,R,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, O1=:=0, 
          new201(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, O1=:=0, 
          new201(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, 
          new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=J, L1=:=1, 
          new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=J, L1=:=1, 
          new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=J, L1=:=1, 
          new217(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=D, J1=:=1, K1=:=2, 
          new196(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=D, J1=:=1, 
          new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=D, J1=:=1, 
          new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=D, J1=:=1, K1=:=2, 
          new190(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=D, J1=:=1, 
          new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=D, J1=:=1, 
          new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=0, K1=:=2, L1=:=1, 
          new183(s(A,B,C,D,E,F,G,H,K1,L1,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=0, 
          new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new182(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, K1=:=L1+M1, L1=:=G, M1=:=1, N1=:=0, O1=:=1, 
          new181(s(J1,N1,C,D,O1,F,K1,I1,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=1, 
          new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=1, 
          new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=1, 
          new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=0, 
          new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=0, 
          new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=0, 
          new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new135(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=R, P1=:=0, Q1=:=1, 
          new168(s(A,B,C,D,E,F,G,H,Q1,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=R, P1=:=0, Q1=:=1, 
          new168(s(A,B,C,D,E,F,G,H,Q1,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=R, P1=:=0, 
          new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=B, L1=:=1, M1=:=2, N1=:=1, O1=:=R, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,M1,N1,P,O1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=B, L1=:=1, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=B, L1=:=1, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new159(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)) :- 
          new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)) :- 
          new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=G, L1=:=L, 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=G, L1=:=L, 
          new159(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=G, L1=:=L, 
          new159(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=H, L1=:=M, 
          new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=H, L1=:=M, 
          new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=H, L1=:=M, 
          new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=A, L1=:=K1, M1=:=N1+O1, N1=:=L, O1=:=1, P1=:=1, Q1=:=1, 
          new153(s(A,P1,C,D,Q1,F,G,H,I,J,K,M1,L1,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=O, L1=:=1, M1=:=Q, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=1, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=1, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=O, L1=:=0, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=0, 
          new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=0, 
          new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,M1)).
new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2)), 
          new126(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=S, P1=:=0, Q1=:=1, 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,Q1,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=S, P1=:=0, Q1=:=1, 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,Q1,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=S, P1=:=0, 
          new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=N, P1=:=0, 
          new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=N, P1=:=0, 
          new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=N, P1=:=0, 
          new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=I, P1=:=0, 
          new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=I, P1=:=0, 
          new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=I, P1=:=0, 
          new135(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=T, P1=:=0, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=T, P1=:=0, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=T, P1=:=0, 
          new133(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,M1)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,P1)), 
          new130(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,S,O1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=0, K1=:=2, L1=:=1, 
          new122(s(A,B,C,D,E,F,G,H,K1,L1,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=0, 
          new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, K1=:=L1+M1, L1=:=G, M1=:=1, N1=:=0, O1=:=1, 
          new120(s(J1,N1,C,D,O1,F,K1,I1,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=1, 
          new116(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=1, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=1, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=0, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=0, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=0, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new78(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=R, P1=:=0, Q1=:=1, 
          new108(s(A,B,C,D,E,F,G,H,Q1,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=R, P1=:=0, Q1=:=1, 
          new108(s(A,B,C,D,E,F,G,H,Q1,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=R, P1=:=0, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=B, L1=:=1, M1=:=2, N1=:=1, O1=:=R, 
          new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,M1,N1,P,O1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=B, L1=:=1, 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=B, L1=:=1, 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=G, L1=:=L, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=G, L1=:=L, 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=G, L1=:=L, 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=H, L1=:=M, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=H, L1=:=M, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=H, L1=:=M, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=A, L1=:=K1, M1=:=N1+O1, N1=:=L, O1=:=1, P1=:=1, Q1=:=1, 
          new95(s(A,P1,C,D,Q1,F,G,H,I,J,K,M1,L1,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=O, L1=:=1, M1=:=Q, 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=1, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=1, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=O, L1=:=0, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=0, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=0, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2)), 
          new70(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new83(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=S, P1=:=0, Q1=:=1, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,Q1,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new83(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=S, P1=:=0, Q1=:=1, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,Q1,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new83(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=S, P1=:=0, 
          new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new83(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=N, P1=:=0, 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=N, P1=:=0, 
          new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=N, P1=:=0, 
          new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=I, P1=:=0, 
          new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=I, P1=:=0, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=I, P1=:=0, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=T, P1=:=0, 
          new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=T, P1=:=0, 
          new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=T, P1=:=0, 
          new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new71(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,P1)), 
          new73(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,S,O1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new71(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=N, L1=:=0, M1=:=1, 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=N, L1=:=0, M1=:=0, 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=N, L1=:=0, M1=:=0, 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, O1=:=0, 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, O1=:=0, 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, O1=:=1, 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=I, L1=:=0, M1=:=1, 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=I, L1=:=0, 
          new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=I, L1=:=0, 
          new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=N, L1=:=0, M1=:=1, 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=N, L1=:=0, M1=:=0, 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=N, L1=:=0, M1=:=0, 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, O1=:=0, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, O1=:=0, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, O1=:=1, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=I, L1=:=0, M1=:=1, 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=I, L1=:=0, 
          new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=I, L1=:=0, 
          new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=S, N1=:=0, 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=S, N1=:=0, 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=S, N1=:=0, 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,N1)), 
          new48(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,L1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,N1)), 
          new60(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1,L1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,M1,N1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,P1),d(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,N1)), 
          new43(s(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,R,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2)), 
          new40(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1,L1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,M1,N1)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1,N1),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2)), 
          new37(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2)), 
          new34(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=3, 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)), 
          new31(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1,L1,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,N1,O1,P1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=2, 
          new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,N1,O1,P1),d(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2)), 
          new28(s(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=1, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=C, J1=:=1, K1=:=2, 
          new187(s(A,B,K1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=C, J1=:=1, 
          new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=1, 
          new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=C, J1=:=1, K1=:=2, 
          new193(s(A,B,K1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=C, J1=:=1, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=1, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2)), 
          new24(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,N1)), 
          new200(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new223(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,L1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,N1)), 
          new225(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1,L1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,M1,N1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1,N1),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2)), 
          new21(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=C, J1=:=0, K1=:=1, 
          new249(s(A,B,K1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=C, J1=:=0, 
          new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=0, 
          new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=C, J1=:=0, K1=:=1, 
          new255(s(A,B,K1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=C, J1=:=0, 
          new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=0, 
          new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2)), 
          new18(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=1, K1=:=0, 
          new261(s(A,B,C,D,E,F,G,H,K1,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=1, K1=:=2, 
          new261(s(A,B,C,D,E,F,G,H,K1,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=1, K1=:=2, 
          new261(s(A,B,C,D,E,F,G,H,K1,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=1, K1=:=0, 
          new267(s(A,B,C,D,E,F,G,H,K1,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=1, K1=:=2, 
          new267(s(A,B,C,D,E,F,G,H,K1,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=1, K1=:=2, 
          new267(s(A,B,C,D,E,F,G,H,K1,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2)), 
          new15(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=E, J1=:=1, 
          new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=E, J1=:=1, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=E, J1=:=1, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=E, J1=:=1, 
          new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=E, J1=:=1, 
          new285(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=E, J1=:=1, 
          new285(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2)), 
          new12(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,R)) :- 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,J1,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,L1,M1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,R,S,T,E,F,U,H,I,V,W,X,M,N,Y,Z,Q)) :- 
          R=:=1, T=:=2, S=:=T, U=:=0, V=:=0, W=:=1, X=:=0, Y=:=0, Z=:=1.
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,R)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2)), 
          new7(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,J1)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=0, 
          K=:=0, L=:=0, M=:=0, N=:=0, O=:=0, P=:=0, Q=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
inv1 :- \+new1.
