new23(s(A),d(A)).
new17(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new17(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new17(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new22(s(A),d(B)).
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new23(s(A),d(B)).
new15(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F>=G+1, F=:=D, G=:=0, new16(s(E),d(H)).
new15(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F=<G, F=:=D, G=:=0, new16(s(E),d(H)).
new15(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J>=K+1, J=:=D, K=:=0, L=:=M+N, M=:=C, 
          N=:=1, O=:=P-Q, P=:=D, Q=:=1, new17(s(I),d(R)), 
          new13(s(A,B,L,O),d(E,F,G,H)).
new15(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=<K, J=:=D, K=:=0, L=:=M+N, M=:=C, 
          N=:=1, O=:=P-Q, P=:=D, Q=:=1, new17(s(I),d(R)), 
          new13(s(A,B,L,O),d(E,F,G,H)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=K*L, K=:=20, L=:=A, 
          new15(s(A,B,C,D),d(E,F,G,H)).
new13(s(A,B,C,D),d(E,F,G,H)) :- new14(s(A,B,C,D),d(E,F,G,H)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=K+L, K=:=M*N, M=:=6, N=:=B, 
          L=:=128, O=:=P+Q, P=:=C, Q=:=1, R=:=S-T, S=:=D, T=:=1, 
          new10(s(A,B,O,R),d(E,F,G,H)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=K+L, K=:=M*N, M=:=6, N=:=B, 
          L=:=128, O=:=0, new13(s(A,B,O,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- new11(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=K+L, K=:=M*N, M=:=6, N=:=B, 
          L=:=128, O=:=P+Q, P=:=C, Q=:=1, R=:=S+T, S=:=D, T=:=1, 
          new7(s(A,B,O,R),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=K+L, K=:=M*N, M=:=6, N=:=B, 
          L=:=128, O=:=0, new10(s(A,B,O,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- new8(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=K*L, K=:=20, L=:=A, M=:=N+O, 
          N=:=C, O=:=1, P=:=Q+R, Q=:=D, R=:=1, new4(s(A,B,M,P),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=K*L, K=:=20, L=:=A, M=:=0, 
          new7(s(A,B,M,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,B,I,J),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
