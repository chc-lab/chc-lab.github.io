new48(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=1, Q=:=0, R=:=0, 
          S=:=1, T=:=U-V, U=:=W+X, W=:=Y+Z, Y=:=A1+B1, A1=:=A, B1=:=Q, Z=:=S, 
          X=:=R, V=:=1, new7(s(T,Q,R,S,E,F,G),d(H,I,J,K,L,M,N)).
new46(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=Q+R, Q=:=C, R=:=B, P=:=1, 
          S=:=T-U, T=:=V+W, V=:=X+Y, X=:=A, Y=:=B, W=:=C, U=:=1, Z=:=A1+B1, 
          A1=:=D, B1=:=1, C1=:=0, D1=:=0, 
          new7(s(S,C1,D1,Z,E,F,G),d(H,I,J,K,L,M,N)).
new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=0, 
          new46(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=0, 
          new46(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=E, P=:=0, 
          new48(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new44(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new45(s(A,B,C,D,O,F,G),d(H,I,J,K,L,M,N)).
new42(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=1, Q=:=R+S, R=:=C, 
          S=:=D, T=:=0, U=:=V-W, V=:=A, W=:=1, X=:=Y+Z, Y=:=B, Z=:=1, 
          new7(s(U,X,Q,T,E,F,G),d(H,I,J,K,L,M,N)).
new41(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=F, P=:=0, 
          new42(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new41(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=F, P=:=0, 
          new42(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new41(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=F, P=:=0, 
          new44(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new40(s(A),d(A)).
new35(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I>=J, I=:=K+L, K=:=M+N, 
          M=:=A, N=:=B, L=:=D, J=:=1, new13(s(H),d(O)).
new35(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I+1=<J, I=:=K+L, K=:=M+N, 
          M=:=A, N=:=B, L=:=D, J=:=1, new13(s(H),d(O)).
new29(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I>=J, I=:=A, J=:=0, 
          new13(s(H),d(K)).
new29(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I+1=<J, I=:=A, J=:=0, 
          new13(s(H),d(K)).
new29(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P>=Q, P=:=A, Q=:=0, 
          new14(s(O),d(R)), new35(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new29(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P+1=<Q, P=:=A, Q=:=0, 
          new14(s(O),d(R)), new35(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new23(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I>=J, I=:=B, J=:=0, 
          new13(s(H),d(K)).
new23(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I+1=<J, I=:=B, J=:=0, 
          new13(s(H),d(K)).
new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P>=Q, P=:=B, Q=:=0, 
          new14(s(O),d(R)), new29(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P+1=<Q, P=:=B, Q=:=0, 
          new14(s(O),d(R)), new29(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I>=J, I=:=C, J=:=0, 
          new13(s(H),d(K)).
new17(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I+1=<J, I=:=C, J=:=0, 
          new13(s(H),d(K)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P>=Q, P=:=C, Q=:=0, 
          new14(s(O),d(R)), new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P+1=<Q, P=:=C, Q=:=0, 
          new14(s(O),d(R)), new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new14(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new14(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new14(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new39(s(A),d(B)).
new13(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new40(s(A),d(B)).
new12(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I>=J, I=:=D, J=:=0, 
          new13(s(H),d(K)).
new12(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I+1=<J, I=:=D, J=:=0, 
          new13(s(H),d(K)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P>=Q, P=:=D, Q=:=0, 
          new14(s(O),d(R)), new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P+1=<Q, P=:=D, Q=:=0, 
          new14(s(O),d(R)), new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new41(s(A,B,C,D,E,O,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=G, P=:=0, 
          new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=G, P=:=0, 
          new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=G, P=:=0, 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new9(s(A,B,C,D,E,F,O),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=A, P=:=1, 
          new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=B, P=:=0, 
          new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=C, P=:=0, 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=D, P=:=0, 
          new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new1 :- new2(s,d).
inv1 :- \+new1.
