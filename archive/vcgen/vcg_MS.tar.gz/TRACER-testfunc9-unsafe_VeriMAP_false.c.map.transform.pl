new27(s(A,B),d(C,D)) :- E=:=F, E=:=B, F=:=15, G=:=15, new23(s(G,B),d(C,D)).
new27(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=15, G=:=20, new23(s(G,B),d(C,D)).
new27(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=15, G=:=20, new23(s(G,B),d(C,D)).
new24(s(A,B),d(C,D)) :- E=:=F, E=:=B, F=:=5, G=:=5, new23(s(G,B),d(C,D)).
new24(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=5, new27(s(A,B),d(C,D)).
new24(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=5, new27(s(A,B),d(C,D)).
new22(s(A,B),d(C,D)) :- E=:=F, E=:=B, F=:=0, G=:=0, new23(s(G,B),d(C,D)).
new22(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, new24(s(A,B),d(C,D)).
new22(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=0, new24(s(A,B),d(C,D)).
new17(s(A,B),d(C,D)) :- E=:=F, E=:=B, F=:=15, G=:=15, new13(s(G,B),d(C,D)).
new17(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=15, G=:=20, new13(s(G,B),d(C,D)).
new17(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=15, G=:=20, new13(s(G,B),d(C,D)).
new14(s(A,B),d(C,D)) :- E=:=F, E=:=B, F=:=5, G=:=5, new13(s(G,B),d(C,D)).
new14(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=5, new17(s(A,B),d(C,D)).
new14(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=5, new17(s(A,B),d(C,D)).
new13(s(A,B),d(A,B)).
new12(s(A,B),d(C,D)) :- E=:=F, E=:=B, F=:=0, G=:=0, new13(s(G,B),d(C,D)).
new12(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, new14(s(A,B),d(C,D)).
new12(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=0, new14(s(A,B),d(C,D)).
new11(s(A),d(A)).
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new11(s(A),d(B)).
new7(s(A),d(A)) :- B=:=1, C>=D+1, C=:=A, D=:=15, new8(s(B),d(E)).
new7(s(A),d(A)) :- B=:=1, C+1=<D, C=:=A, D=:=15, new8(s(B),d(E)).
new7(s(A),d(A)) :- B=:=0, C=:=D, C=:=A, D=:=15, new8(s(B),d(E)).
new6(s(A,B),d(C,D)) :- new12(s(A,E),d(C,D)).
new5(s(A,B),d(C,D)) :- new22(s(A,E),d(C,D)).
new4(s(A),d(A)) :- new5(s(B,C),d(D,E)).
new4(s(A),d(B)) :- C=:=D, new6(s(E,F),d(D,G)), new7(s(C),d(B)).
new3(s(A),d(B)) :- new4(s(A),d(B)).
new2(s,d) :- new3(s(A),d(B)).
new1 :- new2(s,d).
inv1 :- \+new1.
