new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L+M, L=:=A, M=:=1, 
          new5(s(K,B,C,D,E),d(F,G,H,I,J)).
new16(s(A),d(A)).
new15(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new16(s(A),d(B)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=0, M=:=1, 
          new9(s(A,B,C,D,M),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=0, M=:=0, 
          new9(s(A,B,C,D,M),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=0, M=:=0, 
          new9(s(A,B,C,D,M),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=E, new15(s(F),d(G)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=M*N, M=:=B, N=:=2, O=:=1, 
          new9(s(A,B,C,D,O),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=M*N, M=:=B, N=:=2, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=M*N, M=:=B, N=:=2, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=10, M=:=N+O, N=:=D, 
          O=:=2, new17(s(A,B,C,M,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=10, 
          new17(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=A, L=:=B, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=B, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, L>=0, M=:=K, K>=0, N=:=0, O=:=1, 
          new5(s(O,M,K,N,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- new4(s(A,B,C,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
