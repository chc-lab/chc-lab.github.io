new24(s(A),d(A)).
new21(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new21(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new21(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new23(s(A),d(B)).
new20(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new24(s(A),d(B)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, Q=:=1, 
          new11(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, Q=:=0, 
          new11(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, Q=:=0, 
          new11(s(A,B,C,D,E,F,Q),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=G, new20(s(H),d(I)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=G, new21(s(O),d(P)), 
          new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, Q=:=A, 
          O=:=18446744073709551616+Q, Q+1=<0, P=:=R*S, R=:=F, F>=0, S=:=2, 
          T=:=1, new11(s(A,B,C,D,E,F,T),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, Q=:=A, O=:=Q, Q>=0, P=:=R*S, 
          R=:=F, F>=0, S=:=2, T=:=1, new11(s(A,B,C,D,E,F,T),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, Q=:=A, 
          O=:=18446744073709551616+Q, Q+1=<0, P=:=R*S, R=:=F, F>=0, S=:=2, 
          new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, Q=:=A, 
          O=:=18446744073709551616+Q, Q+1=<0, P=:=R*S, R=:=F, F>=0, S=:=2, 
          new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, Q=:=A, O=:=Q, Q>=0, 
          P=:=R*S, R=:=F, F>=0, S=:=2, new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, Q=:=A, O=:=Q, Q>=0, 
          P=:=R*S, R=:=F, F>=0, S=:=2, new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P+Q, P=:=F, F>=0, Q=:=1, 
          new10(s(A,B,C,D,E,O,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=F, F>=0, P=:=10, 
          Q=:=R+S, R=:=A, S=:=2, new8(s(Q,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=F, F>=0, P=:=10, 
          new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, P>=0, Q=:=O, O>=0, R=:=0, 
          new6(s(A,B,C,Q,O,R,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, P>=0, Q=:=O, O>=0, 
          new5(s(A,Q,O,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, 
          new4(s(O,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new1 :- new2(s,d).
inv1 :- \+new1.
