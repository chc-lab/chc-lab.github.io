new41(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=F, Q=:=R+S, 
          R=:=C, S=:=1, T=:=U+V, U=:=E, V=:=1, 
          new37(s(A,B,Q,D,T,F,G),d(H,I,J,K,L,M,N)).
new41(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=F, 
          new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P+Q, P=:=B, Q=:=1, 
          new7(s(A,O,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new37(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new41(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new34(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=C, P=:=Q+R, Q=:=F, 
          R=:=D, S=:=T+U, T=:=C, U=:=1, 
          new32(s(A,B,S,D,E,F,G),d(H,I,J,K,L,M,N)).
new34(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=C, P=:=Q+R, Q=:=F, R=:=D, 
          S=:=T+U, T=:=E, U=:=1, new30(s(A,B,C,D,S,F,G),d(H,I,J,K,L,M,N)).
new32(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new34(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new31(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=G, Q=:=0, 
          new32(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new31(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=G, 
          new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new30(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new31(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new28(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=G, Q=:=R+S, 
          R=:=E, S=:=1, new20(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new28(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=G, Q=:=0, 
          new30(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=E, P=:=F, Q=:=R-S, 
          R=:=C, S=:=1, T=:=U+V, U=:=E, V=:=1, 
          new22(s(A,B,Q,D,T,F,G),d(H,I,J,K,L,M,N)).
new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=E, P=:=F, 
          new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P+Q, P=:=B, Q=:=1, 
          new4(s(A,O,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new22(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new21(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=F, Q=:=0, 
          new22(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new21(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=F, 
          new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new28(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new19(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=5, Q=:=0, 
          new20(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new19(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=5, 
          new21(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, Q=:=0, 
          new37(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, Q=:=0, 
          new37(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new18(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, 
          new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=B, P=:=G, Q=:=D, 
          new18(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=B, P=:=G, 
          new19(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new16(s(A,B),d(A,B)).
new10(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new10(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new10(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new15(s(A,B),d(A,C)).
new9(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new16(s(A,B),d(A,C)).
new8(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=K+L, K=:=F, 
          L=:=D, new9(s(A,H),d(A,M)).
new8(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=K+L, 
          K=:=F, L=:=D, new9(s(A,H),d(A,M)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=R+S, R=:=F, 
          S=:=D, new10(s(A,O),d(A,T)), new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=R+S, 
          R=:=F, S=:=D, new10(s(A,O),d(A,T)), 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=B, P=:=F, Q=:=0, 
          new7(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=B, P=:=F, 
          new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=C, P=:=Q+R, Q=:=F, R=:=D, 
          S=:=0, new4(s(A,S,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=C, P=:=Q+R, Q=:=F, 
          R=:=D, new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
