new19(s(A,B),d(A,B)).
new10(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new10(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new10(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new18(s(A,B),d(A,C)).
new9(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new19(s(A,B),d(A,C)).
new8(s(A),d(A)) :- B=:=1, C=:=D, C=:=A, D=:=0, new9(s(A,B),d(A,E)).
new8(s(A),d(A)) :- B=:=0, C>=D+1, C=:=A, D=:=0, new9(s(A,B),d(A,E)).
new8(s(A),d(A)) :- B=:=0, C+1=<D, C=:=A, D=:=0, new9(s(A,B),d(A,E)).
new8(s(A),d(B)) :- C=:=1, D=:=E, D=:=A, E=:=0, new10(s(A,C),d(A,F)), 
          new4(s(A),d(B)).
new8(s(A),d(B)) :- C=:=0, D>=E+1, D=:=A, E=:=0, new10(s(A,C),d(A,F)), 
          new4(s(A),d(B)).
new8(s(A),d(B)) :- C=:=0, D+1=<E, D=:=A, E=:=0, new10(s(A,C),d(A,F)), 
          new4(s(A),d(B)).
new7(s(A),d(B)) :- B=:=0.
new5(s(A),d(B)) :- new6(s(A),d(B)).
new5(s(A),d(B)) :- new7(s(A),d(C)), new8(s(C),d(B)).
new4(s(A),d(B)) :- new5(s(A),d(B)).
new3(s(A),d(B)) :- new4(s(A),d(B)).
new2(s(A),d(B)) :- new3(s(A),d(B)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
