new22(s(A,B),d(A,B)).
new13(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I+1=<J, I=:=E, J=:=K+L, 
          K=:=B, L=:=1, new9(s(A,H),d(A,M)).
new13(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J, I=:=E, J=:=K+L, K=:=B, 
          L=:=1, new9(s(A,H),d(A,M)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P+1=<Q, P=:=E, Q=:=R+S, 
          R=:=B, S=:=1, T=:=U+V, U=:=E, V=:=1, new10(s(A,O),d(A,W)), 
          new4(s(A,B,C,D,T,F,G),d(H,I,J,K,L,M,N)).
new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q, P=:=E, Q=:=R+S, R=:=B, 
          S=:=1, T=:=U+V, U=:=E, V=:=1, new10(s(A,O),d(A,W)), 
          new4(s(A,B,C,D,T,F,G),d(H,I,J,K,L,M,N)).
new10(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new10(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new10(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new21(s(A,B),d(A,C)).
new9(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new22(s(A,B),d(A,C)).
new7(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=0, J=:=E, 
          new9(s(A,H),d(A,K)).
new7(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=0, J=:=E, 
          new9(s(A,H),d(A,K)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=0, Q=:=E, 
          new10(s(A,O),d(A,R)), new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=0, Q=:=E, 
          new10(s(A,O),d(A,R)), new13(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=E, P=:=G, 
          new7(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=G, 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=B, P=:=0, Q=:=0, 
          R=:=S-T, S=:=U+V, U=:=Q, V=:=W+X, W=:=B, X=:=1, T=:=1, Y=:=Q, Z=:=R, 
          A1=:=Y, new4(s(A,B,Q,R,A1,Y,Z),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=B, P=:=0, 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
