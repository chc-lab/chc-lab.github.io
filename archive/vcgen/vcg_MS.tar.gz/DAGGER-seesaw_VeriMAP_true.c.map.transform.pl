new36(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=A, N=:=9, O=:=P+Q, P=:=A, 
          Q=:=1, R=:=S+T, S=:=B, T=:=3, new5(s(O,R,C,D,E,F),d(G,H,I,J,K,L)).
new34(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=O-P, O=:=A, P=:=7, N=:=0, 
          Q=:=R+S, R=:=A, S=:=2, T=:=U+V, U=:=B, V=:=1, 
          new5(s(Q,T,C,D,E,F),d(G,H,I,J,K,L)).
new32(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=O-P, O=:=A, P=:=4, N=:=0, 
          Q=:=R+S, R=:=A, S=:=1, T=:=U+V, U=:=B, V=:=2, 
          new5(s(Q,T,C,D,E,F),d(G,H,I,J,K,L)).
new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O-P, O=:=A, P=:=5, N=:=0, 
          new34(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=0, 
          new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=0, 
          new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=C, N=:=0, 
          new32(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new28(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new29(s(A,B,M,D,E,F),d(G,H,I,J,K,L)).
new26(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=A, N=:=7, 
          new36(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=0, 
          new26(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=0, 
          new26(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=D, N=:=0, 
          new28(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new25(s(A,B,C,M,E,F),d(G,H,I,J,K,L)).
new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=A, N=:=9, O=:=P+Q, P=:=A, 
          Q=:=2, R=:=S+T, S=:=B, T=:=1, new5(s(O,R,C,D,E,F),d(G,H,I,J,K,L)).
new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=0, 
          new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=0, 
          new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=0, 
          new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new20(s(A),d(A)).
new15(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H>=I, H=:=J-K, J=:=L*M, L=:=3, 
          M=:=A, K=:=B, I=:=0, new11(s(G),d(N)).
new15(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H+1=<I, H=:=J-K, J=:=L*M, L=:=3, 
          M=:=A, K=:=B, I=:=0, new11(s(G),d(N)).
new12(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new12(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new12(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new19(s(A),d(B)).
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new20(s(A),d(B)).
new10(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H>=I, H=:=J+K, J=:=L*M, L=:= -1, 
          M=:=A, K=:=N*O, N=:=2, O=:=B, I=:=0, new11(s(G),d(P)).
new10(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H+1=<I, H=:=J+K, J=:=L*M, 
          L=:= -1, M=:=A, K=:=N*O, N=:=2, O=:=B, I=:=0, new11(s(G),d(P)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N>=O, N=:=P+Q, P=:=R*S, R=:= -1, 
          S=:=A, Q=:=T*U, T=:=2, U=:=B, O=:=0, new12(s(M),d(V)), 
          new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N+1=<O, N=:=P+Q, P=:=R*S, 
          R=:= -1, S=:=A, Q=:=T*U, T=:=2, U=:=B, O=:=0, new12(s(M),d(V)), 
          new15(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new21(s(A,B,C,D,M,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=0, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=0, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=F, N=:=0, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new7(s(A,B,C,D,E,M),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=B, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
inv1 :- \+new1.
