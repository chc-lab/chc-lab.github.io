new28(s(A),d(B)) :- new28(s(A),d(B)).
new27(s(A),d(A)).
new25(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new27(s(A),d(B)).
new22(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=B, J=:=A, K=:=L+M, L=:=C, M=:=B, 
          N=:=O*P, O=:=D, P=:=B, Q=:=R+S, R=:=B, S=:=1, 
          new23(s(A,Q,K,N),d(E,F,G,H)).
new22(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=A, 
          new23(s(A,B,C,D),d(E,F,G,H)).
new20(s(A,B,C,D),d(A,B,C,D)).
new19(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=B, J=:=A, K=:=L+M, L=:=C, M=:=B, 
          N=:=O*P, O=:=D, P=:=B, Q=:=R+S, R=:=B, S=:=1, 
          new20(s(A,Q,K,N),d(E,F,G,H)).
new19(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=A, 
          new20(s(A,B,C,D),d(E,F,G,H)).
new15(s(A,B,C,D),d(A,B,C,D)) :- E=:=5, new13(s(E,F,G,H),d(I,J,K,L)).
new15(s(A,B,C,D),d(E,F,G,H)) :- I=:=5, J=:=K, L=:=M+N, M=:=J, N=:=5, 
          new14(s(I,O,P,Q),d(R,S,K,T)), new10(s(L,B,J,D),d(E,F,G,H)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=0, K=:=1, 
          new19(s(A,I,J,K),d(E,F,G,H)).
new13(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=:=0, K=:=1, 
          new22(s(A,I,J,K),d(E,F,G,H)).
new12(s(A,B,C,D),d(A,B,C,D)) :- E=:=A, new13(s(E,F,G,H),d(I,J,K,L)).
new12(s(A,B,C,D),d(E,F,G,H)) :- I=:=A, J=:=K, L=:=M-N, M=:=J, N=:=1, 
          new14(s(I,O,P,Q),d(R,S,K,T)), new15(s(L,J,C,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F>=G+1, F=:=A, G=:=0, new25(s(E),d(H)).
new10(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F=<G, F=:=A, G=:=0, new25(s(E),d(H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new10(s(K,B,C,D),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new10(s(K,B,C,D),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=D, J=:=0, 
          new12(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- new9(s(A,B,C,I),d(E,F,G,H)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new28(s(A),d(B)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J>=K+1, J=:=A, K=:=0, new5(s(I),d(L)), 
          new7(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=<K, J=:=A, K=:=0, new5(s(I),d(L)), 
          new7(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- new4(s(A,B,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
