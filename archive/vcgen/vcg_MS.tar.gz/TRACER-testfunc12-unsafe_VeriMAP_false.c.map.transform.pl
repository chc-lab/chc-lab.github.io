new15(s(A),d(A)).
new12(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new15(s(A),d(B)).
new11(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F>=G+1, F=:=A, G=:=2, new12(s(E),d(H)).
new11(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F+1=<G, F=:=A, G=:=2, new12(s(E),d(H)).
new11(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F=:=G, F=:=A, G=:=2, new12(s(E),d(H)).
new10(s(A),d(B)) :- B=:=1.
new8(s(A,B,C,D),d(A,B,C,D)) :- new9(s(E),d(F)).
new8(s(A,B,C,D),d(E,F,G,H)) :- new10(s(I),d(J)), new11(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- new8(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=0, K=:=1, 
          new6(s(K,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=C, J=:=0, K=:=2, 
          new6(s(K,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, K=:=2, 
          new4(s(A,K,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=D, J=:=0, K=:=3, 
          new4(s(A,K,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
