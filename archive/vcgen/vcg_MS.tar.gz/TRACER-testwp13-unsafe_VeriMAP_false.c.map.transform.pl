new17(s(A),d(A)).
new11(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new11(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new16(s(A),d(B)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new17(s(A),d(B)).
new8(s(A,B),d(A,B)) :- C=:=1, D>=E, D=:=A, E=:=0, new10(s(C),d(F)).
new8(s(A,B),d(A,B)) :- C=:=0, D+1=<E, D=:=A, E=:=0, new10(s(C),d(F)).
new8(s(A,B),d(C,D)) :- E=:=1, F>=G, F=:=A, G=:=0, new11(s(E),d(H)), 
          new5(s(A,B),d(C,D)).
new8(s(A,B),d(C,D)) :- E=:=0, F+1=<G, F=:=A, G=:=0, new11(s(E),d(H)), 
          new5(s(A,B),d(C,D)).
new6(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=50, new8(s(A,B),d(C,D)).
new6(s(A,B),d(C,D)) :- E>=F, E=:=A, F=:=50, new5(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=H+I, H=:=B, I=:=1, 
          new6(s(A,G),d(C,D)).
new4(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=H-I, H=:=A, I=:=10, 
          new6(s(G,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=5, new4(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=<F, E=:=A, F=:=5, new5(s(A,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
