new22(s(A,B),d(A,B)).
new16(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new16(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new16(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new21(s(A,B),d(A,C)).
new15(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new22(s(A,B),d(A,C)).
new13(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=J+K, J=:=B, K=:=C, 
          I=:=L+M, L=:=N+O, N=:=E, O=:=D, M=:=F, new15(s(A,G),d(A,P)).
new13(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=J+K, J=:=B, K=:=C, 
          I=:=L+M, L=:=N+O, N=:=E, O=:=D, M=:=F, new15(s(A,G),d(A,P)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=P+Q, P=:=B, Q=:=C, 
          O=:=R+S, R=:=T+U, T=:=E, U=:=D, S=:=F, V=:=W+X, W=:=D, X=:=1, 
          new16(s(A,M),d(A,Y)), new10(s(A,B,C,V,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=P+Q, P=:=B, Q=:=C, 
          O=:=R+S, R=:=T+U, T=:=E, U=:=D, S=:=F, V=:=W+X, W=:=D, X=:=1, 
          new16(s(A,M),d(A,Y)), new10(s(A,B,C,V,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=O+P, O=:=E, P=:=F, 
          new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=O+P, O=:=E, P=:=F, 
          Q=:=R+S, R=:=C, S=:=1, new7(s(A,B,Q,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=E, O=:=C, 
          new10(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=E, O=:=P+Q, P=:=B, 
          Q=:=1, new4(s(A,O,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=E, O=:=0, 
          new7(s(A,B,O,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=B, N=:=E, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=F, O=:=0, 
          new4(s(A,O,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=F, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
