new29(s(A,B),d(A,B)).
new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=G, P=:=F, 
          new19(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new22(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new22(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new22(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new28(s(A,B),d(A,C)).
new21(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new29(s(A,B),d(A,C)).
new20(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I>=J, I=:=E, J=:=0, 
          new21(s(A,H),d(A,K)).
new20(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I+1=<J, I=:=E, J=:=0, 
          new21(s(A,H),d(A,K)).
new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P>=Q, P=:=E, Q=:=0, R=:=S-T, 
          S=:=E, T=:=1, U=:=V-W, V=:=B, W=:=1, X=:=Y+Z, Y=:=G, Z=:=1, 
          new22(s(A,O),d(A,A1)), new25(s(A,U,C,D,R,F,X),d(H,I,J,K,L,M,N)).
new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P+1=<Q, P=:=E, Q=:=0, 
          R=:=S-T, S=:=E, T=:=1, U=:=V-W, V=:=B, W=:=1, X=:=Y+Z, Y=:=G, Z=:=1, 
          new22(s(A,O),d(A,A1)), new25(s(A,U,C,D,R,F,X),d(H,I,J,K,L,M,N)).
new19(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new20(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, 
          new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, 
          new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, Q=:=0, R=:=B, 
          new19(s(A,B,C,D,E,R,Q),d(H,I,J,K,L,M,N)).
new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new16(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, Q=:=B, 
          R=:=S+T, S=:=B, T=:=1, U=:=V+W, V=:=E, W=:=1, 
          new11(s(A,R,C,Q,U,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, Q=:=B, 
          R=:=S+T, S=:=B, T=:=1, U=:=V+W, V=:=E, W=:=1, 
          new11(s(A,R,C,Q,U,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, 
          new15(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, 
          new11(s(A,O,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=B, P=:=C, Q=:=B, 
          new9(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=B, P=:=C, 
          new9(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, Q=:=R+S, 
          R=:=B, S=:=1, new4(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, Q=:=R+S, 
          R=:=B, S=:=1, new4(s(A,Q,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, 
          new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new5(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P=:=0, 
          new4(s(A,P,C,D,O,F,G),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
