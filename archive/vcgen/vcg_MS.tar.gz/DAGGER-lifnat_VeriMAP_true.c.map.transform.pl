new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=E, J1=:=1, K1=:=L1-M1, L1=:=E, M1=:=1, N1=:=O1+P1, 
          O1=:=Q1+R1, Q1=:=C, R1=:=D, P1=:=1, S1=:=0, T1=:=0, 
          new4(s(A,N1,S1,T1,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=A, J1=:=1, K1=:=L1-M1, L1=:=A, M1=:=1, N1=:=O1+P1, 
          O1=:=Q1+R1, Q1=:=S1+T1, S1=:=B, T1=:=C, R1=:=D, P1=:=1, U1=:=0, 
          V1=:=0, 
          new4(s(K1,N1,U1,V1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=H, J1=:=0, 
          new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=H, J1=:=0, 
          new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=H, J1=:=0, 
          new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new100(s(A,B,C,D,E,F,G,I1,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=A, J1=:=1, K1=:=L1-M1, L1=:=A, M1=:=1, N1=:=O1+P1, 
          O1=:=Q1+R1, Q1=:=S1+T1, S1=:=E, T1=:=F, R1=:=G, P1=:=1, U1=:=0, 
          V1=:=0, 
          new4(s(K1,B,C,D,N1,U1,V1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=I, J1=:=0, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=I, J1=:=0, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=I, J1=:=0, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new96(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=B, J1=:=1, K1=:=L1-M1, L1=:=B, M1=:=1, N1=:=O1+P1, 
          O1=:=Q1+R1, Q1=:=S1+T1, S1=:=E, T1=:=F, R1=:=G, P1=:=1, U1=:=0, 
          V1=:=0, 
          new4(s(A,K1,C,D,N1,U1,V1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=0, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new91(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new92(s(A,B,C,D,E,F,G,H,I,I1,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=B, J1=:=1, K1=:=L1+M1, L1=:=N1+O1, N1=:=P1+Q1, P1=:=A, 
          Q1=:=B, O1=:=C, M1=:=D, R1=:=0, S1=:=1, T1=:=0, 
          new4(s(K1,R1,S1,T1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=0, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=0, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=0, 
          new91(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new88(s(A,B,C,D,E,F,G,H,I,J,I1,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=E, J1=:=1, K1=:=L1-M1, L1=:=E, M1=:=1, N1=:=O1+P1, 
          O1=:=Q1+R1, Q1=:=S1+T1, S1=:=A, T1=:=B, R1=:=C, P1=:=D, U1=:=0, 
          V1=:=1, W1=:=0, 
          new4(s(N1,U1,V1,W1,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=0, 
          new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=0, 
          new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=0, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new83(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,I1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=E, J1=:=1, K1=:=L1+M1, L1=:=N1+O1, N1=:=P1+Q1, P1=:=A, 
          Q1=:=E, O1=:=F, M1=:=G, R1=:=0, S1=:=1, T1=:=0, 
          new4(s(K1,B,C,D,R1,S1,T1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=M, J1=:=0, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=M, J1=:=0, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=M, J1=:=0, 
          new83(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new79(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,I1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=B, J1=:=1, K1=:=L1-M1, L1=:=B, M1=:=1, N1=:=O1+P1, 
          O1=:=Q1+R1, Q1=:=S1+T1, S1=:=A, T1=:=E, R1=:=F, P1=:=G, U1=:=0, 
          V1=:=1, W1=:=0, 
          new4(s(N1,K1,C,D,U1,V1,W1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=N, J1=:=0, 
          new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=N, J1=:=0, 
          new77(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=N, J1=:=0, 
          new79(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new76(s(A,B,C,D,E,F,G,H,I,J,K,L,M,I1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=C, J1=:=1, K1=:=L1-M1, L1=:=C, M1=:=1, N1=:=O1+P1, 
          O1=:=D, P1=:=1, 
          new4(s(A,B,K1,N1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=0, 
          new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=0, 
          new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=0, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new71(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=F, J1=:=1, K1=:=L1-M1, L1=:=F, M1=:=1, N1=:=O1+P1, 
          O1=:=G, P1=:=1, 
          new4(s(A,B,C,D,E,K1,N1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=P, J1=:=0, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=P, J1=:=0, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=P, J1=:=0, 
          new71(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new67(s(A),d(A)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S>=T, S=:=U+V, U=:=W+X, W=:=Y+Z, Y=:=A1+B1, A1=:=C1+D1, 
          C1=:=E1+F1, E1=:=A, F1=:=B, D1=:=C, B1=:=D, Z=:=E, X=:=F, V=:=G, 
          T=:=1, new10(s(R),d(G1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S+1=<T, S=:=U+V, U=:=W+X, W=:=Y+Z, Y=:=A1+B1, A1=:=C1+D1, 
          C1=:=E1+F1, E1=:=A, F1=:=B, D1=:=C, B1=:=D, Z=:=E, X=:=F, V=:=G, 
          T=:=1, new10(s(R),d(G1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S>=T, S=:=F, T=:=0, new10(s(R),d(U)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S+1=<T, S=:=F, T=:=0, new10(s(R),d(U)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1>=K1, J1=:=F, K1=:=0, new11(s(I1),d(L1)), 
          new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, J1+1=<K1, J1=:=F, K1=:=0, new11(s(I1),d(L1)), 
          new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S>=T, S=:=G, T=:=0, new10(s(R),d(U)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S+1=<T, S=:=G, T=:=0, new10(s(R),d(U)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1>=K1, J1=:=G, K1=:=0, new11(s(I1),d(L1)), 
          new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, J1+1=<K1, J1=:=G, K1=:=0, new11(s(I1),d(L1)), 
          new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S>=T, S=:=E, T=:=0, new10(s(R),d(U)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S+1=<T, S=:=E, T=:=0, new10(s(R),d(U)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1>=K1, J1=:=E, K1=:=0, new11(s(I1),d(L1)), 
          new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, J1+1=<K1, J1=:=E, K1=:=0, new11(s(I1),d(L1)), 
          new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S>=T, S=:=C, T=:=0, new10(s(R),d(U)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S+1=<T, S=:=C, T=:=0, new10(s(R),d(U)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1>=K1, J1=:=C, K1=:=0, new11(s(I1),d(L1)), 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, J1+1=<K1, J1=:=C, K1=:=0, new11(s(I1),d(L1)), 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S>=T, S=:=D, T=:=0, new10(s(R),d(U)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S+1=<T, S=:=D, T=:=0, new10(s(R),d(U)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1>=K1, J1=:=D, K1=:=0, new11(s(I1),d(L1)), 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, J1+1=<K1, J1=:=D, K1=:=0, new11(s(I1),d(L1)), 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S>=T, S=:=B, T=:=0, new10(s(R),d(U)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S+1=<T, S=:=B, T=:=0, new10(s(R),d(U)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1>=K1, J1=:=B, K1=:=0, new11(s(I1),d(L1)), 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, J1+1=<K1, J1=:=B, K1=:=0, new11(s(I1),d(L1)), 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S>=T, S=:=A, T=:=0, new10(s(R),d(U)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S+1=<T, S=:=A, T=:=0, new10(s(R),d(U)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1>=K1, J1=:=A, K1=:=0, new11(s(I1),d(L1)), 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, J1+1=<K1, J1=:=A, K1=:=0, new11(s(I1),d(L1)), 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S=<T, S=:=U+V, U=:=F, V=:=G, T=:=1, new10(s(R),d(W)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S>=T+1, S=:=U+V, U=:=F, V=:=G, T=:=1, new10(s(R),d(W)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1=<K1, J1=:=L1+M1, L1=:=F, M1=:=G, K1=:=1, 
          new11(s(I1),d(N1)), 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, J1>=K1+1, J1=:=L1+M1, L1=:=F, M1=:=G, K1=:=1, 
          new11(s(I1),d(N1)), 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new11(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new11(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new66(s(A),d(B)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new67(s(A),d(B)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S=<T, S=:=U+V, U=:=C, V=:=D, T=:=1, new10(s(R),d(W)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          R=:=0, S>=T+1, S=:=U+V, U=:=C, V=:=D, T=:=1, new10(s(R),d(W)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1=<K1, J1=:=L1+M1, L1=:=C, M1=:=D, K1=:=1, 
          new11(s(I1),d(N1)), 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, J1>=K1+1, J1=:=L1+M1, L1=:=C, M1=:=D, K1=:=1, 
          new11(s(I1),d(N1)), 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=Q, J1=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=Q, J1=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=Q, J1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=A, J1=:=1, K1=:=0, L1=:=0, M1=:=0, N1=:=0, O1=:=0, 
          P1=:=0, 
          new4(s(A,K1,L1,M1,N1,O1,P1,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new2(s,d) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new1 :- new2(s,d).
inv1 :- \+new1.
