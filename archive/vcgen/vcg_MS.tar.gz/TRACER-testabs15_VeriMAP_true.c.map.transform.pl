new20(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L+M, L=:=B, M=:=1, 
          new4(s(A,K,C,D,E),d(F,G,H,I,J)).
new19(s(A),d(A)).
new10(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new10(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new18(s(A),d(B)).
new9(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new19(s(A),d(B)).
new8(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G=:=H, G=:=I+J, I=:=C, J=:=D, 
          H=:=K*L, K=:=3, L=:=A, new9(s(F),d(M)).
new8(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H+1, G=:=I+J, I=:=C, J=:=D, 
          H=:=K*L, K=:=3, L=:=A, new9(s(F),d(M)).
new8(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=I+J, I=:=C, J=:=D, 
          H=:=K*L, K=:=3, L=:=A, new9(s(F),d(M)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L=:=M, L=:=N+O, N=:=C, O=:=D, 
          M=:=P*Q, P=:=3, Q=:=A, new10(s(K),d(R)), 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=N+O, N=:=C, O=:=D, 
          M=:=P*Q, P=:=3, Q=:=A, new10(s(K),d(R)), 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=N+O, N=:=C, O=:=D, 
          M=:=P*Q, P=:=3, Q=:=A, new10(s(K),d(R)), 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          P=:=Q+R, Q=:=D, R=:=2, new20(s(A,B,M,P,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          P=:=Q+R, Q=:=D, R=:=2, new20(s(A,B,M,P,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=E, L=:=0, M=:=N+O, N=:=C, O=:=2, 
          P=:=Q+R, Q=:=D, R=:=1, new20(s(A,B,M,P,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=A, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=A, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=0, M=:=0, N=:=0, O=:=0, 
          new4(s(A,M,N,O,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=0, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
