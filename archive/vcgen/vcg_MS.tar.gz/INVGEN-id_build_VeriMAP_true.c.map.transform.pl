new23(s(A),d(A)).
new14(s(A,B,C),d(A,B,C)) :- D=:=1, E+1=<F, E=:=G-H, G=:=I-J, I=:=A, J=:=1, 
          H=:=B, F=:=A, new10(s(D),d(K)).
new14(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F, E=:=G-H, G=:=I-J, I=:=A, J=:=1, H=:=B, 
          F=:=A, new10(s(D),d(K)).
new14(s(A,B,C),d(D,E,F)) :- G=:=1, H+1=<I, H=:=J-K, J=:=L-M, L=:=A, M=:=1, 
          K=:=B, I=:=A, N=:=O+P, O=:=C, P=:=1, new11(s(G),d(Q)), 
          new6(s(A,B,N),d(D,E,F)).
new14(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I, H=:=J-K, J=:=L-M, L=:=A, M=:=1, K=:=B, 
          I=:=A, N=:=O+P, O=:=C, P=:=1, new11(s(G),d(Q)), 
          new6(s(A,B,N),d(D,E,F)).
new11(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new11(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new22(s(A),d(B)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new23(s(A),d(B)).
new8(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=0, F=:=G-H, G=:=I-J, I=:=A, J=:=1, 
          H=:=B, new10(s(D),d(K)).
new8(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=0, F=:=G-H, G=:=I-J, I=:=A, 
          J=:=1, H=:=B, new10(s(D),d(K)).
new8(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=J-K, J=:=L-M, L=:=A, M=:=1, 
          K=:=B, new11(s(G),d(N)), new14(s(A,B,C),d(D,E,F)).
new8(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=J-K, J=:=L-M, L=:=A, 
          M=:=1, K=:=B, new11(s(G),d(N)), new14(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=8, new8(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=8, I=:=J+K, J=:=B, K=:=1, 
          new4(s(A,I,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=A, I=:=0, new6(s(A,B,I),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, new4(s(A,G,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
