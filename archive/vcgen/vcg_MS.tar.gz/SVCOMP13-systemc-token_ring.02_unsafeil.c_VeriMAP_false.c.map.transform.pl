new447(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=I, J1=:=1, K1=:=0, 
          new450(s(A,B,C,D,E,K1,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new447(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=I, J1=:=1, K1=:=2, 
          new450(s(A,B,C,D,E,K1,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new447(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=I, J1=:=1, K1=:=2, 
          new450(s(A,B,C,D,E,K1,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new444(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=H, J1=:=1, K1=:=0, 
          new447(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new444(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=H, J1=:=1, K1=:=2, 
          new447(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new444(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=H, J1=:=1, K1=:=2, 
          new447(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new441(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new438(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=I, J1=:=1, K1=:=0, 
          new441(s(A,B,C,D,E,K1,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new438(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=I, J1=:=1, K1=:=2, 
          new441(s(A,B,C,D,E,K1,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new438(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=I, J1=:=1, K1=:=2, 
          new441(s(A,B,C,D,E,K1,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new435(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=H, J1=:=1, K1=:=0, 
          new438(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new435(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=H, J1=:=1, K1=:=2, 
          new438(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new435(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=H, J1=:=1, K1=:=2, 
          new438(s(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new429(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=0, K1=:=1, 
          new432(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new429(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=0, 
          new432(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new429(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=0, 
          new432(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new426(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=N, J1=:=0, K1=:=1, 
          new429(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new426(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=N, J1=:=0, 
          new429(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new426(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=N, J1=:=0, 
          new429(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new423(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=M, J1=:=0, K1=:=1, 
          new426(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new423(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=M, J1=:=0, 
          new426(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new423(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=M, J1=:=0, 
          new426(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new420(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=0, K1=:=1, 
          new423(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new420(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=0, 
          new423(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new420(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=0, 
          new423(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new417(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=0, K1=:=1, 
          new420(s(A,B,C,D,E,F,G,H,I,J,K1,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new417(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=0, 
          new420(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new417(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=0, 
          new420(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new414(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new411(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=0, K1=:=1, 
          new414(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new411(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=0, 
          new414(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new411(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=0, 
          new414(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new408(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=N, J1=:=0, K1=:=1, 
          new411(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new408(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=N, J1=:=0, 
          new411(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new408(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=N, J1=:=0, 
          new411(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new405(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=M, J1=:=0, K1=:=1, 
          new408(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new405(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=M, J1=:=0, 
          new408(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new405(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=M, J1=:=0, 
          new408(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new402(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=0, K1=:=1, 
          new405(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new402(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=0, 
          new405(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new402(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=0, 
          new405(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new399(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=0, K1=:=1, 
          new402(s(A,B,C,D,E,F,G,H,I,J,K1,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new399(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=0, 
          new402(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new399(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=0, 
          new402(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new393(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new395(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new392(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=M, L1=:=1, M1=:=1, 
          new395(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new392(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=M, L1=:=1, 
          new393(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new392(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=M, L1=:=1, 
          new393(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new386(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new388(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new385(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=N, L1=:=1, M1=:=1, 
          new388(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new385(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=N, L1=:=1, 
          new386(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new385(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=N, L1=:=1, 
          new386(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new379(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new381(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new378(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=O, L1=:=1, M1=:=1, 
          new381(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new378(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=1, 
          new379(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new378(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=1, 
          new379(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new374(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=T, P1=:=0, Q1=:=0, 
          new375(s(A,B,C,D,E,Q1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new374(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=T, P1=:=0, Q1=:=0, 
          new375(s(A,B,C,D,E,Q1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new374(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=T, P1=:=0, 
          new375(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new372(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=C, L1=:=1, 
          new378(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new372(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=C, L1=:=1, 
          new379(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new372(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=C, L1=:=1, 
          new379(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new369(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new372(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,M1)).
new369(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new334(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,P1)), 
          new374(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,S,O1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new368(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=S, P1=:=0, Q1=:=0, 
          new369(s(A,B,C,D,Q1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new368(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=S, P1=:=0, Q1=:=0, 
          new369(s(A,B,C,D,Q1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new368(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=S, P1=:=0, 
          new369(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new366(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=B, L1=:=1, 
          new385(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new366(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=B, L1=:=1, 
          new386(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new366(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=B, L1=:=1, 
          new386(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new363(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new366(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,M1)).
new363(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new329(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,P1)), 
          new368(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,O1,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new362(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=R, P1=:=0, Q1=:=0, 
          new363(s(A,B,C,Q1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new362(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=R, P1=:=0, Q1=:=0, 
          new363(s(A,B,C,Q1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new362(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=R, P1=:=0, 
          new363(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new360(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=A, L1=:=1, 
          new392(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new360(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=A, L1=:=1, 
          new393(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new360(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=A, L1=:=1, 
          new393(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new356(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new354(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new356(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=M, L1=:=1, M1=:=1, 
          new356(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=M, L1=:=1, 
          new354(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=M, L1=:=1, 
          new354(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new349(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new349(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new346(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=N, L1=:=1, M1=:=1, 
          new349(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new346(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=N, L1=:=1, 
          new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new346(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=N, L1=:=1, 
          new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new342(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new340(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new342(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new339(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=O, L1=:=1, M1=:=1, 
          new342(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new339(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=1, 
          new340(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new339(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=1, 
          new340(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new336(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)).
new335(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=T, P1=:=0, Q1=:=0, 
          new336(s(A,B,C,D,E,Q1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new335(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=T, P1=:=0, Q1=:=0, 
          new336(s(A,B,C,D,E,Q1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new335(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=T, P1=:=0, 
          new336(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new334(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=C, L1=:=1, 
          new339(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new334(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=C, L1=:=1, 
          new340(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new334(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=C, L1=:=1, 
          new340(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new331(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new334(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,P1)), 
          new335(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,S,O1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new330(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=S, P1=:=0, Q1=:=0, 
          new331(s(A,B,C,D,Q1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new330(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=S, P1=:=0, Q1=:=0, 
          new331(s(A,B,C,D,Q1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new330(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=S, P1=:=0, 
          new331(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new329(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=B, L1=:=1, 
          new346(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new329(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=B, L1=:=1, 
          new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new329(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=B, L1=:=1, 
          new347(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new326(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new329(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,P1)), 
          new330(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,O1,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new325(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=R, P1=:=0, Q1=:=0, 
          new326(s(A,B,C,Q1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new325(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=R, P1=:=0, Q1=:=0, 
          new326(s(A,B,C,Q1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new325(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=R, P1=:=0, 
          new326(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new324(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=A, L1=:=1, 
          new353(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new324(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=A, L1=:=1, 
          new354(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new324(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=A, L1=:=1, 
          new354(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new318(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=1, K1=:=2, 
          new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new318(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=1, 
          new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new318(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=1, 
          new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new315(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=N, J1=:=1, K1=:=2, 
          new318(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new315(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=N, J1=:=1, 
          new318(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new315(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=N, J1=:=1, 
          new318(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new312(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=M, J1=:=1, K1=:=2, 
          new315(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new312(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=M, J1=:=1, 
          new315(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new312(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=M, J1=:=1, 
          new315(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=1, K1=:=2, 
          new312(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=1, 
          new312(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=1, 
          new312(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new306(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=1, K1=:=2, 
          new309(s(A,B,C,D,E,F,G,H,I,J,K1,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new306(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=1, 
          new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new306(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=1, 
          new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new300(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=1, K1=:=2, 
          new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new300(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=1, 
          new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new300(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=1, 
          new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=N, J1=:=1, K1=:=2, 
          new300(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=N, J1=:=1, 
          new300(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=N, J1=:=1, 
          new300(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=M, J1=:=1, K1=:=2, 
          new297(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=M, J1=:=1, 
          new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=M, J1=:=1, 
          new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=1, K1=:=2, 
          new294(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=1, 
          new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=1, 
          new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=1, K1=:=2, 
          new291(s(A,B,C,D,E,F,G,H,I,J,K1,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=1, 
          new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=1, 
          new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new285(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new282(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)) :- 
          new285(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=5, 
          new282(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=5, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=5, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,R)) :- 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1)).
new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=2, L1=:=1, M1=:=2, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)), 
          new279(s(L1,O1,P1,M1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,K1,B2,C2,D2,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new275(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, M1=:=1, 
          new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M,M1,O,L1,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new275(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1, K1=:=R, L1=:=5, 
          new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=5, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new272(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=<L1, K1=:=R, L1=:=5, 
          new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new272(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=5, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)) :- 
          new285(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=P, L1=:=M1+N1, M1=:=Q, N1=:=2, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=P, L1=:=M1+N1, M1=:=Q, N1=:=2, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=P, L1=:=M1+N1, M1=:=Q, N1=:=2, 
          new272(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=A, L1=:=1, 
          new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=A, L1=:=1, 
          new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=A, L1=:=1, 
          new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=A, L1=:=0, 
          new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=A, L1=:=0, 
          new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=A, L1=:=0, 
          new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,R,S,T,U)) :- 
          new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,N1)).
new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2)), 
          new210(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=S, R1=:=0, S1=:=1, 
          new258(s(A,B,C,S1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=S, R1=:=0, S1=:=1, 
          new258(s(A,B,C,S1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=S, R1=:=0, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1=:=2, 
          new255(s(A,I1,C,D,J1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=2, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new254(s(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,I1,Y1,Z1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1+K1, J1=:=P, K1=:=1, L1=:=1, 
          new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,L1,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=1, 
          new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=1, 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=1, 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=0, 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=0, 
          new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new239(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,R,S,T,U)) :- 
          new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new239(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2)), 
          new213(s(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=T, R1=:=0, S1=:=1, 
          new239(s(A,B,C,D,S1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=T, R1=:=0, S1=:=1, 
          new239(s(A,B,C,D,S1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=T, R1=:=0, 
          new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new234(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1=:=2, 
          new235(s(A,B,I1,D,E,J1,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new232(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,I1,J1,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,L1,M1,N1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new232(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=2, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new234(s(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,I1,W1,X1,Y1,Z1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1+K1, J1=:=P, K1=:=1, L1=:=1, 
          new231(s(A,B,C,D,E,F,G,H,I,J,K,L,L1,N,O,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=C, J1=:=1, 
          new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=C, J1=:=1, 
          new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=1, 
          new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new234(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=C, J1=:=0, 
          new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=C, J1=:=0, 
          new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=0, 
          new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new219(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,R,S,T,U)) :- 
          new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new219(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2)), 
          new201(s(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=U, R1=:=0, S1=:=1, 
          new219(s(A,B,C,D,E,S1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=U, R1=:=0, S1=:=1, 
          new219(s(A,B,C,D,E,S1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=U, R1=:=0, 
          new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,Q1),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=F, R1=:=0, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=F, R1=:=0, 
          new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=F, R1=:=0, 
          new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Q1,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=E, R1=:=0, 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=E, R1=:=0, 
          new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=E, R1=:=0, 
          new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Q1,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=D, R1=:=0, 
          new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=D, R1=:=0, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=D, R1=:=0, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=R, R1=:=0, 
          new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=R, R1=:=0, 
          new206(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=R, R1=:=0, 
          new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,R,S,T,U)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,N1)).
new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S1),d(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,R1)), 
          new205(s(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,Q1,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=5, 
          new197(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=5, 
          new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=5, 
          new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new194(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=2, L1=:=1, M1=:=2, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)), 
          new194(s(L1,O1,P1,M1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,K1,B2,C2,D2,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, M1=:=1, 
          new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,M1,O,L1,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1, K1=:=R, L1=:=5, 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=5, 
          new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=<L1, K1=:=R, L1=:=5, 
          new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=5, 
          new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new183(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=P, L1=:=M1+N1, M1=:=Q, N1=:=2, 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new183(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=P, L1=:=M1+N1, M1=:=Q, N1=:=2, 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new183(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=P, L1=:=M1+N1, M1=:=Q, N1=:=2, 
          new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=A, L1=:=1, 
          new183(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=A, L1=:=1, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=A, L1=:=1, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=A, L1=:=0, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=A, L1=:=0, 
          new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=A, L1=:=0, 
          new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2)), 
          new131(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=S, R1=:=0, S1=:=1, 
          new175(s(A,B,C,S1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=S, R1=:=0, S1=:=1, 
          new175(s(A,B,C,S1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=S, R1=:=0, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1=:=2, 
          new172(s(A,I1,C,D,J1,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=2, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new171(s(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,I1,Y1,Z1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1+K1, J1=:=P, K1=:=1, L1=:=1, 
          new169(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,L1,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=1, 
          new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=1, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=1, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=0, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=0, 
          new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2)), 
          new134(s(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=T, R1=:=0, S1=:=1, 
          new158(s(A,B,C,D,S1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=T, R1=:=0, S1=:=1, 
          new158(s(A,B,C,D,S1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=T, R1=:=0, 
          new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=1, J1=:=2, 
          new154(s(A,B,I1,D,E,J1,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,I1,J1,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,L1,M1,N1)).
new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=2, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new153(s(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,I1,W1,X1,Y1,Z1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1+K1, J1=:=P, K1=:=1, L1=:=1, 
          new151(s(A,B,C,D,E,F,G,H,I,J,K,L,L1,N,O,I1,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=C, J1=:=1, 
          new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=C, J1=:=1, 
          new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=1, 
          new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=C, J1=:=0, 
          new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=C, J1=:=0, 
          new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=0, 
          new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2)), 
          new123(s(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=U, R1=:=0, S1=:=1, 
          new140(s(A,B,C,D,E,S1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=U, R1=:=0, S1=:=1, 
          new140(s(A,B,C,D,E,S1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=U, R1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,Q1),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=F, R1=:=0, 
          new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=F, R1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=F, R1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new133(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Q1,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=E, R1=:=0, 
          new133(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=E, R1=:=0, 
          new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=E, R1=:=0, 
          new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Q1,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=D, R1=:=0, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=D, R1=:=0, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=D, R1=:=0, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=R, R1=:=0, 
          new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=R, R1=:=0, 
          new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=R, R1=:=0, 
          new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new124(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S1),d(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,R1)), 
          new126(s(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,Q1,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new124(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=F, L1=:=0, M1=:=1, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=F, L1=:=0, M1=:=0, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=F, L1=:=0, M1=:=0, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=E, L1=:=0, M1=:=1, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=E, L1=:=0, 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=E, L1=:=0, 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=F, L1=:=0, M1=:=1, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=F, L1=:=0, M1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=F, L1=:=0, M1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=E, L1=:=0, M1=:=1, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=E, L1=:=0, 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=E, L1=:=0, 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=1, K1=:=2, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=1, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=1, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=N, J1=:=1, K1=:=2, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=N, J1=:=1, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=N, J1=:=1, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=M, J1=:=1, K1=:=2, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=M, J1=:=1, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=M, J1=:=1, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=1, K1=:=2, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=1, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=1, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=1, K1=:=2, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K1,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=1, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=1, 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=1, K1=:=2, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=1, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=1, 
          new84(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=N, J1=:=1, K1=:=2, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=N, J1=:=1, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=N, J1=:=1, 
          new81(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=M, J1=:=1, K1=:=2, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=M, J1=:=1, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=M, J1=:=1, 
          new78(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=1, K1=:=2, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=1, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=1, 
          new75(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=1, K1=:=2, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K1,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=1, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=1, 
          new72(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=1, K1=:=2, 
          new69(s(A,B,C,D,E,F,G,H,I,K1,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=1, 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=1, K1=:=2, 
          new87(s(A,B,C,D,E,F,G,H,I,K1,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=1, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=1, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new41(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1,M1,N1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,O1,P1,Q1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,P1,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new65(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,R,K,L,M,N,O,P,Q)) :- 
          R=:=1.
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, O1=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, O1=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, O1=:=1, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, O1=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, O1=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, O1=:=1, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=T, P1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=T, P1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=T, P1=:=0, 
          new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,N1)), 
          new50(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,R,S)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,L1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,N1)), 
          new56(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1,M1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,N1,O1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1,R1),d(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,P1)), 
          new45(s(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,R,S,O1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new62(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=S, P1=:=0, Q1=:=4, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=S, P1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=S, P1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=D, L1=:=0, M1=:=1, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=D, L1=:=0, 
          new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=D, L1=:=0, 
          new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=D, L1=:=0, M1=:=1, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=D, L1=:=0, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=D, L1=:=0, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,M1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,P1)), 
          new39(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,O1,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new36(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1,M1,N1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,O1,P1,Q1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,P1,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new33(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new30(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=3, 
          new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1,M1,N1,O1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,P1,Q1,R1,S1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=2, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,P1,Q1,R1,S1),d(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2)), 
          new26(s(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=1, K1=:=2, 
          new288(s(A,B,C,D,E,F,G,H,I,K1,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=1, 
          new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=1, 
          new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=1, K1=:=2, 
          new306(s(A,B,C,D,E,F,G,H,I,K1,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=1, 
          new306(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=1, 
          new306(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new22(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new324(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,P1)), 
          new325(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new360(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,M1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, 
          new324(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,P1)), 
          new362(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,L1,M1,N1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,O1,P1,Q1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,P1,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2)), 
          new19(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=0, K1=:=1, 
          new399(s(A,B,C,D,E,F,G,H,I,K1,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=0, 
          new399(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=0, 
          new399(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=J, J1=:=0, K1=:=1, 
          new417(s(A,B,C,D,E,F,G,H,I,K1,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=J, J1=:=0, 
          new417(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=J, J1=:=0, 
          new417(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new16(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=G, J1=:=1, K1=:=0, 
          new435(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=G, J1=:=1, K1=:=2, 
          new435(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=G, J1=:=1, K1=:=2, 
          new435(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=G, J1=:=1, K1=:=0, 
          new444(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=G, J1=:=1, K1=:=2, 
          new444(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=G, J1=:=1, K1=:=2, 
          new444(s(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,R,S,T)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new13(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,R)) :- 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,J1,K1,L1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,M1,N1,O1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,R,S,T,J,K,L,M,N,O,P,Q)) :- 
          R=:=1, S=:=1, T=:=1.
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,R)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2)), 
          new7(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,J1)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=2, 
          K=:=2, L=:=2, M=:=2, N=:=2, O=:=2, P=:=0, Q=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
inv1 :- \+new1.
