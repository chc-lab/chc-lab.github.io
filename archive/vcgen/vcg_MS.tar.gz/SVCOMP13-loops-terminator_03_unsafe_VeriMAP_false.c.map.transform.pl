new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=100, M=:=N+O, N=:=A, 
          O=:=C, new7(s(M,B,C,D,E),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=100, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new16(s(A),d(A)).
new15(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new16(s(A),d(B)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=100, M=:=1, 
          new9(s(A,B,C,D,M),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=100, M=:=0, 
          new9(s(A,B,C,D,M),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=0, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=0, M=:=0, 
          new9(s(A,B,C,D,M),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=E, new15(s(F),d(G)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=C, L=:=0, M=:=1, 
          new9(s(A,B,C,D,M),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=C, L=:=0, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- new17(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=C, L=:=0, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=C, L=:=0, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, new6(s(A,B,K,L,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, new5(s(K,L,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- new4(s(A,B,C,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
