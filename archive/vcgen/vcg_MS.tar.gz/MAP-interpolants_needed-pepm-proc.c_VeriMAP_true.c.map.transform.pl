new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=4, M=:=N+O, N=:=A, O=:=1, 
          P=:=Q+R, Q=:=B, R=:=3, new4(s(M,P,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=4, 
          new4(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=C, L=:=0, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=0, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=C, L=:=0, 
          new4(s(A,B,C,D,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- new14(s(A,B,K,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, P=:=Q+R, Q=:=B, R=:=2, new4(s(M,P,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=0, M=:=N+O, N=:=A, 
          O=:=1, P=:=Q+R, Q=:=B, R=:=2, new4(s(M,P,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=D, L=:=0, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(A,B,C,D,E)) :- F+1=<G, F=:=H*I, H=:=3, I=:=A, G=:=B.
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- new10(s(A,B,C,K,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=E, L=:=0, 
          new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- new6(s(A,B,C,D,K),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, 
          new4(s(K,L,C,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
