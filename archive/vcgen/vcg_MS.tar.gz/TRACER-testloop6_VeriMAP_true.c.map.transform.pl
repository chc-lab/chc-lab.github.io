new25(s(A),d(B)) :- new25(s(A),d(B)).
new19(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new19(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new19(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new24(s(A),d(B)).
new17(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H, G=:=C, H=:=0, new12(s(F),d(I)).
new17(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=C, H=:=0, 
          new12(s(F),d(I)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M, L=:=C, M=:=0, N=:=O+P, O=:=A, 
          P=:=1, new19(s(K),d(Q)), new7(s(N,B,C,D,E),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=C, M=:=0, N=:=O+P, 
          O=:=A, P=:=1, new19(s(K),d(Q)), new7(s(N,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- new17(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A),d(A)).
new12(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new14(s(A),d(B)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H, G=:=E, H=:=0, new12(s(F),d(I)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=E, H=:=0, 
          new12(s(F),d(I)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=D, L=:=0, M=:=B, 
          new15(s(A,M,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=D, L=:=0, M=:=N+O, N=:=B, O=:=1, 
          new15(s(A,M,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=10, 
          new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=10, 
          new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new25(s(A),d(B)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M, L=:=C, M=:=0, N=:=0, 
          new5(s(K),d(O)), new7(s(N,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=C, M=:=0, N=:=0, 
          new5(s(K),d(O)), new7(s(N,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=1, 
          new4(s(A,K,C,D,L),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
