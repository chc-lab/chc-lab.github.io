new33(s(A,B,C),d(D,E,F)) :- G=:=3, new4(s(A,G,C),d(D,E,F)).
new29(s(A,B,C),d(D,E,F)) :- G=:=4, new4(s(A,G,C),d(D,E,F)).
new28(s(A),d(A)).
new19(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new19(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new19(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new27(s(A),d(B)).
new18(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new28(s(A),d(B)).
new15(s(A,B,C),d(A,B,C)) :- D=:=1, E>=F+1, E=:=A, F=:=3, new18(s(D),d(G)).
new15(s(A,B,C),d(A,B,C)) :- D=:=1, E+1=<F, E=:=A, F=:=3, new18(s(D),d(G)).
new15(s(A,B,C),d(A,B,C)) :- D=:=0, E=:=F, E=:=A, F=:=3, new18(s(D),d(G)).
new15(s(A,B,C),d(D,E,F)) :- G=:=1, H>=I+1, H=:=A, I=:=3, J=:=5, 
          new19(s(G),d(K)), new4(s(A,J,C),d(D,E,F)).
new15(s(A,B,C),d(D,E,F)) :- G=:=1, H+1=<I, H=:=A, I=:=3, J=:=5, 
          new19(s(G),d(K)), new4(s(A,J,C),d(D,E,F)).
new15(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=I, H=:=A, I=:=3, J=:=5, 
          new19(s(G),d(K)), new4(s(A,J,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=4, new15(s(A,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=4, new4(s(A,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=4, new4(s(A,B,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=1, I=:=2, 
          new29(s(I,B,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=1, new29(s(A,B,C),d(D,E,F)).
new12(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=1, new29(s(A,B,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=3, new12(s(A,B,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=3, new13(s(A,B,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=3, new13(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=0, I=:=1, new33(s(I,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, new33(s(A,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, new33(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=2, new9(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=2, new10(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=2, new10(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new7(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new7(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- new6(s(A,B,G),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=2, new4(s(G,H,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
