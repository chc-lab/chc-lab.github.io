new43(s(A),d(B)) :- new43(s(A),d(B)).
new30(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G>=H+1, G=:=B, H=:=0, 
          new13(s(F),d(I)).
new30(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G+1=<H, G=:=B, H=:=0, 
          new13(s(F),d(I)).
new30(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G=:=H, G=:=B, H=:=0, 
          new13(s(F),d(I)).
new30(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M+1, L=:=B, M=:=0, N=:=O+P, 
          O=:=A, P=:=1, new18(s(K),d(Q)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new30(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L+1=<M, L=:=B, M=:=0, N=:=O+P, 
          O=:=A, P=:=1, new18(s(K),d(Q)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new30(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=M, L=:=B, M=:=0, N=:=O+P, O=:=A, 
          P=:=1, new18(s(K),d(Q)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new26(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M+1, L=:=C, M=:=0, N=:=O+P, 
          O=:=B, P=:=C, new6(s(K),d(Q)), new30(s(A,N,C,D,E),d(F,G,H,I,J)).
new26(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L+1=<M, L=:=C, M=:=0, N=:=O+P, 
          O=:=B, P=:=C, new6(s(K),d(Q)), new30(s(A,N,C,D,E),d(F,G,H,I,J)).
new26(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=M, L=:=C, M=:=0, N=:=O+P, O=:=B, 
          P=:=C, new6(s(K),d(Q)), new30(s(A,N,C,D,E),d(F,G,H,I,J)).
new23(s(A,B,C,D,E),d(F,G,H,I,J)) :- new26(s(A,B,K,D,E),d(F,G,H,I,J)).
new18(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new18(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new18(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new42(s(A),d(B)).
new16(s(A),d(A)).
new13(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new16(s(A),d(B)).
new12(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G=:=H, G=:=B, H=:=0, 
          new13(s(F),d(I)).
new12(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H+1, G=:=B, H=:=0, 
          new13(s(F),d(I)).
new12(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=B, H=:=0, 
          new13(s(F),d(I)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G=:=H, G=:=B, H=:=0, 
          new13(s(F),d(I)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H+1, G=:=B, H=:=0, 
          new13(s(F),d(I)).
new11(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=B, H=:=0, 
          new13(s(F),d(I)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L=:=M, L=:=B, M=:=0, 
          new18(s(K),d(N)), new23(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=B, M=:=0, 
          new18(s(K),d(N)), new23(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=B, M=:=0, 
          new18(s(K),d(N)), new23(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=A, L=:=D, M=:=N-O, N=:=B, 
          O=:=C, new11(s(A,M,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=A, L=:=D, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new6(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new6(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new43(s(A),d(B)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M+1, L=:=D, M=:=0, N=:=0, 
          new6(s(K),d(O)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=<M, L=:=D, M=:=0, N=:=0, 
          new6(s(K),d(O)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, new5(s(A,B,C,K,L),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, M=:=0, 
          new4(s(K,L,M,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
