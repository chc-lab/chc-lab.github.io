new9(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=100, new8(s(A,B),d(C,D)).
new8(s(A,B),d(A,B)).
new7(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=100, new8(s(A,B),d(C,D)).
new7(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=100, new9(s(A,B),d(C,D)).
new6(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=50, G=:=H+I, H=:=A, I=:=1, 
          new4(s(G,B),d(C,D)).
new6(s(A,B),d(C,D)) :- E>=F, E=:=A, F=:=50, G=:=H+I, H=:=A, I=:=1, J=:=K+L, 
          K=:=B, L=:=1, new4(s(G,J),d(C,D)).
new5(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=100, new6(s(A,B),d(C,D)).
new5(s(A,B),d(C,D)) :- E>=F, E=:=A, F=:=100, new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- new5(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=:=0, F=:=50, new4(s(E,F),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
