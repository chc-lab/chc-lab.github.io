new38(s(A),d(B)) :- new38(s(A),d(B)).
new35(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:= -1, L=:=D, 
          new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new35(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:= -1, L=:=D, 
          new28(s(A,B,C,D,E),d(F,G,H,I,J)).
new33(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=A, 
          new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new33(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=A, 
          new35(s(A,B,C,D,E),d(F,G,H,I,J)).
new31(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:= -1, L=:=B, 
          new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new31(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:= -1, L=:=B, 
          new33(s(A,B,C,D,E),d(F,G,H,I,J)).
new28(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L+M, L=:=C, M=:=1, 
          new10(s(A,B,K,D,E),d(F,G,H,I,J)).
new26(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=B, L=:=A, 
          new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new26(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=A, 
          new31(s(A,B,C,D,E),d(F,G,H,I,J)).
new23(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=D, 
          new26(s(A,B,C,D,E),d(F,G,H,I,J)).
new23(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=D, 
          new26(s(A,B,C,D,E),d(F,G,H,I,J)).
new23(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=B, L=:=D, 
          new28(s(A,B,C,D,E),d(F,G,H,I,J)).
new22(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, M=:=C, 
          new23(s(A,B,C,M,E),d(F,G,H,I,J)).
new22(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=E, L=:=0, M=:=C, 
          new23(s(A,B,C,M,E),d(F,G,H,I,J)).
new22(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, K=:=E, L=:=0, 
          new23(s(A,B,C,D,E),d(F,G,H,I,J)).
new21(s(A,B,C,D,E),d(F,G,H,I,J)) :- new22(s(A,B,C,D,K),d(F,G,H,I,J)).
new19(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:= -1, L=:=D, 
          new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new19(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:= -1, L=:=D, 
          new21(s(A,B,C,D,E),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=A, 
          new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new17(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=A, 
          new19(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:= -1, L=:=C, 
          new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new15(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:= -1, L=:=C, 
          new17(s(A,B,C,D,E),d(F,G,H,I,J)).
new14(s(A,B,C,D,E),d(A,B,C,D,E)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=A, 
          new14(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=A, 
          new15(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=C, L=:=A, 
          new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new11(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=C, L=:=A, M=:=N+O, N=:=B, O=:=1, 
          new7(s(A,M,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- new11(s(A,B,C,D,E),d(F,G,H,I,J)).
new9(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=B, L=:=M-N, M=:=A, N=:=1, O=:=B, 
          P=:=Q+R, Q=:=B, R=:=1, new10(s(A,B,P,O,E),d(F,G,H,I,J)).
new7(s(A,B,C,D,E),d(F,G,H,I,J)) :- new9(s(A,B,C,D,E),d(F,G,H,I,J)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new38(s(A),d(B)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M, L=:=A, M=:=0, new5(s(K),d(N)), 
          new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=A, M=:=0, 
          new5(s(K),d(N)), new7(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, M=:=0, 
          new4(s(A,K,L,M,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
