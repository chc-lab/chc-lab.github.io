new10(s(A),d(A)).
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new10(s(A),d(B)).
new7(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=D, G=:=2, new8(s(E),d(H)).
new7(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=D, G=:=2, new8(s(E),d(H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=C, K=:=L+M, L=:=B, M=:=1, 
          new4(s(A,K,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=B, J=:=C, new7(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, K=:=1, 
          new4(s(A,B,C,K),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=A, J=:=0, K=:=2, 
          new4(s(A,B,C,K),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
