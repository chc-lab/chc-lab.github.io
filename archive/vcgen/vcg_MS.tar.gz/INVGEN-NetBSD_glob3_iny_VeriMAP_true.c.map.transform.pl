new44(s(A,B),d(A,B)).
new38(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=A, V=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new38(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=A, V=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new38(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=0, 
          new24(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new32(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=1, L=<M, L=:=J, 
          M=:=E, new10(s(A,K),d(A,N)).
new32(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=J, 
          M=:=E, new10(s(A,K),d(A,N)).
new32(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=1, V=<W, V=:=J, 
          W=:=E, X=:=Y+Z, Y=:=J, Z=:=1, new11(s(A,U),d(A,A1)), 
          new38(s(A,B,C,D,E,F,G,H,I,X),d(K,L,M,N,O,P,Q,R,S,T)).
new32(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, V>=W+1, V=:=J, 
          W=:=E, X=:=Y+Z, Y=:=J, Z=:=1, new11(s(A,U),d(A,A1)), 
          new38(s(A,B,C,D,E,F,G,H,I,X),d(K,L,M,N,O,P,Q,R,S,T)).
new27(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=1, L=<M, L=:=0, 
          M=:=J, new10(s(A,K),d(A,N)).
new27(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=0, 
          M=:=J, new10(s(A,K),d(A,N)).
new27(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=1, V=<W, V=:=0, 
          W=:=J, new11(s(A,U),d(A,X)), 
          new32(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new27(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, V>=W+1, V=:=0, 
          W=:=J, new11(s(A,U),d(A,X)), 
          new32(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new25(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=J, V=:=E, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new25(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=<V, U=:=J, V=:=E, 
          new27(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new24(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- 
          new25(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new20(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=A, V=:=0, 
          new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new20(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=A, V=:=0, 
          new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new20(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=0, 
          W=:=0, new24(s(A,B,C,D,E,F,G,H,I,W),d(K,L,M,N,O,P,Q,R,S,T)).
new14(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=1, L=<M, L=:=C, 
          M=:=E, new10(s(A,K),d(A,N)).
new14(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=C, 
          M=:=E, new10(s(A,K),d(A,N)).
new14(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=1, V=<W, V=:=C, 
          W=:=E, new11(s(A,U),d(A,X)), 
          new20(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new14(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, V>=W+1, V=:=C, 
          W=:=E, new11(s(A,U),d(A,X)), 
          new20(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new11(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new11(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new11(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new43(s(A,B),d(A,C)).
new10(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new44(s(A,B),d(A,C)).
new7(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=1, L=<M, L=:=0, 
          M=:=C, new10(s(A,K),d(A,N)).
new7(s(A,B,C,D,E,F,G,H,I,J),d(A,B,C,D,E,F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=0, 
          M=:=C, new10(s(A,K),d(A,N)).
new7(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=1, V=<W, V=:=0, 
          W=:=C, new11(s(A,U),d(A,X)), 
          new14(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new7(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=0, V>=W+1, V=:=0, 
          W=:=C, new11(s(A,U),d(A,X)), 
          new14(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new6(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=A, V=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new6(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U+1=<V, U=:=A, V=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new6(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=:=V, U=:=A, V=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new4(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new3(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U>=V+1, U=:=E, V=:=0, 
          W=:=0, X=:=0, Y=:=E, Z=:=0, A1=:=0, B1=:=E, C1=:=0, 
          new4(s(A,W,X,Y,E,C1,Z,A1,B1,J),d(K,L,M,N,O,P,Q,R,S,T)).
new3(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)) :- U=<V, U=:=E, V=:=0, 
          new5(s(A,B,C,D,E,F,G,H,I,J),d(K,L,M,N,O,P,Q,R,S,T)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H,I,J,K),d(B,L,M,N,O,P,Q,R,S,T)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
