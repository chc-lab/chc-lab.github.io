new35(s(A),d(A)).
new31(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new30(s(I,B,C),d(D,E,F)).
new31(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=J+K, J=:=B, K=:=1, 
          new4(s(A,I,C),d(D,E,F)).
new30(s(A,B,C),d(D,E,F)) :- new31(s(A,B,C),d(D,E,F)).
new28(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new27(s(I,B,C),d(D,E,F)).
new28(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new30(s(I,B,C),d(D,E,F)).
new27(s(A,B,C),d(D,E,F)) :- new28(s(A,B,C),d(D,E,F)).
new25(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new24(s(I,B,C),d(D,E,F)).
new25(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new27(s(I,B,C),d(D,E,F)).
new24(s(A,B,C),d(D,E,F)) :- new25(s(A,B,C),d(D,E,F)).
new22(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new21(s(I,B,C),d(D,E,F)).
new22(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new24(s(I,B,C),d(D,E,F)).
new21(s(A,B,C),d(D,E,F)) :- new22(s(A,B,C),d(D,E,F)).
new19(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new18(s(I,B,C),d(D,E,F)).
new19(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new21(s(I,B,C),d(D,E,F)).
new18(s(A,B,C),d(D,E,F)) :- new19(s(A,B,C),d(D,E,F)).
new16(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new15(s(I,B,C),d(D,E,F)).
new16(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new18(s(I,B,C),d(D,E,F)).
new15(s(A,B,C),d(D,E,F)) :- new16(s(A,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=C, I=:=J+K, J=:=A, K=:=1, 
          new11(s(I,B,C),d(D,E,F)).
new13(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=C, I=:=1, new15(s(I,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- new13(s(A,B,C),d(D,E,F)).
new8(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new8(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new34(s(A),d(B)).
new7(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new35(s(A),d(B)).
new6(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=1, F=:=B, new7(s(D),d(G)).
new6(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=1, F=:=B, new7(s(D),d(G)).
new6(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=B, J=:=1, new8(s(G),d(K)), 
          new11(s(J,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=B, J=:=1, new8(s(G),d(K)), 
          new11(s(J,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=C, new6(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=1, new4(s(A,G,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
