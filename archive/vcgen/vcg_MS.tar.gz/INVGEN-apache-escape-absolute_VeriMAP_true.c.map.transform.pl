new155(s(A),d(A)).
new146(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new146(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new146(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=E, P=:=Q+R, 
          Q=:=E, R=:=1, new16(s(M),d(S)), new40(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new146(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=E, P=:=Q+R, 
          Q=:=E, R=:=1, new16(s(M),d(S)), new40(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new141(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new141(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new141(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new146(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new141(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new146(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new131(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new131(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new131(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=E, 
          new16(s(M),d(P)), new113(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new131(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=E, 
          new16(s(M),d(P)), new113(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new125(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new125(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new125(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new131(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new125(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new131(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new119(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=F, 
          new15(s(G),d(J)).
new119(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=F, 
          new15(s(G),d(J)).
new119(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=F, 
          new16(s(M),d(P)), new125(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new119(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=F, 
          new16(s(M),d(P)), new125(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new113(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N+O, N=:=E, O=:=1, 
          new90(s(A,B,C,D,M,F),d(G,H,I,J,K,L)).
new111(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=F, I=:=D, 
          new15(s(G),d(J)).
new111(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=F, I=:=D, 
          new15(s(G),d(J)).
new111(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=F, O=:=D, 
          new16(s(M),d(P)), new119(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new111(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=F, O=:=D, 
          new16(s(M),d(P)), new119(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new109(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=P+Q, P=:=F, 
          Q=:=1, new111(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new109(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=P+Q, P=:=F, 
          Q=:=1, new111(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new109(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new113(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new103(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new103(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new103(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=E, 
          new16(s(M),d(P)), new109(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new103(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=E, 
          new16(s(M),d(P)), new109(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new97(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new97(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new97(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new103(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new97(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new103(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new95(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new93(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=F, N=:=O-P, O=:=D, P=:=1, 
          new97(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new93(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=F, N=:=O-P, O=:=D, P=:=1, 
          new95(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new92(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new93(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new92(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new93(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new92(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new95(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new90(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new92(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new84(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new84(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new84(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=E, 
          new16(s(M),d(P)), new90(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new84(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=E, 
          new16(s(M),d(P)), new90(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new77(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new77(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new77(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new84(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new77(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new84(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new75(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=0, 
          new77(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new75(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=0, 
          new77(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new75(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=O+P, O=:=E, P=:=1, N=:=Q-R, 
          Q=:=C, R=:=1, new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=O+P, O=:=E, P=:=1, N=:=Q-R, 
          Q=:=C, R=:=1, S=:=T+U, T=:=E, U=:=1, V=:=S, 
          new75(s(A,V,C,D,S,F),d(G,H,I,J,K,L)).
new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O+P, O=:=E, P=:=1, N=:=Q-R, 
          Q=:=C, R=:=1, S=:=T+U, T=:=E, U=:=1, V=:=S, 
          new75(s(A,V,C,D,S,F),d(G,H,I,J,K,L)).
new66(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=J+K, J=:=E, 
          K=:=1, new15(s(G),d(L)).
new66(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=J+K, J=:=E, 
          K=:=1, new15(s(G),d(L)).
new66(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=P+Q, P=:=E, 
          Q=:=1, new16(s(M),d(R)), new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new66(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=P+Q, P=:=E, 
          Q=:=1, new16(s(M),d(R)), new72(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new60(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=J+K, J=:=E, K=:=1, 
          I=:=C, new15(s(G),d(L)).
new60(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=J+K, J=:=E, K=:=1, 
          I=:=C, new15(s(G),d(L)).
new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=P+Q, P=:=E, Q=:=1, 
          O=:=C, new16(s(M),d(R)), new66(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=P+Q, P=:=E, Q=:=1, 
          O=:=C, new16(s(M),d(R)), new66(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new60(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new51(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=E, 
          new16(s(M),d(P)), new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=E, 
          new16(s(M),d(P)), new57(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new46(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new46(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new46(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new46(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new51(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new46(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new141(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new43(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=E, N=:=O-P, O=:=C, P=:=1, 
          new45(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new40(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new42(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new34(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new34(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=E, 
          new15(s(G),d(J)).
new34(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=E, 
          new16(s(M),d(P)), new40(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new34(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=E, 
          new16(s(M),d(P)), new40(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new27(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new27(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=E, I=:=C, 
          new15(s(G),d(J)).
new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new34(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=E, O=:=C, 
          new16(s(M),d(P)), new34(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new19(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=J-K, J=:=E, 
          K=:=1, new15(s(G),d(L)).
new19(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=J-K, J=:=E, 
          K=:=1, new15(s(G),d(L)).
new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=P-Q, P=:=E, 
          Q=:=1, new16(s(M),d(R)), new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=P-Q, P=:=E, 
          Q=:=1, new16(s(M),d(R)), new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new16(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new16(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new154(s(A),d(B)).
new15(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new155(s(A),d(B)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=J-K, J=:=E, K=:=1, 
          I=:=C, new15(s(G),d(L)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=J-K, J=:=E, K=:=1, 
          I=:=C, new15(s(G),d(L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=P-Q, P=:=E, Q=:=1, 
          O=:=C, new16(s(M),d(R)), new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=P-Q, P=:=E, Q=:=1, 
          O=:=C, new16(s(M),d(R)), new19(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O-P, O=:=C, P=:=1, N=:=B, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O-P, O=:=C, P=:=1, N=:=B, 
          Q=:=B, new14(s(A,B,C,D,Q,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=B, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=B, N=:=0, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=0, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=B, N=:=0, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=0, 
          new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=0, 
          new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=C, N=:=0, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
inv1 :- \+new1.
