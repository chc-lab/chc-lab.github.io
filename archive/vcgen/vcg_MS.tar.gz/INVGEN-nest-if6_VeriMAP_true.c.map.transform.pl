new55(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=D, B1=:=C, C1=:=D1+E1, D1=:=D, E1=:=1, 
          new51(s(A,B,C,C1,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new55(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=D, B1=:=C, 
          new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1+C1, 
          B1=:=E, C1=:=1, 
          new8(s(A,B,C,D,A1,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new55(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=0, C1=:=F, 
          new51(s(A,B,C,C1,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=0, C1=:=F, 
          new51(s(A,B,C,C1,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=0, 
          new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1+C1, 
          B1=:=M, C1=:=L, D1=:=E1+F1, E1=:=I, F1=:=1, 
          new33(s(A,B,C,D,E,F,G,H,D1,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=0, C1=:=I, 
          new46(s(A,B,C,D,E,F,G,H,I,C1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=0, C1=:=I, 
          new46(s(A,B,C,D,E,F,G,H,I,C1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=C1-D1, C1=:=C, D1=:=E, 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=I, B1=:=C1-D1, C1=:=C, D1=:=E, 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1+C1, 
          B1=:=I, C1=:=1, 
          new35(s(A,B,C,D,E,F,G,H,A1,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=0, C1=:=I, 
          new39(s(A,B,C,D,E,F,G,H,I,C1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=0, C1=:=I, 
          new39(s(A,B,C,D,E,F,G,H,I,C1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=0, 
          new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=C1-D1, C1=:=C, D1=:=E, 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=I, B1=:=C1-D1, C1=:=C, D1=:=E, 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=L, B1=:=1, C1=:=1, D1=:=E1+F1, E1=:=C1, F1=:=L, G1=:=1, 
          new33(s(A,B,C,D,E,F,G,H,G1,J,K,L,D1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=L, B1=:=1, C1=:=1, D1=:=E1+F1, E1=:=C1, F1=:=L, G1=:=1, 
          new33(s(A,B,C,D,E,F,G,H,G1,J,K,L,D1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=L, B1=:=1, C1=:=0, D1=:=1, 
          new35(s(A,B,C,D,E,F,G,H,D1,C1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, E1=:=0, 
          new28(s(A,B,C,D,E,F,G,H,I,E1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, 
          new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, 
          new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1+C1, 
          B1=:=J, C1=:=E, 
          new50(s(A,B,C,D,E,F,A1,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, E1=:= -1, 
          new28(s(A,B,C,D,E,F,G,H,I,E1,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=C1-D1, C1=:=C, D1=:=E, B1=:=1, 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=E, B1=:=H, C1=:=D1+E1, D1=:=E, E1=:=1, F1=:=E, G1=:=1, 
          new26(s(A,B,C,D,E,C1,G,H,I,J,F1,G1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=E, B1=:=H, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new24(s(A,B),d(A,B)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)) :- N=:=1, 
          O+1=<P, O=:=C, P=:=B, new11(s(A,N),d(A,Q)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)) :- N=:=0, 
          O>=P, O=:=C, P=:=B, new11(s(A,N),d(A,Q)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=1, 
          B1+1=<C1, B1=:=C, C1=:=B, new12(s(A,A1),d(A,D1)), 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          B1>=C1, B1=:=C, C1=:=B, new12(s(A,A1),d(A,D1)), 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new12(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new12(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new12(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new23(s(A,B),d(A,C)).
new11(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new24(s(A,B),d(A,C)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)) :- N=:=1, 
          O=<P, O=:=0, P=:=C, new11(s(A,N),d(A,Q)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)) :- N=:=0, 
          O>=P+1, O=:=0, P=:=C, new11(s(A,N),d(A,Q)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=1, 
          B1=<C1, B1=:=0, C1=:=C, new12(s(A,A1),d(A,D1)), 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          B1>=C1+1, B1=:=0, C1=:=C, new12(s(A,A1),d(A,D1)), 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=H, B1=:=0, C1=:=0, 
          new8(s(A,B,C,D,C1,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=H, B1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=<B1, 
          A1=:=0, B1=:=C, C1=:=D1-E1, D1=:=C, E1=:=1, 
          new6(s(A,B,C,D,E,F,G,C1,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=0, B1=:=C, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=B, 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=C, B1=:=B, 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new2(s(A),d(B)) :- 
          new3(s(A,C,D,E,F,G,H,I,J,K,L,M,N),d(B,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
