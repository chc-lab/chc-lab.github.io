new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=0, O=:=0, 
          new12(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=B, N=:=0, O=:=1, 
          new12(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new14(s(A),d(A)).
new13(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new14(s(A),d(B)).
new12(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=F, new13(s(G),d(H)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=0, 
          new12(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=A, N=:=0, 
          new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=C, N=:=6, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=C, N=:=6, O=:=1, 
          new12(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=B, N=:=0, O=:=P+Q, P=:=C, 
          Q=:=4, new9(s(A,B,O,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=B, N=:=0, O=:=3, 
          new9(s(A,O,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=0, O=:=3, 
          new7(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=0, O=:=2, 
          new7(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=P+Q, P=:=C, 
          Q=:=2, new5(s(A,B,O,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=A, N=:=0, O=:=3, 
          new5(s(O,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, 
          new4(s(A,B,M,D,E,F),d(G,H,I,J,K,L)).
new2(s,d) :- new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new1 :- new2(s,d).
inv1 :- \+new1.
