new10(s(A),d(A)).
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new10(s(A),d(B)).
new7(s(A,B),d(A,B)) :- C=:=1, D=<E, D=:=A, E=:=50, new8(s(C),d(F)).
new7(s(A,B),d(A,B)) :- C=:=0, D>=E+1, D=:=A, E=:=50, new8(s(C),d(F)).
new5(s(A,B),d(C,D)) :- E=:=F+G, F=:=A, G=:=1, H=:=I+J, I=:=E, J=:=2, K=:=L+M, 
          L=:=H, M=:=3, new7(s(K,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=H+I, H=:=A, I=:=1, 
          new5(s(G,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=H+I, H=:=A, I=:=2, 
          new5(s(G,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=:=0, new4(s(E,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
