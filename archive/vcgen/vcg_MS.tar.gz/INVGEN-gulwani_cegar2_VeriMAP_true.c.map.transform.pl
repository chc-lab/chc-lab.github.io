new24(s(A,B,C,D),d(E,F,G,H)) :- I=:=J+K, J=:=B, K=:=1, 
          new4(s(A,I,C,D),d(E,F,G,H)).
new23(s(A,B),d(A,B)).
new14(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F+1=<G, F=:=C, G=:=D, 
          new10(s(A,E),d(A,H)).
new14(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G, F=:=C, G=:=D, new10(s(A,E),d(A,H)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J+1=<K, J=:=C, K=:=D, 
          new11(s(A,I),d(A,L)), new9(s(A,B,C,D),d(E,F,G,H)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K, J=:=C, K=:=D, 
          new11(s(A,I),d(A,L)), new9(s(A,B,C,D),d(E,F,G,H)).
new11(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new11(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new11(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new22(s(A,B),d(A,C)).
new10(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new23(s(A,B),d(A,C)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=0, G=:=C, new10(s(A,E),d(A,H)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=0, G=:=C, 
          new10(s(A,E),d(A,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=<K, J=:=0, K=:=C, new11(s(A,I),d(A,L)), 
          new14(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K+1, J=:=0, K=:=C, 
          new11(s(A,I),d(A,L)), new14(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=D, J=:=0, new9(s(A,B,C,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=A, J=:=0, K=:=B, 
          new24(s(A,B,K,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=0, K=:=B, 
          new24(s(A,B,K,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=A, J=:=0, 
          new24(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=D, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=B, J=:=D, new7(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(A,I,J,D),d(E,F,G,H)).
new2(s(A),d(B)) :- new3(s(A,C,D,E),d(B,F,G,H)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
