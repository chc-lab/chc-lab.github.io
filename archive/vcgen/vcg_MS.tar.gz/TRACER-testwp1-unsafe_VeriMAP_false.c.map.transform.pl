new10(s(A),d(A)).
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new10(s(A),d(B)).
new6(s(A,B,C),d(A,B,C)) :- D=:=1, E>=F+1, E=:=G+H, G=:=A, H=:=B, F=:=0, 
          new8(s(D),d(I)).
new6(s(A,B,C),d(A,B,C)) :- D=:=0, E=<F, E=:=G+H, G=:=A, H=:=B, F=:=0, 
          new8(s(D),d(I)).
new4(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=0, I=:=3, new6(s(A,B,I),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=0, I=:=1, new6(s(A,I,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=2, new4(s(A,B,I),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=0, I=:= -1, new4(s(I,B,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
