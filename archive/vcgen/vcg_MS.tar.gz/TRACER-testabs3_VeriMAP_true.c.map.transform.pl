new67(s(A),d(A)).
new65(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new67(s(A),d(B)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U)) :- 
          V=:=1, W=<X, W=:=A, X=:=40, new65(s(V),d(Y)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U)) :- 
          V=:=0, W>=X+1, W=:=A, X=:=40, new65(s(V),d(Y)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=U, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new62(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=U, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new62(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=U, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new62(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=T, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new59(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=T, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new59(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=T, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new59(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=S, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new56(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=S, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new56(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=S, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new56(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=R, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new53(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=R, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new53(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=R, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new53(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=Q, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new50(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=Q, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new50(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=Q, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new50(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=P, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new47(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=P, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new47(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=P, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new47(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=O, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new44(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=O, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new44(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=O, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new44(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=N, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new41(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=N, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new41(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=N, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new41(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=M, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new38(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=M, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new38(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=M, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new38(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=L, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new35(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=L, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new35(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=L, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new35(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=K, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new32(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=K, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new32(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=K, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new32(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=J, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new29(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=J, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new29(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=J, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new29(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=I, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new26(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=I, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new26(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=I, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new26(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=H, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new23(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=H, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new23(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=H, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new23(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=G, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new20(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=G, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new20(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=G, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new20(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=F, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new17(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=F, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new17(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=F, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new17(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=E, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new14(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=E, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new14(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=E, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new14(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=D, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new11(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=D, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new11(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=D, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new11(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=C, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new8(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=C, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new8(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=C, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new8(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=R1, Q1=:=B, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=1, 
          new5(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1>=R1+1, Q1=:=B, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new5(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1+1=<R1, Q1=:=B, R1=:=0, S1=:=T1+U1, T1=:=A, U1=:=2, 
          new5(s(S1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)) :- 
          Q1=:=0, 
          new4(s(Q1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new2(s,d) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U),d(V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)).
new1 :- new2(s,d).
inv1 :- \+new1.
