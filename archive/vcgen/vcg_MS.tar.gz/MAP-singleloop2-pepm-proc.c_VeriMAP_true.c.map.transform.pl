new14(s(A),d(B)) :- new14(s(A),d(B)).
new11(s(A,B,C),d(A,B,C)) :- D+1=<E, D=:=A, E=:=B.
new10(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=C, I=:=J-K, J=:=B, K=:=1, 
          new7(s(A,I,C),d(D,E,F)).
new10(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=C, I=:=J+K, J=:=B, K=:=2, 
          new7(s(A,I,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=I*J, I=:=2, J=:=C, K=:=L+M, 
          L=:=A, M=:=1, new10(s(K,B,C),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=I*J, I=:=2, J=:=C, 
          new11(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- new9(s(A,B,C),d(D,E,F)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new14(s(A),d(B)).
new4(s(A,B,C),d(D,E,F)) :- G=:=1, H>=I, H=:=C, I=:=1, new5(s(G),d(J)), 
          new7(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=:=0, H+1=<I, H=:=C, I=:=1, new5(s(G),d(J)), 
          new7(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=0, new4(s(G,H,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
