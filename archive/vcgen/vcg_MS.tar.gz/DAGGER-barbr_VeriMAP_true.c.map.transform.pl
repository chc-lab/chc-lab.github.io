new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=A, P1=:=1, Q1=:=R1-S1, R1=:=A, S1=:=1, T1=:=U1+V1, 
          U1=:=B, V1=:=1, W1=:=1, 
          new4(s(Q1,T1,C,W1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=D, P1=:=0, 
          new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new159(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=A, P1=:=1, Q1=:=R1-S1, R1=:=A, S1=:=1, T1=:=U1+V1, 
          U1=:=B, V1=:=1, W1=:=1, 
          new4(s(Q1,T1,C,D,W1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=E, P1=:=0, 
          new159(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=C, P1=:=1, Q1=:=R1-S1, R1=:=C, S1=:=1, T1=:=0, 
          new4(s(A,B,Q1,D,T1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=E, P1=:=1, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=A, P1=:=1, Q1=:=R1-S1, R1=:=A, S1=:=1, T1=:=U1+V1, 
          U1=:=B, V1=:=1, W1=:=1, 
          new4(s(Q1,T1,C,D,E,W1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=F, P1=:=0, 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=C, P1=:=1, Q1=:=R1-S1, R1=:=C, S1=:=1, T1=:=0, 
          new4(s(A,B,Q1,D,E,T1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=F, P1=:=1, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=A, P1=:=1, Q1=:=R1-S1, R1=:=A, S1=:=1, T1=:=U1+V1, 
          U1=:=B, V1=:=1, W1=:=X1+Y1, X1=:=G, Y1=:=1, 
          new4(s(Q1,T1,C,D,E,F,W1,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=G, P1=:=0, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=C, P1=:=1, Q1=:=R1-S1, R1=:=C, S1=:=1, T1=:=U1-V1, 
          U1=:=G, V1=:=1, 
          new4(s(A,B,Q1,D,E,F,T1,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=G, P1=:=1, 
          new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=H, P1=:=0, Q1=:=R1+S1, R1=:=A, S1=:=1, T1=:=1, 
          new4(s(Q1,B,C,D,E,F,G,T1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=B, P1=:=1, Q1=:=R1-S1, R1=:=B, S1=:=1, T1=:=2, 
          new4(s(A,Q1,C,D,E,F,G,T1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new138(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=H, P1=:=1, 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=H, P1=:=2, Q1=:=R1+S1, R1=:=C, S1=:=1, T1=:=3, 
          new4(s(A,B,Q1,D,E,F,G,T1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=C, P1=:=0, Q1=:=0, 
          new4(s(A,B,C,D,E,F,G,Q1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new133(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=H, P1=:=3, 
          new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=C, P1=:=1, Q1=:=R1-S1, R1=:=C, S1=:=1, T1=:=0, 
          new4(s(A,B,Q1,T1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=<P1, O1=:=D, P1=:=1, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=D, P1=:=1, 
          new130(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=H, P1=:=3, 
          new133(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=I, P1=:=0, 
          new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=I, P1=:=0, 
          new127(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=I, P1=:=0, 
          new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new126(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=H, P1=:=2, 
          new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=J, P1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=J, P1=:=0, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=J, P1=:=0, 
          new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new122(s(A,B,C,D,E,F,G,H,I,O1,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=H, P1=:=1, 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=K, P1=:=0, 
          new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=K, P1=:=0, 
          new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=K, P1=:=0, 
          new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new118(s(A,B,C,D,E,F,G,H,I,J,O1,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=H, P1=:=0, 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=L, P1=:=0, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=L, P1=:=0, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=L, P1=:=0, 
          new117(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,O1,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=G, P1=:=1, 
          new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=M, P1=:=0, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=M, P1=:=0, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=M, P1=:=0, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new110(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=G, P1=:=0, 
          new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=N, P1=:=0, 
          new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=N, P1=:=0, 
          new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=N, P1=:=0, 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,O1,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=F, P1=:=1, 
          new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=O, P1=:=0, 
          new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=O, P1=:=0, 
          new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=O, P1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=F, P1=:=0, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=P, P1=:=0, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=P, P1=:=0, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=P, P1=:=0, 
          new101(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=E, P1=:=1, 
          new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=Q, P1=:=0, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=Q, P1=:=0, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=Q, P1=:=0, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new91(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=E, P1=:=0, 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=R, P1=:=0, 
          new91(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=R, P1=:=0, 
          new91(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=R, P1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new90(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,O1,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1, O1=:=D, P1=:=0, 
          new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=S, P1=:=0, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=S, P1=:=0, 
          new87(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=S, P1=:=0, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new85(s(A),d(A)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V>=W, V=:=A, W=:=0, new10(s(U),d(X)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V+1=<W, V=:=A, W=:=0, new10(s(U),d(X)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V>=W, V=:=B, W=:=0, new10(s(U),d(X)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V+1=<W, V=:=B, W=:=0, new10(s(U),d(X)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1>=Q1, P1=:=B, Q1=:=0, new11(s(O1),d(R1)), 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1+1=<Q1, P1=:=B, Q1=:=0, new11(s(O1),d(R1)), 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V>=W, V=:=C, W=:=0, new10(s(U),d(X)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V+1=<W, V=:=C, W=:=0, new10(s(U),d(X)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1>=Q1, P1=:=C, Q1=:=0, new11(s(O1),d(R1)), 
          new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1+1=<Q1, P1=:=C, Q1=:=0, new11(s(O1),d(R1)), 
          new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V>=W, V=:=D, W=:=0, new10(s(U),d(X)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V+1=<W, V=:=D, W=:=0, new10(s(U),d(X)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1>=Q1, P1=:=D, Q1=:=0, new11(s(O1),d(R1)), 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1+1=<Q1, P1=:=D, Q1=:=0, new11(s(O1),d(R1)), 
          new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V>=W, V=:=E, W=:=0, new10(s(U),d(X)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V+1=<W, V=:=E, W=:=0, new10(s(U),d(X)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1>=Q1, P1=:=E, Q1=:=0, new11(s(O1),d(R1)), 
          new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1+1=<Q1, P1=:=E, Q1=:=0, new11(s(O1),d(R1)), 
          new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V>=W, V=:=F, W=:=0, new10(s(U),d(X)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V+1=<W, V=:=F, W=:=0, new10(s(U),d(X)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1>=Q1, P1=:=F, Q1=:=0, new11(s(O1),d(R1)), 
          new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1+1=<Q1, P1=:=F, Q1=:=0, new11(s(O1),d(R1)), 
          new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V>=W, V=:=G, W=:=0, new10(s(U),d(X)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V+1=<W, V=:=G, W=:=0, new10(s(U),d(X)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1>=Q1, P1=:=G, Q1=:=0, new11(s(O1),d(R1)), 
          new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1+1=<Q1, P1=:=G, Q1=:=0, new11(s(O1),d(R1)), 
          new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V=<W, V=:=H, W=:=3, new10(s(U),d(X)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V>=W+1, V=:=H, W=:=3, new10(s(U),d(X)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1=<Q1, P1=:=H, Q1=:=3, new11(s(O1),d(R1)), 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1>=Q1+1, P1=:=H, Q1=:=3, new11(s(O1),d(R1)), 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V=<W, V=:=G, W=:=1, new10(s(U),d(X)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V>=W+1, V=:=G, W=:=1, new10(s(U),d(X)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1=<Q1, P1=:=G, Q1=:=1, new11(s(O1),d(R1)), 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1>=Q1+1, P1=:=G, Q1=:=1, new11(s(O1),d(R1)), 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V=<W, V=:=F, W=:=1, new10(s(U),d(X)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V>=W+1, V=:=F, W=:=1, new10(s(U),d(X)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1=<Q1, P1=:=F, Q1=:=1, new11(s(O1),d(R1)), 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1>=Q1+1, P1=:=F, Q1=:=1, new11(s(O1),d(R1)), 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V=<W, V=:=E, W=:=1, new10(s(U),d(X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V>=W+1, V=:=E, W=:=1, new10(s(U),d(X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1=<Q1, P1=:=E, Q1=:=1, new11(s(O1),d(R1)), 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1>=Q1+1, P1=:=E, Q1=:=1, new11(s(O1),d(R1)), 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V=<W, V=:=D, W=:=1, new10(s(U),d(X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V>=W+1, V=:=D, W=:=1, new10(s(U),d(X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1=<Q1, P1=:=D, Q1=:=1, new11(s(O1),d(R1)), 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1>=Q1+1, P1=:=D, Q1=:=1, new11(s(O1),d(R1)), 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new11(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new11(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new84(s(A),d(B)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new85(s(A),d(B)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=1, V>=W, V=:=H, W=:=C, new10(s(U),d(X)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T)) :- 
          U=:=0, V+1=<W, V=:=H, W=:=C, new10(s(U),d(X)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=1, P1>=Q1, P1=:=H, Q1=:=C, new11(s(O1),d(R1)), 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1+1=<Q1, P1=:=H, Q1=:=C, new11(s(O1),d(R1)), 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1>=P1+1, O1=:=T, P1=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1+1=<P1, O1=:=T, P1=:=0, 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=P1, O1=:=T, P1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,O1),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)) :- 
          O1=:=0, P1=:=0, Q1=:=0, R1=:=0, S1=:=0, T1=:=0, U1=:=0, V1=:=0, 
          new4(s(O1,P1,Q1,R1,S1,T1,U1,V1,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new2(s,d) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T),d(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1)).
new1 :- new2(s,d).
inv1 :- \+new1.
