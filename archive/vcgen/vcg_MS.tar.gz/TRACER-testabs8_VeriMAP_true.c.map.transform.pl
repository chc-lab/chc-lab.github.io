new10(s(A),d(A)).
new8(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new10(s(A),d(B)).
new7(s(A,B),d(A,B)) :- C=:=1, D=<E, D=:=B, E=:=10, new8(s(C),d(F)).
new7(s(A,B),d(A,B)) :- C=:=0, D>=E+1, D=:=B, E=:=10, new8(s(C),d(F)).
new5(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=A, G=:=H+I, H=:=B, I=:=1, 
          new4(s(A,G),d(C,D)).
new5(s(A,B),d(C,D)) :- E>=F, E=:=B, F=:=A, new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- new5(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=:=0, F=:=10, new4(s(F,E),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
