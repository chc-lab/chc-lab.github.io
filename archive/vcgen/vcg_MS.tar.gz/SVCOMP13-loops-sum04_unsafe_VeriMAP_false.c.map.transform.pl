new16(s(A,B,C),d(D,E,F)) :- G=:=H+I, H=:=A, I=:=1, new4(s(G,B,C),d(D,E,F)).
new15(s(A),d(A)).
new14(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new15(s(A),d(B)).
new9(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=0, I=:=1, new8(s(A,B,I),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=0, I=:=0, new8(s(A,B,I),d(D,E,F)).
new9(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=0, I=:=0, new8(s(A,B,I),d(D,E,F)).
new8(s(A,B,C),d(A,B,C)) :- D=:=C, new14(s(D),d(E)).
new7(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=B, H=:=16, I=:=1, new8(s(A,B,I),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=16, new9(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=B, H=:=16, new9(s(A,B,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=4, I=:=J+K, J=:=B, K=:=2, 
          new16(s(A,I,C),d(D,E,F)).
new6(s(A,B,C),d(D,E,F)) :- G>=H, G=:=A, H=:=4, new16(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=<H, G=:=A, H=:=8, new6(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=8, new7(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new5(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=1, new4(s(H,G,C),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
