new19(s(A),d(A)).
new10(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new10(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new18(s(A),d(B)).
new9(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new19(s(A),d(B)).
new6(s(A,B),d(A,B)) :- C=:=1, D=:=E, D=:=A, E=:=0, new9(s(C),d(F)).
new6(s(A,B),d(A,B)) :- C=:=0, D>=E+1, D=:=A, E=:=0, new9(s(C),d(F)).
new6(s(A,B),d(A,B)) :- C=:=0, D+1=<E, D=:=A, E=:=0, new9(s(C),d(F)).
new6(s(A,B),d(C,D)) :- E=:=1, F=:=G, F=:=A, G=:=0, new10(s(E),d(H)), 
          new7(s(A,B),d(C,D)).
new6(s(A,B),d(C,D)) :- E=:=0, F>=G+1, F=:=A, G=:=0, new10(s(E),d(H)), 
          new7(s(A,B),d(C,D)).
new6(s(A,B),d(C,D)) :- E=:=0, F+1=<G, F=:=A, G=:=0, new10(s(E),d(H)), 
          new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E=:=F, E=:=A, F=:=0, new6(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E>=F+1, E=:=A, F=:=0, new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E+1=<F, E=:=A, F=:=0, new7(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=0, new4(s(G,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=1, new4(s(G,B),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
