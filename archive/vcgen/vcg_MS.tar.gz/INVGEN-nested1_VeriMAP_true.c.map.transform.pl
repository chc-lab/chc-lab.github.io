new25(s(A),d(B)) :- new25(s(A),d(B)).
new24(s(A),d(A)).
new18(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new18(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new18(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new23(s(A),d(B)).
new17(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new24(s(A),d(B)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=C, K=:=L+M, L=:=A, M=:=1, 
          new13(s(K,B,C,D),d(E,F,G,H)).
new14(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=A, J=:=C, K=:=L+M, L=:=B, M=:=1, 
          new7(s(A,K,C,D),d(E,F,G,H)).
new13(s(A,B,C,D),d(E,F,G,H)) :- new14(s(A,B,C,D),d(E,F,G,H)).
new12(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=1, G=:=B, new17(s(E),d(H)).
new12(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=1, G=:=B, new17(s(E),d(H)).
new12(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=<K, J=:=1, K=:=B, L=:=M+N, M=:=A, 
          N=:=1, new18(s(I),d(O)), new10(s(L,B,C,D),d(E,F,G,H)).
new12(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K+1, J=:=1, K=:=B, L=:=M+N, M=:=A, 
          N=:=1, new18(s(I),d(O)), new10(s(L,B,C,D),d(E,F,G,H)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=C, 
          new12(s(A,B,C,D),d(E,F,G,H)).
new11(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=A, J=:=C, K=:=D, 
          new13(s(K,B,C,D),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- new11(s(A,B,C,D),d(E,F,G,H)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=C, K=:=D, 
          new10(s(K,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- new9(s(A,B,C,D),d(E,F,G,H)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new25(s(A),d(B)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J>=K+1, J=:=D, K=:=0, L=:=1, 
          new5(s(I),d(M)), new7(s(A,L,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=<K, J=:=D, K=:=0, L=:=1, 
          new5(s(I),d(M)), new7(s(A,L,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- new4(s(A,B,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
