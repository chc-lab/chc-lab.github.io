new16(s(A),d(A)).
new15(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new16(s(A),d(B)).
new12(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=C, J=:=10, K=:=0, 
          new11(s(A,B,C,K),d(E,F,G,H)).
new12(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=C, J=:=10, K=:=1, 
          new11(s(A,B,C,K),d(E,F,G,H)).
new11(s(A,B,C,D),d(A,B,C,D)) :- E=:=D, new15(s(E),d(F)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=B, J=:=10, K=:=0, 
          new11(s(A,B,C,K),d(E,F,G,H)).
new10(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=B, J=:=10, 
          new12(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=B, J=:=A, K=:=L+M, L=:=B, M=:=1, 
          new7(s(A,K,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=B, J=:=A, new10(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- new8(s(A,B,C,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=C, J=:=A, K=:=L+M, L=:=C, M=:=1, 
          new4(s(A,B,K,D),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I>=J, I=:=C, J=:=A, new7(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, K=:=10, 
          new4(s(K,I,J,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
