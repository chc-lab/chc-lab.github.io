new11(s(A),d(A)).
new9(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new11(s(A),d(B)).
new8(s(A,B,C),d(A,B,C)) :- D=:=1, E=<F, E=:=C, F=:=1, new9(s(D),d(G)).
new8(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F+1, E=:=C, F=:=1, new9(s(D),d(G)).
new5(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=B, new4(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=B, new4(s(A,B,C),d(D,E,F)).
new5(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=B, new8(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=:=H+I, H=:=A, I=:=1, new5(s(G,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=:=0, H=:=10, I=:=0, new4(s(I,H,G),d(D,E,F)).
new2(s,d) :- new3(s(A,B,C),d(D,E,F)).
new1 :- new2(s,d).
inv1 :- \+new1.
