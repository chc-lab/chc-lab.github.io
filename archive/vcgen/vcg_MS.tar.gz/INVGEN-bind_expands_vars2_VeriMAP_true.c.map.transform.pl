new22(s(A),d(A)).
new16(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new16(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new16(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new21(s(A),d(B)).
new15(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new22(s(A),d(B)).
new13(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G+1=<H, G=:=I+J, I=:=A, J=:=D, 
          H=:=K*L, K=:=E, L=:=2, new15(s(F),d(M)).
new13(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H, G=:=I+J, I=:=A, J=:=D, 
          H=:=K*L, K=:=E, L=:=2, new15(s(F),d(M)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L+1=<M, L=:=N+O, N=:=A, O=:=D, 
          M=:=P*Q, P=:=E, Q=:=2, R=:=S+T, S=:=D, T=:=1, new16(s(K),d(U)), 
          new10(s(A,B,C,R,E),d(F,G,H,I,J)).
new13(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M, L=:=N+O, N=:=A, O=:=D, 
          M=:=P*Q, P=:=E, Q=:=2, R=:=S+T, S=:=D, T=:=1, new16(s(K),d(U)), 
          new10(s(A,B,C,R,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K+1=<L, K=:=D, L=:=C, 
          new13(s(A,B,C,D,E),d(F,G,H,I,J)).
new12(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L, K=:=D, L=:=C, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- new12(s(A,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=C, L=:=M-N, M=:=O*P, O=:=E, P=:=2, 
          N=:=B, Q=:=0, new10(s(A,B,C,Q,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=C, L=:=M-N, M=:=O*P, O=:=E, 
          P=:=2, N=:=B, new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=A, L=:=B, 
          new8(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=A, L=:=B, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=B, L=:=M*N, M=:=E, N=:=2, 
          new6(s(A,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=B, L=:=M*N, M=:=E, N=:=2, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K>=L+1, K=:=E, L=:=0, 
          new4(s(A,B,C,D,E),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=<L, K=:=E, L=:=0, 
          new5(s(A,B,C,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
