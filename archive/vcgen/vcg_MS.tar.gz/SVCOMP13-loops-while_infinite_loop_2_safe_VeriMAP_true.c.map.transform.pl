new16(s(A),d(A)).
new7(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new7(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new7(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new15(s(A),d(B)).
new6(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new16(s(A),d(B)).
new5(s(A),d(A)) :- B=:=1, C=:=D, C=:=A, D=:=0, new6(s(B),d(E)).
new5(s(A),d(A)) :- B=:=0, C>=D+1, C=:=A, D=:=0, new6(s(B),d(E)).
new5(s(A),d(A)) :- B=:=0, C+1=<D, C=:=A, D=:=0, new6(s(B),d(E)).
new5(s(A),d(B)) :- C=:=1, D=:=E, D=:=A, E=:=0, new7(s(C),d(F)), new4(s(A),d(B)).
new5(s(A),d(B)) :- C=:=0, D>=E+1, D=:=A, E=:=0, new7(s(C),d(F)), 
          new4(s(A),d(B)).
new5(s(A),d(B)) :- C=:=0, D+1=<E, D=:=A, E=:=0, new7(s(C),d(F)), 
          new4(s(A),d(B)).
new4(s(A),d(B)) :- new5(s(A),d(B)).
new3(s(A),d(B)) :- C=:=0, new4(s(C),d(B)).
new2(s,d) :- new3(s(A),d(B)).
new1 :- new2(s,d).
inv1 :- \+new1.
