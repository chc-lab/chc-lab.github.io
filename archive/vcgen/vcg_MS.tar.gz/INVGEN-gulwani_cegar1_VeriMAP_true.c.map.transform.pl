new39(s(A,B),d(A,C)) :- new39(s(A,B),d(A,C)).
new38(s(A,B),d(A,B)).
new32(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new32(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new32(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new37(s(A,B),d(A,C)).
new31(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new38(s(A,B),d(A,C)).
new29(s(A,B,C),d(A,B,C)) :- D=:=1, E+1=<F, E=:=B, F=:=4, new31(s(A,D),d(A,G)).
new29(s(A,B,C),d(A,B,C)) :- D=:=0, E>=F, E=:=B, F=:=4, new31(s(A,D),d(A,G)).
new29(s(A,B,C),d(D,E,F)) :- G=:=1, H+1=<I, H=:=B, I=:=4, new32(s(A,G),d(A,J)), 
          new26(s(A,B,C),d(D,E,F)).
new29(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I, H=:=B, I=:=4, new32(s(A,G),d(A,J)), 
          new26(s(A,B,C),d(D,E,F)).
new27(s(A,B,C),d(D,E,F)) :- G=<H, G=:=4, H=:=B, new29(s(A,B,C),d(D,E,F)).
new27(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=4, H=:=B, new26(s(A,B,C),d(D,E,F)).
new25(s(A,B,C),d(D,E,F)) :- G=<H, G=:=C, H=:=0, new27(s(A,B,C),d(D,E,F)).
new25(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=C, H=:=0, new26(s(A,B,C),d(D,E,F)).
new24(s(A,B,C),d(D,E,F)) :- G>=H, G=:=C, H=:=0, new25(s(A,B,C),d(D,E,F)).
new24(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=C, H=:=0, new26(s(A,B,C),d(D,E,F)).
new21(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=A, H=:=0, I=:=J+K, J=:=B, K=:=2, 
          L=:=M+N, M=:=C, N=:=2, new19(s(A,I,L),d(D,E,F)).
new21(s(A,B,C),d(D,E,F)) :- G+1=<H, G=:=A, H=:=0, I=:=J+K, J=:=B, K=:=2, 
          L=:=M+N, M=:=C, N=:=2, new19(s(A,I,L),d(D,E,F)).
new21(s(A,B,C),d(D,E,F)) :- G=:=H, G=:=A, H=:=0, new24(s(A,B,C),d(D,E,F)).
new19(s(A,B,C),d(D,E,F)) :- new21(s(A,B,C),d(D,E,F)).
new15(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=C, I=:=2, new5(s(A,G),d(A,J)), 
          new19(s(A,B,C),d(D,E,F)).
new15(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=C, I=:=2, new5(s(A,G),d(A,J)), 
          new19(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=C, new5(s(A,G),d(A,J)), 
          new15(s(A,B,C),d(D,E,F)).
new11(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=C, new5(s(A,G),d(A,J)), 
          new15(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=B, I=:=2, new5(s(A,G),d(A,J)), 
          new11(s(A,B,C),d(D,E,F)).
new7(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=B, I=:=2, new5(s(A,G),d(A,J)), 
          new11(s(A,B,C),d(D,E,F)).
new5(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new5(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new5(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new39(s(A,B),d(A,C)).
new4(s(A,B,C),d(D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=B, new5(s(A,G),d(A,J)), 
          new7(s(A,B,C),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=B, new5(s(A,G),d(A,J)), 
          new7(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- new4(s(A,B,C),d(D,E,F)).
new2(s(A),d(B)) :- new3(s(A,C,D),d(B,E,F)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
