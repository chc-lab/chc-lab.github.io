new30(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H+1=<I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new30(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I, H=:=D, I=:=E, 
          new15(s(A,G),d(A,J)).
new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N+1=<O, N=:=D, O=:=E, P=:=Q+R, 
          Q=:=D, R=:=1, new16(s(A,M),d(A,S)), 
          new27(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O, N=:=D, O=:=E, P=:=Q+R, 
          Q=:=D, R=:=1, new16(s(A,M),d(A,S)), 
          new27(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=C, 
          new30(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=C, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new29(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new22(s(A,B),d(A,B)).
new16(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new16(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new16(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new21(s(A,B),d(A,C)).
new15(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new22(s(A,B),d(A,C)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H>=I+1, H=:=J+K, J=:=L+M, L=:=E, 
          M=:=C, K=:=5, I=:=B, new15(s(A,G),d(A,N)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H=<I, H=:=J+K, J=:=L+M, L=:=E, 
          M=:=C, K=:=5, I=:=B, new15(s(A,G),d(A,N)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N>=O+1, N=:=P+Q, P=:=R+S, R=:=E, 
          S=:=C, Q=:=5, O=:=B, T=:=U+V, U=:=C, V=:=2, new16(s(A,M),d(A,W)), 
          new7(s(A,B,T,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N=<O, N=:=P+Q, P=:=R+S, R=:=E, 
          S=:=C, Q=:=5, O=:=B, T=:=U+V, U=:=C, V=:=2, new16(s(A,M),d(A,W)), 
          new7(s(A,B,T,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H>=I, H=:=C, I=:=0, 
          new15(s(A,G),d(A,J)).
new12(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H+1=<I, H=:=C, I=:=0, 
          new15(s(A,G),d(A,J)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N>=O, N=:=C, O=:=0, P=:=Q+R, 
          Q=:=C, R=:=1, S=:=0, new16(s(A,M),d(A,T)), 
          new27(s(A,B,P,S,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N+1=<O, N=:=C, O=:=0, P=:=Q+R, 
          Q=:=C, R=:=1, S=:=0, new16(s(A,M),d(A,T)), 
          new27(s(A,B,P,S,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=F, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=F, O=:=P+Q, P=:=B, 
          Q=:=4, new4(s(A,O,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=B, N=:=E, O=:=B, 
          new7(s(A,B,O,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=B, N=:=E, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O+P, O=:=F, P=:=1, N=:=E, 
          Q=:=0, new4(s(A,Q,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O+P, O=:=F, P=:=1, N=:=E, 
          new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
