new18(s(A),d(A)).
new12(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new12(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new12(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new17(s(A),d(B)).
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new18(s(A),d(B)).
new9(s(A,B,C,D),d(E,F,G,H)) :- I=:=J+K, J=:=A, K=:=1, 
          new4(s(I,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F=<G, F=:=C, G=:=0, new11(s(E),d(H)).
new8(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F>=G+1, F=:=C, G=:=0, new11(s(E),d(H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I=:=1, J=<K, J=:=C, K=:=0, new12(s(I),d(L)), 
          new9(s(A,B,C,D),d(E,F,G,H)).
new8(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J>=K+1, J=:=C, K=:=0, new12(s(I),d(L)), 
          new9(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, 
          new8(s(A,B,C,D),d(E,F,G,H)).
new7(s(A,B,C,D),d(E,F,G,H)) :- I=<J, I=:=D, J=:=0, K=:=1, 
          new9(s(A,B,K,D),d(E,F,G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- new7(s(A,B,C,I),d(E,F,G,H)).
new5(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=A, J=:=B, 
          new6(s(A,B,C,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- new5(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=0, J=:=0, new4(s(J,B,I,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
