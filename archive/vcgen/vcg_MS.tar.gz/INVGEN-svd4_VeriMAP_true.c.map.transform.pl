new241(s(A,B),d(A,C)) :- new241(s(A,B),d(A,C)).
new240(s(A,B),d(A,B)).
new231(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=D, J=:=B, 
          new13(s(A,H),d(A,K)).
new231(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=D, J=:=B, 
          new13(s(A,H),d(A,K)).
new231(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=D, Q=:=B, 
          R=:=S+T, S=:=D, T=:=1, new14(s(A,O),d(A,U)), 
          new23(s(A,B,C,R,E,F,G),d(H,I,J,K,L,M,N)).
new231(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=D, Q=:=B, 
          R=:=S+T, S=:=D, T=:=1, new14(s(A,O),d(A,U)), 
          new23(s(A,B,C,R,E,F,G),d(H,I,J,K,L,M,N)).
new225(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new225(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new225(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new231(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new225(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new231(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new219(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=G, 
          new13(s(A,H),d(A,K)).
new219(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=G, 
          new13(s(A,H),d(A,K)).
new219(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=G, 
          new14(s(A,O),d(A,R)), new225(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new219(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=G, 
          new14(s(A,O),d(A,R)), new225(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new207(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=D, J=:=B, 
          new13(s(A,H),d(A,K)).
new207(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=D, J=:=B, 
          new13(s(A,H),d(A,K)).
new207(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=D, Q=:=B, 
          R=:=S+T, S=:=E, T=:=1, new14(s(A,O),d(A,U)), 
          new84(s(A,B,C,D,R,F,G),d(H,I,J,K,L,M,N)).
new207(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=D, Q=:=B, 
          R=:=S+T, S=:=E, T=:=1, new14(s(A,O),d(A,U)), 
          new84(s(A,B,C,D,R,F,G),d(H,I,J,K,L,M,N)).
new201(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new201(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new201(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new207(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new201(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new207(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new195(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new195(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new195(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=B, 
          new14(s(A,O),d(A,R)), new201(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new195(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=B, 
          new14(s(A,O),d(A,R)), new201(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new189(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new189(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new189(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new195(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new189(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new195(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new183(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=E, J=:=G, 
          new13(s(A,H),d(A,K)).
new183(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=E, J=:=G, 
          new13(s(A,H),d(A,K)).
new183(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=E, Q=:=G, 
          new14(s(A,O),d(A,R)), new189(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new183(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=E, Q=:=G, 
          new14(s(A,O),d(A,R)), new189(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new171(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new171(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new171(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=B, 
          R=:=S+T, S=:=E, T=:=1, new14(s(A,O),d(A,U)), 
          new138(s(A,B,C,D,R,F,G),d(H,I,J,K,L,M,N)).
new171(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=B, 
          R=:=S+T, S=:=E, T=:=1, new14(s(A,O),d(A,U)), 
          new138(s(A,B,C,D,R,F,G),d(H,I,J,K,L,M,N)).
new165(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new165(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new165(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new171(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new165(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new171(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new159(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=D, J=:=B, 
          new13(s(A,H),d(A,K)).
new159(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=D, J=:=B, 
          new13(s(A,H),d(A,K)).
new159(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=D, Q=:=B, 
          new14(s(A,O),d(A,R)), new165(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new159(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=D, Q=:=B, 
          new14(s(A,O),d(A,R)), new165(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new153(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new153(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new153(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new159(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new153(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new159(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new147(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=E, J=:=G, 
          new13(s(A,H),d(A,K)).
new147(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=E, J=:=G, 
          new13(s(A,H),d(A,K)).
new147(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=E, Q=:=G, 
          new14(s(A,O),d(A,R)), new153(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new147(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=E, Q=:=G, 
          new14(s(A,O),d(A,R)), new153(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new141(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=E, 
          new13(s(A,H),d(A,K)).
new141(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=E, 
          new13(s(A,H),d(A,K)).
new141(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=E, 
          new14(s(A,O),d(A,R)), new147(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new141(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=E, 
          new14(s(A,O),d(A,R)), new147(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new140(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=E, P=:=G, 
          new141(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new140(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=G, Q=:=R+S, 
          R=:=D, S=:=1, new28(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new138(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new140(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new132(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new132(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new132(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=B, R=:=C, 
          new14(s(A,O),d(A,S)), new138(s(A,B,C,D,R,F,G),d(H,I,J,K,L,M,N)).
new132(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=B, 
          R=:=C, new14(s(A,O),d(A,S)), 
          new138(s(A,B,C,D,R,F,G),d(H,I,J,K,L,M,N)).
new126(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new126(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new126(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new132(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new126(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new132(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new120(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=G, 
          new13(s(A,H),d(A,K)).
new120(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=G, 
          new13(s(A,H),d(A,K)).
new120(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=G, 
          new14(s(A,O),d(A,R)), new126(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new120(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=G, 
          new14(s(A,O),d(A,R)), new126(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new115(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new115(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new115(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new120(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new115(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new120(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new114(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=E, 
          new13(s(A,H),d(A,K)).
new114(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=E, 
          new13(s(A,H),d(A,K)).
new114(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=E, 
          new14(s(A,O),d(A,R)), new183(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new114(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=E, 
          new14(s(A,O),d(A,R)), new183(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new113(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=E, P=:=G, 
          new114(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new113(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=E, P=:=G, 
          new115(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new105(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new105(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new105(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=B, 
          R=:=S+T, S=:=D, T=:=1, new14(s(A,O),d(A,U)), 
          new85(s(A,B,C,R,E,F,G),d(H,I,J,K,L,M,N)).
new105(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=B, 
          R=:=S+T, S=:=D, T=:=1, new14(s(A,O),d(A,U)), 
          new85(s(A,B,C,R,E,F,G),d(H,I,J,K,L,M,N)).
new99(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new99(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new99(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new105(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new99(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new105(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new93(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=D, J=:=G, 
          new13(s(A,H),d(A,K)).
new93(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=D, J=:=G, 
          new13(s(A,H),d(A,K)).
new93(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=D, Q=:=G, 
          new14(s(A,O),d(A,R)), new99(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new93(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=D, Q=:=G, 
          new14(s(A,O),d(A,R)), new99(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new87(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new87(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new87(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new93(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new87(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new93(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new86(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=G, 
          new87(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new86(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=G, 
          new33(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new85(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new86(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new84(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new113(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new83(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=B, Q=:=F, 
          new84(s(A,B,C,D,Q,F,G),d(H,I,J,K,L,M,N)).
new83(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=B, Q=:=C, 
          new85(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new75(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new75(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new75(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=B, R=:=S+T, 
          S=:=D, T=:=1, new14(s(A,O),d(A,U)), 
          new30(s(A,B,C,R,E,F,G),d(H,I,J,K,L,M,N)).
new75(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=B, 
          R=:=S+T, S=:=D, T=:=1, new14(s(A,O),d(A,U)), 
          new30(s(A,B,C,R,E,F,G),d(H,I,J,K,L,M,N)).
new69(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new69(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new69(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new75(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new69(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new75(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new63(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=D, J=:=G, 
          new13(s(A,H),d(A,K)).
new63(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=D, J=:=G, 
          new13(s(A,H),d(A,K)).
new63(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=D, Q=:=G, 
          new14(s(A,O),d(A,R)), new69(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new63(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=D, Q=:=G, 
          new14(s(A,O),d(A,R)), new69(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new51(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new51(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new51(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=B, R=:=S-T, 
          S=:=C, T=:=1, new14(s(A,O),d(A,U)), 
          new10(s(A,B,R,D,E,F,G),d(H,I,J,K,L,M,N)).
new51(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=B, 
          R=:=S-T, S=:=C, T=:=1, new14(s(A,O),d(A,U)), 
          new10(s(A,B,R,D,E,F,G),d(H,I,J,K,L,M,N)).
new45(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new45(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new51(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new51(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new39(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=G, 
          new13(s(A,H),d(A,K)).
new39(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=G, 
          new13(s(A,H),d(A,K)).
new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=G, 
          new14(s(A,O),d(A,R)), new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=G, 
          new14(s(A,O),d(A,R)), new45(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new34(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new34(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new34(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new34(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new39(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new33(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new34(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new32(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new32(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=D, 
          new13(s(A,H),d(A,K)).
new32(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new63(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new32(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=D, 
          new14(s(A,O),d(A,R)), new63(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new31(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=G, 
          new32(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new31(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=G, 
          new33(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new30(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new31(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new28(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new83(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new27(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=A, P=:=0, Q=:=F, 
          new28(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new27(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O+1=<P, O=:=A, P=:=0, Q=:=F, 
          new28(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new27(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=P, O=:=A, P=:=0, Q=:=C, 
          new30(s(A,B,C,Q,E,F,G),d(H,I,J,K,L,M,N)).
new26(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new26(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new26(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new219(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new26(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new219(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=D, P=:=B, 
          new26(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=D, P=:=B, 
          new27(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new23(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new25(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new17(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=C, J=:=B, 
          new13(s(A,H),d(A,K)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=C, Q=:=B, R=:=F, 
          new14(s(A,O),d(A,S)), new23(s(A,B,C,R,E,F,G),d(H,I,J,K,L,M,N)).
new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=C, Q=:=B, R=:=F, 
          new14(s(A,O),d(A,S)), new23(s(A,B,C,R,E,F,G),d(H,I,J,K,L,M,N)).
new14(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new14(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new14(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new239(s(A,B),d(A,C)).
new13(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new240(s(A,B),d(A,C)).
new12(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=1, I=<J, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new12(s(A,B,C,D,E,F,G),d(A,B,C,D,E,F,G)) :- H=:=0, I>=J+1, I=:=1, J=:=C, 
          new13(s(A,H),d(A,K)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P=<Q, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new12(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P>=Q+1, P=:=1, Q=:=C, 
          new14(s(A,O),d(A,R)), new17(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P, O=:=C, P=:=1, Q=:=R+S, R=:=C, 
          S=:=1, new12(s(A,B,C,D,E,Q,G),d(H,I,J,K,L,M,N)).
new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new11(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new8(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- 
          new10(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=<P, O=:=G, P=:=B, Q=:=G, 
          new8(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O>=P+1, O=:=G, P=:=B, Q=:=B, 
          new8(s(A,B,Q,D,E,F,G),d(H,I,J,K,L,M,N)).
new4(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new4(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new4(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new241(s(A,B),d(A,C)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=1, P>=Q+1, P=:=B, Q=:=G, 
          new4(s(A,O),d(A,R)), new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new3(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)) :- O=:=0, P=<Q, P=:=B, Q=:=G, 
          new4(s(A,O),d(A,R)), new6(s(A,B,C,D,E,F,G),d(H,I,J,K,L,M,N)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G,H),d(B,I,J,K,L,M,N)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
