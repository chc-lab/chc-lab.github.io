new357(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=F, 
          Z=:=1, A1=:=0, 
          new360(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new357(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=F, 
          Z=:=1, A1=:=2, 
          new360(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new357(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=F, 
          Z=:=1, A1=:=2, 
          new360(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new354(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new351(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=F, 
          Z=:=1, A1=:=0, 
          new354(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new351(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=F, 
          Z=:=1, A1=:=2, 
          new354(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new351(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=F, 
          Z=:=1, A1=:=2, 
          new354(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new345(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=0, A1=:=1, 
          new348(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new345(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new348(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new345(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new348(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new342(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=0, A1=:=1, 
          new345(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new342(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new345(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new342(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new345(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new339(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=0, A1=:=1, 
          new342(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new339(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new342(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new339(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new342(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new336(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new333(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=0, A1=:=1, 
          new336(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new333(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new336(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new333(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new336(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new330(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=0, A1=:=1, 
          new333(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new330(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new333(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new330(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new333(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new327(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=0, A1=:=1, 
          new330(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new327(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new330(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new327(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new330(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new323(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new320(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=I, B1=:=1, C1=:=1, 
          new323(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new320(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=I, B1=:=1, 
          new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new320(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=1, 
          new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new314(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new316(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new313(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=J, B1=:=1, C1=:=1, 
          new316(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new313(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=J, B1=:=1, 
          new314(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new313(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=J, B1=:=1, 
          new314(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=N, D1=:=0, E1=:=0, 
          new310(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=N, D1=:=0, E1=:=0, 
          new310(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new309(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=N, D1=:=0, 
          new310(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new307(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=B, B1=:=1, 
          new313(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new307(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=B, B1=:=1, 
          new314(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new307(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=B, B1=:=1, 
          new314(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new304(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new307(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new304(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new282(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new309(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new304(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new304(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, 
          new304(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new301(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new320(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new301(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=1, 
          new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new301(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=1, 
          new321(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new295(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new297(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=I, B1=:=1, C1=:=1, 
          new297(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=I, B1=:=1, 
          new295(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=1, 
          new295(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new290(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=J, B1=:=1, C1=:=1, 
          new290(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=J, B1=:=1, 
          new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=J, B1=:=1, 
          new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)).
new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=N, D1=:=0, E1=:=0, 
          new284(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=N, D1=:=0, E1=:=0, 
          new284(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=N, D1=:=0, 
          new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new282(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=B, B1=:=1, 
          new287(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new282(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=B, B1=:=1, 
          new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new282(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=B, B1=:=1, 
          new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new279(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new282(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new283(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new279(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new279(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, 
          new279(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new294(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=1, 
          new295(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=1, 
          new295(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new271(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new274(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new271(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new274(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new271(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new274(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new268(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new271(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new268(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new271(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new268(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new271(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new268(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new268(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new268(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new262(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new259(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new262(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new259(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new262(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new259(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new262(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new256(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new259(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new256(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new259(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new256(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new259(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new253(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new256(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new253(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new256(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new253(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new256(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, 
          new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,G1,H1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new249(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          new249(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=5, 
          new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=5, 
          new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=5, 
          new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O,P)) :- 
          new209(s(A,B,C,D,E,F,G,H,I,J,K,L),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=2, H1=:=1, I1=:=2, 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1)), 
          new239(s(H1,K1,I1,M1,N1,O1,P1,Q1,R1,G1,T1,U1,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, I1=:=1, 
          new240(s(A,B,C,D,E,F,G,H,I,I1,H1,G1,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=N, H1=:=O, 
          new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1, G1=:=N, H1=:=O, 
          new239(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1+I1, H1=:=N, I1=:=1, 
          new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,G1,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new234(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1, G1=:=M, H1=:=5, 
          new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new234(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=5, 
          new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new233(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=<H1, G1=:=M, H1=:=5, 
          new234(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new233(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=5, 
          new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)) :- 
          new249(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=K, H1=:=I1+J1, I1=:=L, J1=:=1, 
          new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=K, H1=:=I1+J1, I1=:=L, J1=:=1, 
          new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=K, H1=:=I1+J1, I1=:=L, J1=:=1, 
          new233(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=A, H1=:=1, 
          new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=A, H1=:=1, 
          new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=A, H1=:=1, 
          new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=0, 
          new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,G1,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=A, H1=:=0, 
          new225(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=A, H1=:=0, 
          new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=A, H1=:=0, 
          new226(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new219(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new222(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1,G1,H1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,I1,J1,K1,L1)).
new219(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1,M1,N1),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)), 
          new189(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=1, 
          new219(s(A,B,M1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=1, 
          new219(s(A,B,M1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new211(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1,F1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=M, F1=:=N, G1=:=1, H1=:=2, 
          new213(s(A,G1,C,H1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=M, F1=:=N, 
          new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new211(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z),d(M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new209(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=2, F1=:=G1+H1, G1=:=M, H1=:=1, 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new211(s(I1,J1,K1,L1,M1,N1,O1,P1,E1,R1,S1,T1,F1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1+G1, F1=:=K, G1=:=1, H1=:=1, 
          new208(s(A,B,C,D,E,F,G,H,H1,J,E1,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=B, F1=:=1, 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=B, F1=:=1, 
          new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=B, F1=:=1, 
          new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=0, 
          new216(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=B, F1=:=0, 
          new202(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=B, F1=:=0, 
          new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=B, F1=:=0, 
          new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new199(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1,G1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,H1,I1,J1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new129(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new192(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=0, M1=:=1, 
          new196(s(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=0, M1=:=1, 
          new196(s(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=0, 
          new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1+M1, L1=:=N, M1=:=1, 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=D, L1=:=0, 
          new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=D, L1=:=0, 
          new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=D, L1=:=0, 
          new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=C, L1=:=0, 
          new188(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=C, L1=:=0, 
          new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=C, L1=:=0, 
          new189(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new184(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=M, L1=:=0, 
          new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new184(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=M, L1=:=0, 
          new185(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new184(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=M, L1=:=0, 
          new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,F1)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,L1)), 
          new184(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,K1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=N, L1=:=O, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1, K1=:=N, L1=:=O, 
          new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new179(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,L1,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,G1,H1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=M, H1=:=5, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=5, 
          new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=5, 
          new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=2, H1=:=1, I1=:=2, 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1)), 
          new166(s(H1,K1,I1,M1,N1,O1,P1,Q1,R1,G1,T1,U1,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, I1=:=1, 
          new167(s(A,B,C,D,E,F,G,H,I,I1,H1,G1,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=N, H1=:=O, 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1, G1=:=N, H1=:=O, 
          new166(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1+I1, H1=:=N, I1=:=1, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,G1,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1, G1=:=M, H1=:=5, 
          new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=M, H1=:=5, 
          new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=<H1, G1=:=M, H1=:=5, 
          new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=M, H1=:=5, 
          new162(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=K, H1=:=I1+J1, I1=:=L, J1=:=1, 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=K, H1=:=I1+J1, I1=:=L, J1=:=1, 
          new158(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=K, H1=:=I1+J1, I1=:=L, J1=:=1, 
          new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=A, H1=:=1, 
          new155(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=A, H1=:=1, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=A, H1=:=1, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=0, 
          new175(s(A,B,C,D,E,F,G,H,I,J,K,L,M,G1,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=A, H1=:=0, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=A, H1=:=0, 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=A, H1=:=0, 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1,M1,N1),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)), 
          new119(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=1, 
          new147(s(A,B,M1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=1, 
          new147(s(A,B,M1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1,F1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=M, F1=:=N, G1=:=1, H1=:=2, 
          new141(s(A,G1,C,H1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1, E1=:=M, F1=:=N, 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z),d(M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1)).
new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=2, F1=:=G1+H1, G1=:=M, H1=:=1, 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new139(s(I1,J1,K1,L1,M1,N1,O1,P1,E1,R1,S1,T1,F1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1+G1, F1=:=K, G1=:=1, H1=:=1, 
          new137(s(A,B,C,D,E,F,G,H,H1,J,E1,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=B, F1=:=1, 
          new134(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=B, F1=:=1, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=B, F1=:=1, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=0, 
          new144(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=B, F1=:=0, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=B, F1=:=0, 
          new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=B, F1=:=0, 
          new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new129(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new122(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=0, M1=:=1, 
          new126(s(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=0, M1=:=1, 
          new126(s(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=0, 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1+M1, L1=:=N, M1=:=1, 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=D, L1=:=0, 
          new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=D, L1=:=0, 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=D, L1=:=0, 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=C, L1=:=0, 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=C, L1=:=0, 
          new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=C, L1=:=0, 
          new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=M, L1=:=0, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=M, L1=:=0, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=M, L1=:=0, 
          new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,L1)), 
          new114(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,K1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=N, L1=:=O, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1, K1=:=N, L1=:=O, 
          new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,L1,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=D, B1=:=0, C1=:=1, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=D, B1=:=0, C1=:=1, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new96(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new93(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new93(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new90(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new93(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new90(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new90(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new90(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new87(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new81(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new78(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new75(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new70(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new72(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new70(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new70(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new84(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new68(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new70(s(A,B,C,D,E,F,G,H,I,J,K,L),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new44(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,G1,H1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new68(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new64(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,M,H,I,J,K,L)) :- M=:=1.
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, E1=:=1, 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, E1=:=1, 
          new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=O, L1=:=0, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=O, L1=:=0, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=O, L1=:=0, M1=:=N1+O1, N1=:=P, O1=:=1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,M1,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new53(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new59(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,G1,H1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new47(s(A,B,C,D,E,F,G,H,I,J,K,L,M1,N1),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,L1)), 
          new48(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,M,N,K1,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new63(s(A,B,C,D,E,F,G,H,I,J,K,L),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new65(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=N, L1=:=0, M1=:=4, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=N, L1=:=0, 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=N, L1=:=0, 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=C, B1=:=0, C1=:=1, 
          new96(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, B1=:=0, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=0, 
          new97(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=C, B1=:=0, C1=:=1, 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, B1=:=0, 
          new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=0, 
          new103(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,F1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,L1)), 
          new42(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,M,K1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new39(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,G1,H1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new36(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new33(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=3, 
          new30(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new27(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1,G1,H1,I1,J1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,K1,L1,M1,N1,O1,P1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=2, 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,L1,M1,N1,O1,P1,Q1),d(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2)), 
          new29(s(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,K1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=P, L1=:=Q, M1=:=1, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1, K1=:=P, L1=:=Q, 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1,L1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new253(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new253(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new253(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new265(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new265(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new265(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1)), 
          new22(s(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,M,N,O,K1,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new277(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new278(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new301(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new277(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new303(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,G1,H1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new19(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=0, A1=:=1, 
          new327(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=0, new327(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=0, new327(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=0, A1=:=1, 
          new339(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=0, new339(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=0, new339(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new16(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=E, 
          Z=:=1, A1=:=0, 
          new351(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=1, A1=:=2, 
          new351(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=1, A1=:=2, 
          new351(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=E, 
          Z=:=1, A1=:=0, 
          new357(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=1, A1=:=2, 
          new357(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=1, A1=:=2, 
          new357(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,M,N,O,P,Q,R)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1)), 
          new13(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,M)) :- 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,Z,A1,B1,C1,D1,E1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,F1,G1,H1,I1,J1,K1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,M,N,G,H,I,J,K,L)) :- M=:=1, N=:=1.
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,M)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(N,O,P,Q,R,S,T,U,V,W,X,Y)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)), 
          new7(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X,Z)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, J=:=2, 
          K=:=0, L=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
inv1 :- \+new1.
