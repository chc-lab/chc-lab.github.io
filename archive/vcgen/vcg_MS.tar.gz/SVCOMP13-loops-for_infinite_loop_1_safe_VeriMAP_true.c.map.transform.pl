new22(s(A),d(B)) :- new22(s(A),d(B)).
new21(s(A),d(A)).
new12(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new12(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new12(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new20(s(A),d(B)).
new11(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new21(s(A),d(B)).
new10(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=1, G=:=H, G=:=B, H=:=0, 
          new11(s(F),d(I)).
new10(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G>=H+1, G=:=B, H=:=0, 
          new11(s(F),d(I)).
new10(s(A,B,C,D,E),d(A,B,C,D,E)) :- F=:=0, G+1=<H, G=:=B, H=:=0, 
          new11(s(F),d(I)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L=:=M, L=:=B, M=:=0, N=:=O+P, O=:=A, 
          P=:=1, new12(s(K),d(Q)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L>=M+1, L=:=B, M=:=0, N=:=O+P, 
          O=:=A, P=:=1, new12(s(K),d(Q)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new10(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L+1=<M, L=:=B, M=:=0, N=:=O+P, 
          O=:=A, P=:=1, new12(s(K),d(Q)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new8(s(A,B,C,D,E),d(F,G,H,I,J)) :- new10(s(A,B,C,D,E),d(F,G,H,I,J)).
new6(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new6(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new6(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new22(s(A),d(B)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=1, L>=M+1, L=:=D, M=:=0, N=:=0, 
          new6(s(K),d(O)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new5(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=<M, L=:=D, M=:=0, N=:=0, 
          new6(s(K),d(O)), new8(s(N,B,C,D,E),d(F,G,H,I,J)).
new4(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=L, new5(s(A,B,C,K,L),d(F,G,H,I,J)).
new3(s(A,B,C,D,E),d(F,G,H,I,J)) :- K=:=0, L=:=0, M=:=0, 
          new4(s(K,L,M,D,E),d(F,G,H,I,J)).
new2(s,d) :- new3(s(A,B,C,D,E),d(F,G,H,I,J)).
new1 :- new2(s,d).
inv1 :- \+new1.
