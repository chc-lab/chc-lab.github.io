new12(s(A),d(B)) :- new12(s(A),d(B)).
new11(s(A,B),d(A,B)) :- C+1=<D, C=:=E+F, E=:=A, F=:=B, D=:=10000.
new9(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=10000, G=:=H+I, H=:=A, I=:=1, 
          J=:=K+L, K=:=B, L=:=1, new7(s(G,J),d(C,D)).
new9(s(A,B),d(C,D)) :- E>=F, E=:=B, F=:=10000, new11(s(A,B),d(C,D)).
new7(s(A,B),d(C,D)) :- new9(s(A,B),d(C,D)).
new5(s(A),d(A)) :- B>=C+1, B=:=A, C=:=0.
new5(s(A),d(A)) :- B+1=<C, B=:=A, C=:=0.
new5(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new12(s(A),d(B)).
new4(s(A,B),d(C,D)) :- E=:=1, F>=G, F=:=A, G=:=0, new5(s(E),d(H)), 
          new7(s(A,B),d(C,D)).
new4(s(A,B),d(C,D)) :- E=:=0, F+1=<G, F=:=A, G=:=0, new5(s(E),d(H)), 
          new7(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- E=:=0, new4(s(A,E),d(C,D)).
new2(s,d) :- new3(s(A,B),d(C,D)).
new1 :- new2(s,d).
inv1 :- \+new1.
