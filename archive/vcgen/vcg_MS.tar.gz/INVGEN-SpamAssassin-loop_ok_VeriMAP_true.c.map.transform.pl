new22(s(A,B),d(A,B)).
new16(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new16(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new16(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new21(s(A,B),d(A,C)).
new15(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new22(s(A,B),d(A,C)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=0, I=:=C, 
          new15(s(A,G),d(A,J)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=0, O=:=C, P=:=Q+R, 
          Q=:=D, R=:=1, S=:=T+U, T=:=C, U=:=1, new16(s(A,M),d(A,V)), 
          new6(s(A,B,S,P,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=0, O=:=C, P=:=Q+R, 
          Q=:=D, R=:=1, S=:=T+U, T=:=C, U=:=1, new16(s(A,M),d(A,V)), 
          new6(s(A,B,S,P,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, O=:=P+Q, P=:=D, 
          Q=:=1, R=:=S+T, S=:=C, T=:=1, U=:=V+W, V=:=O, W=:=1, X=:=Y+Z, Y=:=R, 
          Z=:=1, A1=:=B1+C1, B1=:=U, C1=:=1, 
          new6(s(A,B,X,A1,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=O+P, O=:=C, P=:=1, N=:=B, 
          new13(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=O+P, O=:=C, P=:=1, N=:=B, 
          new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=F, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=F, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=B, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=B, 
          new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=B, O=:=0, 
          new6(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N-O, N=:=E, O=:=4, P=:=0, 
          new4(s(A,B,P,D,E,M),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
