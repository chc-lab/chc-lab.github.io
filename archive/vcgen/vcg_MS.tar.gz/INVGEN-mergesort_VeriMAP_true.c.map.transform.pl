new36(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z+A1, 
          Z=:=E, A1=:=1, 
          new12(s(A,B,C,D,Y,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=0, A1=:=B1+C1, B1=:=B, C1=:=1, 
          new36(s(A,A1,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=0, A1=:=B1+C1, B1=:=B, C1=:=1, 
          new36(s(A,A1,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new34(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=0, A1=:=B1+C1, B1=:=I, C1=:=1, 
          new36(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=H, A1=:=B1+C1, B1=:=E, C1=:=1, 
          new28(s(A,B,C,D,A1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=E, 
          Z=:=H, A1=:=B1+C1, B1=:=L, C1=:=D1*E1, D1=:=J, E1=:=2, 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,A1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=H, A1=:=B1+C1, B1=:=I, C1=:=1, D1=:=E1+F1, E1=:=E, F1=:=1, 
          new25(s(A,B,C,D,D1,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=I, 
          Z=:=H, A1=:=F, 
          new28(s(A,B,C,D,A1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new26(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=G, A1=:=B1+C1, B1=:=B, C1=:=1, D1=:=E1+F1, E1=:=E, F1=:=1, 
          new21(s(A,A1,C,D,D1,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=B, 
          Z=:=G, new25(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)) :- N>=O+1, 
          N=:=M, O=:=0.
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)) :- N+1=<O, 
          N=:=M, O=:=0.
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O=:=P, 
          O=:=M, P=:=0, 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)) :- O=:=P, 
          O=:=M, P=:=0, 
          new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,N)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- M=:=1, N=<O, 
          N=:=E, O=:=C, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,P)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- M=:=0, N>=O+1, 
          N=:=E, O=:=C, 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,P)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=1, Z=<A1, 
          Z=:=E, A1=:=C, 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,Y),d(A,B,C,D,E,F,G,H,I,J,K,L,B1)), 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=0, Z>=A1+1, 
          Z=:=E, A1=:=C, 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,Y),d(A,B,C,D,E,F,G,H,I,J,K,L,B1)), 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=H, new34(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=I, 
          Z=:=H, new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=G, new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z, Y=:=B, 
          Z=:=G, new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new13(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=L, 
          Z=:=A1+B1, A1=:=L, B1=:=J, C1=:=K, D1=:=Y, E1=:=Z, F1=:=Y, 
          new12(s(A,D1,C,D,F1,Y,Z,C1,E1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=C, A1=:=B1+C1, B1=:=C, C1=:=1, 
          new10(s(A,B,C,D,E,F,G,H,I,J,A1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=<Z, Y=:=K, 
          Z=:=C, new10(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=<Z, Y=:=A1+B1, 
          A1=:=L, B1=:=J, Z=:=C, C1=:=D1+E1, D1=:=L, E1=:=F1*G1, F1=:=J, 
          G1=:=2, new8(s(A,B,C,D,E,F,G,H,I,J,C1,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, 
          Y=:=A1+B1, A1=:=L, B1=:=J, Z=:=C, C1=:=D1*E1, D1=:=J, E1=:=2, 
          new4(s(A,B,C,D,E,F,G,H,I,C1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new7(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=C, A1=:=1, 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,A1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=1, 
          new4(s(A,B,C,D,E,F,G,H,I,Y,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=0, 
          K=:=0, L=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
inv1 :- \+new1.
