new14(s(A,B),d(A,B)).
new11(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new14(s(A,B),d(A,C)).
new10(s(A,B),d(A,B)) :- C=:=1, D>=E+1, D=:=A, E=:=10, new11(s(A,C),d(A,F)).
new10(s(A,B),d(A,B)) :- C=:=1, D+1=<E, D=:=A, E=:=10, new11(s(A,C),d(A,F)).
new10(s(A,B),d(A,B)) :- C=:=0, D=:=E, D=:=A, E=:=10, new11(s(A,C),d(A,F)).
new8(s(A,B),d(C,D)) :- E+1=<F, E=:=B, F=:=10, new4(s(A,B),d(C,D)).
new8(s(A,B),d(C,D)) :- E>=F, E=:=B, F=:=10, new10(s(A,B),d(C,D)).
new7(s(A),d(B)) :- B=:=C+D, C=:=A, D=:=1.
new5(s(A,B),d(C,B)) :- new6(s(A),d(C)).
new5(s(A,B),d(C,D)) :- E=:=F, new7(s(A),d(F)), new8(s(F,E),d(C,D)).
new4(s(A,B),d(C,D)) :- new5(s(A,B),d(C,D)).
new3(s(A,B),d(C,D)) :- new4(s(A,B),d(C,D)).
new2(s(A),d(B)) :- new3(s(A,C),d(B,D)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
