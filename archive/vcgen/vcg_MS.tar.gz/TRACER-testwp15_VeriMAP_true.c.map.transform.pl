new13(s(A,B),d(A,B)).
new12(s(A,B),d(A,B)).
new10(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new12(s(A,B),d(A,C)).
new9(s(A,B,C),d(A,B,C)) :- D=:=1, E>=F+1, E=:=G+H, G=:=B, H=:=C, F=:=0, 
          new10(s(A,D),d(A,I)).
new9(s(A,B,C),d(A,B,C)) :- D=:=0, E=<F, E=:=G+H, G=:=B, H=:=C, F=:=0, 
          new10(s(A,D),d(A,I)).
new8(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=3, new13(s(G,B),d(C,D)).
new8(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=1, new13(s(A,G),d(C,D)).
new7(s(A,B),d(C,D)) :- E>=F+1, E=:=B, F=:=0, G=:=3, new15(s(G,B),d(C,D)).
new7(s(A,B),d(C,D)) :- E=<F, E=:=B, F=:=0, G=:=1, new15(s(A,G),d(C,D)).
new6(s(A,B,C),d(D,B,C)) :- new7(s(A,E),d(D,F)).
new6(s(A,B,C),d(D,E,F)) :- G=:=H, new8(s(A,I),d(J,H)), new9(s(J,B,G),d(D,E,F)).
new4(s(A,B,C),d(D,E,F)) :- new6(s(A,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G>=H+1, G=:=B, H=:=0, I=:=2, new4(s(I,B,C),d(D,E,F)).
new3(s(A,B,C),d(D,E,F)) :- G=<H, G=:=B, H=:=0, I=:=0, new4(s(A,I,C),d(D,E,F)).
new2(s(A),d(B)) :- new3(s(A,C,D),d(B,E,F)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
