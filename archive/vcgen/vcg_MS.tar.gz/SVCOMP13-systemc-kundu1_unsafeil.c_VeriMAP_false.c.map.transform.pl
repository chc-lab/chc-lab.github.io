new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=N, H1=:=1, I1=:=0, 
          new306(s(A,B,C,D,E,F,G,H,I,J,K,L,I1,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=N, H1=:=1, I1=:=2, 
          new306(s(A,B,C,D,E,F,G,H,I,J,K,L,I1,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new303(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=N, H1=:=1, I1=:=2, 
          new306(s(A,B,C,D,E,F,G,H,I,J,K,L,I1,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new300(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=N, H1=:=1, I1=:=0, 
          new300(s(A,B,C,D,E,F,G,H,I,J,K,L,I1,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=N, H1=:=1, I1=:=2, 
          new300(s(A,B,C,D,E,F,G,H,I,J,K,L,I1,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new297(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=N, H1=:=1, I1=:=2, 
          new300(s(A,B,C,D,E,F,G,H,I,J,K,L,I1,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, 
          new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=1, K1=:=1, 
          new293(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=1, 
          new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=1, 
          new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, 
          new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=1, K1=:=1, 
          new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=1, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=1, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=2, 
          new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=2, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=2, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=D, J1=:=1, K1=:=1, 
          new283(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=D, J1=:=1, 
          new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=D, J1=:=1, 
          new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=0, M1=:=0, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=0, M1=:=0, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=0, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=1, 
          new277(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=1, 
          new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=1, 
          new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new268(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,Q,R)) :- 
          new271(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,J1)).
new268(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,L1)), 
          new273(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=0, 
          new268(s(A,B,C,D,E,F,G,H,M1,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=0, 
          new268(s(A,B,C,D,E,F,G,H,M1,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new268(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=H, J1=:=1, 
          new290(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=H, J1=:=1, 
          new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=H, J1=:=1, 
          new291(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, 
          new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=K, J1=:=1, K1=:=1, 
          new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=K, J1=:=1, 
          new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=K, J1=:=1, 
          new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=0, 
          new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=O, J1=:=1, K1=:=1, 
          new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=O, J1=:=1, 
          new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=O, J1=:=1, 
          new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=2, 
          new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=2, 
          new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=2, 
          new249(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=D, J1=:=1, K1=:=1, 
          new251(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=D, J1=:=1, 
          new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=D, J1=:=1, 
          new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new241(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=R, L1=:=0, M1=:=0, 
          new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new241(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=R, L1=:=0, M1=:=0, 
          new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M1,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new241(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=R, L1=:=0, 
          new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=1, 
          new245(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=1, 
          new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=1, 
          new246(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new240(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,L1)), 
          new241(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,Q,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=0, 
          new237(s(A,B,C,D,E,F,G,H,M1,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=0, 
          new237(s(A,B,C,D,E,F,G,H,M1,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new236(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=H, J1=:=1, 
          new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=H, J1=:=1, 
          new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=H, J1=:=1, 
          new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)) :- 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=1, M1=:=R, 
          new227(s(A,B,C,D,E,F,M1,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=1, 
          new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=1, 
          new231(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, M1=:=R, 
          new227(s(A,B,C,D,E,M1,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, 
          new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, 
          new228(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=B, H1=:=65, 
          new224(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,G1,H1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,I1,J1)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=B, H1=:=65, I1=:=J1+K1, J1=:=L1, K1=:=1, M1=:=1, N1=:=2, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,G1,H1),d(O1,L1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new223(s(O1,I1,P1,Q1,R1,S1,T1,M1,N1,W1,X1,Y1,Z1,A2,B2,C2),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new221(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=C, H1=:=A, 
          new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new221(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1, G1=:=C, H1=:=A, I1=:=2, 
          new223(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new221(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=H, H1=:=1, 
          new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=H, H1=:=1, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=H, H1=:=1, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new218(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=H, H1=:=0, 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=H, H1=:=0, 
          new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=H, H1=:=0, 
          new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1)).
new209(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new165(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=0, O1=:=1, 
          new209(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=0, O1=:=1, 
          new209(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=0, 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)) :- 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=1, O1=:=G, 
          new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=1, 
          new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=1, 
          new203(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=0, O1=:=F, 
          new199(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=0, 
          new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=0, 
          new200(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,Q)) :- 
          H1=:=B, 
          new196(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,H1,I1,J1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,K1,L1,M1)).
new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=B, J1=:=K1, L1=:=M1+N1, M1=:=O1, N1=:=1, P1=:=2, Q1=:=2, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1,R1,S1),d(T1,U1,O1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K1)), 
          new188(s(T1,U1,L1,V1,W1,X1,Y1,Z1,A2,B2,C2,P1,Q1,F2,G2,H2,J1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new194(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new195(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)) :- 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new192(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=B, J1=:=0, 
          new194(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=0, K1=:=1, L1=:=M1+N1, M1=:=C, N1=:=1, O1=:=1, 
          P1=:=2, 
          new188(s(A,B,L1,D,K1,F,G,H,I,J,K,O1,P1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=0, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=A, 
          new187(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=C, J1=:=A, K1=:=2, 
          new188(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new183(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=2, 
          new183(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=2, 
          new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=2, 
          new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1-K1, J1=:=B, K1=:=1, 
          new192(s(A,I1,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=1, 
          new180(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=1, 
          new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=1, 
          new181(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new183(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=0, 
          new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=0, 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=0, 
          new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,J1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,K1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)), 
          new156(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, O1=:=1, 
          new171(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, O1=:=1, 
          new171(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=0, 
          new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new208(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=I, N1=:=0, 
          new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=I, N1=:=0, 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=I, N1=:=0, 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=S, N1=:=0, 
          new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=S, N1=:=0, 
          new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=S, N1=:=0, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,J1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,K1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,N1)), 
          new160(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,Q,R,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=1, M1=:=R, 
          new149(s(A,B,C,D,E,F,M1,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=1, 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=1, 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new149(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, M1=:=R, 
          new149(s(A,B,C,D,E,M1,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new146(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=B, H1=:=65, I1=:=J1+K1, J1=:=L1, K1=:=1, M1=:=1, N1=:=2, 
          new147(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,G1,H1),d(O1,L1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2)), 
          new146(s(O1,I1,P1,Q1,R1,S1,T1,M1,N1,W1,X1,Y1,Z1,A2,B2,C2),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=C, H1=:=A, 
          new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1, G1=:=C, H1=:=A, I1=:=2, 
          new146(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new144(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=H, H1=:=1, 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=H, H1=:=1, 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=H, H1=:=1, 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new138(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new141(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=H, H1=:=0, 
          new138(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=H, H1=:=0, 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=H, H1=:=0, 
          new139(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new133(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new93(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=0, O1=:=1, 
          new133(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=0, O1=:=1, 
          new133(s(A,B,C,D,E,F,G,H,O1,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=1, O1=:=G, 
          new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=1, 
          new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=1, 
          new129(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=Q, N1=:=0, O1=:=F, 
          new125(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,O1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=Q, N1=:=0, 
          new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=Q, N1=:=0, 
          new126(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=B, J1=:=K1, L1=:=M1+N1, M1=:=O1, N1=:=1, P1=:=2, Q1=:=2, 
          new123(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1,R1,S1),d(T1,U1,O1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K1)), 
          new115(s(T1,U1,L1,V1,W1,X1,Y1,Z1,A2,B2,C2,P1,Q1,F2,G2,H2,J1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new120(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=B, J1=:=0, 
          new121(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=B, J1=:=0, K1=:=1, L1=:=M1+N1, M1=:=C, N1=:=1, O1=:=1, 
          P1=:=2, 
          new115(s(A,B,L1,D,K1,F,G,H,I,J,K,O1,P1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=B, J1=:=0, 
          new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=B, J1=:=0, 
          new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=C, J1=:=A, 
          new114(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1, I1=:=C, J1=:=A, K1=:=2, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,K1,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=2, 
          new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=2, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=2, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1-K1, J1=:=B, K1=:=1, 
          new119(s(A,I1,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=1, 
          new107(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=1, 
          new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=1, 
          new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          new110(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=L, J1=:=0, 
          new104(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=L, J1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=L, J1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new99(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new102(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2)), 
          new85(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, O1=:=1, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, O1=:=1, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,O1,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, 
          new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new98(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=M, N1=:=0, 
          new95(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=M, N1=:=0, 
          new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=M, N1=:=0, 
          new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new132(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new91(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=I, N1=:=0, 
          new92(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=I, N1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=I, N1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=S, N1=:=0, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=S, N1=:=0, 
          new89(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new88(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=S, N1=:=0, 
          new91(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,N1)), 
          new88(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,Q,R,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new86(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=M, J1=:=0, K1=:=1, 
          new79(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=M, J1=:=0, K1=:=0, 
          new79(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=M, J1=:=0, K1=:=0, 
          new79(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=M, J1=:=0, K1=:=1, 
          new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=M, J1=:=0, K1=:=0, 
          new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=M, J1=:=0, K1=:=0, 
          new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=O, H1=:=1, I1=:=2, 
          new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=O, H1=:=1, 
          new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=O, H1=:=1, 
          new70(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P)).
new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=O, H1=:=1, I1=:=2, 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=O, H1=:=1, 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=O, H1=:=1, 
          new64(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=K, H1=:=1, I1=:=2, 
          new61(s(A,B,C,D,E,F,G,H,I,J,I1,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=K, H1=:=1, 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=K, H1=:=1, 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=K, H1=:=1, I1=:=2, 
          new67(s(A,B,C,D,E,F,G,H,I,J,I1,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=K, H1=:=1, 
          new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=K, H1=:=1, 
          new67(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new58(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1)).
new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new59(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new33(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,J1,K1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,L1,M1)).
new54(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,N1),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2)), 
          new57(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,J,Q,L,M,N,R,P)) :- 
          R=:=1, Q=:=1.
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=0, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=0, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new48(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, M1=:=1, 
          new49(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=0, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=0, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new42(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, K1=:=Q, L1=:=0, M1=:=1, 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=S, N1=:=0, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=S, N1=:=0, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=S, N1=:=0, 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,L1)), 
          new42(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,Q,R)) :- 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,J1)).
new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,L1)), 
          new48(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new35(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,J1,K1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,L1,M1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,P1),d(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,N1)), 
          new37(s(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,Q,R,M1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new52(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1)).
new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new53(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new54(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, M1=:=R, N1=:=0, O1=:=4, 
          new32(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1>=N1+1, M1=:=R, N1=:=0, 
          new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new31(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1+1=<N1, M1=:=R, N1=:=0, 
          new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=I, J1=:=0, K1=:=1, 
          new73(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=I, J1=:=0, 
          new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=I, J1=:=0, 
          new74(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1=:=J1, I1=:=I, J1=:=0, K1=:=1, 
          new79(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,K1),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1>=J1+1, I1=:=I, J1=:=0, 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)) :- 
          I1+1=<J1, I1=:=I, J1=:=0, 
          new80(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q),d(R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new29(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,J1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,K1)).
new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=N1, 
          new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,O1),d(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,N1)), 
          new31(s(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,Q,M1,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new28(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,J1,K1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,L1,M1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,N1),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2)), 
          new27(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=3, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new85(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,J1,K1,L1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,M1,N1,O1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=2, 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,N1,O1,P1),d(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2)), 
          new22(s(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=1, 
          new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,L1)), 
          new236(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,Q,R)) :- 
          new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,J1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=L1, 
          new235(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1),d(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,L1)), 
          new267(s(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,K1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,J1,K1),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,L1,M1)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,N1),d(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2)), 
          new17(s(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=J, H1=:=1, I1=:=0, 
          new297(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=J, H1=:=1, I1=:=2, 
          new297(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=J, H1=:=1, I1=:=2, 
          new297(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1=:=H1, G1=:=J, H1=:=1, I1=:=0, 
          new303(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1>=H1+1, G1=:=J, H1=:=1, I1=:=2, 
          new303(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          G1+1=<H1, G1=:=J, H1=:=1, I1=:=2, 
          new303(s(A,B,C,D,E,F,G,H,I1,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Q,R,S)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new12(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2)), 
          new13(s(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)) :- 
          M1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R,S),d(T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,Q,R)) :- 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1,J1,K1),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,L1,M1,N1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(A,B,C,D,E,F,G,H,I,Q,K,L,M,R,O,P)) :- 
          Q=:=1, R=:=1.
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,Q,R)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1)), 
          new7(s(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)) :- 
          K1=:=0, L1=:=0, M1=:=2, N1=:=0, O1=:=0, P1=:=0, Q1=:=0, 
          new4(s(M1,K1,L1,D,N1,F,G,O1,I,J,K,P1,M,N,O,P,Q1,R),d(S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,G1,H1),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,I1,J1)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=0, 
          K=:=0, L=:=0, M=:=0, N=:=0, O=:=0, P=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P),d(Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1)).
inv1 :- \+new1.
