new155(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new155(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new155(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=D, O=:=B, P=:=Q+R, 
          Q=:=E, R=:=1, new11(s(A,M),d(A,S)), 
          new36(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new155(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=D, O=:=B, P=:=Q+R, 
          Q=:=E, R=:=1, new11(s(A,M),d(A,S)), 
          new36(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new149(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new149(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new149(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new155(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new149(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new155(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new143(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=E, I=:=B, 
          new10(s(A,G),d(A,J)).
new143(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=E, I=:=B, 
          new10(s(A,G),d(A,J)).
new143(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=E, O=:=B, 
          new11(s(A,M),d(A,P)), new149(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new143(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=E, O=:=B, 
          new11(s(A,M),d(A,P)), new149(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new131(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=E, I=:=B, 
          new10(s(A,G),d(A,J)).
new131(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=E, I=:=B, 
          new10(s(A,G),d(A,J)).
new131(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=E, O=:=B, P=:=Q+R, 
          Q=:=F, R=:=1, new11(s(A,M),d(A,S)), 
          new71(s(A,B,C,D,E,P),d(G,H,I,J,K,L)).
new131(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=E, O=:=B, P=:=Q+R, 
          Q=:=F, R=:=1, new11(s(A,M),d(A,S)), 
          new71(s(A,B,C,D,E,P),d(G,H,I,J,K,L)).
new125(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=E, 
          new10(s(A,G),d(A,J)).
new125(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=E, 
          new10(s(A,G),d(A,J)).
new125(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=E, 
          new11(s(A,M),d(A,P)), new131(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new125(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=E, 
          new11(s(A,M),d(A,P)), new131(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new119(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=F, I=:=B, 
          new10(s(A,G),d(A,J)).
new119(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=F, I=:=B, 
          new10(s(A,G),d(A,J)).
new119(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=F, O=:=B, 
          new11(s(A,M),d(A,P)), new125(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new119(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=F, O=:=B, 
          new11(s(A,M),d(A,P)), new125(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new107(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new107(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new107(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=D, O=:=B, P=:=Q+R, 
          Q=:=F, R=:=1, new11(s(A,M),d(A,S)), 
          new75(s(A,B,C,D,E,P),d(G,H,I,J,K,L)).
new107(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=D, O=:=B, P=:=Q+R, 
          Q=:=F, R=:=1, new11(s(A,M),d(A,S)), 
          new75(s(A,B,C,D,E,P),d(G,H,I,J,K,L)).
new101(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new101(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new101(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new107(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new101(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new107(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new95(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=E, I=:=B, 
          new10(s(A,G),d(A,J)).
new95(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=E, I=:=B, 
          new10(s(A,G),d(A,J)).
new95(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=E, O=:=B, 
          new11(s(A,M),d(A,P)), new101(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new95(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=E, O=:=B, 
          new11(s(A,M),d(A,P)), new101(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new89(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=E, 
          new10(s(A,G),d(A,J)).
new89(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=E, 
          new10(s(A,G),d(A,J)).
new89(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=E, 
          new11(s(A,M),d(A,P)), new95(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new89(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=E, 
          new11(s(A,M),d(A,P)), new95(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new83(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=F, I=:=B, 
          new10(s(A,G),d(A,J)).
new83(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=F, I=:=B, 
          new10(s(A,G),d(A,J)).
new83(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=F, O=:=B, 
          new11(s(A,M),d(A,P)), new89(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new83(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=F, O=:=B, 
          new11(s(A,M),d(A,P)), new89(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new77(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=F, 
          new10(s(A,G),d(A,J)).
new77(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=F, 
          new10(s(A,G),d(A,J)).
new77(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=F, 
          new11(s(A,M),d(A,P)), new83(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new77(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=F, 
          new11(s(A,M),d(A,P)), new83(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new76(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=F, N=:=B, 
          new77(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new76(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=B, O=:=P+Q, P=:=E, 
          Q=:=1, new69(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new75(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new76(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new74(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=F, 
          new10(s(A,G),d(A,J)).
new74(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=F, 
          new10(s(A,G),d(A,J)).
new74(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=F, 
          new11(s(A,M),d(A,P)), new119(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new74(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=F, 
          new11(s(A,M),d(A,P)), new119(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new73(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=F, N=:=B, 
          new74(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new73(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=F, N=:=B, O=:=C, 
          new75(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new71(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new73(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new70(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, O=:=C, 
          new71(s(A,B,C,D,E,O),d(G,H,I,J,K,L)).
new70(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, 
          new38(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new69(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new70(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new68(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=E, 
          new10(s(A,G),d(A,J)).
new68(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=E, 
          new10(s(A,G),d(A,J)).
new68(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=E, 
          new11(s(A,M),d(A,P)), new143(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new68(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=E, 
          new11(s(A,M),d(A,P)), new143(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new67(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new68(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new67(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, O=:=C, 
          new69(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new59(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new59(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new59(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=D, O=:=B, P=:=Q+R, 
          Q=:=E, R=:=1, new11(s(A,M),d(A,S)), 
          new39(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new59(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=D, O=:=B, P=:=Q+R, 
          Q=:=E, R=:=1, new11(s(A,M),d(A,S)), 
          new39(s(A,B,C,D,P,F),d(G,H,I,J,K,L)).
new53(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new53(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new59(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new59(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new47(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=E, I=:=B, 
          new10(s(A,G),d(A,J)).
new47(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=E, I=:=B, 
          new10(s(A,G),d(A,J)).
new47(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=E, O=:=B, 
          new11(s(A,M),d(A,P)), new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new47(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=E, O=:=B, 
          new11(s(A,M),d(A,P)), new53(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new41(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=E, 
          new10(s(A,G),d(A,J)).
new41(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=E, 
          new10(s(A,G),d(A,J)).
new41(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=E, 
          new11(s(A,M),d(A,P)), new47(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new41(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=E, 
          new11(s(A,M),d(A,P)), new47(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new40(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, 
          new41(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new40(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new39(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new40(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new38(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=C, 
          new39(s(A,B,C,D,M,F),d(G,H,I,J,K,L)).
new36(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new67(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new35(s(A,B),d(A,B)).
new26(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new26(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new26(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=D, O=:=B, P=:=D, 
          Q=:=R-S, R=:=D, S=:=1, new11(s(A,M),d(A,T)), 
          new4(s(A,B,P,Q,E,F),d(G,H,I,J,K,L)).
new26(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=D, O=:=B, P=:=D, 
          Q=:=R-S, R=:=D, S=:=1, new11(s(A,M),d(A,T)), 
          new4(s(A,B,P,Q,E,F),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new20(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new26(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new26(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new14(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=D, I=:=B, 
          new10(s(A,G),d(A,J)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=D, O=:=B, 
          new11(s(A,M),d(A,P)), new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=D, O=:=B, 
          new11(s(A,M),d(A,P)), new20(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new11(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new11(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new11(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new34(s(A,B),d(A,C)).
new10(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new35(s(A,B),d(A,C)).
new9(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new9(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new10(s(A,G),d(A,J)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, 
          new11(s(A,M),d(A,P)), new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=C, 
          new36(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=C, 
          new36(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new38(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=D, N=:=B, 
          new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new6(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=B, 
          new8(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=D, N=:=1, O=:=P+Q, P=:=D, 
          Q=:=1, new6(s(A,B,O,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new5(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=B, 
          new4(s(A,B,C,M,E,F),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
