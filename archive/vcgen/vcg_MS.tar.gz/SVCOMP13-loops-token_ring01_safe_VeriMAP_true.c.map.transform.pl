new317(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=F, 
          Z=:=1, A1=:=0, 
          new320(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new317(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=F, 
          Z=:=1, A1=:=2, 
          new320(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new317(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=F, 
          Z=:=1, A1=:=2, 
          new320(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new314(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new311(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=F, 
          Z=:=1, A1=:=0, 
          new314(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new311(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=F, 
          Z=:=1, A1=:=2, 
          new314(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new311(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=F, 
          Z=:=1, A1=:=2, 
          new314(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=0, A1=:=1, 
          new308(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new308(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new308(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=0, A1=:=1, 
          new305(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new299(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=0, A1=:=1, 
          new302(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new299(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new299(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new296(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new293(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=0, A1=:=1, 
          new296(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new293(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new296(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new293(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new296(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=0, A1=:=1, 
          new293(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new293(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new290(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new293(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=0, A1=:=1, 
          new290(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new290(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new287(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new290(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new283(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=I, B1=:=1, C1=:=1, 
          new283(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=I, B1=:=1, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=1, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new276(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=J, B1=:=1, C1=:=1, 
          new276(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=J, B1=:=1, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=J, B1=:=1, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=N, D1=:=0, E1=:=0, 
          new270(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=N, D1=:=0, E1=:=0, 
          new270(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=N, D1=:=0, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=B, B1=:=1, 
          new273(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=B, B1=:=1, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new267(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=B, B1=:=1, 
          new274(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new267(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new242(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new269(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new264(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new264(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, 
          new264(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new280(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=1, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new261(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=1, 
          new281(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new257(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=I, B1=:=1, C1=:=1, 
          new257(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=I, B1=:=1, 
          new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=1, 
          new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new250(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new250(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new247(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=J, B1=:=1, C1=:=1, 
          new250(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new247(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=J, B1=:=1, 
          new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new247(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=J, B1=:=1, 
          new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)).
new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=N, D1=:=0, E1=:=0, 
          new244(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=N, D1=:=0, E1=:=0, 
          new244(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new243(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=N, D1=:=0, 
          new244(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=B, B1=:=1, 
          new247(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=B, B1=:=1, 
          new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new242(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=B, B1=:=1, 
          new248(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new239(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new242(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new243(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new239(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new239(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new238(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, 
          new239(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=1, 
          new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new237(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=1, 
          new255(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new234(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new234(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new234(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new231(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new225(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new228(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new225(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new225(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new219(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new222(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new219(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new222(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new219(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new222(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new219(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new219(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new219(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new216(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new216(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new216(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new211(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new207(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new184(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new207(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, Z=:=1, 
          A1=:=2, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1)), 
          new210(s(Z,C1,A1,E1,F1,G1,H1,I1,J1,Y,L1,M1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new206(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, A1=:=1, 
          new207(s(A,B,C,D,E,F,G,H,I,A1,Z,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new206(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new203(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)) :- 
          new211(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new203(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new203(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new200(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=1, new200(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=1, new197(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=1, new197(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new197(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new194(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=0, new197(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new194(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=0, new198(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new194(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=0, new198(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new194(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new191(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new140(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new165(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, G1=:=1, 
          new191(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, G1=:=1, 
          new191(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new186(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=1, Z=:=2, 
          new187(s(A,Y,C,Z,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new184(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z),d(M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1)).
new183(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new184(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new183(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new186(s(Z,A1,B1,C1,D1,E1,F1,G1,Y,I1,J1,K1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new180(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z+A1, 
          Z=:=K, A1=:=1, B1=:=1, 
          new183(s(A,B,C,D,E,F,G,H,B1,J,Y,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=1, new180(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=1, new177(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=1, new177(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new186(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=0, new177(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=0, new178(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=0, new178(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new174(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new156(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=O, F1=:=0, G1=:=1, 
          new171(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=O, F1=:=0, G1=:=1, 
          new171(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=D, F1=:=0, 
          new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=D, F1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new190(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=C, F1=:=0, 
          new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=C, F1=:=0, 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=C, F1=:=0, 
          new165(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=M, F1=:=0, 
          new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=M, F1=:=0, 
          new161(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new160(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=M, F1=:=0, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,B1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1)), 
          new160(s(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, Z=:=1, 
          A1=:=2, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1)), 
          new154(s(Z,C1,A1,E1,F1,G1,H1,I1,J1,Y,L1,M1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new151(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, A1=:=1, 
          new152(s(A,B,C,D,E,F,G,H,I,A1,Z,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new151(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new148(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new148(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=1, new145(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=1, new142(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=1, new142(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new142(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=A, 
          Z=:=0, new142(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=A, 
          Z=:=0, new143(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=A, 
          Z=:=0, new143(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new140(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new113(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, G1=:=1, 
          new137(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, G1=:=1, 
          new137(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new133(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=1, Z=:=2, 
          new133(s(A,Y,C,Z,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z),d(M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new132(s(Z,A1,B1,C1,D1,E1,F1,G1,Y,I1,J1,K1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z+A1, 
          Z=:=K, A1=:=1, B1=:=1, 
          new130(s(A,B,C,D,E,F,G,H,B1,J,Y,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=1, new127(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=1, new124(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=1, new124(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new124(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new132(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=0, new124(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=0, new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=0, new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new105(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=O, F1=:=0, G1=:=1, 
          new119(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=O, F1=:=0, G1=:=1, 
          new119(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=D, F1=:=0, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=D, F1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=C, F1=:=0, 
          new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=C, F1=:=0, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=C, F1=:=0, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=M, F1=:=0, 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=M, F1=:=0, 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=M, F1=:=0, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1)), 
          new108(s(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=D, B1=:=0, C1=:=1, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=D, B1=:=0, C1=:=1, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new90(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new90(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new90(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new87(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new84(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new78(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new75(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new72(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new69(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new81(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new67(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new41(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new65(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new61(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,M,H,I,J,K,L)) :- M=:=1.
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, E1=:=1, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, E1=:=1, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=O, F1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=O, F1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new50(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new56(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,F1)), 
          new45(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,N,E1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new62(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, G1=:=4, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,G1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=C, B1=:=0, C1=:=1, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, B1=:=0, 
          new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=0, 
          new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=C, B1=:=0, C1=:=1, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, B1=:=0, 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=0, 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,B1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1)), 
          new39(s(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,M,E1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new36(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new33(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new30(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=3, 
          new27(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1,D1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,E1,F1,G1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=2, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1)), 
          new26(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new213(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new213(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new213(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new225(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new225(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new225(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new22(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new237(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new238(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new261(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new237(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new263(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new19(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=0, A1=:=1, 
          new287(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=0, new287(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=0, new287(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=0, A1=:=1, 
          new299(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=0, new299(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=0, new299(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new16(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=E, 
          Z=:=1, A1=:=0, 
          new311(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=1, A1=:=2, 
          new311(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=1, A1=:=2, 
          new311(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=E, 
          Z=:=1, A1=:=0, 
          new317(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=1, A1=:=2, 
          new317(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=1, A1=:=2, 
          new317(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new13(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,M)) :- 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,Z,A1,B1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,C1,D1,E1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,M,N,G,H,I,J,K,L)) :- M=:=1, N=:=1.
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,M)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(N,O,P,Q,R,S,T,U,V,W,X,Y)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)), 
          new7(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X,Z)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, J=:=2, 
          K=:=0, L=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
inv1 :- \+new1.
