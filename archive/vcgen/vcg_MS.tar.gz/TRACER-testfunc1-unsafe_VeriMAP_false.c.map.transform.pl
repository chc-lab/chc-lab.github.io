new15(s(A,B),d(A,C)) :- C=:=D+E, D=:=A, E=:=3.
new13(s(A),d(A)).
new10(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new13(s(A),d(B)).
new9(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F>=G+1, F=:=C, G=:=0, new10(s(E),d(H)).
new9(s(A,B,C,D),d(A,B,C,D)) :- E=:=1, F+1=<G, F=:=C, G=:=0, new10(s(E),d(H)).
new9(s(A,B,C,D),d(A,B,C,D)) :- E=:=0, F=:=G, F=:=C, G=:=0, new10(s(E),d(H)).
new8(s(A,B),d(A,C)) :- C=:=D+E, D=:=A, E=:=5.
new6(s(A,B,C,D),d(A,B,C,D)) :- E=:=A, new7(s(E,F),d(G,H)).
new6(s(A,B,C,D),d(E,F,G,H)) :- I=:=A, J=:=K, L=:=M-N, M=:=O-P, O=:=J, P=:=A, 
          N=:=5, new8(s(I,Q),d(R,K)), new9(s(A,J,L,D),d(E,F,G,H)).
new4(s(A,B,C,D),d(A,B,C,D)) :- E=:=A, new14(s(E,F),d(G,H)).
new4(s(A,B,C,D),d(E,F,G,H)) :- I=:=A, J=:=K, L=:=M-N, M=:=O-P, O=:=J, P=:=A, 
          N=:=3, new15(s(I,Q),d(R,K)), new9(s(A,J,L,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I>=J+1, I=:=D, J=:=0, 
          new4(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I+1=<J, I=:=D, J=:=0, 
          new4(s(A,B,C,D),d(E,F,G,H)).
new3(s(A,B,C,D),d(E,F,G,H)) :- I=:=J, I=:=D, J=:=0, new6(s(A,B,C,D),d(E,F,G,H)).
new2(s,d) :- new3(s(A,B,C,D),d(E,F,G,H)).
new1 :- new2(s,d).
inv1 :- \+new1.
