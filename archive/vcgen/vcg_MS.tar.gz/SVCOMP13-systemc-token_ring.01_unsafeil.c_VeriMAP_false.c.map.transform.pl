new332(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=F, 
          Z=:=1, A1=:=0, 
          new335(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new332(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=F, 
          Z=:=1, A1=:=2, 
          new335(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new332(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=F, 
          Z=:=1, A1=:=2, 
          new335(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new329(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new326(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=F, 
          Z=:=1, A1=:=0, 
          new329(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new326(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=F, 
          Z=:=1, A1=:=2, 
          new329(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new326(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=F, 
          Z=:=1, A1=:=2, 
          new329(s(A,B,C,A1,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new320(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=0, A1=:=1, 
          new323(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new320(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new323(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new320(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new323(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new317(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=0, A1=:=1, 
          new320(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new317(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new320(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new317(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new320(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new314(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=0, A1=:=1, 
          new317(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new314(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new317(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new314(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new317(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new311(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new308(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=0, A1=:=1, 
          new311(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new308(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=0, new311(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new308(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=0, new311(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=0, A1=:=1, 
          new308(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new308(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new308(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=0, A1=:=1, 
          new305(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new305(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new296(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new298(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new295(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=I, B1=:=1, C1=:=1, 
          new298(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new295(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=I, B1=:=1, 
          new296(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new295(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=1, 
          new296(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new289(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new291(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=J, B1=:=1, C1=:=1, 
          new291(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=J, B1=:=1, 
          new289(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=J, B1=:=1, 
          new289(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=N, D1=:=0, E1=:=0, 
          new285(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=N, D1=:=0, E1=:=0, 
          new285(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new284(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=N, D1=:=0, 
          new285(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new282(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=B, B1=:=1, 
          new288(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new282(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=B, B1=:=1, 
          new289(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new282(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=B, B1=:=1, 
          new289(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new279(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new282(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new279(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new257(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new284(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new279(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new279(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new278(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, 
          new279(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new295(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=1, 
          new296(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new276(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=1, 
          new296(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new272(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new272(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=I, B1=:=1, C1=:=1, 
          new272(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=I, B1=:=1, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=I, B1=:=1, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new265(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=0, 
          new265(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=J, B1=:=1, C1=:=1, 
          new265(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=J, B1=:=1, 
          new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=J, B1=:=1, 
          new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)).
new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=N, D1=:=0, E1=:=0, 
          new259(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=N, D1=:=0, E1=:=0, 
          new259(s(A,B,C,E1,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new258(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=N, D1=:=0, 
          new259(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=B, B1=:=1, 
          new262(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=B, B1=:=1, 
          new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new257(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=B, B1=:=1, 
          new263(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new257(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new258(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,C1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new253(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new254(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new253(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new254(s(A,B,E1,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new253(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, 
          new254(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new252(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new269(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new252(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=1, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new252(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=1, 
          new270(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new249(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new249(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new246(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new249(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new243(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new246(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new243(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new246(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new243(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new246(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new240(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new243(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new240(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new243(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new240(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new243(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new237(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new234(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new237(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new234(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new237(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new234(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new237(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new234(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new234(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new234(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new231(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new231(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new225(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)) :- 
          new225(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new220(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=M, B1=:=5, 
          new222(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new220(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=M, B1=:=5, 
          new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new220(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=M, B1=:=5, 
          new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,M)) :- 
          new191(s(A,B,C,D,E,F,G,H,I,J,K,L),d(N,O,P,Q,R,S,T,U,V,W,X,Y)).
new216(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=2, 
          B1=:=1, C1=:=2, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1)), 
          new219(s(B1,E1,C1,G1,H1,I1,J1,K1,L1,A1,N1,O1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          C1=:=1, 
          new216(s(A,B,C,D,E,F,G,H,I,C1,B1,A1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new215(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=M, B1=:=5, 
          new220(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=M, B1=:=5, 
          new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=<B1, 
          A1=:=M, B1=:=5, 
          new213(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=M, B1=:=5, 
          new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)) :- 
          new225(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new207(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=K, B1=:=C1+D1, C1=:=L, D1=:=1, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new207(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=K, B1=:=C1+D1, C1=:=L, D1=:=1, 
          new210(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new207(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=K, B1=:=C1+D1, C1=:=L, D1=:=1, 
          new212(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new207(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=1, 
          new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=1, 
          new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new214(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=0, 
          new204(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=0, 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new201(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=0, 
          new205(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new201(s(A,B,C,D,E,F,G,H,I,J,K,L,B1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1)).
new198(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new140(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)), 
          new172(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new197(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, G1=:=1, 
          new198(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new197(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, G1=:=1, 
          new198(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new197(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new193(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=1, Z=:=2, 
          new194(s(A,Y,C,Z,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new191(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z),d(M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new191(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new190(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new193(s(Z,A1,B1,C1,D1,E1,F1,G1,Y,I1,J1,K1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new187(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z+A1, 
          Z=:=K, A1=:=1, B1=:=1, 
          new190(s(A,B,C,D,E,F,G,H,B1,J,Y,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=1, new187(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=1, new184(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new185(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=1, new184(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new184(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new193(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=0, new184(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=0, new185(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new181(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=0, new185(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new181(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new178(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new163(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=O, F1=:=0, G1=:=1, 
          new178(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=O, F1=:=0, G1=:=1, 
          new178(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new177(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=D, F1=:=0, 
          new174(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=D, F1=:=0, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new197(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=C, F1=:=0, 
          new171(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=C, F1=:=0, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=C, F1=:=0, 
          new172(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=M, F1=:=0, 
          new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=M, F1=:=0, 
          new168(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new167(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=M, F1=:=0, 
          new170(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,B1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1)).
new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1)), 
          new167(s(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new164(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=M, B1=:=5, 
          new159(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=M, B1=:=5, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=M, B1=:=5, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new156(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new154(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=2, 
          B1=:=1, C1=:=2, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1)), 
          new156(s(B1,E1,C1,G1,H1,I1,J1,K1,L1,A1,N1,O1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          C1=:=1, 
          new154(s(A,B,C,D,E,F,G,H,I,C1,B1,A1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new153(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1, 
          A1=:=M, B1=:=5, 
          new157(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=M, B1=:=5, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=<B1, 
          A1=:=M, B1=:=5, 
          new151(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=M, B1=:=5, 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=K, B1=:=C1+D1, C1=:=L, D1=:=1, 
          new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=K, B1=:=C1+D1, C1=:=L, D1=:=1, 
          new148(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=K, B1=:=C1+D1, C1=:=L, D1=:=1, 
          new150(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=1, 
          new145(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=1, 
          new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=1, 
          new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new152(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=A, B1=:=0, 
          new142(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=A, B1=:=0, 
          new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new140(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=A, B1=:=0, 
          new143(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new137(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new140(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1)), 
          new113(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, G1=:=1, 
          new137(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, G1=:=1, 
          new137(s(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new133(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new132(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=1, Z=:=2, 
          new133(s(A,Y,C,Z,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z),d(M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1)).
new130(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=2, 
          new131(s(A,B,C,D,E,F,G,H,I,J,K,L),d(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1)), 
          new132(s(Z,A1,B1,C1,D1,E1,F1,G1,Y,I1,J1,K1),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new127(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z+A1, 
          Z=:=K, A1=:=1, B1=:=1, 
          new130(s(A,B,C,D,E,F,G,H,B1,J,Y,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=1, new127(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=1, new124(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=1, new124(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new124(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new132(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=B, 
          Z=:=0, new124(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=B, 
          Z=:=0, new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=B, 
          Z=:=0, new125(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new119(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new122(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new105(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=O, F1=:=0, G1=:=1, 
          new119(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=O, F1=:=0, G1=:=1, 
          new119(s(A,B,C,G1,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new118(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=D, F1=:=0, 
          new115(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=D, F1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new136(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=C, F1=:=0, 
          new112(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=C, F1=:=0, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=C, F1=:=0, 
          new113(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=M, F1=:=0, 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=M, F1=:=0, 
          new109(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new108(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=M, F1=:=0, 
          new111(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1)), 
          new108(s(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new106(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=D, B1=:=0, C1=:=1, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=D, B1=:=0, C1=:=1, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=D, B1=:=0, C1=:=0, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new93(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(A,B,C,D,E,F,G,H,I,J,K,L,M)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new90(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new90(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new90(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new87(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new87(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new84(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new84(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,G,H,I,J,K,L)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=J, 
          Z=:=1, A1=:=2, 
          new78(s(A,B,C,D,E,F,G,H,I,A1,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=J, 
          Z=:=1, new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=J, 
          Z=:=1, new78(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=I, 
          Z=:=1, A1=:=2, 
          new75(s(A,B,C,D,E,F,G,H,A1,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new75(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=H, 
          Z=:=1, A1=:=2, 
          new72(s(A,B,C,D,E,F,G,A1,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new72(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new69(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new67(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new69(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new81(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new81(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new66(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new65(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new67(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new41(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new62(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new65(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new61(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,E,F,M,H,I,J,K,L)) :- M=:=1.
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new56(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, E1=:=1, 
          new57(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(A,B,C,D,E,F,G,H,I,J,K,L,M,N)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1>=D1+1, C1=:=M, D1=:=0, E1=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1+1=<D1, C1=:=M, D1=:=0, E1=:=0, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new50(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, C1=:=M, D1=:=0, E1=:=1, 
          new51(s(A,B,C,D,E,F,G,H,I,J,K,L,M,E1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=O, F1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=O, F1=:=0, 
          new46(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new45(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=O, F1=:=0, 
          new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new44(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new50(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new43(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new56(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new43(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new44(s(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,F1)), 
          new45(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,N,E1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new60(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new40(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new61(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new62(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, E1=:=N, F1=:=0, G1=:=4, 
          new40(s(A,B,C,D,E,F,G,H,I,J,K,L,G1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1>=F1+1, E1=:=N, F1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new39(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1+1=<F1, E1=:=N, F1=:=0, 
          new41(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=C, B1=:=0, C1=:=1, 
          new93(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, B1=:=0, 
          new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new38(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=0, 
          new94(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1=:=B1, 
          A1=:=C, B1=:=0, C1=:=1, 
          new99(s(A,B,C,D,E,F,G,H,I,J,K,L,C1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1>=B1+1, 
          A1=:=C, B1=:=0, 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new37(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- A1+1=<B1, 
          A1=:=C, B1=:=0, 
          new100(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new37(s(A,B,C,D,E,F,G,H,I,J,K,L,B1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1)).
new36(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=F1, 
          new38(s(A,B,C,D,E,F,G,H,I,J,K,L,G1),d(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1)), 
          new39(s(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,M,E1,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new33(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new36(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new30(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new33(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new27(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new30(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new26(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=3, 
          new27(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new25(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new105(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new24(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new163(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new24(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1,D1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,E1,F1,G1)).
new23(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=2, 
          new25(s(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1),d(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1)), 
          new26(s(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new22(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=1, 
          new23(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new228(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new228(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=1, A1=:=2, 
          new240(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=1, new240(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=1, new240(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new20(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new19(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new21(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new22(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new18(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new252(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new253(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,M,N)) :- 
          new276(s(A,B,C,D,E,F,G,H,I,J,K,L,A1),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,B1)).
new17(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)) :- 
          C1=:=D1, 
          new252(s(A,B,C,D,E,F,G,H,I,J,K,L,E1),d(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1)), 
          new278(s(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N),d(O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new17(s(A,B,C,D,E,F,G,H,I,J,K,L,B1,C1),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,D1,E1)).
new16(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new18(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1),d(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1)), 
          new19(s(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=0, A1=:=1, 
          new302(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=0, new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=0, new302(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=G, 
          Z=:=0, A1=:=1, 
          new314(s(A,B,C,D,E,F,A1,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=G, 
          Z=:=0, new314(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=G, 
          Z=:=0, new314(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new14(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new13(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new15(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new16(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=E, 
          Z=:=1, A1=:=0, 
          new326(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=1, A1=:=2, 
          new326(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=1, A1=:=2, 
          new326(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y=:=Z, Y=:=E, 
          Z=:=1, A1=:=0, 
          new332(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y>=Z+1, Y=:=E, 
          Z=:=1, A1=:=2, 
          new332(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- Y+1=<Z, Y=:=E, 
          Z=:=1, A1=:=2, 
          new332(s(A,B,A1,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N,O)) :- 
          new11(s(A,B,C,D,E,F,G,H,I,J,K,L),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1)).
new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new12(s(A,B,C,D,E,F,G,H,I,J,K,L),d(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1)), 
          new13(s(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new9(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          new10(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new8(s(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)) :- 
          E1=:=0, 
          new9(s(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O),d(P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1)).
new7(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,M)) :- 
          new8(s(A,B,C,D,E,F,G,H,I,J,K,L,Z,A1,B1),d(N,O,P,Q,R,S,T,U,V,W,X,Y,C1,D1,E1)).
new6(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A,B,C,D,M,N,G,H,I,J,K,L)) :- M=:=1, N=:=1.
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,M)) :- 
          new5(s(A,B,C,D,E,F,G,H,I,J,K,L),d(N,O,P,Q,R,S,T,U,V,W,X,Y)).
new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new6(s(A,B,C,D,E,F,G,H,I,J,K,L),d(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1)), 
          new7(s(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new3(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)) :- 
          new4(s(A,B,C,D,E,F,G,H,I,J,K,L,M),d(N,O,P,Q,R,S,T,U,V,W,X,Y,Z)).
new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)) :- 
          new3(s(A,B,C,D,E,F,G,H,I,J,K,L,Y),d(M,N,O,P,Q,R,S,T,U,V,W,X,Z)).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, J=:=2, 
          K=:=0, L=:=0, 
          new2(s(A,B,C,D,E,F,G,H,I,J,K,L),d(M,N,O,P,Q,R,S,T,U,V,W,X)).
inv1 :- \+new1.
