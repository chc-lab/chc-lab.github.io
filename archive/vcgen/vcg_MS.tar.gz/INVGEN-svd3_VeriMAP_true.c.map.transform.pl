new38(s(A,B),d(A,C)) :- new38(s(A,B),d(A,C)).
new37(s(A,B),d(A,B)).
new31(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new31(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new31(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new36(s(A,B),d(A,C)).
new30(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new37(s(A,B),d(A,C)).
new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=E, N=:=B, O=:=P+Q, P=:=E, 
          Q=:=1, new25(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=E, N=:=B, O=:=P+Q, P=:=D, 
          Q=:=1, new23(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new25(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new27(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=F, 
          new25(s(A,B,C,D,O,F),d(G,H,I,J,K,L)).
new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, 
          new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new23(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new24(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new22(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=1, H=<I, H=:=1, I=:=D, 
          new30(s(A,G),d(A,J)).
new22(s(A,B,C,D,E,F),d(A,B,C,D,E,F)) :- G=:=0, H>=I+1, H=:=1, I=:=D, 
          new30(s(A,G),d(A,J)).
new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N=<O, N=:=1, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, new31(s(A,M),d(A,S)), 
          new14(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N>=O+1, N=:=1, O=:=D, P=:=Q+R, 
          Q=:=D, R=:=1, new31(s(A,M),d(A,S)), 
          new14(s(A,B,C,P,E,F),d(G,H,I,J,K,L)).
new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, 
          new22(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, O=:=F, 
          new23(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=<N, M=:=D, N=:=B, O=:=P+Q, P=:=D, 
          Q=:=1, new17(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=D, N=:=B, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new17(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new18(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=F, 
          new17(s(A,B,C,M,E,F),d(G,H,I,J,K,L)).
new14(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new21(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=C, N=:=O-P, O=:=C, P=:=1, 
          new7(s(A,B,N,D,E,M),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N+1, M=:=A, N=:=0, O=:=F, 
          new14(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=A, N=:=0, O=:=F, 
          new14(s(A,B,C,O,E,F),d(G,H,I,J,K,L)).
new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=N, M=:=A, N=:=0, 
          new16(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M+1=<N, M=:=C, N=:=B, 
          new11(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=B, 
          new12(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M>=N, M=:=C, N=:=1, 
          new10(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new7(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new9(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new5(s(A,B),d(A,B)) :- C>=D+1, C=:=B, D=:=0.
new5(s(A,B),d(A,B)) :- C+1=<D, C=:=B, D=:=0.
new5(s(A,B),d(A,C)) :- D=:=E, D=:=B, E=:=0, new38(s(A,B),d(A,C)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=1, N>=O+1, N=:=F, O=:=1, P=:=B, 
          new5(s(A,M),d(A,Q)), new7(s(A,B,P,D,E,F),d(G,H,I,J,K,L)).
new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- M=:=0, N=<O, N=:=F, O=:=1, P=:=B, 
          new5(s(A,M),d(A,Q)), new7(s(A,B,P,D,E,F),d(G,H,I,J,K,L)).
new3(s(A,B,C,D,E,F),d(G,H,I,J,K,L)) :- new4(s(A,B,C,D,E,F),d(G,H,I,J,K,L)).
new2(s(A),d(B)) :- new3(s(A,C,D,E,F,G),d(B,H,I,J,K,L)).
new1 :- A=:=0, new2(s(A),d(B)).
inv1 :- \+new1.
