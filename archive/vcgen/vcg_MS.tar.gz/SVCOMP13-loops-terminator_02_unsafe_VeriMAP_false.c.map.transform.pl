new16(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R+1, Q=:=G, R=:=0, S=:=T+U, 
          T=:=A, U=:=1, new7(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new16(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=G, R=:=0, S=:=T+U, 
          T=:=A, U=:=1, new7(s(S,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new16(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, Q=:=G, R=:=0, S=:=T-U, 
          T=:=A, U=:=1, V=:=W-X, W=:=E, X=:=1, 
          new7(s(S,B,C,D,V,F,G,H),d(I,J,K,L,M,N,O,P)).
new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new16(s(A,B,C,D,E,F,Q,R),d(I,J,K,L,M,N,O,P)).
new13(s(A),d(A)).
new12(s(A),d(B)) :- C=:=D, C=:=A, D=:=0, new13(s(A),d(B)).
new11(s(A,B,C,D,E,F,G,H),d(A,B,C,D,E,F,G,H)) :- I=:=0, new12(s(I),d(J)).
new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new11(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new9(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=100, R=:=E, 
          new14(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new9(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=100, R=:=E, 
          new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q+1=<R, Q=:=A, R=:=100, 
          new9(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q>=R, Q=:=A, R=:=100, 
          new10(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new7(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new8(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new6(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new7(s(A,B,C,D,Q,R,G,H),d(I,J,K,L,M,N,O,P)).
new5(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new6(s(A,B,Q,R,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- Q=:=R, 
          new5(s(Q,R,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)) :- 
          new4(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new2(s,d) :- new3(s(A,B,C,D,E,F,G,H),d(I,J,K,L,M,N,O,P)).
new1 :- new2(s,d).
inv1 :- \+new1.
