new7(A,B,C) :- D=<E, D=:=F+G, F=:=B, G=:=C, E=:=0.
new6(A,B,C,D) :- E>=F+1, E=:=B, F=:=0, G=:=3, H=:=B, new7(G,C,H).
new6(A,B,C,D) :- E=<F, E=:=B, F=:=0, G=:=1, H=:=G, new7(A,C,H).
new4(A,B,C) :- new6(A,D,B,C).
new3(A,B,C) :- D>=E+1, D=:=B, E=:=0, F=:=2, new4(F,B,C).
new3(A,B,C) :- D=<E, D=:=B, E=:=0, F=:=0, new4(A,F,C).
new2(A) :- new3(A,B,C).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
