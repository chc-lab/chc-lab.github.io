new37(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0, H=:=8656, new26(H,B,C,D,E).
new37(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=0, H=:=8656, new26(H,B,C,D,E).
new37(A,B,C,D,E) :- F=:=G, F=:=B, G=:=0, H=:=8512, new26(H,B,C,D,E).
new33(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0, H=:=8466, new26(H,B,C,D,E).
new33(A,B,C,D,E) :- F+1=<G, F=:=E, G=:=0, H=:=8466, new26(H,B,C,D,E).
new33(A,B,C,D,E) :- F=:=G, F=:=E, G=:=0, H=:=8640, new26(H,B,C,D,E).
new29(A,B,C,D,E) :- F=:=G, F=:=B, G=:=0, H=:=8656, new26(H,B,C,D,E).
new26(A,B,C,D,E) :- new4(A,B,C,D,E).
new22(A,B,C,D,E) :- F=:=G, F=:=D, G=:=5.
new22(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=5, new21(A,B,C,D,E).
new22(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=5, new21(A,B,C,D,E).
new21(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0, H=:=8640, new26(H,B,C,D,E).
new21(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=0, H=:=8640, new26(H,B,C,D,E).
new18(A,B,C,D,E) :- F=:=G, F=:=D, G=:=4, H=:=5, new21(A,B,C,H,E).
new18(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=4, new22(A,B,C,D,E).
new18(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=4, new22(A,B,C,D,E).
new17(A,B,C,D,E) :- F=:=G, F=:=D, G=:=2, H=:=3, new18(A,B,C,H,E).
new17(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=2, new18(A,B,C,D,E).
new17(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=2, new18(A,B,C,D,E).
new15(A,B,C,D,E) :- F=:=G, F=:=A, G=:=8656, new17(A,B,C,D,E).
new14(A,B,C,D,E) :- F=:=G, F=:=D, G=:=3, H=:=4, new29(A,B,C,H,E).
new14(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=3, new29(A,B,C,D,E).
new14(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=3, new29(A,B,C,D,E).
new12(A,B,C,D,E) :- F=:=G, F=:=A, G=:=8640, new14(A,B,C,D,E).
new12(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=8640, new15(A,B,C,D,E).
new12(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=8640, new15(A,B,C,D,E).
new11(A,B,C,D,E) :- new33(A,B,C,D,F).
new9(A,B,C,D,E) :- F=:=G, F=:=A, G=:=8512, new11(A,B,C,D,E).
new9(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=8512, new12(A,B,C,D,E).
new9(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=8512, new12(A,B,C,D,E).
new8(A,B,C,D,E) :- F=:=G, F=:=D, G=:=0, H=:=2, new37(A,B,C,H,E).
new8(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=0, new37(A,B,C,D,E).
new8(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=0, new37(A,B,C,D,E).
new7(A,B,C,D,E) :- F=:=G, F=:=A, G=:=8466, new8(A,B,C,D,E).
new7(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=8466, new9(A,B,C,D,E).
new7(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=8466, new9(A,B,C,D,E).
new6(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=2.
new6(A,B,C,D,E) :- F=<G, F=:=D, G=:=2, new7(A,B,C,D,E).
new5(A,B,C,D,E) :- F=<G, F=:=A, G=:=8512, new6(A,B,C,D,E).
new5(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=8512, new7(A,B,C,D,E).
new4(A,B,C,D,E) :- F>=G+1, F=:=1, G=:=0, new5(A,B,C,D,E).
new3(A,B,C,D,E) :- F=:=G, H=:=8466, I=:=0, new4(H,F,G,I,E).
new2 :- new3(A,B,C,D,E).
new1 :- new2.
inv1 :- \+new1.
