new13(A,B,C) :- new3(A,B,C).
new12(A,B,C) :- D=:=E, D=:=A, E=:=3.
new12(A,B,C) :- D>=E+1, D=:=A, E=:=3, F=:=5, new13(A,F,C).
new12(A,B,C) :- D+1=<E, D=:=A, E=:=3, F=:=5, new13(A,F,C).
new10(A,B,C) :- D=:=E, D=:=B, E=:=4, new12(A,B,C).
new10(A,B,C) :- D>=E+1, D=:=B, E=:=4, new13(A,B,C).
new10(A,B,C) :- D+1=<E, D=:=B, E=:=4, new13(A,B,C).
new9(A,B,C) :- D=:=E, D=:=A, E=:=1, F=:=2, G=:=4, new13(F,G,C).
new9(A,B,C) :- D>=E+1, D=:=A, E=:=1, F=:=4, new13(A,F,C).
new9(A,B,C) :- D+1=<E, D=:=A, E=:=1, F=:=4, new13(A,F,C).
new7(A,B,C) :- D=:=E, D=:=B, E=:=3, new9(A,B,C).
new7(A,B,C) :- D>=E+1, D=:=B, E=:=3, new10(A,B,C).
new7(A,B,C) :- D+1=<E, D=:=B, E=:=3, new10(A,B,C).
new6(A,B,C) :- D=:=E, D=:=A, E=:=0, F=:=1, G=:=3, new13(F,G,C).
new6(A,B,C) :- D>=E+1, D=:=A, E=:=0, F=:=3, new13(A,F,C).
new6(A,B,C) :- D+1=<E, D=:=A, E=:=0, F=:=3, new13(A,F,C).
new4(A,B,C) :- D=:=E, D=:=B, E=:=2, new6(A,B,C).
new4(A,B,C) :- D>=E+1, D=:=B, E=:=2, new7(A,B,C).
new4(A,B,C) :- D+1=<E, D=:=B, E=:=2, new7(A,B,C).
new3(A,B,C) :- D>=E+1, D=:=C, E=:=0, new4(A,B,C).
new3(A,B,C) :- D+1=<E, D=:=C, E=:=0, new4(A,B,C).
new2 :- A=:=0, B=:=2, new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
