new5(A,B,C) :- D>=E+1, D=:=B, E=:=0.
new5(A,B,C) :- D+1=<E, D=:=B, E=:=0.
new4(A,B,C) :- D>=E+1, D=:=C, E=:=0, F=:=G-H, G=:=B, H=:=1, I=:=J+K, J=:=A, 
          K=:=1, new3(I,F,C).
new4(A,B,C) :- D=<E, D=:=C, E=:=0, F=:=G+H, G=:=A, H=:=1, new3(F,B,C).
new3(A,B,C) :- D+1=<E, D=:=A, E=:=1, F=:=G+H, G=:=B, H=:=1, new4(A,F,C).
new3(A,B,C) :- D>=E, D=:=A, E=:=1, new5(A,B,C).
new2 :- A=:=0, B=:=0, new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
