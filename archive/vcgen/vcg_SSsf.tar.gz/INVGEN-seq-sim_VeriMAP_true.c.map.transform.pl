new10(A,B,C,D) :- E=<F, E=:=D, F=:=0.
new10(A,B,C,D) :- E>=F+1, E=:=D, F=:=0, G=:=H+I, H=:=C, I=:=1, J=:=K-L, K=:=D, 
          L=:=1, new9(A,B,G,J).
new9(A,B,C,D) :- E+1=<F, E=:=C, F=:=A, new10(A,B,C,D).
new7(A,B,C,D) :- E+1=<F, E=:=C, F=:=B, G=:=H+I, H=:=C, I=:=1, J=:=K-L, K=:=D, 
          L=:=1, new7(A,B,G,J).
new7(A,B,C,D) :- E>=F, E=:=C, F=:=B, G=:=0, new9(A,B,G,D).
new5(A,B,C,D) :- E+1=<F, E=:=C, F=:=B, G=:=H+I, H=:=C, I=:=1, J=:=K+L, K=:=D, 
          L=:=1, new5(A,B,G,J).
new5(A,B,C,D) :- E>=F, E=:=C, F=:=B, G=:=0, new7(A,B,G,D).
new3(A,B,C,D) :- E+1=<F, E=:=C, F=:=A, G=:=H+I, H=:=C, I=:=1, J=:=K+L, K=:=D, 
          L=:=1, new3(A,B,G,J).
new3(A,B,C,D) :- E>=F, E=:=C, F=:=A, G=:=0, new5(A,B,G,D).
new2 :- A=:=0, B=:=0, new3(C,D,A,B).
new1 :- new2.
inv1 :- \+new1.
