new12(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=B.
new12(A,B,C,D,E) :- F>=G, F=:=C, G=:=B, H=:=I+J, I=:=D, J=:=1, new5(A,B,C,H,E).
new9(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=C.
new9(A,B,C,D,E) :- F>=G, F=:=D, G=:=C, new12(A,B,C,D,E).
new7(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=0, new9(A,B,C,D,E).
new7(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0, new9(A,B,C,D,E).
new7(A,B,C,D,E) :- F=:=G, F=:=A, G=:=0, H=:=I+J, I=:=D, J=:=1, new5(A,B,C,H,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=E, new7(A,B,C,D,E).
new5(A,B,C,D,E) :- F>=G, F=:=D, G=:=E, H=:=I+J, I=:=C, J=:=1, new4(A,B,H,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=E, H=:=C, new5(A,B,C,H,E).
new4(A,B,C,D,E) :- F>=G, F=:=C, G=:=E, H=:=I+J, I=:=B, J=:=1, new3(A,H,C,D,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=E, H=:=B, new4(A,B,H,D,E).
new2(A) :- B=:=0, new3(A,B,C,D,E).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
