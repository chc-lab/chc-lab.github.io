new3(A,B) :- C+1=<D, C=:=A, D=:=0.
new2 :- A=:=99, B=:=0, new3(B,A).
new1 :- new2.
inv1 :- \+new1.
