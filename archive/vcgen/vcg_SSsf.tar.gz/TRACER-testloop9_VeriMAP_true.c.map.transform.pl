new13(A,B,C) :- D=:=E, D=:=B, E=:=4, F=:=1, G=:=6, H=:=I+J, I=:=A, J=:=1, 
          new3(H,F,G).
new13(A,B,C) :- D>=E+1, D=:=B, E=:=4, F=:=2, G=:=H+I, H=:=A, I=:=1, new3(G,F,C).
new13(A,B,C) :- D+1=<E, D=:=B, E=:=4, F=:=2, G=:=H+I, H=:=A, I=:=1, new3(G,F,C).
new10(A,B,C) :- D=:=E, D=:=B, E=:=3, F=:=1, G=:=5, H=:=I+J, I=:=A, J=:=1, 
          new3(H,F,G).
new10(A,B,C) :- D>=E+1, D=:=B, E=:=3, new13(A,B,C).
new10(A,B,C) :- D+1=<E, D=:=B, E=:=3, new13(A,B,C).
new7(A,B,C) :- D=:=E, D=:=B, E=:=2, F=:=3, G=:=4, H=:=I+J, I=:=A, J=:=1, 
          new3(H,F,G).
new7(A,B,C) :- D>=E+1, D=:=B, E=:=2, new10(A,B,C).
new7(A,B,C) :- D+1=<E, D=:=B, E=:=2, new10(A,B,C).
new5(A,B,C) :- D=:=E, D=:=C, E=:=6.
new4(A,B,C) :- D=:=E, D=:=B, E=:=1, F=:=2, G=:=3, H=:=I+J, I=:=A, J=:=1, 
          new3(H,F,G).
new4(A,B,C) :- D>=E+1, D=:=B, E=:=1, new7(A,B,C).
new4(A,B,C) :- D+1=<E, D=:=B, E=:=1, new7(A,B,C).
new3(A,B,C) :- D+1=<E, D=:=A, E=:=10, new4(A,B,C).
new3(A,B,C) :- D>=E, D=:=A, E=:=10, new5(A,B,C).
new2 :- A=:=0, B=:=1, new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
