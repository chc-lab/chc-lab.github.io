new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=K, T=:=0, U=:=0, 
          V=:=2, new185(A,B,C,U,E,F,G,H,V,L,M,N,O,P,Q,R).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=K, T=:=0, U=:=0, 
          V=:=2, new185(A,B,C,U,E,F,G,H,V,L,M,N,O,P,Q,R).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=K, T=:=0, U=:=2, 
          new185(A,B,C,D,E,F,G,H,U,L,M,N,O,P,Q,R).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=1, V=:=1, 
          W=:=V, new199(A,B,C,D,E,F,G,H,I,K,W,M,N,O,P,Q,R,S).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=1, V=:=0, 
          W=:=V, new199(A,B,C,D,E,F,G,H,I,K,W,M,N,O,P,Q,R,S).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=1, V=:=0, 
          W=:=V, new199(A,B,C,D,E,F,G,H,I,K,W,M,N,O,P,Q,R,S).
new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=B, U=:=1, 
          new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=B, U=:=1, V=:=0, 
          W=:=V, new199(A,B,C,D,E,F,G,H,I,K,W,M,N,O,P,Q,R,S).
new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=B, U=:=1, V=:=0, 
          W=:=V, new199(A,B,C,D,E,F,G,H,I,K,W,M,N,O,P,Q,R,S).
new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new197(A,B,C,D,E,F,G,H,I,S,J,K,L,M,N,O,P,Q,R).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=J, T=:=0, U=:=0, 
          new194(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=J, T=:=0, U=:=0, 
          new194(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=J, T=:=0, 
          new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=1, V=:=1, 
          W=:=V, new192(A,B,C,D,E,F,G,H,I,W,L,M,N,O,P,Q,R,S).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=1, V=:=0, 
          W=:=V, new192(A,B,C,D,E,F,G,H,I,W,L,M,N,O,P,Q,R,S).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=1, V=:=0, 
          W=:=V, new192(A,B,C,D,E,F,G,H,I,W,L,M,N,O,P,Q,R,S).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=A, U=:=1, 
          new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=A, U=:=1, V=:=0, 
          W=:=V, new192(A,B,C,D,E,F,G,H,I,W,L,M,N,O,P,Q,R,S).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=A, U=:=1, V=:=0, 
          W=:=V, new192(A,B,C,D,E,F,G,H,I,W,L,M,N,O,P,Q,R,S).
new189(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new190(A,B,C,D,E,F,G,H,I,S,J,K,L,M,N,O,P,Q,R).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new189(A,B,C,D,E,F,G,H,I,Q,R,J,K,L,M,N,O,P).
new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=1, R=:=0, S=:=1, T=:=2, 
          new158(S,B,T,D,E,F,G,H,I,J,K,L,M,N,O,P).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=A, R=:=1, 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=A, R=:=1, 
          new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=A, R=:=1, 
          new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=1, R=:=0, S=:=1, 
          new187(A,B,C,D,E,F,G,H,S,J,K,L,M,N,O,P).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=A, R=:=0, 
          new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=A, R=:=0, 
          new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=A, R=:=0, 
          new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new174(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=K, R=:=0, S=:=1, 
          new175(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
new174(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=K, R=:=0, S=:=1, 
          new175(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
new174(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=K, R=:=0, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=B, R=:=1.
new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=B, R=:=1, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=B, R=:=1, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=1, R=:=0, S=:=1, T=:=2, 
          new50(A,S,C,T,E,F,G,H,I,J,K,L,M,N,O,P).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=B, R=:=0, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=B, R=:=0, 
          new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=B, R=:=0, 
          new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=L, R=:=0, S=:=1, 
          new164(A,B,C,S,E,F,G,H,I,J,K,L,M,N,O,P).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=L, R=:=0, S=:=1, 
          new164(A,B,C,S,E,F,G,H,I,J,K,L,M,N,O,P).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=L, R=:=0, 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new163(A,B,C,D,E,F,G,H,I,J,K,Q,M,N,O,P).
new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=D, R=:=0, 
          new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=D, R=:=0, 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=D, R=:=0, 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new174(A,B,C,D,E,F,G,H,I,J,Q,L,M,N,O,P).
new139(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=I, O=:=1, P=:=2, 
          new105(A,B,C,D,E,F,G,H,P,J,K,L,M).
new139(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=I, O=:=1, 
          new105(A,B,C,D,E,F,G,H,I,J,K,L,M).
new139(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=I, O=:=1, 
          new105(A,B,C,D,E,F,G,H,I,J,K,L,M).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=1, P=:=2, 
          new139(A,B,C,D,E,F,G,P,I,J,K,L,M).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=1, 
          new139(A,B,C,D,E,F,G,H,I,J,K,L,M).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=1, 
          new139(A,B,C,D,E,F,G,H,I,J,K,L,M).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=G, O=:=1, P=:=2, 
          new136(A,B,C,D,E,F,P,H,I,J,K,L,M).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=1, 
          new136(A,B,C,D,E,F,G,H,I,J,K,L,M).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=G, O=:=1, 
          new136(A,B,C,D,E,F,G,H,I,J,K,L,M).
new132(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new135(A,B,C,D,E,F,G,H,I,J,K,L,M).
new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=K, Q=:=0, R=:=0, 
          new132(A,B,C,R,E,F,G,H,I,L,M,N,O).
new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=K, Q=:=0, R=:=0, 
          new132(A,B,C,R,E,F,G,H,I,L,M,N,O).
new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=K, Q=:=0, 
          new132(A,B,C,D,E,F,G,H,I,L,M,N,O).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=I, R=:=1, S=:=1, T=:=S, 
          new130(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=I, R=:=1, S=:=0, T=:=S, 
          new130(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=I, R=:=1, S=:=0, T=:=S, 
          new130(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=B, R=:=1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=B, R=:=1, S=:=0, T=:=S, 
          new130(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=B, R=:=1, S=:=0, T=:=S, 
          new130(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- 
          new128(A,B,C,D,E,F,G,H,I,P,J,K,L,M,N,O).
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=J, Q=:=0, R=:=0, 
          new125(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=J, Q=:=0, R=:=0, 
          new125(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=J, Q=:=0, 
          new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=1, S=:=1, T=:=S, 
          new123(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=1, S=:=0, T=:=S, 
          new123(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=1, S=:=0, T=:=S, 
          new123(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=A, R=:=1, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=A, R=:=1, S=:=0, T=:=S, 
          new123(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=A, R=:=1, S=:=0, T=:=S, 
          new123(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- 
          new121(A,B,C,D,E,F,G,H,I,P,J,K,L,M,N,O).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new120(A,B,C,D,E,F,G,H,I,N,O,J,K,L,M).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=D, R=:=0, S=:=1, T=:=S, 
          new109(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=D, R=:=0, S=:=0, T=:=S, 
          new109(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=D, R=:=0, S=:=0, T=:=S, 
          new109(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=J, Q=:=0, R=:=0, S=:=R, 
          new115(A,B,C,D,E,F,G,H,I,L,M,S,O).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=J, Q=:=0, R=:=0, S=:=R, 
          new115(A,B,C,D,E,F,G,H,I,L,M,S,O).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=J, Q=:=0, R=:=1, S=:=R, 
          new115(A,B,C,D,E,F,G,H,I,L,M,S,O).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=C, R=:=0, S=:=1, T=:=S, 
          new109(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=C, R=:=0, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=C, R=:=0, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new107(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- 
          new108(A,B,C,D,E,F,G,H,I,P,J,K,L,M,N,O).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new107(A,B,C,D,E,F,G,H,I,N,O,J,K,L,M).
new104(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=1, new119(A,B,C,D,E,F,N,H,I,J,K,L,M).
new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=P, O=:=D, P=:=0, Q=:=1, R=:=Q, 
          new98(A,B,C,D,E,F,G,H,I,K,R,M,N).
new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O>=P+1, O=:=D, P=:=0, Q=:=0, R=:=Q, 
          new98(A,B,C,D,E,F,G,H,I,K,R,M,N).
new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, O=:=D, P=:=0, Q=:=0, R=:=Q, 
          new98(A,B,C,D,E,F,G,H,I,K,R,M,N).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=K, O=:=0, P=:=4, 
          new104(A,B,C,D,E,F,G,H,I,P,K,L,M).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=K, O=:=0, 
          new105(A,B,C,D,E,F,G,H,I,J,K,L,M).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=0, 
          new105(A,B,C,D,E,F,G,H,I,J,K,L,M).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=P, O=:=C, P=:=0, Q=:=1, R=:=Q, 
          new98(A,B,C,D,E,F,G,H,I,K,R,M,N).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O>=P+1, O=:=C, P=:=0, 
          new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, O=:=C, P=:=0, 
          new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new97(A,B,C,D,E,F,G,H,I,N,J,K,L,M).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=I, O=:=1, P=:=2, 
          new94(A,B,C,D,E,F,G,H,P,J,K,L,M).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=I, O=:=1, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=I, O=:=1, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=1, P=:=2, 
          new91(A,B,C,D,E,F,G,P,I,J,K,L,M).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=1, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=1, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=G, O=:=1, P=:=2, 
          new88(A,B,C,D,E,F,P,H,I,J,K,L,M).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=1, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=G, O=:=1, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new87(A,B,C,D,E,F,G,H,I,J,K,L,M).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=K, Q=:=0, R=:=0, 
          new84(A,B,C,R,E,F,G,H,I,L,M,N,O).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=K, Q=:=0, R=:=0, 
          new84(A,B,C,R,E,F,G,H,I,L,M,N,O).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=K, Q=:=0, 
          new84(A,B,C,D,E,F,G,H,I,L,M,N,O).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=I, R=:=1, S=:=1, T=:=S, 
          new82(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=I, R=:=1, S=:=0, T=:=S, 
          new82(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=I, R=:=1, S=:=0, T=:=S, 
          new82(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=B, R=:=1, 
          new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=B, R=:=1, S=:=0, T=:=S, 
          new82(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=B, R=:=1, S=:=0, T=:=S, 
          new82(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new80(A,B,C,D,E,F,G,H,I,P,J,K,L,M,N,O).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=J, Q=:=0, R=:=0, 
          new77(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=J, Q=:=0, R=:=0, 
          new77(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=J, Q=:=0, 
          new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=1, S=:=1, T=:=S, 
          new75(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=1, S=:=0, T=:=S, 
          new75(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=1, S=:=0, T=:=S, 
          new75(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=A, R=:=1, 
          new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=A, R=:=1, S=:=0, T=:=S, 
          new75(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=A, R=:=1, S=:=0, T=:=S, 
          new75(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new73(A,B,C,D,E,F,G,H,I,P,J,K,L,M,N,O).
new69(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new72(A,B,C,D,E,F,G,H,I,N,O,J,K,L,M).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=I, O=:=0, P=:=1, 
          new69(A,B,C,D,E,F,G,H,P,J,K,L,M).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=I, O=:=0, 
          new69(A,B,C,D,E,F,G,H,I,J,K,L,M).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=I, O=:=0, 
          new69(A,B,C,D,E,F,G,H,I,J,K,L,M).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=0, P=:=1, 
          new66(A,B,C,D,E,F,G,P,I,J,K,L,M).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=0, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=0, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=G, O=:=0, P=:=1, 
          new63(A,B,C,D,E,F,P,H,I,J,K,L,M).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=0, 
          new63(A,B,C,D,E,F,G,H,I,J,K,L,M).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=G, O=:=0, 
          new63(A,B,C,D,E,F,G,H,I,J,K,L,M).
new61(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new62(A,B,C,D,E,F,G,H,I,J,K,L,M).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=3, new61(A,B,C,D,E,F,G,H,I,N,K,L,M).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=C, R=:=0, 
          new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=C, R=:=0, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=C, R=:=0, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=D, S=:=0, T=:=1, U=:=T, 
          new52(A,B,C,D,E,F,G,H,I,U,L,M,N,O,P,Q).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=D, S=:=0, T=:=0, U=:=T, 
          new52(A,B,C,D,E,F,G,H,I,U,L,M,N,O,P,Q).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=D, S=:=0, T=:=0, U=:=T, 
          new52(A,B,C,D,E,F,G,H,I,U,L,M,N,O,P,Q).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=J, R=:=0, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=J, R=:=0, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=J, R=:=0, S=:=2, 
          new60(A,B,C,D,E,F,G,H,I,S,N,O,P).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=C, S=:=0, T=:=1, U=:=T, 
          new52(A,B,C,D,E,F,G,H,I,U,L,M,N,O,P,Q).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=C, S=:=0, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=C, S=:=0, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new51(A,B,C,D,E,F,G,H,I,Q,J,K,L,M,N,O,P).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new50(A,B,C,D,E,F,G,H,I,N,O,P,J,K,L,M).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=0, P=:=1, 
          new49(A,B,C,D,E,F,G,H,I,P,K,L,M).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=I, O=:=1, P=:=2, 
          new46(A,B,C,D,E,F,G,H,P,J,K,L,M).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=I, O=:=1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=I, O=:=1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=1, P=:=2, 
          new43(A,B,C,D,E,F,G,P,I,J,K,L,M).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=1, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=1, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=G, O=:=1, P=:=2, 
          new40(A,B,C,D,E,F,P,H,I,J,K,L,M).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=1, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=G, O=:=1, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new39(A,B,C,D,E,F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=K, Q=:=0, R=:=0, 
          new36(A,B,C,R,E,F,G,H,I,L,M,N,O).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=K, Q=:=0, R=:=0, 
          new36(A,B,C,R,E,F,G,H,I,L,M,N,O).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=K, Q=:=0, 
          new36(A,B,C,D,E,F,G,H,I,L,M,N,O).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=I, R=:=1, S=:=1, T=:=S, 
          new34(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=I, R=:=1, S=:=0, T=:=S, 
          new34(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=I, R=:=1, S=:=0, T=:=S, 
          new34(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=B, R=:=1, 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=B, R=:=1, S=:=0, T=:=S, 
          new34(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=B, R=:=1, S=:=0, T=:=S, 
          new34(A,B,C,D,E,F,G,H,I,K,T,M,N,O,P).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new32(A,B,C,D,E,F,G,H,I,P,J,K,L,M,N,O).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=J, Q=:=0, R=:=0, 
          new29(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=J, Q=:=0, R=:=0, 
          new29(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=J, Q=:=0, 
          new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=1, S=:=1, T=:=S, 
          new27(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=1, S=:=0, T=:=S, 
          new27(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=1, S=:=0, T=:=S, 
          new27(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=A, R=:=1, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=A, R=:=1, S=:=0, T=:=S, 
          new27(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=A, R=:=1, S=:=0, T=:=S, 
          new27(A,B,C,D,E,F,G,H,I,T,L,M,N,O,P).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new25(A,B,C,D,E,F,G,H,I,P,J,K,L,M,N,O).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new24(A,B,C,D,E,F,G,H,I,N,O,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=I, O=:=0, P=:=1, 
          new21(A,B,C,D,E,F,G,H,P,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=I, O=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=I, O=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=0, P=:=1, 
          new18(A,B,C,D,E,F,G,P,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=G, O=:=0, P=:=1, 
          new15(A,B,C,D,E,F,P,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=G, O=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=F, O=:=1, P=:=0, 
          new11(A,B,C,P,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=1, P=:=2, 
          new11(A,B,C,P,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=F, O=:=1, P=:=2, 
          new11(A,B,C,P,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=E, O=:=1, P=:=0, 
          new8(A,B,P,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=1, P=:=2, 
          new8(A,B,P,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=1, P=:=2, 
          new8(A,B,P,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J) :- K=:=0, new5(A,B,C,D,E,F,G,H,I,K,L,M,J).
new3(A,B,C,D,E,F,G,H,I,J) :- K=:=1, L=:=1, new4(A,B,C,D,K,L,G,H,I,J).
new2(A,B,C,D,E,F,G,H,I) :- new3(A,B,C,D,E,F,G,H,I,J).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, 
          new2(A,B,C,D,E,F,G,H,I).
inv1 :- \+new1.
