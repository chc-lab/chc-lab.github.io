new12(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=0.
new10(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=0, I=:=J-K, J=:=D, K=:=1, L=:=M+N, 
          M=:=F, N=:=1, O=:=P+Q, P=:=I, Q=:=L, new10(A,O,C,I,E,L).
new10(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=0, new12(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, I=:=J-K, J=:=C, K=:=1, L=:=M+N, 
          M=:=E, N=:=1, O=:=P+Q, P=:=I, Q=:=L, new7(A,O,I,D,L,F).
new7(A,B,C,D,E,F) :- G=<H, G=:=C, H=:=0, I=:=E, J=:=0, K=:=L+M, L=:=I, M=:=J, 
          new10(A,K,C,I,E,J).
new5(A,B,C,D,E,F) :- new5(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G=<H, G=:=A, H=:=200, I=:=0, J=:=A, K=:=L+M, L=:=J, M=:=I, 
          new7(A,K,J,D,I,F).
new4(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=200, new5(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G>=H, G=:=A, H=:=0, new4(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, new5(A,B,C,D,E,F).
new2 :- new3(A,B,C,D,E,F).
new1 :- new2.
inv1 :- \+new1.
