new5(A,B) :- C>=D+1, C=:=B, D=:=10.
new3(A,B) :- C+1=<D, C=:=B, D=:=A, E=:=F+G, F=:=B, G=:=1, new3(A,E).
new3(A,B) :- C>=D, C=:=B, D=:=A, new5(A,B).
new2 :- A=:=0, B=:=10, new3(B,A).
new1 :- new2.
inv1 :- \+new1.
