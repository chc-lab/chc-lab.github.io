new6(A,B) :- C>=D+1, C=:=B, D=:=0.
new6(A,B) :- C+1=<D, C=:=B, D=:=0.
new5(A,B) :- C>=D+1, C=:=B, D=:=16, new6(A,B).
new5(A,B) :- C+1=<D, C=:=B, D=:=16, new6(A,B).
new4(A,B) :- C+1=<D, C=:=A, D=:=4, E=:=F+G, F=:=B, G=:=2, H=:=I+J, I=:=A, 
          J=:=1, new3(H,E).
new4(A,B) :- C>=D, C=:=A, D=:=4, E=:=F+G, F=:=A, G=:=1, new3(E,B).
new3(A,B) :- C=<D, C=:=A, D=:=8, new4(A,B).
new3(A,B) :- C>=D+1, C=:=A, D=:=8, new5(A,B).
new2 :- A=:=0, B=:=1, new3(B,A).
new1 :- new2.
inv1 :- \+new1.
