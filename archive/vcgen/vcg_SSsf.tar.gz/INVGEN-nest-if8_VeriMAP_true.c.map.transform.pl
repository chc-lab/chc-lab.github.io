new14(A,B,C,D,E,F) :- new5(A,B,C,D,E,F).
new13(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=E.
new13(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=E, I=:=J+K, J=:=D, K=:=1, 
          new12(A,B,C,I,E,F).
new12(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=C, new13(A,B,C,D,E,F).
new12(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=C, new14(A,B,C,D,E,F).
new10(A,B,C,D,E,F) :- G=<H, G=:=I+J, I=:=K+L, K=:=E, L=:=C, J=:=5, H=:=B.
new10(A,B,C,D,E,F) :- G>=H+1, G=:=I+J, I=:=K+L, K=:=E, L=:=C, J=:=5, H=:=B, 
          M=:=N+O, N=:=C, O=:=2, new5(A,B,M,D,E,F).
new8(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=0.
new8(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=0, I=:=J+K, J=:=C, K=:=1, L=:=0, 
          new12(A,B,I,L,E,F).
new6(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, new8(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, new8(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G=:=H, G=:=A, H=:=0, new10(A,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=F, new6(A,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=F, I=:=J+K, J=:=B, K=:=4, 
          new4(A,I,C,D,E,F).
new4(A,B,C,D,E,F) :- G+1=<H, G=:=B, H=:=E, I=:=B, new5(A,B,I,D,E,F).
new3(A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=F, J=:=1, H=:=E, K=:=0, 
          new4(A,K,C,D,E,F).
new2(A) :- new3(A,B,C,D,E,F).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
