new7(A,B,C) :- new7(A,B,C).
new6(A,B,C) :- D=<E, D=:=B, E=:=4.
new4(A,B,C) :- D>=E+1, D=:=A, E=:=0, F=:=A, new6(A,F,C).
new4(A,B,C) :- D=<E, D=:=A, E=:=0, new7(A,B,C).
new3(A,B,C) :- D>=E+1, D=:=A, E=:=4, F=:=4, new4(A,B,F).
new3(A,B,C) :- D=<E, D=:=A, E=:=4, F=:=5, new4(F,B,C).
new2 :- new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
