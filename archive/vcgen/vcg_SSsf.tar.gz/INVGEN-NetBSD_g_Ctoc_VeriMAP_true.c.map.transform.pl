new14(A,B,C,D,E) :- F=:=G, F=:=B, G=:=0, H=:=I+J, I=:=C, J=:=1, K=:=L+M, L=:=D, 
          M=:=1, N=:=O-P, O=:=E, P=:=1, new6(A,B,H,K,N).
new13(A,B,C,D,E) :- F>=G, F=:=C, G=:=A.
new13(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=A, new14(A,B,C,D,E).
new12(A,B,C,D,E) :- F>=G+1, F=:=0, G=:=C.
new12(A,B,C,D,E) :- F=<G, F=:=0, G=:=C, new13(A,B,C,D,E).
new11(A,B,C,D,E) :- F>=G, F=:=D, G=:=A.
new11(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=A, new12(A,B,C,D,E).
new9(A,B,C,D,E) :- F>=G+1, F=:=0, G=:=D.
new9(A,B,C,D,E) :- F=<G, F=:=0, G=:=D, new11(A,B,C,D,E).
new8(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0, new9(A,B,C,D,E).
new8(A,B,C,D,E) :- F+1=<G, F=:=E, G=:=0, new9(A,B,C,D,E).
new6(A,B,C,D,E) :- F>=G+1, F=:=1, G=:=0, new8(A,B,C,D,E).
new5(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0, H=:=0, I=:=0, new6(A,B,H,I,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=E, G=:=0, H=:=0, I=:=0, new6(A,B,H,I,E).
new4(A,B,C,D,E) :- F>=G+1, F=:=0, G=:=H-I, H=:=A, I=:=1.
new4(A,B,C,D,E) :- F=<G, F=:=0, G=:=H-I, H=:=A, I=:=1, new5(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=0, new4(A,B,C,D,E).
new2(A,B) :- C=:=A, new3(A,B,D,E,C).
new1 :- A=:=0, B=:=0, new2(A,B).
inv1 :- \+new1.
