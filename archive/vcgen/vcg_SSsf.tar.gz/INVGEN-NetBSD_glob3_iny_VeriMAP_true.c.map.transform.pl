new15(A,B,C,D,E,F,G,H,I,J) :- K=:=L, K=:=A, L=:=0, new12(A,B,C,D,E,F,G,H,I,J).
new14(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=J, L=:=E.
new14(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=J, L=:=E, M=:=N+O, N=:=J, O=:=1, 
          new15(A,B,C,D,E,F,G,H,I,M).
new13(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=0, L=:=J.
new13(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=0, L=:=J, new14(A,B,C,D,E,F,G,H,I,J).
new12(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=J, L=:=E, new13(A,B,C,D,E,F,G,H,I,J).
new11(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=1, L=:=0, new12(A,B,C,D,E,F,G,H,I,J).
new9(A,B,C,D,E,F,G,H,I,J) :- new4(A,B,C,D,E,F,G,H,I,J).
new8(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, L=:=0, new9(A,B,C,D,E,F,G,H,I,J).
new8(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=A, L=:=0, new9(A,B,C,D,E,F,G,H,I,J).
new8(A,B,C,D,E,F,G,H,I,J) :- K=:=L, K=:=A, L=:=0, M=:=0, 
          new11(A,B,C,D,E,F,G,H,I,M).
new7(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=C, L=:=E.
new7(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=C, L=:=E, new8(A,B,C,D,E,F,G,H,I,J).
new5(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=0, L=:=C.
new5(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=0, L=:=C, new7(A,B,C,D,E,F,G,H,I,J).
new4(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, L=:=0, new5(A,B,C,D,E,F,G,H,I,J).
new4(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=A, L=:=0, new5(A,B,C,D,E,F,G,H,I,J).
new3(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=E, L=:=0, M=:=0, N=:=0, O=:=E, P=:=0, 
          Q=:=0, R=:=E, S=:=0, new4(A,M,N,O,E,S,P,Q,R,J).
new2(A) :- new3(A,B,C,D,E,F,G,H,I,J).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
