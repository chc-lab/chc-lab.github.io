new17(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=G, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new10(K,B,C,D,E,F,G,H).
new17(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=G, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new10(K,B,C,D,E,F,G,H).
new17(A,B,C,D,E,F,G,H) :- I=:=J, I=:=G, J=:=0, K=:=L-M, L=:=A, M=:=1, N=:=O-P, 
          O=:=E, P=:=1, new10(K,B,C,D,N,F,G,H).
new15(A,B,C,D,E,F,G,H) :- I=:=J, new17(A,B,C,D,E,F,I,J).
new14(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=E, J=:=100.
new13(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=A, J=:=100, new14(A,B,C,D,E,F,G,H).
new12(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=100, J=:=E, new15(A,B,C,D,E,F,G,H).
new12(A,B,C,D,E,F,G,H) :- I>=J, I=:=100, J=:=E, new13(A,B,C,D,E,F,G,H).
new10(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=A, J=:=100, new12(A,B,C,D,E,F,G,H).
new10(A,B,C,D,E,F,G,H) :- I>=J, I=:=A, J=:=100, new13(A,B,C,D,E,F,G,H).
new8(A,B,C,D,E,F,G,H) :- new8(A,B,C,D,E,F,G,H).
new7(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=E, J=:=100, new10(A,B,C,D,E,F,G,H).
new7(A,B,C,D,E,F,G,H) :- I>=J, I=:=E, J=:=100, new8(A,B,C,D,E,F,G,H).
new6(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=A, J=:=100, new7(A,B,C,D,E,F,G,H).
new6(A,B,C,D,E,F,G,H) :- I>=J, I=:=A, J=:=100, new8(A,B,C,D,E,F,G,H).
new5(A,B,C,D,E,F,G,H) :- I=:=J, new6(A,B,C,D,I,J,G,H).
new4(A,B,C,D,E,F,G,H) :- I=:=J, new5(A,B,I,J,E,F,G,H).
new3(A,B,C,D,E,F,G,H) :- I=:=J, new4(I,J,C,D,E,F,G,H).
new2 :- new3(A,B,C,D,E,F,G,H).
new1 :- new2.
inv1 :- \+new1.
