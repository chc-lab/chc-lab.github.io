new7(A,B,C,D) :- E>=F+1, E=:=D, F=:=0.
new7(A,B,C,D) :- E+1=<F, E=:=D, F=:=0.
new6(A,B,C,D) :- E>=F+1, E=:=D, F=:=G*H, G=:=B, H=:=2, new7(A,B,C,D).
new6(A,B,C,D) :- E+1=<F, E=:=D, F=:=G*H, G=:=B, H=:=2, new7(A,B,C,D).
new5(A,B,C,D) :- E=:=F, E=:=A, F=:=4, G=:= -10, H=:=I+J, I=:=A, J=:=1, 
          new4(H,B,C,G).
new5(A,B,C,D) :- E>=F+1, E=:=A, F=:=4, G=:=H+I, H=:=A, I=:=1, new4(G,B,C,D).
new5(A,B,C,D) :- E+1=<F, E=:=A, F=:=4, G=:=H+I, H=:=A, I=:=1, new4(G,B,C,D).
new4(A,B,C,D) :- E=<F, E=:=A, F=:=B, G=:=H+I, H=:=D, I=:=2, new5(A,B,C,G).
new4(A,B,C,D) :- E>=F+1, E=:=A, F=:=B, new6(A,B,C,D).
new3(A,B,C,D) :- E=:=F, F>=0, G=:=0, H=:=1, new4(H,E,F,G).
new2 :- new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
