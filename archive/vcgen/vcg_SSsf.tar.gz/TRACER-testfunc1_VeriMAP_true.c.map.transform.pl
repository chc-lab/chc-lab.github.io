new7(A,B,C,D) :- E>=F+1, E=:=C, F=:=0.
new7(A,B,C,D) :- E+1=<F, E=:=C, F=:=0.
new6(A,B,C,D) :- E=:=A, F=:=G+H, G=:=E, H=:=5, I=:=F, J=:=K-L, K=:=M-N, M=:=I, 
          N=:=A, L=:=5, new7(A,I,J,D).
new4(A,B,C,D) :- E=:=A, F=:=G+H, G=:=E, H=:=3, I=:=F, J=:=K-L, K=:=M-N, M=:=I, 
          N=:=A, L=:=3, new7(A,I,J,D).
new3(A,B,C,D) :- E>=F+1, E=:=D, F=:=0, new4(A,B,C,D).
new3(A,B,C,D) :- E+1=<F, E=:=D, F=:=0, new4(A,B,C,D).
new3(A,B,C,D) :- E=:=F, E=:=D, F=:=0, new6(A,B,C,D).
new2 :- new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
