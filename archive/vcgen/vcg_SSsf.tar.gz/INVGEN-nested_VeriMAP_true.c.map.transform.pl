new5(A,B,C) :- D>=E+1, D=:=1, E=:=B.
new4(A,B,C) :- D+1=<E, D=:=A, E=:=C, F=:=G+H, G=:=A, H=:=1, new4(F,B,C).
new4(A,B,C) :- D>=E, D=:=A, E=:=C, F=:=G+H, G=:=B, H=:=1, new3(A,F,C).
new3(A,B,C) :- D+1=<E, D=:=B, E=:=C, F=:=1, new4(F,B,C).
new3(A,B,C) :- D>=E, D=:=B, E=:=C, new5(A,B,C).
new2 :- A=:=1, new3(B,A,C).
new1 :- new2.
inv1 :- \+new1.
