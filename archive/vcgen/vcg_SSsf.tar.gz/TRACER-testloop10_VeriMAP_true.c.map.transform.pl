new7(A,B,C,D) :- E>=F+1, E=:=D, F=:=0, G=:=0, H=:=I+J, I=:=C, J=:=1, 
          new3(G,B,H,D).
new7(A,B,C,D) :- E+1=<F, E=:=D, F=:=0, G=:=0, H=:=I+J, I=:=C, J=:=1, 
          new3(G,B,H,D).
new7(A,B,C,D) :- E=:=F, E=:=D, F=:=0, new3(A,B,C,D).
new6(A,B,C,D) :- E=:=F, E=:=A, F=:=0.
new4(A,B,C,D) :- new7(A,B,C,E).
new3(A,B,C,D) :- E>=F+1, E=:=C, F=:=B, G=:=1, H=:=C, new4(G,H,C,D).
new3(A,B,C,D) :- E+1=<F, E=:=C, F=:=B, G=:=1, H=:=C, new4(G,H,C,D).
new3(A,B,C,D) :- E=:=F, E=:=C, F=:=B, new6(A,B,C,D).
new2 :- A=:=0, B=:=C+D, C=:=E, D=:=1, new3(A,E,B,F).
new1 :- new2.
inv1 :- \+new1.
