new8(A,B,C,D) :- E>=F+1, E=:=D, F=:=0.
new7(A,B,C,D) :- E+1=<F, E=:=B, F=:=1, G=:=1, H=:=I+J, I=:=C, J=:=1, K=:=L+M, 
          L=:=B, M=:=1, new4(A,K,H,G).
new7(A,B,C,D) :- E>=F, E=:=B, F=:=1, G=:=0, H=:=I+J, I=:=C, J=:=1, K=:=L+M, 
          L=:=B, M=:=1, new4(A,K,H,G).
new5(A,B,C,D) :- new5(A,B,C,D).
new4(A,B,C,D) :- E+1=<F, E=:=B, F=:=A, new7(A,B,C,D).
new4(A,B,C,D) :- E>=F, E=:=B, F=:=A, new8(A,B,C,D).
new3(A,B,C,D) :- E>=F+1, E=:=A, F=:=1, new4(A,B,C,D).
new3(A,B,C,D) :- E=<F, E=:=A, F=:=1, new5(A,B,C,D).
new2 :- A=:=0, B=:=0, C=:=0, new3(D,A,B,C).
new1 :- new2.
inv1 :- \+new1.
