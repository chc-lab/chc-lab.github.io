new39(A,B,C) :- D>=E+1, D=:=B, E=:=A.
new38(A,B,C) :- D>=E+1, D=:=B, E=:=A.
new37(A,B,C) :- D>=E+1, D=:=B, E=:=A.
new34(A,B,C) :- D>=E+1, D=:=0, E=:=B.
new34(A,B,C) :- D=<E, D=:=0, E=:=B, new37(A,B,C).
new33(A,B,C) :- D=:=E, D=:=B, E=:=A, new34(A,B,C).
new33(A,B,C) :- D>=E+1, D=:=B, E=:=A, new25(A,B,C).
new33(A,B,C) :- D+1=<E, D=:=B, E=:=A, new25(A,B,C).
new32(A,B,C) :- D>=E+1, D=:=B, E=:=A.
new32(A,B,C) :- D=<E, D=:=B, E=:=A, F=:=G+H, G=:=B, H=:=1, new33(A,F,C).
new29(A,B,C) :- D>=E+1, D=:=0, E=:=B.
new29(A,B,C) :- D=<E, D=:=0, E=:=B, new32(A,B,C).
new28(A,B,C) :- D>=E+1, D=:=B, E=:=A.
new26(A,B,C) :- D>=E+1, D=:=B, E=:=A.
new26(A,B,C) :- D=<E, D=:=B, E=:=A, F=:=G+H, G=:=B, H=:=1, new15(A,F,C).
new25(A,B,C) :- D>=E+1, D=:=0, E=:=B.
new25(A,B,C) :- D=<E, D=:=0, E=:=B, new26(A,B,C).
new23(A,B,C) :- D>=E+1, D=:=0, E=:=B.
new23(A,B,C) :- D=<E, D=:=0, E=:=B, new28(A,B,C).
new22(A,B,C) :- D>=E+1, D=:=C, E=:=0, new23(A,B,C).
new22(A,B,C) :- D+1=<E, D=:=C, E=:=0, new23(A,B,C).
new22(A,B,C) :- D=:=E, D=:=C, E=:=0, new25(A,B,C).
new20(A,B,C) :- D>=E+1, D=:=C, E=:=0, new29(A,B,C).
new20(A,B,C) :- D+1=<E, D=:=C, E=:=0, new29(A,B,C).
new20(A,B,C) :- D=:=E, D=:=C, E=:=0, new25(A,B,C).
new18(A,B,C) :- D>=E+1, D=:=C, E=:=0, new20(A,B,C).
new18(A,B,C) :- D+1=<E, D=:=C, E=:=0, new20(A,B,C).
new18(A,B,C) :- D=:=E, D=:=C, E=:=0, new22(A,B,C).
new17(A,B,C) :- D>=E+1, D=:=0, E=:=B.
new17(A,B,C) :- D=<E, D=:=0, E=:=B, new38(A,B,C).
new16(A,B,C) :- D=:=E, D=:=B, E=:=A, new17(A,B,C).
new16(A,B,C) :- D>=E+1, D=:=B, E=:=A, new18(A,B,C).
new16(A,B,C) :- D+1=<E, D=:=B, E=:=A, new18(A,B,C).
new15(A,B,C) :- D>=E+1, D=:=1, E=:=0, new16(A,B,C).
new14(A,B,C) :- D>=E+1, D=:=B, E=:=A.
new14(A,B,C) :- D=<E, D=:=B, E=:=A, F=:=G+H, G=:=B, H=:=1, new15(A,F,C).
new12(A,B,C) :- D>=E+1, D=:=B, E=:=A.
new12(A,B,C) :- D=<E, D=:=B, E=:=A, F=:=G+H, G=:=B, H=:=1, new4(A,F,C).
new11(A,B,C) :- D>=E+1, D=:=0, E=:=B.
new11(A,B,C) :- D=<E, D=:=0, E=:=B, new12(A,B,C).
new9(A,B,C) :- D>=E+1, D=:=0, E=:=B.
new9(A,B,C) :- D=<E, D=:=0, E=:=B, new14(A,B,C).
new7(A,B,C) :- D>=E+1, D=:=C, E=:=0, new9(A,B,C).
new7(A,B,C) :- D+1=<E, D=:=C, E=:=0, new9(A,B,C).
new7(A,B,C) :- D=:=E, D=:=C, E=:=0, new11(A,B,C).
new6(A,B,C) :- D>=E+1, D=:=0, E=:=B.
new6(A,B,C) :- D=<E, D=:=0, E=:=B, new39(A,B,C).
new5(A,B,C) :- D=:=E, D=:=B, E=:=A, new6(A,B,C).
new5(A,B,C) :- D>=E+1, D=:=B, E=:=A, new7(A,B,C).
new5(A,B,C) :- D+1=<E, D=:=B, E=:=A, new7(A,B,C).
new4(A,B,C) :- D>=E+1, D=:=1, E=:=0, new5(A,B,C).
new3(A,B,C) :- D>=E, D=:=A, E=:=1, F=:=0, G=:=H-I, H=:=A, I=:=1, new4(G,F,C).
new2 :- new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
