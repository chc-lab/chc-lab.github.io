README for VeriMAP
------------------

VeriMAP is a tool for the verification of C programs based 
on the transformation of constraint logic programs.


Quick start
-----------

Download VeriMAP and run the following commands: 

  tar -zxvf VeriMAP-linux_x86_64.tar.gz
  cd VeriMAP-linux_x86_64
  

Usage
-----

Getting help:

  ./VeriMAP --help 

Generating the VCs by using the interpreter for the small-step semantics (SSsf):

  ./VeriMAP example.c --vcg=vcg_SSsf.iteration --source-format C

Generating the VCs by using the interpreter for the multi-step semantics (MS):

  ./VeriMAP example.c --vcg=vcg_MS.iteration --source-format C

The generated VCs can be found in OutProgs-vcg.

Generating the VCs and converting them to the specified format: 

  ./VeriMAP example.c --vcg=vcg_SSsf.iteration --source-format C --convert-to $FORMAT

where $FORMAT is either 
'horn' (e.g., for the eldarica and qarmc solvers), or
'smt' (e.g., for the msatic3 solver), or
'z3-fixedpoints' (for the muZ with fixed-point constraints extension of the z3 solver).

The result of the translation process can be found in OutProgs-map2{horn,smt,z3}.

Removing non-linking variables:
  
  ./VeriMAP example.pl --transform=nlr.iteration

Constrained FAR (to be applied on the output obtained by using '--transform=nlv.iteration'):
  
  ./VeriMAP example.pl --transform=constrained-far.iteration

The result of the transformation process can be found in OutProgs-uft.

