new5(A) :- B>=C+1, B=:=A, C=:=50.
new5(A) :- B+1=<C, B=:=A, C=:=50.
new4(A) :- B=:=C, B=:=A, C=:=50, new5(A).
new4(A) :- B>=C+1, B=:=A, C=:=50, new3(A).
new4(A) :- B+1=<C, B=:=A, C=:=50, new3(A).
new3(A) :- B+1=<C, B=:=A, C=:=100, D=:=E+F, E=:=A, F=:=1, new4(D).
new3(A) :- B>=C, B=:=A, C=:=100, new5(A).
new2 :- A=:=0, new3(A).
new1 :- new2.
inv1 :- \+new1.
