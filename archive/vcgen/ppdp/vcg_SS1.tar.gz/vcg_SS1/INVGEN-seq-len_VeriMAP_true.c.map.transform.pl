new14(A,B,C,D,E) :- F=<G, F=:=E, G=:=0.
new14(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0, H=:=I+J, I=:=D, J=:=1, K=:=L-M, 
          L=:=E, M=:=1, new13(A,B,C,H,K).
new13(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=A, new14(A,B,C,D,E).
new11(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=B, H=:=I+J, I=:=D, J=:=1, K=:=L-M, 
          L=:=E, M=:=1, new11(A,B,C,H,K).
new11(A,B,C,D,E) :- F>=G, F=:=D, G=:=B, H=:=0, new13(A,B,C,H,E).
new9(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=C, H=:=I+J, I=:=D, J=:=1, K=:=L-M, L=:=E, 
          M=:=1, new9(A,B,C,H,K).
new9(A,B,C,D,E) :- F>=G, F=:=D, G=:=C, H=:=0, new11(A,B,C,H,E).
new7(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=C, H=:=I+J, I=:=D, J=:=1, K=:=L+M, L=:=E, 
          M=:=1, new7(A,B,C,H,K).
new7(A,B,C,D,E) :- F>=G, F=:=D, G=:=C, H=:=0, new9(A,B,C,H,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=B, H=:=I+J, I=:=D, J=:=1, K=:=L+M, L=:=E, 
          M=:=1, new5(A,B,C,H,K).
new5(A,B,C,D,E) :- F>=G, F=:=D, G=:=B, H=:=0, new7(A,B,C,H,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=A, H=:=I+J, I=:=D, J=:=1, K=:=L+M, L=:=E, 
          M=:=1, new3(A,B,C,H,K).
new3(A,B,C,D,E) :- F>=G, F=:=D, G=:=A, H=:=0, new5(A,B,C,H,E).
new2 :- A=:=0, B=:=0, new3(C,D,E,A,B).
new1 :- new2.
inv1 :- \+new1.
