new370(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=T, D1=:=0, E1=:=0, F1=:=2, G1=:=1, H1=:=2, 
          new242(G1,B,C,H1,E,E1,G,H,I,J,K,L,M,F1,O,P,Q,U,V,W,X,Y,Z,A1,B1).
new370(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=T, D1=:=0, E1=:=0, F1=:=2, G1=:=1, H1=:=2, 
          new242(G1,B,C,H1,E,E1,G,H,I,J,K,L,M,F1,O,P,Q,U,V,W,X,Y,Z,A1,B1).
new370(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=T, D1=:=0, E1=:=2, F1=:=1, G1=:=2, 
          new242(F1,B,C,G1,E,F,G,H,I,J,K,L,M,E1,O,P,Q,U,V,W,X,Y,Z,A1,B1).
new369(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=O, E1=:=1, F1=:=1, G1=:=F1, 
          new370(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new369(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=O, E1=:=1, F1=:=0, G1=:=F1, 
          new370(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new369(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=O, E1=:=1, F1=:=0, G1=:=F1, 
          new370(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new368(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=C, E1=:=1, 
          new369(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new368(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=C, E1=:=1, F1=:=0, G1=:=F1, 
          new370(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new368(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=C, E1=:=1, F1=:=0, G1=:=F1, 
          new370(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new365(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new368(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new363(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=S, D1=:=0, E1=:=0, 
          new365(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new363(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=S, D1=:=0, E1=:=0, 
          new365(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new363(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=S, D1=:=0, 
          new365(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new362(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=N, E1=:=1, F1=:=1, G1=:=F1, 
          new363(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new362(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=N, E1=:=1, F1=:=0, G1=:=F1, 
          new363(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new362(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=N, E1=:=1, F1=:=0, G1=:=F1, 
          new363(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new361(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=B, E1=:=1, 
          new362(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new361(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=B, E1=:=1, F1=:=0, G1=:=F1, 
          new363(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new361(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=B, E1=:=1, F1=:=0, G1=:=F1, 
          new363(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new358(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new361(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new356(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=R, D1=:=0, E1=:=0, 
          new358(A,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new356(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=R, D1=:=0, E1=:=0, 
          new358(A,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new356(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=R, D1=:=0, 
          new358(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new355(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=M, E1=:=1, F1=:=1, G1=:=F1, 
          new356(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new355(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=1, F1=:=0, G1=:=F1, 
          new356(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new355(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=1, F1=:=0, G1=:=F1, 
          new356(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=A, E1=:=1, 
          new355(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=A, E1=:=1, F1=:=0, G1=:=F1, 
          new356(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=A, E1=:=1, F1=:=0, G1=:=F1, 
          new356(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new353(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new352(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new353(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,A1,B1,R,S,T,U,V,W,X,Y).
new351(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new352(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new350(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, B1=:=1, 
          new351(A,B,C,D,E,F,G,H,I,J,K,L,M,B1,O,A1,Z,R,S,T,U,V,W,X,Y).
new346(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=P, 
          A1=:=B1+C1, B1=:=Q, C1=:=2.
new346(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=P, 
          A1=:=B1+C1, B1=:=Q, C1=:=2.
new346(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=P, 
          A1=:=B1+C1, B1=:=Q, C1=:=2, 
          new343(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new344(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=A, 
          A1=:=1, new346(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new344(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=A, 
          A1=:=1, new343(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new344(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=A, 
          A1=:=1, new343(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new343(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=1, 
          A1=:=0, new350(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new342(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=A, 
          A1=:=0, new343(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new342(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=A, 
          A1=:=0, new344(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new342(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=A, 
          A1=:=0, new344(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new339(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new342(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new338(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=S, 
          A1=:=0, B1=:=1, 
          new339(A,B,C,B1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new338(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=S, 
          A1=:=0, B1=:=1, 
          new339(A,B,C,B1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new338(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=S, 
          A1=:=0, new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=T, D1=:=0, E1=:=0, F1=:=2, 
          new299(A,B,C,D,E,E1,G,H,I,J,K,L,M,N,F1,P,Q,U,V,W,X,Y,Z,A1,B1).
new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=T, D1=:=0, E1=:=0, F1=:=2, 
          new299(A,B,C,D,E,E1,G,H,I,J,K,L,M,N,F1,P,Q,U,V,W,X,Y,Z,A1,B1).
new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=T, D1=:=0, E1=:=2, 
          new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E1,P,Q,U,V,W,X,Y,Z,A1,B1).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=O, E1=:=1, F1=:=1, G1=:=F1, 
          new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=O, E1=:=1, F1=:=0, G1=:=F1, 
          new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=O, E1=:=1, F1=:=0, G1=:=F1, 
          new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new321(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=C, E1=:=1, 
          new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new321(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=C, E1=:=1, F1=:=0, G1=:=F1, 
          new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new321(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=C, E1=:=1, F1=:=0, G1=:=F1, 
          new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new318(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new321(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=S, D1=:=0, E1=:=0, 
          new318(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=S, D1=:=0, E1=:=0, 
          new318(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=S, D1=:=0, 
          new318(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=N, E1=:=1, F1=:=1, G1=:=F1, 
          new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=N, E1=:=1, F1=:=0, G1=:=F1, 
          new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=N, E1=:=1, F1=:=0, G1=:=F1, 
          new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new314(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=B, E1=:=1, 
          new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new314(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=B, E1=:=1, F1=:=0, G1=:=F1, 
          new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new314(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=B, E1=:=1, F1=:=0, G1=:=F1, 
          new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new311(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new314(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new309(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=R, D1=:=0, E1=:=0, 
          new311(A,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new309(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=R, D1=:=0, E1=:=0, 
          new311(A,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new309(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=R, D1=:=0, 
          new311(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=M, E1=:=1, F1=:=1, G1=:=F1, 
          new309(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=1, F1=:=0, G1=:=F1, 
          new309(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=1, F1=:=0, G1=:=F1, 
          new309(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=A, E1=:=1, 
          new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=A, E1=:=1, F1=:=0, G1=:=F1, 
          new309(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=A, E1=:=1, F1=:=0, G1=:=F1, 
          new309(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new306(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new305(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new306(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,A1,B1,R,S,T,U,V,W,X,Y).
new302(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new305(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new300(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=B, 
          A1=:=1, B1=:=C1+D1, C1=:=P, D1=:=1, E1=:=1, 
          new302(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E1,B1,Q,R,S,T,U,V,W,X,Y).
new300(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=B, 
          A1=:=1, new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new300(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=1, new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=1, 
          A1=:=0, B1=:=1, C1=:=2, 
          new245(A,B1,C,D,C1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new298(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=B, 
          A1=:=0, new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new298(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=B, 
          A1=:=0, new300(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new298(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=0, new300(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new295(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new298(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new294(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=T, 
          A1=:=0, B1=:=1, 
          new295(A,B,C,D,B1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new294(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=T, 
          A1=:=0, B1=:=1, 
          new295(A,B,C,D,B1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new294(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=T, 
          A1=:=0, new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=T, D1=:=0, E1=:=0, F1=:=2, 
          new255(A,B,C,D,E,E1,G,H,I,J,K,L,F1,N,O,P,Q,U,V,W,X,Y,Z,A1,B1).
new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=T, D1=:=0, E1=:=0, F1=:=2, 
          new255(A,B,C,D,E,E1,G,H,I,J,K,L,F1,N,O,P,Q,U,V,W,X,Y,Z,A1,B1).
new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=T, D1=:=0, E1=:=2, 
          new255(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O,P,Q,U,V,W,X,Y,Z,A1,B1).
new278(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=O, E1=:=1, F1=:=1, G1=:=F1, 
          new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new278(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=O, E1=:=1, F1=:=0, G1=:=F1, 
          new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new278(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=O, E1=:=1, F1=:=0, G1=:=F1, 
          new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new277(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=C, E1=:=1, 
          new278(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new277(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=C, E1=:=1, F1=:=0, G1=:=F1, 
          new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new277(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=C, E1=:=1, F1=:=0, G1=:=F1, 
          new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,G1,V,W,X,Y,Z,A1,B1,C1).
new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new277(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new272(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=S, D1=:=0, E1=:=0, 
          new274(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new272(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=S, D1=:=0, E1=:=0, 
          new274(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new272(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=S, D1=:=0, 
          new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new271(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=N, E1=:=1, F1=:=1, G1=:=F1, 
          new272(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new271(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=N, E1=:=1, F1=:=0, G1=:=F1, 
          new272(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new271(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=N, E1=:=1, F1=:=0, G1=:=F1, 
          new272(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new270(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=B, E1=:=1, 
          new271(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new270(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=B, E1=:=1, F1=:=0, G1=:=F1, 
          new272(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new270(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=B, E1=:=1, F1=:=0, G1=:=F1, 
          new272(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,G1,U,V,W,X,Y,Z,A1,B1,C1).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new270(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=R, D1=:=0, E1=:=0, 
          new267(A,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=R, D1=:=0, E1=:=0, 
          new267(A,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=R, D1=:=0, 
          new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new264(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=M, E1=:=1, F1=:=1, G1=:=F1, 
          new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new264(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=1, F1=:=0, G1=:=F1, 
          new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new264(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=1, F1=:=0, G1=:=F1, 
          new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new263(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=A, E1=:=1, 
          new264(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new263(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=A, E1=:=1, F1=:=0, G1=:=F1, 
          new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new263(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=A, E1=:=1, F1=:=0, G1=:=F1, 
          new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,G1,T,U,V,W,X,Y,Z,A1,B1,C1).
new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new263(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,A1,B1,R,S,T,U,V,W,X,Y).
new258(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=C, 
          A1=:=1, B1=:=C1+D1, C1=:=P, D1=:=1, E1=:=1, 
          new258(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O,B1,Q,R,S,T,U,V,W,X,Y).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=C, 
          A1=:=1, new255(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=C, 
          A1=:=1, new255(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new255(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=1, 
          A1=:=0, B1=:=1, C1=:=2, 
          new78(A,B,B1,D,E,C1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=C, 
          A1=:=0, new255(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=C, 
          A1=:=0, new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=C, 
          A1=:=0, new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=U, 
          A1=:=0, B1=:=1, 
          new251(A,B,C,D,E,B1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=U, 
          A1=:=0, B1=:=1, 
          new251(A,B,C,D,E,B1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=U, 
          A1=:=0, new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,Z,V,W,X,Y).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=F, 
          A1=:=0, new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=F, 
          A1=:=0, new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=F, 
          A1=:=0, new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new294(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Z,U,V,W,X,Y).
new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=E, 
          A1=:=0, new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=E, 
          A1=:=0, new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=E, 
          A1=:=0, new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new241(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new338(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W,X,Y).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=O, W=:=1, 
          X=:=2, new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,X,P,Q,R,S,T,U).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=O, W=:=1, 
          new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=O, W=:=1, 
          new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=1, 
          X=:=2, new217(A,B,C,D,E,F,G,H,I,J,K,L,M,X,O,P,Q,R,S,T,U).
new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=1, 
          new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=1, 
          new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=1, 
          X=:=2, new214(A,B,C,D,E,F,G,H,I,J,K,L,X,N,O,P,Q,R,S,T,U).
new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=1, 
          new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=1, 
          new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=L, W=:=1, 
          X=:=2, new211(A,B,C,D,E,F,G,H,I,J,K,X,M,N,O,P,Q,R,S,T,U).
new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=L, W=:=1, 
          new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=L, W=:=1, 
          new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=K, W=:=1, 
          X=:=2, new208(A,B,C,D,E,F,G,H,I,J,X,L,M,N,O,P,Q,R,S,T,U).
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=K, W=:=1, 
          new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=K, W=:=1, 
          new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=J, W=:=1, 
          X=:=2, new205(A,B,C,D,E,F,G,H,I,X,K,L,M,N,O,P,Q,R,S,T,U).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=J, W=:=1, 
          new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=J, W=:=1, 
          new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new201(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=T, 
          Z=:=0, A1=:=0, new201(A,B,C,D,E,A1,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,X).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=T, 
          Z=:=0, A1=:=0, new201(A,B,C,D,E,A1,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,X).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=T, Z=:=0, 
          new201(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,X).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=O, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=O, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=O, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=C, 
          A1=:=1, new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=C, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=C, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Y,R,S,T,U,V,W,X).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=S, 
          Z=:=0, A1=:=0, 
          new194(A,B,C,D,A1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=S, 
          Z=:=0, A1=:=0, 
          new194(A,B,C,D,A1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=S, Z=:=0, 
          new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=N, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=N, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=N, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=B, 
          A1=:=1, new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=B, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Y,R,S,T,U,V,W,X).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=R, 
          Z=:=0, A1=:=0, 
          new187(A,B,C,A1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=R, 
          Z=:=0, A1=:=0, 
          new187(A,B,C,A1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=R, Z=:=0, 
          new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new184(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=M, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new184(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=M, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new184(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=M, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=A, 
          A1=:=1, new184(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=A, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=A, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Y,R,S,T,U,V,W,X).
new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,V,W,X,R,S,T,U).
new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=T, W=:=0, 
          new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=F, Z=:=0, 
          A1=:=1, B1=:=A1, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,B1,T,U,V,W,X).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=F, 
          Z=:=0, A1=:=0, B1=:=A1, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,B1,T,U,V,W,X).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=F, 
          Z=:=0, A1=:=0, B1=:=A1, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,B1,T,U,V,W,X).
new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=E, Z=:=0, 
          A1=:=1, B1=:=A1, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,B1,T,U,V,W,X).
new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=E, 
          Z=:=0, new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=E, 
          Z=:=0, new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=R, Y=:=0, 
          Z=:=0, A1=:=Z, new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,T,U,A1,W).
new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=R, Y=:=0, 
          Z=:=0, A1=:=Z, new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,T,U,A1,W).
new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=R, Y=:=0, 
          Z=:=1, A1=:=Z, new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,T,U,A1,W).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=D, Z=:=0, 
          A1=:=1, B1=:=A1, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,B1,T,U,V,W,X).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=D, 
          Z=:=0, new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=D, 
          Z=:=0, new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new166(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,X,R,S,T,U,V,W).
new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new166(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,V,W,R,S,T,U).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=1, 
          new181(A,B,C,D,E,F,G,H,I,V,K,L,M,N,O,P,Q,R,S,T,U).
new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=F, X=:=0, 
          Y=:=1, Z=:=Y, new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,Z,U,V).
new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=F, X=:=0, 
          Y=:=0, Z=:=Y, new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,Z,U,V).
new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=F, X=:=0, 
          Y=:=0, Z=:=Y, new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,Z,U,V).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=E, X=:=0, 
          Y=:=1, Z=:=Y, new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,Z,U,V).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=E, X=:=0, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=E, X=:=0, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=S, W=:=0, 
          X=:=4, new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,X,S,T,U).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=S, W=:=0, 
          new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=S, W=:=0, 
          new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=D, X=:=0, 
          Y=:=1, Z=:=Y, new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,Z,U,V).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=D, X=:=0, 
          new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=D, X=:=0, 
          new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,V,R,S,T,U).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=O, W=:=1, 
          X=:=2, new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,X,P,Q,R,S,T,U).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=O, W=:=1, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=O, W=:=1, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=1, 
          X=:=2, new147(A,B,C,D,E,F,G,H,I,J,K,L,M,X,O,P,Q,R,S,T,U).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=1, 
          new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=1, 
          new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=1, 
          X=:=2, new144(A,B,C,D,E,F,G,H,I,J,K,L,X,N,O,P,Q,R,S,T,U).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=1, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=1, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=L, W=:=1, 
          X=:=2, new141(A,B,C,D,E,F,G,H,I,J,K,X,M,N,O,P,Q,R,S,T,U).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=L, W=:=1, 
          new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=L, W=:=1, 
          new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=K, W=:=1, 
          X=:=2, new138(A,B,C,D,E,F,G,H,I,J,X,L,M,N,O,P,Q,R,S,T,U).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=K, W=:=1, 
          new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=K, W=:=1, 
          new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=J, W=:=1, 
          X=:=2, new135(A,B,C,D,E,F,G,H,I,X,K,L,M,N,O,P,Q,R,S,T,U).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=J, W=:=1, 
          new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=J, W=:=1, 
          new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=T, 
          Z=:=0, A1=:=0, new131(A,B,C,D,E,A1,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,X).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=T, 
          Z=:=0, A1=:=0, new131(A,B,C,D,E,A1,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,X).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=T, Z=:=0, 
          new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,X).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=O, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=O, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=O, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=C, 
          A1=:=1, new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=C, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=C, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Y,R,S,T,U,V,W,X).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=S, 
          Z=:=0, A1=:=0, 
          new124(A,B,C,D,A1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=S, 
          Z=:=0, A1=:=0, 
          new124(A,B,C,D,A1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=S, Z=:=0, 
          new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=N, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=N, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=N, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=B, 
          A1=:=1, new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=B, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Y,R,S,T,U,V,W,X).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=R, 
          Z=:=0, A1=:=0, 
          new117(A,B,C,A1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=R, 
          Z=:=0, A1=:=0, 
          new117(A,B,C,A1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=R, Z=:=0, 
          new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=M, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=M, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=M, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=A, 
          A1=:=1, new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=A, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=A, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Y,R,S,T,U,V,W,X).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,V,W,X,R,S,T,U).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=O, W=:=0, 
          X=:=1, new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,X,P,Q,R,S,T,U).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=O, W=:=0, 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=O, W=:=0, 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=0, 
          X=:=1, new106(A,B,C,D,E,F,G,H,I,J,K,L,M,X,O,P,Q,R,S,T,U).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=0, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=0, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=0, 
          X=:=1, new103(A,B,C,D,E,F,G,H,I,J,K,L,X,N,O,P,Q,R,S,T,U).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=0, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=0, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=L, W=:=0, X=:=1, 
          new100(A,B,C,D,E,F,G,H,I,J,K,X,M,N,O,P,Q,R,S,T,U).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=L, W=:=0, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=L, W=:=0, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=K, W=:=0, X=:=1, 
          new97(A,B,C,D,E,F,G,H,I,J,X,L,M,N,O,P,Q,R,S,T,U).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=K, W=:=0, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=K, W=:=0, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=J, W=:=0, X=:=1, 
          new94(A,B,C,D,E,F,G,H,I,X,K,L,M,N,O,P,Q,R,S,T,U).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=J, W=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=J, W=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=3, 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,V,S,T,U).
new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=D, 
          A1=:=0, new241(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=D, 
          A1=:=0, new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=D, 
          A1=:=0, new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=F, 
          B1=:=0, C1=:=1, D1=:=C1, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,D1,T,U,V,W,X,Y,Z).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, A1=:=F, 
          B1=:=0, C1=:=0, D1=:=C1, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,D1,T,U,V,W,X,Y,Z).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, A1=:=F, 
          B1=:=0, C1=:=0, D1=:=C1, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,D1,T,U,V,W,X,Y,Z).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=E, 
          B1=:=0, C1=:=1, D1=:=C1, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,D1,T,U,V,W,X,Y,Z).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, A1=:=E, 
          B1=:=0, new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, A1=:=E, 
          B1=:=0, new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=R, 
          A1=:=0, new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=R, 
          A1=:=0, new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=R, 
          A1=:=0, B1=:=2, new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,B1,W,X,Y).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=D, 
          B1=:=0, C1=:=1, D1=:=C1, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,D1,T,U,V,W,X,Y,Z).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, A1=:=D, 
          B1=:=0, new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, A1=:=D, 
          B1=:=0, new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,R,S,T,U,V,W,X,Y).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,V,W,X,Y,R,S,T,U).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=1, W=:=0, 
          X=:=1, new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,X,S,T,U).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=O, W=:=1, X=:=2, 
          new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,X,P,Q,R,S,T,U).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=O, W=:=1, 
          new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=O, W=:=1, 
          new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=1, X=:=2, 
          new71(A,B,C,D,E,F,G,H,I,J,K,L,M,X,O,P,Q,R,S,T,U).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=1, 
          new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=1, 
          new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=1, X=:=2, 
          new68(A,B,C,D,E,F,G,H,I,J,K,L,X,N,O,P,Q,R,S,T,U).
new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=1, 
          new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=1, 
          new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=L, W=:=1, X=:=2, 
          new65(A,B,C,D,E,F,G,H,I,J,K,X,M,N,O,P,Q,R,S,T,U).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=L, W=:=1, 
          new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=L, W=:=1, 
          new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=K, W=:=1, X=:=2, 
          new62(A,B,C,D,E,F,G,H,I,J,X,L,M,N,O,P,Q,R,S,T,U).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=K, W=:=1, 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=K, W=:=1, 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=J, W=:=1, X=:=2, 
          new59(A,B,C,D,E,F,G,H,I,X,K,L,M,N,O,P,Q,R,S,T,U).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=J, W=:=1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=J, W=:=1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=T, Z=:=0, 
          A1=:=0, new55(A,B,C,D,E,A1,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,X).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=T, Z=:=0, 
          A1=:=0, new55(A,B,C,D,E,A1,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,X).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=T, Z=:=0, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,X).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=O, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=O, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=O, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=C, 
          A1=:=1, new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=C, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=C, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,C1,V,W,X,Y).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Y,R,S,T,U,V,W,X).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=S, Z=:=0, 
          A1=:=0, new48(A,B,C,D,A1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=S, Z=:=0, 
          A1=:=0, new48(A,B,C,D,A1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=S, Z=:=0, 
          new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=N, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=N, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=N, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=B, 
          A1=:=1, new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=B, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,C1,U,V,W,X,Y).
new41(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Y,R,S,T,U,V,W,X).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=R, Z=:=0, 
          A1=:=0, new41(A,B,C,A1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=R, Z=:=0, 
          A1=:=0, new41(A,B,C,A1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=R, Z=:=0, 
          new41(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=M, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=M, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=M, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=A, 
          A1=:=1, new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=A, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=A, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,C1,T,U,V,W,X,Y).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Y,R,S,T,U,V,W,X).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,V,W,X,R,S,T,U).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=O, W=:=0, X=:=1, 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,X,P,Q,R,S,T,U).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=O, W=:=0, 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=O, W=:=0, 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=0, X=:=1, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,X,O,P,Q,R,S,T,U).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=0, X=:=1, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,X,N,O,P,Q,R,S,T,U).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=L, W=:=0, X=:=1, 
          new24(A,B,C,D,E,F,G,H,I,J,K,X,M,N,O,P,Q,R,S,T,U).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=L, W=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=L, W=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=K, W=:=0, X=:=1, 
          new21(A,B,C,D,E,F,G,H,I,J,X,L,M,N,O,P,Q,R,S,T,U).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=K, W=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=K, W=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=J, W=:=0, X=:=1, 
          new18(A,B,C,D,E,F,G,H,I,X,K,L,M,N,O,P,Q,R,S,T,U).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=J, W=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=J, W=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=I, W=:=1, X=:=0, 
          new14(A,B,C,D,E,X,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=I, W=:=1, 
          X=:=2, new14(A,B,C,D,E,X,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=I, W=:=1, 
          X=:=2, new14(A,B,C,D,E,X,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=H, W=:=1, X=:=0, 
          new11(A,B,C,D,X,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=H, W=:=1, X=:=2, 
          new11(A,B,C,D,X,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=H, W=:=1, X=:=2, 
          new11(A,B,C,D,X,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=G, W=:=1, X=:=0, 
          new8(A,B,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=G, W=:=1, X=:=2, 
          new8(A,B,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=G, W=:=1, X=:=2, 
          new8(A,B,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,U,R).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=1, T=:=1, U=:=1, 
          new4(A,B,C,D,E,F,S,T,U,J,K,L,M,N,O,P,Q,R).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=2, 
          K=:=2, L=:=2, M=:=2, N=:=2, O=:=2, P=:=0, Q=:=0, 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
inv1 :- \+new1.
