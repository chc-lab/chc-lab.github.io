new6(A,B,C) :- D+1=<E, D=:=B, E=:=0.
new4(A,B,C) :- D+1=<E, D=:=A, E=:=0, F=:= -1, new6(A,F,C).
new4(A,B,C) :- D>=E, D=:=A, E=:=0, F=:=1, new6(A,F,C).
new3(A,B,C) :- D>=E+1, D=:=C, E=:=0, F=:=1, new4(F,B,C).
new3(A,B,C) :- D=<E, D=:=C, E=:=0, F=:=2, new4(F,B,C).
new2 :- new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
