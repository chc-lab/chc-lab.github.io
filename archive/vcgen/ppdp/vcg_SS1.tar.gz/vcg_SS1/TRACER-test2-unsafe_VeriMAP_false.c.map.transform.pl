new12(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=A, J=:=K+L, K=:=C, L=:=B, M=:=N*O, 
          N=:=D, O=:=B, P=:=Q+R, Q=:=B, R=:=1, S=:=J, T=:=U+V, U=:=S, V=:=5, 
          new7(T,F,S).
new12(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, J=:=C, K=:=L+M, L=:=J, M=:=5, 
          new7(K,F,J).
new10(A,B,C) :- D=:=5, E=:=1, F=:=0, G=:=1, new12(D,E,F,G,A,B,C).
new9(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=A, J=:=K+L, K=:=C, L=:=B, M=:=N*O, 
          N=:=D, O=:=B, P=:=Q+R, Q=:=B, R=:=1, S=:=J, T=:=U-V, U=:=S, V=:=1, 
          new10(T,S,G).
new9(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, J=:=C, K=:=L-M, L=:=J, M=:=1, 
          new10(K,J,G).
new8(A,B,C) :- D=:=A, E=:=1, F=:=0, G=:=1, new9(D,E,F,G,A,B,C).
new7(A,B,C) :- D>=E+1, D=:=A, E=:=0.
new5(A,B,C) :- new5(A,B,C).
new4(A,B,C) :- D>=E+1, D=:=A, E=:=0, F=:=G+H, G=:=A, H=:=1, new7(F,B,C).
new4(A,B,C) :- D=<E, D=:=A, E=:=0, new8(A,B,C).
new3(A,B,C) :- D>=E+1, D=:=A, E=:=0, new4(A,B,C).
new3(A,B,C) :- D=<E, D=:=A, E=:=0, new5(A,B,C).
new2 :- new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
