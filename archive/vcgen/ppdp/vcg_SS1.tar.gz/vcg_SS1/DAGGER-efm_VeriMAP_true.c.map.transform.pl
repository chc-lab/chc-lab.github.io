new45(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=1, N=:=O-P, O=:=A, P=:=1, 
          Q=:=R-S, R=:=D, S=:=1, T=:=U+V, U=:=B, V=:=1, W=:=X+Y, X=:=E, Y=:=1, 
          new9(N,T,C,Q,W,F,G,H,I,J,K).
new43(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=F, M=:=1, N=:=O-P, O=:=B, P=:=1, 
          Q=:=R+S, R=:=C, S=:=1, new9(A,N,Q,D,E,F,G,H,I,J,K).
new41(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=1, N=:=O-P, O=:=C, P=:=1, 
          Q=:=R+S, R=:=B, S=:=1, new9(A,Q,N,D,E,F,G,H,I,J,K).
new38(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=B, M=:=1, N=:=O-P, O=:=B, P=:=1, 
          Q=:=R+S, R=:=A, S=:=1, T=:=U+V, U=:=D, V=:=F, W=:=0, 
          new9(Q,N,C,T,E,W,G,H,I,J,K).
new36(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=1, N=:=O-P, O=:=C, P=:=1, 
          Q=:=R+S, R=:=A, S=:=1, T=:=U+V, U=:=F, V=:=E, W=:=0, 
          new9(Q,B,N,D,W,T,G,H,I,J,K).
new35(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=G, M=:=0, 
          new36(A,B,C,D,E,F,G,H,I,J,K).
new35(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=G, M=:=0, 
          new36(A,B,C,D,E,F,G,H,I,J,K).
new35(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=G, M=:=0, 
          new38(A,B,C,D,E,F,G,H,I,J,K).
new34(A,B,C,D,E,F,G,H,I,J,K) :- new35(A,B,C,D,E,F,L,H,I,J,K).
new32(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=1, 
          new41(A,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=H, M=:=0, 
          new32(A,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=H, M=:=0, 
          new32(A,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=H, M=:=0, 
          new34(A,B,C,D,E,F,G,H,I,J,K).
new30(A,B,C,D,E,F,G,H,I,J,K) :- new31(A,B,C,D,E,F,G,L,I,J,K).
new28(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=B, M=:=1, 
          new43(A,B,C,D,E,F,G,H,I,J,K).
new27(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=I, M=:=0, 
          new28(A,B,C,D,E,F,G,H,I,J,K).
new27(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=I, M=:=0, 
          new28(A,B,C,D,E,F,G,H,I,J,K).
new27(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=I, M=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K).
new26(A,B,C,D,E,F,G,H,I,J,K) :- new27(A,B,C,D,E,F,G,H,L,J,K).
new24(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=A, M=:=1, 
          new45(A,B,C,D,E,F,G,H,I,J,K).
new23(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=J, M=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K).
new23(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=J, M=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K).
new23(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=J, M=:=0, 
          new26(A,B,C,D,E,F,G,H,I,J,K).
new22(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=N+O, N=:=P+Q, P=:=A, Q=:=B, O=:=C, 
          M=:=1.
new21(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=N+O, N=:=A, O=:=B, M=:=P+Q, P=:=D, 
          Q=:=E.
new21(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=N+O, N=:=A, O=:=B, M=:=P+Q, P=:=D, 
          Q=:=E, new22(A,B,C,D,E,F,G,H,I,J,K).
new20(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=N+O, N=:=A, O=:=E, M=:=1.
new20(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=N+O, N=:=A, O=:=E, M=:=1, 
          new21(A,B,C,D,E,F,G,H,I,J,K).
new19(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0.
new19(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=B, M=:=0, 
          new20(A,B,C,D,E,F,G,H,I,J,K).
new18(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=0.
new18(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=0, 
          new19(A,B,C,D,E,F,G,H,I,J,K).
new17(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=0.
new17(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K).
new16(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=0.
new16(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=E, M=:=0, 
          new17(A,B,C,D,E,F,G,H,I,J,K).
new15(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=N+O, N=:=D, O=:=E, M=:=1.
new15(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=N+O, N=:=D, O=:=E, M=:=1, 
          new16(A,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=N-O, N=:=P+Q, P=:=R+S, R=:=D, 
          S=:=E, Q=:=F, O=:=1, M=:=0.
new14(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=N-O, N=:=P+Q, P=:=R+S, R=:=D, S=:=E, 
          Q=:=F, O=:=1, M=:=0, new15(A,B,C,D,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=N-O, N=:=P+Q, P=:=R+S, R=:=D, 
          S=:=E, Q=:=F, O=:=1, M=:=0.
new13(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=N-O, N=:=P+Q, P=:=R+S, R=:=D, S=:=E, 
          Q=:=F, O=:=1, M=:=0, new14(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- new23(A,B,C,D,E,F,G,H,I,L,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=K, M=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=K, M=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=K, M=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- new10(A,B,C,D,E,F,G,H,I,J,L).
new8(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=F, M=:=0, new9(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=E, M=:=0, new8(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=D, M=:=1, new7(A,B,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=C, M=:=0, new6(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, new5(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=A, M=:=1, new4(A,B,C,D,E,F,G,H,I,J,K).
new2 :- new3(A,B,C,D,E,F,G,H,I,J,K).
new1 :- new2.
inv1 :- \+new1.
