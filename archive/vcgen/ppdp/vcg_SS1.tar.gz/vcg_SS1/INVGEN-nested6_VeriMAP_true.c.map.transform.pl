new13(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=H*I, H=:=2, I=:=B.
new13(A,B,C,D,E) :- F>=G, F=:=D, G=:=H*I, H=:=2, I=:=B, J=:=K+L, K=:=D, L=:=1, 
          new8(A,B,C,J,E).
new11(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=E.
new11(A,B,C,D,E) :- F=<G, F=:=D, G=:=E, H=:=I+J, I=:=C, J=:=1, new5(A,B,H,D,E).
new10(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=E.
new10(A,B,C,D,E) :- F>=G, F=:=D, G=:=E, new11(A,B,C,D,E).
new8(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=E, new13(A,B,C,D,E).
new8(A,B,C,D,E) :- F>=G, F=:=D, G=:=E, H=:=I+J, I=:=C, J=:=1, new5(A,B,H,D,E).
new6(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=0, H=:=C, new8(A,B,C,H,E).
new6(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0, H=:=C, new8(A,B,C,H,E).
new6(A,B,C,D,E) :- F=:=G, F=:=A, G=:=0, new10(A,B,C,D,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=E, new6(A,B,C,D,E).
new5(A,B,C,D,E) :- F>=G, F=:=C, G=:=E, H=:=I+J, I=:=B, J=:=1, new4(A,H,C,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=E, H=:=I*J, I=:=2, J=:=B, new5(A,B,H,D,E).
new3(A,B,C,D,E) :- F=:=G, F=:=D, G=:=E, H=:=0, new4(A,H,C,D,E).
new2(A) :- new3(A,B,C,D,E).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
