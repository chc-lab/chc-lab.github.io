new5(A,B,C,D) :- E>=F+1, E=:=A, F=:=1000.
new4(A,B,C,D) :- E=:=F, E=:=C, F=:=3, G=:=H+I, H=:=A, I=:=1, J=:=K+L, K=:=G, 
          L=:=1, new5(J,B,C,D).
new4(A,B,C,D) :- E>=F+1, E=:=C, F=:=3, G=:=H+I, H=:=A, I=:=1, new5(G,B,C,D).
new4(A,B,C,D) :- E+1=<F, E=:=C, F=:=3, G=:=H+I, H=:=A, I=:=1, new5(G,B,C,D).
new3(A,B,C,D) :- E=:=F, E=:=B, F=:=0, new4(A,B,C,D).
new3(A,B,C,D) :- E>=F+1, E=:=B, F=:=0, G=:=H+I, H=:=A, I=:=1, new5(G,B,C,D).
new3(A,B,C,D) :- E+1=<F, E=:=B, F=:=0, G=:=H+I, H=:=A, I=:=1, new5(G,B,C,D).
new2 :- A=:=1, B=:=C, D=:=C, new3(A,B,D,C).
new1 :- new2.
inv1 :- \+new1.
