new8(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=0.
new7(A,B,C,D,E) :- F>=G, F=:=D, G=:=0, H=:=I+J, I=:=C, J=:=1, new4(A,B,H,D,E).
new7(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=0, new5(A,B,C,D,E).
new5(A,B,C,D,E) :- new5(A,B,C,D,E).
new4(A,B,C,D,E) :- F=<G, F=:=C, G=:=B, new7(A,B,C,D,E).
new4(A,B,C,D,E) :- F>=G+1, F=:=C, G=:=B, new8(A,B,C,D,E).
new3(A,B,C,D,E) :- F=<G, F=:=C, G=:=B, new4(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G+1, F=:=C, G=:=B, new5(A,B,C,D,E).
new2(A) :- B=:=0, C=:=0, new3(A,D,E,B,C).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
