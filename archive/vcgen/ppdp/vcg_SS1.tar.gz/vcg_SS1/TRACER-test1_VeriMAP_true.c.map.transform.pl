new13(A,B,C,D) :- E>=F+1, E=:=A, F=:=7.
new12(A,B,C,D) :- E>=F+1, E=:=D, F=:=0, G=:=H+I, H=:=A, I=:=4, new13(G,B,C,D).
new12(A,B,C,D) :- E+1=<F, E=:=D, F=:=0, G=:=H+I, H=:=A, I=:=4, new13(G,B,C,D).
new12(A,B,C,D) :- E=:=F, E=:=D, F=:=0, new13(A,B,C,D).
new9(A,B,C,D) :- new12(A,B,C,E).
new8(A,B,C,D) :- E>=F+1, E=:=C, F=:=0, G=:=H+I, H=:=A, I=:=2, new9(G,B,C,D).
new8(A,B,C,D) :- E+1=<F, E=:=C, F=:=0, G=:=H+I, H=:=A, I=:=2, new9(G,B,C,D).
new8(A,B,C,D) :- E=:=F, E=:=C, F=:=0, new9(A,B,C,D).
new5(A,B,C,D) :- new8(A,B,E,D).
new4(A,B,C,D) :- E>=F+1, E=:=B, F=:=0, G=:=H+I, H=:=A, I=:=1, new5(G,B,C,D).
new4(A,B,C,D) :- E+1=<F, E=:=B, F=:=0, G=:=H+I, H=:=A, I=:=1, new5(G,B,C,D).
new4(A,B,C,D) :- E=:=F, E=:=B, F=:=0, new5(A,B,C,D).
new3(A,B,C,D) :- new4(A,E,C,D).
new2 :- A=:=0, new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
