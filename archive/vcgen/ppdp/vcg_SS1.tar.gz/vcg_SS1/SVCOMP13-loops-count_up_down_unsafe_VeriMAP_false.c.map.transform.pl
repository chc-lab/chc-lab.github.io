new6(A,B,C,D) :- E=:=F, E=:=D, D>=0, F=:=A, A>=0.
new4(A,B,C,D) :- E>=F+1, E=:=C, C>=0, F=:=0, G=:=H-I, H=:=C, C>=0, I=:=1, 
          J=:=K+L, K=:=D, D>=0, L=:=1, new4(A,B,G,J).
new4(A,B,C,D) :- E=<F, E=:=C, C>=0, F=:=0, new6(A,B,C,D).
new3(A,B,C,D) :- E=:=F, F>=0, G=:=E, E>=0, H=:=0, new4(E,F,G,H).
new2 :- new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
