new8(A,B,C) :- D>=E+1, D=:=B, E=:=10.
new8(A,B,C) :- D+1=<E, D=:=B, E=:=10.
new5(A,B,C) :- D>=E+1, D=:=A, E=:=5, new8(A,B,C).
new5(A,B,C) :- D+1=<E, D=:=A, E=:=5, new8(A,B,C).
new4(A,B,C) :- D>=E+1, D=:=C, E=:=0, F=:=5, new5(F,B,C).
new4(A,B,C) :- D+1=<E, D=:=C, E=:=0, F=:=5, new5(F,B,C).
new4(A,B,C) :- D=:=E, D=:=C, E=:=0, F=:=10, new5(A,F,C).
new3(A,B,C) :- new4(A,B,D).
new2 :- A=:=0, B=:=0, new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
