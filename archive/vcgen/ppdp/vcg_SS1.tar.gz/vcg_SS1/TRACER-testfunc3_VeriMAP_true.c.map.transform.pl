new6(A,B,C,D) :- E>=F+1, E=:=D, F=:=17.
new6(A,B,C,D) :- E+1=<F, E=:=D, F=:=17.
new5(A,B,C,D) :- E=:=F+G, F=:=C, G=:=3, H=:=I+J, I=:=E, J=:=1, K=:=H, 
          new6(A,B,C,K).
new4(A,B,C,D) :- E=:=F+G, F=:=B, G=:=2, H=:=I+J, I=:=E, J=:=1, K=:=H, 
          new5(A,B,K,D).
new3(A,B,C,D) :- E=:=F+G, F=:=A, G=:=1, H=:=I+J, I=:=E, J=:=1, K=:=H, 
          new4(A,K,C,D).
new2 :- A=:=8, new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
