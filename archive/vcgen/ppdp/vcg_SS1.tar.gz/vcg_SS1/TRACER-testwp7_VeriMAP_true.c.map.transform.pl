new6(A,B,C) :- D=<E, D=:=F+G, F=:=A, G=:=B, E=:=0.
new4(A,B,C) :- D>=E+1, D=:=B, E=:=0, F=:=3, new6(A,B,F).
new4(A,B,C) :- D=<E, D=:=B, E=:=0, F=:=1, new6(A,F,C).
new3(A,B,C) :- D>=E+1, D=:=A, E=:=0, F=:=2, new4(A,B,F).
new3(A,B,C) :- D=<E, D=:=A, E=:=0, F=:=0, new4(F,B,C).
new2 :- new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
