new3(A) :- B>=C+1, B=:=A, C=:=0.
new3(A) :- B+1=<C, B=:=A, C=:=0.
new3(A) :- B=:=C, B=:=A, C=:=0, new3(A).
new2 :- A=:=0, new3(A).
new1 :- new2.
inv1 :- \+new1.
