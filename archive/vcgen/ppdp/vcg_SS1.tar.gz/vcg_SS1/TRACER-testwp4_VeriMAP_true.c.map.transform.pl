new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=A, W=:=40.
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=U, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new61(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=U, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new61(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=U, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new61(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=T, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new58(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=T, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new58(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=T, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new58(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=S, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new55(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=S, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new55(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=S, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new55(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=R, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new52(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=R, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new52(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=R, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new52(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=Q, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new49(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=Q, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new49(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=Q, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new49(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=P, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new46(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=P, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new46(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=P, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new46(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=O, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new43(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=O, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new43(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=O, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new43(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new40(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new40(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new40(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new37(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new37(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new37(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=L, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new34(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=L, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new34(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=L, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new34(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=K, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new31(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=K, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new31(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=K, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new31(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=J, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new28(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=J, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new28(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=J, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new28(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=I, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new25(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=I, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new25(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=I, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new25(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=H, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new22(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=H, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new22(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=H, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new22(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=G, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new19(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=G, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new19(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=G, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new19(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=F, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new16(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=F, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new16(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=F, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new16(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=E, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new13(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=E, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new13(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=E, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new13(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=D, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new10(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=D, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new10(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=D, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new10(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=C, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new7(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=C, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new7(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=C, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new7(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=B, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=1, 
          new4(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=B, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new4(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=B, W=:=0, 
          X=:=Y+Z, Y=:=A, Z=:=2, 
          new4(X,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new2 :- A=:=0, new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new1 :- new2.
inv1 :- \+new1.
