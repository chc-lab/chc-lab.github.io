new15(A,B,C,D,E,F,G,H,I,J) :- K=:=L, M=:=N-O, N=:=E, O=:=1, 
          new11(A,B,K,D,M,F,G,L,I,J).
new14(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=F, L=:=0, M=:=N-O, N=:=B, O=:=A, 
          new15(A,M,C,D,E,F,G,H,I,J).
new14(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=F, L=:=0, M=:=N-O, N=:=B, O=:=A, 
          new15(A,M,C,D,E,F,G,H,I,J).
new14(A,B,C,D,E,F,G,H,I,J) :- K=:=L, K=:=F, L=:=0, M=:=N-O, N=:=C, O=:=A, 
          new11(A,B,M,D,E,F,G,H,I,J).
new13(A,B,C,D,E,F,G,H,I,J) :- K=:=L, new14(A,B,C,D,E,K,L,H,I,J).
new12(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=C, L=:=0, new13(A,B,C,D,E,F,G,H,I,J).
new11(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=B, L=:=0, new12(A,B,C,D,E,F,G,H,I,J).
new10(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=E, L=:=2.
new10(A,B,C,D,E,F,G,H,I,J) :- K>=L, K=:=E, L=:=2, new11(A,B,C,D,E,F,G,H,I,J).
new8(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=E, L=:=D, M=:=N*O, N=:=2, O=:=E, 
          new8(A,B,C,D,M,F,G,H,I,J).
new8(A,B,C,D,E,F,G,H,I,J) :- K>=L, K=:=E, L=:=D, new10(A,B,C,D,E,F,G,H,I,J).
new7(A,B) :- C=:=2, D=:=1, new8(C,E,F,G,D,H,I,J,A,B).
new5(A,B) :- C=:=1, D=:=1, new8(C,E,F,G,D,H,I,J,A,B).
new4(A,B) :- C>=D+1, C=:=A, D=:=0, new5(A,B).
new4(A,B) :- C+1=<D, C=:=A, D=:=0, new5(A,B).
new4(A,B) :- C=:=D, C=:=A, D=:=0, new7(A,B).
new3(A,B) :- C=:=D, new4(C,D).
new2 :- new3(A,B).
new1 :- new2.
inv1 :- \+new1.
