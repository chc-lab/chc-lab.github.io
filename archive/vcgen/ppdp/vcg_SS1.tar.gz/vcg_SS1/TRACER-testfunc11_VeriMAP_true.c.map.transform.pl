new5(A) :- B>=C+1, B=:=A, C=:=1.
new5(A) :- B+1=<C, B=:=A, C=:=1.
new4(A,B) :- C=:=1, D=:=C, new5(D).
new3(A) :- new4(B,A).
new2 :- new3(A).
new1 :- new2.
inv1 :- \+new1.
