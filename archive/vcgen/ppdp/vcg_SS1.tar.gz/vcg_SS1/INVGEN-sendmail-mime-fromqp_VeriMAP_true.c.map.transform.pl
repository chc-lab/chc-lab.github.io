new31(A,B,C,D) :- E>=F, E=:=D, F=:=B.
new31(A,B,C,D) :- E+1=<F, E=:=D, F=:=B, G=:=H+I, H=:=D, I=:=1, new18(A,B,C,G).
new30(A,B,C,D) :- E>=F+1, E=:=0, F=:=D.
new30(A,B,C,D) :- E=<F, E=:=0, F=:=D, new31(A,B,C,D).
new28(A,B,C,D) :- E>=F, E=:=C, F=:=B, new7(A,B,C,D).
new28(A,B,C,D) :- E+1=<F, E=:=C, F=:=B, new30(A,B,C,D).
new25(A,B,C,D) :- E>=F+1, E=:=A, F=:=0, new7(A,B,C,D).
new25(A,B,C,D) :- E+1=<F, E=:=A, F=:=0, new7(A,B,C,D).
new25(A,B,C,D) :- E=:=F, E=:=A, F=:=0, G=:=H+I, H=:=C, I=:=1, new28(A,B,G,D).
new22(A,B,C,D) :- E>=F+1, E=:=A, F=:=0, G=:=0, H=:=0, new18(A,B,H,G).
new22(A,B,C,D) :- E+1=<F, E=:=A, F=:=0, G=:=0, H=:=0, new18(A,B,H,G).
new22(A,B,C,D) :- E=:=F, E=:=A, F=:=0, new25(A,B,C,D).
new18(A,B,C,D) :- new4(A,B,C,D).
new15(A,B,C,D) :- E>=F+1, E=:=A, F=:=0, new7(A,B,C,D).
new15(A,B,C,D) :- E+1=<F, E=:=A, F=:=0, new7(A,B,C,D).
new15(A,B,C,D) :- E=:=F, E=:=A, F=:=0, new18(A,B,C,D).
new14(A,B,C,D) :- E>=F, E=:=D, F=:=B.
new14(A,B,C,D) :- E+1=<F, E=:=D, F=:=B, G=:=H+I, H=:=D, I=:=1, new15(A,B,C,G).
new13(A,B,C,D) :- E>=F+1, E=:=0, F=:=D.
new13(A,B,C,D) :- E=<F, E=:=0, F=:=D, new14(A,B,C,D).
new11(A,B,C,D) :- E>=F, E=:=C, F=:=B, new7(A,B,C,D).
new11(A,B,C,D) :- E+1=<F, E=:=C, F=:=B, new13(A,B,C,D).
new9(A,B,C,D) :- E>=F+1, E=:=A, F=:=0, new7(A,B,C,D).
new9(A,B,C,D) :- E+1=<F, E=:=A, F=:=0, new7(A,B,C,D).
new9(A,B,C,D) :- E=:=F, E=:=A, F=:=0, new22(A,B,C,D).
new8(A,B,C,D) :- E>=F, E=:=D, F=:=B.
new7(A,B,C,D) :- E>=F+1, E=:=0, F=:=D.
new7(A,B,C,D) :- E=<F, E=:=0, F=:=D, new8(A,B,C,D).
new5(A,B,C,D) :- E>=F+1, E=:=A, F=:=0, new9(A,B,C,D).
new5(A,B,C,D) :- E+1=<F, E=:=A, F=:=0, new9(A,B,C,D).
new5(A,B,C,D) :- E=:=F, E=:=A, F=:=0, G=:=H+I, H=:=C, I=:=1, new11(A,B,G,D).
new4(A,B,C,D) :- E>=F+1, E=:=A, F=:=0, new5(A,B,C,D).
new4(A,B,C,D) :- E+1=<F, E=:=A, F=:=0, new5(A,B,C,D).
new4(A,B,C,D) :- E=:=F, E=:=A, F=:=0, new7(A,B,C,D).
new3(A,B,C,D) :- E>=F+1, E=:=B, F=:=0, new4(A,B,C,D).
new2(A) :- B=:=0, C=:=0, new3(A,D,B,C).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
