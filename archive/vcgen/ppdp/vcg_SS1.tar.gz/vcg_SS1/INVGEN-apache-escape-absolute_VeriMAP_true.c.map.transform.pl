new46(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=E.
new46(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=E, I=:=J+K, J=:=E, K=:=1, 
          new15(A,B,C,D,I,F).
new45(A,B,C,D,E,F) :- G>=H, G=:=E, H=:=C.
new45(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=C, new46(A,B,C,D,E,F).
new41(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=E.
new41(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=E, I=:=J+K, J=:=E, K=:=1, 
          new30(A,B,C,D,I,F).
new40(A,B,C,D,E,F) :- G>=H, G=:=E, H=:=C.
new40(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=C, new41(A,B,C,D,E,F).
new39(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=F.
new39(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=F, new40(A,B,C,D,E,F).
new36(A,B,C,D,E,F) :- G>=H, G=:=F, H=:=D.
new36(A,B,C,D,E,F) :- G+1=<H, G=:=F, H=:=D, new39(A,B,C,D,E,F).
new35(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, I=:=J+K, J=:=F, K=:=1, 
          new36(A,B,C,D,E,I).
new35(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, I=:=J+K, J=:=F, K=:=1, 
          new36(A,B,C,D,E,I).
new35(A,B,C,D,E,F) :- G=:=H, G=:=A, H=:=0, I=:=J+K, J=:=E, K=:=1, 
          new30(A,B,C,D,I,F).
new34(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=E.
new34(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=E, new35(A,B,C,D,E,F).
new33(A,B,C,D,E,F) :- G>=H, G=:=E, H=:=C.
new33(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=C, new34(A,B,C,D,E,F).
new31(A,B,C,D,E,F) :- G+1=<H, G=:=F, H=:=I-J, I=:=D, J=:=1, new33(A,B,C,D,E,F).
new30(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=I-J, I=:=C, J=:=1, new31(A,B,C,D,E,F).
new30(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=I-J, I=:=C, J=:=1, new31(A,B,C,D,E,F).
new29(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=E.
new29(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=E, new30(A,B,C,D,E,F).
new27(A,B,C,D,E,F) :- G>=H, G=:=E, H=:=C.
new27(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=C, new29(A,B,C,D,E,F).
new25(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, I=:=0, new27(A,B,C,D,E,I).
new25(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, I=:=0, new27(A,B,C,D,E,I).
new24(A,B,C,D,E,F) :- G>=H+1, G=:=I+J, I=:=E, J=:=1, H=:=K-L, K=:=C, L=:=1, 
          M=:=N+O, N=:=E, O=:=1, P=:=M, new25(A,P,C,D,M,F).
new24(A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=E, J=:=1, H=:=K-L, K=:=C, L=:=1, 
          M=:=N+O, N=:=E, O=:=1, P=:=M, new25(A,P,C,D,M,F).
new23(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=I+J, I=:=E, J=:=1.
new23(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=I+J, I=:=E, J=:=1, new24(A,B,C,D,E,F).
new21(A,B,C,D,E,F) :- G>=H, G=:=I+J, I=:=E, J=:=1, H=:=C.
new21(A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=E, J=:=1, H=:=C, new23(A,B,C,D,E,F).
new20(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=I-J, I=:=C, J=:=1, new21(A,B,C,D,E,F).
new20(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=I-J, I=:=C, J=:=1, new21(A,B,C,D,E,F).
new19(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=E.
new19(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=E, new20(A,B,C,D,E,F).
new18(A,B,C,D,E,F) :- G>=H, G=:=E, H=:=C.
new18(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=C, new19(A,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, new18(A,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, new18(A,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G=:=H, G=:=A, H=:=0, new45(A,B,C,D,E,F).
new15(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=I-J, I=:=C, J=:=1, new16(A,B,C,D,E,F).
new15(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=I-J, I=:=C, J=:=1, new16(A,B,C,D,E,F).
new15(A,B,C,D,E,F) :- G=:=H, G=:=E, H=:=I-J, I=:=C, J=:=1, new18(A,B,C,D,E,F).
new14(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=E.
new14(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=E, new15(A,B,C,D,E,F).
new12(A,B,C,D,E,F) :- G>=H, G=:=E, H=:=C.
new12(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=C, new14(A,B,C,D,E,F).
new11(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, new12(A,B,C,D,E,F).
new11(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, new12(A,B,C,D,E,F).
new10(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=I-J, I=:=E, J=:=1.
new10(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=I-J, I=:=E, J=:=1, new11(A,B,C,D,E,F).
new9(A,B,C,D,E,F) :- G>=H, G=:=I-J, I=:=E, J=:=1, H=:=C.
new9(A,B,C,D,E,F) :- G+1=<H, G=:=I-J, I=:=E, J=:=1, H=:=C, new10(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G>=H, G=:=I-J, I=:=C, J=:=1, H=:=B, K=:=B, 
          new9(A,B,C,D,K,F).
new6(A,B,C,D,E,F) :- G>=H+1, G=:=B, H=:=0, new7(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G+1=<H, G=:=B, H=:=0, new7(A,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G>=H, G=:=B, H=:=0, new6(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=0, new5(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, new4(A,B,C,D,E,F).
new2 :- new3(A,B,C,D,E,F).
new1 :- new2.
inv1 :- \+new1.
