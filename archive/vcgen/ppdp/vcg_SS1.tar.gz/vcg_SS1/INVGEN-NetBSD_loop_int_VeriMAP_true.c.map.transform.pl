new8(A,B,C,D,E,F,G,H,I,J) :- K=:=L, K=:=A, L=:=0, new5(A,B,C,D,E,F,G,H,I,J).
new7(A,B,C,D,E,F,G,H,I,J) :- K>=L, K=:=J, L=:=M+N, M=:=B, N=:=1.
new7(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=J, L=:=M+N, M=:=B, N=:=1, 
          new8(A,B,C,D,E,F,G,H,I,J).
new6(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=0, L=:=J.
new6(A,B,C,D,E,F,G,H,I,J) :- K=<L, K=:=0, L=:=J, new7(A,B,C,D,E,F,G,H,I,J).
new5(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=M+N, M=:=G, N=:=J, L=:=H, O=:=P+Q, 
          P=:=J, Q=:=1, new6(A,B,C,D,E,F,G,H,I,O).
new4(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=1, L=:=0, new5(A,B,C,D,E,F,G,H,I,J).
new3(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=B, L=:=0, M=:=0, N=:=0, O=:=P-Q, 
          P=:=R+S, R=:=B, S=:=1, Q=:=1, T=:=M, U=:=M, V=:=O, W=:=N, X=:=0, 
          new4(A,B,M,N,O,T,U,V,W,X).
new2(A,B) :- new3(A,B,C,D,E,F,G,H,I,J).
new1 :- A=:=0, B=:=0, new2(A,B).
inv1 :- \+new1.
