new4(A,B) :- C>=D+1, C=:=A, D=:=50.
new3(A,B) :- C>=D+1, C=:=B, D=:=0, E=:=2, F=:=G+H, G=:=E, H=:=1, I=:=J+K, 
          J=:=F, K=:=2, new4(I,B).
new3(A,B) :- C=<D, C=:=B, D=:=0, E=:=47, F=:=G+H, G=:=E, H=:=1, I=:=J+K, J=:=F, 
          K=:=2, new4(I,B).
new2 :- new3(A,B).
new1 :- new2.
inv1 :- \+new1.
