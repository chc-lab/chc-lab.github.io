new5(A) :- B>=C+1, B=:=A, C=:=0.
new5(A) :- B+1=<C, B=:=A, C=:=0.
new5(A) :- B=:=C, B=:=A, C=:=0, new3(A).
new4(A) :- B>=C+1, B=:=1, C=:=0, D=:=0, new5(D).
new3(A) :- new4(A).
new2(A) :- new3(A).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
