new13(A,B,C) :- D>=E, D=:=B, E=:=200.
new12(A,B,C) :- new7(A,B,C).
new11(A,B,C) :- D>=E, D=:=C, E=:=100, new12(A,B,C).
new11(A,B,C) :- D+1=<E, D=:=C, E=:=100, new13(A,B,C).
new8(A,B,C) :- D>=E+1, D=:=A, E=:=0, F=:=G+H, G=:=B, H=:=1, I=:=J+K, J=:=C, 
          K=:=1, new8(A,F,I).
new8(A,B,C) :- D+1=<E, D=:=A, E=:=0, F=:=G+H, G=:=B, H=:=1, I=:=J+K, J=:=C, 
          K=:=1, new8(A,F,I).
new8(A,B,C) :- D=:=E, D=:=A, E=:=0, new11(A,B,C).
new7(A,B,C) :- new7(A,B,C).
new6(A,B,C) :- D>=E, D=:=B, E=:=100, new7(A,B,C).
new6(A,B,C) :- D+1=<E, D=:=B, E=:=100, F=:=0, new8(A,B,F).
new3(A,B,C) :- D>=E+1, D=:=A, E=:=0, F=:=G+H, G=:=B, H=:=1, new3(A,F,C).
new3(A,B,C) :- D+1=<E, D=:=A, E=:=0, F=:=G+H, G=:=B, H=:=1, new3(A,F,C).
new3(A,B,C) :- D=:=E, D=:=A, E=:=0, new6(A,B,C).
new2(A) :- B=:=0, new3(A,B,C).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
