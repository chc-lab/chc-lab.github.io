new6(A,B,C,D,E) :- F>=G+1, F=:=H+I, H=:=C, I=:=D, G=:=J*K, J=:=3, K=:=A.
new6(A,B,C,D,E) :- F+1=<G, F=:=H+I, H=:=C, I=:=D, G=:=J*K, J=:=3, K=:=A.
new5(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0, H=:=I+J, I=:=C, J=:=1, K=:=L+M, L=:=D, 
          M=:=2, N=:=O+P, O=:=B, P=:=1, new4(A,N,H,K,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=E, G=:=0, H=:=I+J, I=:=C, J=:=1, K=:=L+M, L=:=D, 
          M=:=2, N=:=O+P, O=:=B, P=:=1, new4(A,N,H,K,E).
new5(A,B,C,D,E) :- F=:=G, F=:=E, G=:=0, H=:=I+J, I=:=C, J=:=2, K=:=L+M, L=:=D, 
          M=:=1, N=:=O+P, O=:=B, P=:=1, new4(A,N,H,K,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=A, new5(A,B,C,D,E).
new4(A,B,C,D,E) :- F>=G, F=:=B, G=:=A, new6(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G, F=:=A, G=:=0, H=:=0, I=:=0, J=:=0, new4(A,H,I,J,E).
new2 :- new3(A,B,C,D,E).
new1 :- new2.
inv1 :- \+new1.
