new10(A,B,C,D) :- E>=F+1, E=:=1, F=:=B.
new10(A,B,C,D) :- E=<F, E=:=1, F=:=B, G=:=H+I, H=:=A, I=:=1, new9(G,B,C,D).
new9(A,B,C,D) :- E+1=<F, E=:=A, F=:=C, new10(A,B,C,D).
new9(A,B,C,D) :- E>=F, E=:=A, F=:=C, G=:=H+I, H=:=B, I=:=1, new4(A,G,C,D).
new7(A,B,C,D) :- E+1=<F, E=:=A, F=:=C, G=:=H+I, H=:=A, I=:=1, new7(G,B,C,D).
new7(A,B,C,D) :- E>=F, E=:=A, F=:=C, G=:=D, new9(G,B,C,D).
new5(A,B,C,D) :- new5(A,B,C,D).
new4(A,B,C,D) :- E+1=<F, E=:=B, F=:=C, G=:=D, new7(G,B,C,D).
new3(A,B,C,D) :- E>=F+1, E=:=D, F=:=0, G=:=1, new4(A,G,C,D).
new3(A,B,C,D) :- E=<F, E=:=D, F=:=0, new5(A,B,C,D).
new2 :- new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
