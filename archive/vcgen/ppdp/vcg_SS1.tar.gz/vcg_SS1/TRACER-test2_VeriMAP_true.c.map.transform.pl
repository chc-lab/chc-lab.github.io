new14(A,B,C,D,E,F,G,H) :- I=<J, I=:=B, J=:=A, K=:=L+M, L=:=C, M=:=B, N=:=O*P, 
          O=:=D, P=:=B, Q=:=R+S, R=:=B, S=:=1, T=:=K, U=:=V+W, V=:=T, W=:=5, 
          new8(U,F,T,H).
new14(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=B, J=:=A, K=:=C, L=:=M+N, M=:=K, N=:=5, 
          new8(L,F,K,H).
new12(A,B,C,D) :- E=:=5, F=:=1, G=:=0, H=:=1, new14(E,F,G,H,A,B,C,D).
new11(A,B,C,D,E,F,G,H) :- I=<J, I=:=B, J=:=A, K=:=L+M, L=:=C, M=:=B, N=:=O*P, 
          O=:=D, P=:=B, Q=:=R+S, R=:=B, S=:=1, T=:=K, U=:=V-W, V=:=T, W=:=1, 
          new12(U,T,G,H).
new11(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=B, J=:=A, K=:=C, L=:=M-N, M=:=K, N=:=1, 
          new12(L,K,G,H).
new10(A,B,C,D) :- E=:=A, F=:=1, G=:=0, H=:=1, new11(E,F,G,H,A,B,C,D).
new8(A,B,C,D) :- E=<F, E=:=A, F=:=0.
new7(A,B,C,D) :- E>=F+1, E=:=D, F=:=0, G=:=H+I, H=:=A, I=:=1, new8(G,B,C,D).
new7(A,B,C,D) :- E+1=<F, E=:=D, F=:=0, G=:=H+I, H=:=A, I=:=1, new8(G,B,C,D).
new7(A,B,C,D) :- E=:=F, E=:=D, F=:=0, new10(A,B,C,D).
new5(A,B,C,D) :- new5(A,B,C,D).
new4(A,B,C,D) :- new7(A,B,C,E).
new3(A,B,C,D) :- E>=F+1, E=:=A, F=:=0, new4(A,B,C,D).
new3(A,B,C,D) :- E=<F, E=:=A, F=:=0, new5(A,B,C,D).
new2 :- new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
