new465(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=W, H1=:=0, I1=:=0, J1=:=2, 
          new437(A,B,C,D,E,F,G,I1,I,J,K,L,M,N,O,P,J1,R,S,X,Y,Z,A1,B1,C1,D1,E1,F1).
new465(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=W, H1=:=0, I1=:=0, J1=:=2, 
          new437(A,B,C,D,E,F,G,I1,I,J,K,L,M,N,O,P,J1,R,S,X,Y,Z,A1,B1,C1,D1,E1,F1).
new465(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=W, H1=:=0, I1=:=2, 
          new437(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I1,R,S,X,Y,Z,A1,B1,C1,D1,E1,F1).
new464(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=S, I1=:=1, J1=:=1, K1=:=J1, 
          new465(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new464(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=S, I1=:=1, J1=:=0, K1=:=J1, 
          new465(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new464(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=S, I1=:=1, J1=:=0, K1=:=J1, 
          new465(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new463(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=D, I1=:=1, 
          new464(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new463(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=D, I1=:=1, J1=:=0, K1=:=J1, 
          new465(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new463(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=D, I1=:=1, J1=:=0, K1=:=J1, 
          new465(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new460(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new463(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new458(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=V, H1=:=0, I1=:=0, 
          new460(A,B,C,D,E,F,I1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new458(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=V, H1=:=0, I1=:=0, 
          new460(A,B,C,D,E,F,I1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new458(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=V, H1=:=0, 
          new460(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new457(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=R, I1=:=1, J1=:=1, K1=:=J1, 
          new458(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new457(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=R, I1=:=1, J1=:=0, K1=:=J1, 
          new458(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new457(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=R, I1=:=1, J1=:=0, K1=:=J1, 
          new458(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new456(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=C, I1=:=1, 
          new457(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new456(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=C, I1=:=1, J1=:=0, K1=:=J1, 
          new458(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new456(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=C, I1=:=1, J1=:=0, K1=:=J1, 
          new458(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new453(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new456(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new451(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=U, H1=:=0, I1=:=0, 
          new453(A,B,C,D,E,I1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new451(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=U, H1=:=0, I1=:=0, 
          new453(A,B,C,D,E,I1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new451(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=U, H1=:=0, 
          new453(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new450(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=Q, I1=:=1, J1=:=1, K1=:=J1, 
          new451(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new450(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=Q, I1=:=1, J1=:=0, K1=:=J1, 
          new451(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new450(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=Q, I1=:=1, J1=:=0, K1=:=J1, 
          new451(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new449(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=B, I1=:=1, 
          new450(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new449(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=B, I1=:=1, J1=:=0, K1=:=J1, 
          new451(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new449(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=B, I1=:=1, J1=:=0, K1=:=J1, 
          new451(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new446(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new449(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new444(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=T, H1=:=0, I1=:=0, 
          new446(A,B,C,D,I1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new444(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=T, H1=:=0, I1=:=0, 
          new446(A,B,C,D,I1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new444(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=T, H1=:=0, 
          new446(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new443(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=M, I1=:=1, J1=:=1, K1=:=J1, 
          new444(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new443(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=M, I1=:=1, J1=:=0, K1=:=J1, 
          new444(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new443(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=M, I1=:=1, J1=:=0, K1=:=J1, 
          new444(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new442(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=A, I1=:=1, 
          new443(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new442(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=A, I1=:=1, J1=:=0, K1=:=J1, 
          new444(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new442(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=A, I1=:=1, J1=:=0, K1=:=J1, 
          new444(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new441(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new442(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new440(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new441(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C1,D1,E1,F1,T,U,V,W,X,Y,Z,A1,B1).
new439(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new440(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new437(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=1, D1=:=0, E1=:=1, F1=:=2, 
          new296(E1,B,C,D,F1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new434(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new437(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new432(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=A, D1=:=1, 
          new434(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new432(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=A, D1=:=1, 
          new431(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new432(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=A, D1=:=1, 
          new431(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new431(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=1, D1=:=0, E1=:=1, 
          new439(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,E1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new430(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=A, D1=:=0, 
          new431(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new430(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=A, D1=:=0, 
          new432(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new430(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=A, D1=:=0, 
          new432(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new427(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new430(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new426(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=U, D1=:=0, E1=:=1, 
          new427(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new426(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=U, D1=:=0, E1=:=1, 
          new427(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new426(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=U, D1=:=0, 
          new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new408(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=W, H1=:=0, I1=:=0, J1=:=2, 
          new377(A,B,C,D,E,F,G,I1,I,J,K,L,M,N,O,P,Q,J1,S,X,Y,Z,A1,B1,C1,D1,E1,F1).
new408(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=W, H1=:=0, I1=:=0, J1=:=2, 
          new377(A,B,C,D,E,F,G,I1,I,J,K,L,M,N,O,P,Q,J1,S,X,Y,Z,A1,B1,C1,D1,E1,F1).
new408(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=W, H1=:=0, I1=:=2, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,I1,S,X,Y,Z,A1,B1,C1,D1,E1,F1).
new407(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=S, I1=:=1, J1=:=1, K1=:=J1, 
          new408(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new407(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=S, I1=:=1, J1=:=0, K1=:=J1, 
          new408(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new407(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=S, I1=:=1, J1=:=0, K1=:=J1, 
          new408(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new406(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=D, I1=:=1, 
          new407(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new406(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=D, I1=:=1, J1=:=0, K1=:=J1, 
          new408(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new406(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=D, I1=:=1, J1=:=0, K1=:=J1, 
          new408(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new403(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new406(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new401(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=V, H1=:=0, I1=:=0, 
          new403(A,B,C,D,E,F,I1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new401(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=V, H1=:=0, I1=:=0, 
          new403(A,B,C,D,E,F,I1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new401(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=V, H1=:=0, 
          new403(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new400(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=R, I1=:=1, J1=:=1, K1=:=J1, 
          new401(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new400(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=R, I1=:=1, J1=:=0, K1=:=J1, 
          new401(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new400(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=R, I1=:=1, J1=:=0, K1=:=J1, 
          new401(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new399(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=C, I1=:=1, 
          new400(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new399(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=C, I1=:=1, J1=:=0, K1=:=J1, 
          new401(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new399(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=C, I1=:=1, J1=:=0, K1=:=J1, 
          new401(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new396(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new399(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new394(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=U, H1=:=0, I1=:=0, 
          new396(A,B,C,D,E,I1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new394(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=U, H1=:=0, I1=:=0, 
          new396(A,B,C,D,E,I1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new394(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=U, H1=:=0, 
          new396(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new393(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=Q, I1=:=1, J1=:=1, K1=:=J1, 
          new394(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new393(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=Q, I1=:=1, J1=:=0, K1=:=J1, 
          new394(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new393(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=Q, I1=:=1, J1=:=0, K1=:=J1, 
          new394(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new392(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=B, I1=:=1, 
          new393(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new392(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=B, I1=:=1, J1=:=0, K1=:=J1, 
          new394(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new392(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=B, I1=:=1, J1=:=0, K1=:=J1, 
          new394(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new389(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new392(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new387(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=T, H1=:=0, I1=:=0, 
          new389(A,B,C,D,I1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new387(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=T, H1=:=0, I1=:=0, 
          new389(A,B,C,D,I1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new387(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=T, H1=:=0, 
          new389(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new386(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=M, I1=:=1, J1=:=1, K1=:=J1, 
          new387(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new386(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=M, I1=:=1, J1=:=0, K1=:=J1, 
          new387(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new386(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=M, I1=:=1, J1=:=0, K1=:=J1, 
          new387(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new385(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=A, I1=:=1, 
          new386(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new385(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=A, I1=:=1, J1=:=0, K1=:=J1, 
          new387(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new385(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=A, I1=:=1, J1=:=0, K1=:=J1, 
          new387(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new384(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new385(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new383(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new384(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C1,D1,E1,F1,T,U,V,W,X,Y,Z,A1,B1).
new380(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new383(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new378(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=B, D1=:=1, E1=:=1, 
          new380(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,E1,S,T,U,V,W,X,Y,Z,A1,B1).
new378(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=B, D1=:=1, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new378(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=B, D1=:=1, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new377(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=1, D1=:=0, E1=:=1, F1=:=2, 
          new299(A,E1,C,D,E,F1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new376(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=B, D1=:=0, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new376(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=B, D1=:=0, 
          new378(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new376(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=B, D1=:=0, 
          new378(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new373(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new376(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new372(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=V, D1=:=0, E1=:=1, 
          new373(A,B,C,D,E,E1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new372(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=V, D1=:=0, E1=:=1, 
          new373(A,B,C,D,E,E1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new372(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=V, D1=:=0, 
          new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=W, H1=:=0, I1=:=0, J1=:=2, 
          new323(A,B,C,D,E,F,G,I1,I,J,K,L,M,N,O,P,Q,R,J1,X,Y,Z,A1,B1,C1,D1,E1,F1).
new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=W, H1=:=0, I1=:=0, J1=:=2, 
          new323(A,B,C,D,E,F,G,I1,I,J,K,L,M,N,O,P,Q,R,J1,X,Y,Z,A1,B1,C1,D1,E1,F1).
new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=W, H1=:=0, I1=:=2, 
          new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,I1,X,Y,Z,A1,B1,C1,D1,E1,F1).
new353(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=S, I1=:=1, J1=:=1, K1=:=J1, 
          new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new353(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=S, I1=:=1, J1=:=0, K1=:=J1, 
          new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new353(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=S, I1=:=1, J1=:=0, K1=:=J1, 
          new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new352(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=D, I1=:=1, 
          new353(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new352(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=D, I1=:=1, J1=:=0, K1=:=J1, 
          new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new352(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=D, I1=:=1, J1=:=0, K1=:=J1, 
          new354(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,K1,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new349(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new352(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new347(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=V, H1=:=0, I1=:=0, 
          new349(A,B,C,D,E,F,I1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new347(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=V, H1=:=0, I1=:=0, 
          new349(A,B,C,D,E,F,I1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new347(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=V, H1=:=0, 
          new349(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new346(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=R, I1=:=1, J1=:=1, K1=:=J1, 
          new347(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new346(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=R, I1=:=1, J1=:=0, K1=:=J1, 
          new347(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new346(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=R, I1=:=1, J1=:=0, K1=:=J1, 
          new347(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new345(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=C, I1=:=1, 
          new346(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new345(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=C, I1=:=1, J1=:=0, K1=:=J1, 
          new347(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new345(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=C, I1=:=1, J1=:=0, K1=:=J1, 
          new347(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,K1,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new342(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new345(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new340(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=U, H1=:=0, I1=:=0, 
          new342(A,B,C,D,E,I1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new340(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=U, H1=:=0, I1=:=0, 
          new342(A,B,C,D,E,I1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new340(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=U, H1=:=0, 
          new342(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new339(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=Q, I1=:=1, J1=:=1, K1=:=J1, 
          new340(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new339(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=Q, I1=:=1, J1=:=0, K1=:=J1, 
          new340(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new339(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=Q, I1=:=1, J1=:=0, K1=:=J1, 
          new340(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new338(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=B, I1=:=1, 
          new339(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new338(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=B, I1=:=1, J1=:=0, K1=:=J1, 
          new340(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new338(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=B, I1=:=1, J1=:=0, K1=:=J1, 
          new340(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,K1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new335(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new338(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new333(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=T, H1=:=0, I1=:=0, 
          new335(A,B,C,D,I1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new333(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=T, H1=:=0, I1=:=0, 
          new335(A,B,C,D,I1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new333(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=T, H1=:=0, 
          new335(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new332(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=M, I1=:=1, J1=:=1, K1=:=J1, 
          new333(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new332(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=M, I1=:=1, J1=:=0, K1=:=J1, 
          new333(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new332(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=M, I1=:=1, J1=:=0, K1=:=J1, 
          new333(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new331(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=A, I1=:=1, 
          new332(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new331(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=A, I1=:=1, J1=:=0, K1=:=J1, 
          new333(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new331(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=A, I1=:=1, J1=:=0, K1=:=J1, 
          new333(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new330(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          new331(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new329(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new330(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C1,D1,E1,F1,T,U,V,W,X,Y,Z,A1,B1).
new326(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new329(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new324(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=C, D1=:=1, E1=:=1, 
          new326(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,E1,T,U,V,W,X,Y,Z,A1,B1).
new324(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=C, D1=:=1, 
          new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new324(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=C, D1=:=1, 
          new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=1, D1=:=0, E1=:=1, F1=:=2, 
          new302(A,B,E1,D,E,F,F1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=C, D1=:=0, 
          new323(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=C, D1=:=0, 
          new324(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=C, D1=:=0, 
          new324(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new319(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new318(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=W, D1=:=0, E1=:=1, 
          new319(A,B,C,D,E,F,E1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new318(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=W, D1=:=0, E1=:=1, 
          new319(A,B,C,D,E,F,E1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new318(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=W, D1=:=0, 
          new302(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=D, D1=:=1.
new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=D, D1=:=1, 
          new312(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=D, D1=:=1, 
          new312(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new312(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=1, D1=:=0, E1=:=1, F1=:=2, 
          new94(A,B,C,E1,E,F,G,F1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new311(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=D, D1=:=0, 
          new312(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new311(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=D, D1=:=0, 
          new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new311(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=D, D1=:=0, 
          new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new311(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=X, D1=:=0, E1=:=1, 
          new308(A,B,C,D,E,F,G,E1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=X, D1=:=0, E1=:=1, 
          new308(A,B,C,D,E,F,G,E1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=X, D1=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new304(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,C1,Y,Z,A1,B1).
new302(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=H, D1=:=0, 
          new304(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new302(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=H, D1=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new302(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=H, D1=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new301(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new318(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,C1,X,Y,Z,A1,B1).
new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=G, D1=:=0, 
          new301(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=G, D1=:=0, 
          new302(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=G, D1=:=0, 
          new302(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new298(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new372(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,C1,W,X,Y,Z,A1,B1).
new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=F, D1=:=0, 
          new298(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=F, D1=:=0, 
          new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=F, D1=:=0, 
          new299(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new295(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new426(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,C1,V,W,X,Y,Z,A1,B1).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=S, Y=:=1, 
          Z=:=2, new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=S, Y=:=1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=S, Y=:=1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=R, Y=:=1, 
          Z=:=2, new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U,V,W).
new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=R, Y=:=1, 
          new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=R, Y=:=1, 
          new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=Q, Y=:=1, 
          Z=:=2, new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Z,R,S,T,U,V,W).
new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=Q, Y=:=1, 
          new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=Q, Y=:=1, 
          new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=P, Y=:=1, 
          Z=:=2, new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Z,Q,R,S,T,U,V,W).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=P, Y=:=1, 
          new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=P, Y=:=1, 
          new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=O, Y=:=1, 
          Z=:=2, new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,P,Q,R,S,T,U,V,W).
new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=O, Y=:=1, 
          new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=O, Y=:=1, 
          new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=N, Y=:=1, 
          Z=:=2, new253(A,B,C,D,E,F,G,H,I,J,K,L,M,Z,O,P,Q,R,S,T,U,V,W).
new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=N, Y=:=1, 
          new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=N, Y=:=1, 
          new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new249(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=M, Y=:=1, 
          Z=:=2, new250(A,B,C,D,E,F,G,H,I,J,K,L,Z,N,O,P,Q,R,S,T,U,V,W).
new249(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=M, Y=:=1, 
          new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new249(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=M, Y=:=1, 
          new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new246(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new249(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=W, C1=:=0, D1=:=0, 
          new246(A,B,C,D,E,F,G,D1,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=W, C1=:=0, D1=:=0, 
          new246(A,B,C,D,E,F,G,D1,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=W, C1=:=0, 
          new246(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1).
new243(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=S, D1=:=1, E1=:=1, F1=:=E1, 
          new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new243(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=S, D1=:=1, E1=:=0, F1=:=E1, 
          new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new243(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=S, D1=:=1, E1=:=0, F1=:=E1, 
          new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=D, D1=:=1, 
          new243(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=D, D1=:=1, E1=:=0, F1=:=E1, 
          new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=D, D1=:=1, E1=:=0, F1=:=E1, 
          new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new239(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=V, C1=:=0, D1=:=0, 
          new239(A,B,C,D,E,F,D1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=V, C1=:=0, D1=:=0, 
          new239(A,B,C,D,E,F,D1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=V, C1=:=0, 
          new239(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=R, D1=:=1, E1=:=1, F1=:=E1, 
          new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=R, D1=:=1, E1=:=0, F1=:=E1, 
          new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=R, D1=:=1, E1=:=0, F1=:=E1, 
          new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=C, D1=:=1, 
          new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=C, D1=:=1, E1=:=0, F1=:=E1, 
          new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=C, D1=:=1, E1=:=0, F1=:=E1, 
          new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=U, C1=:=0, D1=:=0, 
          new232(A,B,C,D,E,D1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=U, C1=:=0, D1=:=0, 
          new232(A,B,C,D,E,D1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=U, C1=:=0, 
          new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=Q, D1=:=1, E1=:=1, F1=:=E1, 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=Q, D1=:=1, E1=:=0, F1=:=E1, 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=Q, D1=:=1, E1=:=0, F1=:=E1, 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new228(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=B, D1=:=1, 
          new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new228(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=B, D1=:=1, E1=:=0, F1=:=E1, 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new228(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=B, D1=:=1, E1=:=0, F1=:=E1, 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new225(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new228(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=T, C1=:=0, D1=:=0, 
          new225(A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=T, C1=:=0, D1=:=0, 
          new225(A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=T, C1=:=0, 
          new225(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=M, D1=:=1, E1=:=1, F1=:=E1, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=M, D1=:=1, E1=:=0, F1=:=E1, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=M, D1=:=1, E1=:=0, F1=:=E1, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new221(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=A, D1=:=1, 
          new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new221(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=A, D1=:=1, E1=:=0, F1=:=E1, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new221(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=A, D1=:=1, E1=:=0, F1=:=E1, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new221(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1,T,U,V,W).
new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=V, Y=:=0, 
          new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new210(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=H, 
          B1=:=0, C1=:=1, D1=:=C1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,D1,V,W,X,Y,Z).
new210(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=H, B1=:=0, C1=:=0, D1=:=C1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,D1,V,W,X,Y,Z).
new210(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=H, B1=:=0, C1=:=0, D1=:=C1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,D1,V,W,X,Y,Z).
new207(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=G, 
          B1=:=0, C1=:=1, D1=:=C1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,D1,V,W,X,Y,Z).
new207(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=G, B1=:=0, 
          new210(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new207(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=G, B1=:=0, 
          new210(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=F, 
          B1=:=0, C1=:=1, D1=:=C1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,D1,V,W,X,Y,Z).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=F, B1=:=0, 
          new207(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=F, B1=:=0, 
          new207(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=T, 
          A1=:=0, B1=:=0, C1=:=B1, 
          new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V,W,C1,Y).
new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=T, 
          A1=:=0, B1=:=0, C1=:=B1, 
          new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V,W,C1,Y).
new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=T, 
          A1=:=0, B1=:=1, C1=:=B1, 
          new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,V,W,C1,Y).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=E, 
          B1=:=0, C1=:=1, D1=:=C1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,D1,V,W,X,Y,Z).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=E, B1=:=0, 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=E, B1=:=0, 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new201(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Z,T,U,V,W,X,Y).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new201(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,Y,T,U,V,W).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=1, 
          new219(A,B,C,D,E,F,G,H,I,J,K,L,X,N,O,P,Q,R,S,T,U,V,W).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=H, Z=:=0, 
          A1=:=1, B1=:=A1, 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,B1,W,X).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=H, 
          Z=:=0, A1=:=0, B1=:=A1, 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,B1,W,X).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=H, 
          Z=:=0, A1=:=0, B1=:=A1, 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,B1,W,X).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=G, Z=:=0, 
          A1=:=1, B1=:=A1, 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,B1,W,X).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=G, 
          Z=:=0, new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=G, 
          Z=:=0, new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=F, Z=:=0, 
          A1=:=1, B1=:=A1, 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,B1,W,X).
new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=F, 
          Z=:=0, new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=F, 
          Z=:=0, new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=U, Y=:=0, 
          Z=:=4, new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Z,U,V,W).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=U, Y=:=0, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=U, Y=:=0, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=E, Z=:=0, 
          A1=:=1, B1=:=A1, 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,B1,W,X).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=E, 
          Z=:=0, new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=E, 
          Z=:=0, new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,T,U,V,W).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=S, Y=:=1, 
          Z=:=2, new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=S, Y=:=1, 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=S, Y=:=1, 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=R, Y=:=1, 
          Z=:=2, new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U,V,W).
new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=R, Y=:=1, 
          new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=R, Y=:=1, 
          new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=Q, Y=:=1, 
          Z=:=2, new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Z,R,S,T,U,V,W).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=Q, Y=:=1, 
          new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=Q, Y=:=1, 
          new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=P, Y=:=1, 
          Z=:=2, new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Z,Q,R,S,T,U,V,W).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=P, Y=:=1, 
          new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=P, Y=:=1, 
          new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=O, Y=:=1, 
          Z=:=2, new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,P,Q,R,S,T,U,V,W).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=O, Y=:=1, 
          new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=O, Y=:=1, 
          new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=N, Y=:=1, 
          Z=:=2, new167(A,B,C,D,E,F,G,H,I,J,K,L,M,Z,O,P,Q,R,S,T,U,V,W).
new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=N, Y=:=1, 
          new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=N, Y=:=1, 
          new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=M, Y=:=1, 
          Z=:=2, new164(A,B,C,D,E,F,G,H,I,J,K,L,Z,N,O,P,Q,R,S,T,U,V,W).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=M, Y=:=1, 
          new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=M, Y=:=1, 
          new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=W, C1=:=0, D1=:=0, 
          new160(A,B,C,D,E,F,G,D1,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1).
new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=W, C1=:=0, D1=:=0, 
          new160(A,B,C,D,E,F,G,D1,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1).
new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=W, C1=:=0, 
          new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=S, D1=:=1, E1=:=1, F1=:=E1, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=S, D1=:=1, E1=:=0, F1=:=E1, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=S, D1=:=1, E1=:=0, F1=:=E1, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=D, D1=:=1, 
          new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=D, D1=:=1, E1=:=0, F1=:=E1, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=D, D1=:=1, E1=:=0, F1=:=E1, 
          new158(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=V, C1=:=0, D1=:=0, 
          new153(A,B,C,D,E,F,D1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=V, C1=:=0, D1=:=0, 
          new153(A,B,C,D,E,F,D1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=V, C1=:=0, 
          new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=R, D1=:=1, E1=:=1, F1=:=E1, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=R, D1=:=1, E1=:=0, F1=:=E1, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=R, D1=:=1, E1=:=0, F1=:=E1, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=C, D1=:=1, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=C, D1=:=1, E1=:=0, F1=:=E1, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=C, D1=:=1, E1=:=0, F1=:=E1, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=U, C1=:=0, D1=:=0, 
          new146(A,B,C,D,E,D1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=U, C1=:=0, D1=:=0, 
          new146(A,B,C,D,E,D1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=U, C1=:=0, 
          new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=Q, D1=:=1, E1=:=1, F1=:=E1, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=Q, D1=:=1, E1=:=0, F1=:=E1, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=Q, D1=:=1, E1=:=0, F1=:=E1, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=B, D1=:=1, 
          new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=B, D1=:=1, E1=:=0, F1=:=E1, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=B, D1=:=1, E1=:=0, F1=:=E1, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new139(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=T, C1=:=0, D1=:=0, 
          new139(A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=T, C1=:=0, D1=:=0, 
          new139(A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=T, C1=:=0, 
          new139(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=M, D1=:=1, E1=:=1, F1=:=E1, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=M, D1=:=1, E1=:=0, F1=:=E1, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=M, D1=:=1, E1=:=0, F1=:=E1, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=A, D1=:=1, 
          new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=A, D1=:=1, E1=:=0, F1=:=E1, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=A, D1=:=1, E1=:=0, F1=:=E1, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1,T,U,V,W).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=S, Y=:=0, 
          Z=:=1, new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=S, Y=:=0, 
          new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=S, Y=:=0, 
          new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=R, Y=:=0, 
          Z=:=1, new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U,V,W).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=R, Y=:=0, 
          new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=R, Y=:=0, 
          new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=Q, Y=:=0, 
          Z=:=1, new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Z,R,S,T,U,V,W).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=Q, Y=:=0, 
          new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=Q, Y=:=0, 
          new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=P, Y=:=0, 
          Z=:=1, new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Z,Q,R,S,T,U,V,W).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=P, Y=:=0, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=P, Y=:=0, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=O, Y=:=0, 
          Z=:=1, new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,P,Q,R,S,T,U,V,W).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=O, Y=:=0, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=O, Y=:=0, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=N, Y=:=0, 
          Z=:=1, new116(A,B,C,D,E,F,G,H,I,J,K,L,M,Z,O,P,Q,R,S,T,U,V,W).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=N, Y=:=0, 
          new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=N, Y=:=0, 
          new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=M, Y=:=0, 
          Z=:=1, new113(A,B,C,D,E,F,G,H,I,J,K,L,Z,N,O,P,Q,R,S,T,U,V,W).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=M, Y=:=0, 
          new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=M, Y=:=0, 
          new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=3, 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,U,V,W).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=E, D1=:=0, 
          new295(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=E, D1=:=0, 
          new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=E, D1=:=0, 
          new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=H, E1=:=0, F1=:=1, G1=:=F1, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,V,W,X,Y,Z,A1,B1,C1).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=H, E1=:=0, F1=:=0, G1=:=F1, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,V,W,X,Y,Z,A1,B1,C1).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=H, E1=:=0, F1=:=0, G1=:=F1, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,V,W,X,Y,Z,A1,B1,C1).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=G, E1=:=0, F1=:=1, G1=:=F1, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,V,W,X,Y,Z,A1,B1,C1).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=G, E1=:=0, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=G, E1=:=0, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          D1=:=F, E1=:=0, F1=:=1, G1=:=F1, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,V,W,X,Y,Z,A1,B1,C1).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=F, E1=:=0, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=F, E1=:=0, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=T, D1=:=0, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=T, D1=:=0, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=T, D1=:=0, E1=:=2, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,E1,Z,A1,B1).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          D1=:=E, E1=:=0, F1=:=1, G1=:=F1, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,G1,V,W,X,Y,Z,A1,B1,C1).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=E, E1=:=0, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=E, E1=:=0, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,C1,T,U,V,W,X,Y,Z,A1,B1).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1,B1,T,U,V,W).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=1, Y=:=0, 
          Z=:=1, new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Z,U,V,W).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=S, Y=:=1, 
          Z=:=2, new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=S, Y=:=1, 
          new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=S, Y=:=1, 
          new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=R, Y=:=1, 
          Z=:=2, new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U,V,W).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=R, Y=:=1, 
          new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=R, Y=:=1, 
          new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=Q, Y=:=1, 
          Z=:=2, new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Z,R,S,T,U,V,W).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=Q, Y=:=1, 
          new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=Q, Y=:=1, 
          new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=P, Y=:=1, 
          Z=:=2, new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Z,Q,R,S,T,U,V,W).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=P, Y=:=1, 
          new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=P, Y=:=1, 
          new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=O, Y=:=1, 
          Z=:=2, new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,P,Q,R,S,T,U,V,W).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=O, Y=:=1, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=O, Y=:=1, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=N, Y=:=1, 
          Z=:=2, new75(A,B,C,D,E,F,G,H,I,J,K,L,M,Z,O,P,Q,R,S,T,U,V,W).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=N, Y=:=1, 
          new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=N, Y=:=1, 
          new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=M, Y=:=1, 
          Z=:=2, new72(A,B,C,D,E,F,G,H,I,J,K,L,Z,N,O,P,Q,R,S,T,U,V,W).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=M, Y=:=1, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=M, Y=:=1, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=W, C1=:=0, D1=:=0, 
          new68(A,B,C,D,E,F,G,D1,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=W, C1=:=0, D1=:=0, 
          new68(A,B,C,D,E,F,G,D1,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=W, C1=:=0, new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1).
new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=S, D1=:=1, E1=:=1, F1=:=E1, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=S, D1=:=1, E1=:=0, F1=:=E1, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=S, D1=:=1, E1=:=0, F1=:=E1, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=D, D1=:=1, 
          new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=D, D1=:=1, E1=:=0, F1=:=E1, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=D, D1=:=1, E1=:=0, F1=:=E1, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,F1,Y,Z,A1,B1).
new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=V, C1=:=0, D1=:=0, 
          new61(A,B,C,D,E,F,D1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=V, C1=:=0, D1=:=0, 
          new61(A,B,C,D,E,F,D1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=V, C1=:=0, 
          new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=R, D1=:=1, E1=:=1, F1=:=E1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=R, D1=:=1, E1=:=0, F1=:=E1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=R, D1=:=1, E1=:=0, F1=:=E1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=C, D1=:=1, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=C, D1=:=1, E1=:=0, F1=:=E1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=C, D1=:=1, E1=:=0, F1=:=E1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,F1,X,Y,Z,A1,B1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=U, C1=:=0, D1=:=0, 
          new54(A,B,C,D,E,D1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=U, C1=:=0, D1=:=0, 
          new54(A,B,C,D,E,D1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=U, C1=:=0, 
          new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=Q, D1=:=1, E1=:=1, F1=:=E1, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=Q, D1=:=1, E1=:=0, F1=:=E1, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=Q, D1=:=1, E1=:=0, F1=:=E1, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=B, D1=:=1, 
          new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=B, D1=:=1, E1=:=0, F1=:=E1, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=B, D1=:=1, E1=:=0, F1=:=E1, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,F1,W,X,Y,Z,A1,B1).
new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=T, C1=:=0, D1=:=0, 
          new47(A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=T, C1=:=0, D1=:=0, 
          new47(A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=T, C1=:=0, 
          new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=M, D1=:=1, E1=:=1, F1=:=E1, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=M, D1=:=1, E1=:=0, F1=:=E1, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=M, D1=:=1, E1=:=0, F1=:=E1, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=A, D1=:=1, 
          new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=A, D1=:=1, E1=:=0, F1=:=E1, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=A, D1=:=1, E1=:=0, F1=:=E1, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,F1,V,W,X,Y,Z,A1,B1).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B1,T,U,V,W,X,Y,Z,A1).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,X,Y,Z,A1,T,U,V,W).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=S, Y=:=0, 
          Z=:=1, new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=S, Y=:=0, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=S, Y=:=0, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=R, Y=:=0, 
          Z=:=1, new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U,V,W).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=R, Y=:=0, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=R, Y=:=0, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=Q, Y=:=0, 
          Z=:=1, new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Z,R,S,T,U,V,W).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=Q, Y=:=0, 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=Q, Y=:=0, 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=P, Y=:=0, 
          Z=:=1, new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Z,Q,R,S,T,U,V,W).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=P, Y=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=P, Y=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=O, Y=:=0, 
          Z=:=1, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,P,Q,R,S,T,U,V,W).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=O, Y=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=O, Y=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=N, Y=:=0, 
          Z=:=1, new24(A,B,C,D,E,F,G,H,I,J,K,L,M,Z,O,P,Q,R,S,T,U,V,W).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=N, Y=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=N, Y=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=M, Y=:=0, 
          Z=:=1, new21(A,B,C,D,E,F,G,H,I,J,K,L,Z,N,O,P,Q,R,S,T,U,V,W).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=M, Y=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=M, Y=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=L, Y=:=1, 
          Z=:=0, new17(A,B,C,D,E,F,G,Z,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=L, Y=:=1, 
          Z=:=2, new17(A,B,C,D,E,F,G,Z,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=L, Y=:=1, 
          Z=:=2, new17(A,B,C,D,E,F,G,Z,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=K, Y=:=1, 
          Z=:=0, new14(A,B,C,D,E,F,Z,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=K, Y=:=1, 
          Z=:=2, new14(A,B,C,D,E,F,Z,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=K, Y=:=1, 
          Z=:=2, new14(A,B,C,D,E,F,Z,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=J, Y=:=1, 
          Z=:=0, new11(A,B,C,D,E,Z,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=J, Y=:=1, 
          Z=:=2, new11(A,B,C,D,E,Z,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=J, Y=:=1, 
          Z=:=2, new11(A,B,C,D,E,Z,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=I, Y=:=1, 
          Z=:=0, new8(A,B,C,D,Z,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=I, Y=:=1, 
          Z=:=2, new8(A,B,C,D,Z,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=I, Y=:=1, 
          Z=:=2, new8(A,B,C,D,Z,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U,V,W,T).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=1, V=:=1, W=:=1, X=:=1, 
          new4(A,B,C,D,E,F,G,H,U,V,W,X,M,N,O,P,Q,R,S,T).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=0, 
          K=:=0, L=:=0, M=:=2, N=:=2, O=:=2, P=:=2, Q=:=2, R=:=2, S=:=2, 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
inv1 :- \+new1.
