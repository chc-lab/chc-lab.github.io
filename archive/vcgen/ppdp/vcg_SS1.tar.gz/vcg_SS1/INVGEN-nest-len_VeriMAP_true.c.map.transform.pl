new17(A,B,C) :- D+1=<E, D=:=A, E=:=C, F=:=G+H, G=:=A, H=:=1, new17(F,B,C).
new17(A,B,C) :- D>=E, D=:=A, E=:=C, F=:=G+H, G=:=B, H=:=1, new3(A,F,C).
new15(A,B,C) :- D+1=<E, D=:=A, E=:=C, F=:=G+H, G=:=A, H=:=1, new15(F,B,C).
new15(A,B,C) :- D>=E, D=:=A, E=:=C, F=:=1, new17(F,B,C).
new13(A,B,C) :- D+1=<E, D=:=A, E=:=C, F=:=G+H, G=:=A, H=:=1, new13(F,B,C).
new13(A,B,C) :- D>=E, D=:=A, E=:=C, F=:=1, new15(F,B,C).
new11(A,B,C) :- D+1=<E, D=:=A, E=:=C, F=:=G+H, G=:=A, H=:=1, new11(F,B,C).
new11(A,B,C) :- D>=E, D=:=A, E=:=C, F=:=1, new13(F,B,C).
new9(A,B,C) :- D+1=<E, D=:=A, E=:=C, F=:=G+H, G=:=A, H=:=1, new9(F,B,C).
new9(A,B,C) :- D>=E, D=:=A, E=:=C, F=:=1, new11(F,B,C).
new7(A,B,C) :- D+1=<E, D=:=A, E=:=C, F=:=G+H, G=:=A, H=:=1, new7(F,B,C).
new7(A,B,C) :- D>=E, D=:=A, E=:=C, F=:=1, new9(F,B,C).
new5(A,B,C) :- D+1=<E, D=:=A, E=:=C, F=:=G+H, G=:=A, H=:=1, new5(F,B,C).
new5(A,B,C) :- D>=E, D=:=A, E=:=C, F=:=1, new7(F,B,C).
new4(A,B,C) :- D>=E+1, D=:=1, E=:=B.
new4(A,B,C) :- D=<E, D=:=1, E=:=B, F=:=1, new5(F,B,C).
new3(A,B,C) :- D+1=<E, D=:=B, E=:=C, new4(A,B,C).
new2 :- A=:=1, new3(B,A,C).
new1 :- new2.
inv1 :- \+new1.
