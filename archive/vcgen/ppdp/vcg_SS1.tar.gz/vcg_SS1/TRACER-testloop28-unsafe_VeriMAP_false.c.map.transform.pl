new6(A,B,C,D) :- E>=F+1, E=:=C, F=:=0.
new6(A,B,C,D) :- E=<F, E=:=C, F=:=0, G=:=H+I, H=:=A, I=:=1, new3(G,B,C,D).
new5(A,B,C,D) :- E>=F+1, E=:=D, F=:=0, new6(A,B,C,D).
new5(A,B,C,D) :- E=<F, E=:=D, F=:=0, G=:=1, H=:=I+J, I=:=A, J=:=1, 
          new3(H,B,G,D).
new4(A,B,C,D) :- new5(A,B,C,E).
new3(A,B,C,D) :- E+1=<F, E=:=A, F=:=B, new4(A,B,C,D).
new2 :- A=:=0, B=:=0, new3(B,C,A,D).
new1 :- new2.
inv1 :- \+new1.
