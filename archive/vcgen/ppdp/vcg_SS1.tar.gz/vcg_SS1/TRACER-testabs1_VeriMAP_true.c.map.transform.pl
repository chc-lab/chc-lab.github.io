new4(A,B,C) :- D=<E, D=:=A, E=:=0.
new3(A,B,C) :- D>=E+1, D=:=C, E=:=0, F=:=4, G=:=1, new4(F,G,C).
new3(A,B,C) :- D=<E, D=:=C, E=:=0, F=:=100, G=:=2, new4(F,G,C).
new2 :- new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
