new8(A,B,C,D,E) :- F>=G, F=:=H+I, H=:=A, I=:=D, G=:=J*K, J=:=E, K=:=2.
new8(A,B,C,D,E) :- F+1=<G, F=:=H+I, H=:=A, I=:=D, G=:=J*K, J=:=E, K=:=2, 
          L=:=M+N, M=:=D, N=:=1, new7(A,B,C,L,E).
new7(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=C, new8(A,B,C,D,E).
new6(A,B,C,D,E) :- F=<G, F=:=C, G=:=H-I, H=:=J*K, J=:=E, K=:=2, I=:=B, L=:=0, 
          new7(A,B,C,L,E).
new5(A,B,C,D,E) :- F=<G, F=:=A, G=:=B, new6(A,B,C,D,E).
new4(A,B,C,D,E) :- F=<G, F=:=B, G=:=H*I, H=:=E, I=:=2, new5(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0, new4(A,B,C,D,E).
new2 :- new3(A,B,C,D,E).
new1 :- new2.
inv1 :- \+new1.
