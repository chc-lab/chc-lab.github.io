new7(A,B,C) :- new3(A,B,C).
new5(A,B,C) :- D=<E, D=:=C, E=:=0.
new4(A,B,C) :- D>=E+1, D=:=B, E=:=0, F=:=G-H, G=:=B, H=:=1, I=:=J*K, J=:=2, 
          K=:=C, new4(A,F,I).
new4(A,B,C) :- D=<E, D=:=B, E=:=0, new7(A,B,C).
new3(A,B,C) :- D+1=<E, D=:=C, E=:=A, new4(A,B,C).
new3(A,B,C) :- D>=E, D=:=C, E=:=A, new5(A,B,C).
new2 :- A=:=1, B=:=10, new3(C,B,A).
new1 :- new2.
inv1 :- \+new1.
