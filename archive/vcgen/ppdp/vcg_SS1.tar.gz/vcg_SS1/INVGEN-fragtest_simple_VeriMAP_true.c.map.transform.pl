new15(A,B,C,D,E,F,G) :- H+1=<I, H=:=G, I=:=F, new14(A,B,C,D,E,F,G).
new14(A,B,C,D,E,F,G) :- H+1=<I, H=:=E, I=:=0.
new14(A,B,C,D,E,F,G) :- H>=I, H=:=E, I=:=0, J=:=K-L, K=:=E, L=:=1, M=:=N-O, 
          N=:=B, O=:=1, P=:=Q+R, Q=:=G, R=:=1, new15(A,M,C,D,J,F,P).
new11(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, new11(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, new11(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, J=:=0, K=:=B, new14(A,B,C,D,E,K,J).
new7(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=B, K=:=L+M, L=:=B, M=:=1, 
          N=:=O+P, O=:=E, P=:=1, new7(A,K,C,J,N,F,G).
new7(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, J=:=B, K=:=L+M, L=:=B, M=:=1, 
          N=:=O+P, O=:=E, P=:=1, new7(A,K,C,J,N,F,G).
new7(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, new11(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=C, J=:=B, K=:=0, new7(A,K,J,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=C, J=:=0, new7(A,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=K+L, K=:=B, L=:=1, 
          new3(A,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, J=:=K+L, K=:=B, L=:=1, 
          new3(A,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new2(A) :- B=:=0, C=:=0, new3(A,C,D,E,B,F,G).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
