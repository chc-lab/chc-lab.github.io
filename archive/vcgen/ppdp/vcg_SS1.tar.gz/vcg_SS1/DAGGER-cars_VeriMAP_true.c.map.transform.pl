new27(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=L-M, L=:=N-O, N=:=P*Q, P=:=2, Q=:=C, 
          O=:=A, M=:=E, K=:=0, R=:=S+T, S=:=A, T=:=B, U=:=V+W, V=:=E, W=:=F, 
          X=:=Y+Z, Y=:=C, Z=:=D, A1=:=B1+C1, B1=:=D, C1=:=1, D1=:=E1+F1, 
          E1=:=G, F1=:=1, new9(R,B,X,A1,U,F,D1,H,I).
new25(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=L-M, L=:=N-O, N=:=P*Q, P=:=2, Q=:=C, 
          O=:=A, M=:=E, K=:=0, R=:=S+T, S=:=A, T=:=B, U=:=V+W, V=:=E, W=:=F, 
          X=:=Y+Z, Y=:=C, Z=:=D, A1=:=B1-C1, B1=:=D, C1=:=1, D1=:=E1+F1, 
          E1=:=G, F1=:=1, new9(R,B,X,A1,U,F,D1,H,I).
new24(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=H, K=:=0, new25(A,B,C,D,E,F,G,H,I).
new24(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=H, K=:=0, new25(A,B,C,D,E,F,G,H,I).
new24(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=H, K=:=0, new27(A,B,C,D,E,F,G,H,I).
new23(A,B,C,D,E,F,G,H,I) :- new24(A,B,C,D,E,F,G,J,I).
new22(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=D, K=:=5, new23(A,B,C,D,E,F,G,H,I).
new21(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=L-M, L=:=B, M=:=F, K=:=0.
new20(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=L+M, L=:=N+O, N=:=P-Q, P=:=B, Q=:=R*S, 
          R=:=2, S=:=D, O=:=F, M=:=T*U, T=:=2, U=:=G, K=:=0.
new20(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=L+M, L=:=N+O, N=:=P-Q, P=:=B, Q=:=R*S, 
          R=:=2, S=:=D, O=:=F, M=:=T*U, T=:=2, U=:=G, K=:=0, 
          new21(A,B,C,D,E,F,G,H,I).
new19(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=L+M, L=:=C, M=:=N*O, N=:=5, O=:=G, 
          K=:=75.
new19(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=L+M, L=:=C, M=:=N*O, N=:=5, O=:=G, 
          K=:=75, new20(A,B,C,D,E,F,G,H,I).
new18(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=L+M, L=:=D, M=:=6, K=:=0.
new18(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=L+M, L=:=D, M=:=6, K=:=0, 
          new19(A,B,C,D,E,F,G,H,I).
new17(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=F, K=:=0.
new17(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=F, K=:=0, new18(A,B,C,D,E,F,G,H,I).
new16(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=6.
new16(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=D, K=:=6, new17(A,B,C,D,E,F,G,H,I).
new15(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=L+M, L=:=N*O, N=:=5, O=:=G, M=:=75, 
          K=:=C.
new15(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=L+M, L=:=N*O, N=:=5, O=:=G, M=:=75, 
          K=:=C, new16(A,B,C,D,E,F,G,H,I).
new14(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=L+M, L=:=N*O, N=:=2, O=:=D, M=:=P*Q, 
          P=:=2, Q=:=G, K=:=R+S, R=:=B, S=:=F.
new14(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=L+M, L=:=N*O, N=:=2, O=:=D, M=:=P*Q, 
          P=:=2, Q=:=G, K=:=R+S, R=:=B, S=:=F, new15(A,B,C,D,E,F,G,H,I).
new13(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=B, K=:=5.
new13(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=B, K=:=5, new14(A,B,C,D,E,F,G,H,I).
new11(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=L+M, L=:=D, M=:=5, K=:=0, 
          new22(A,B,C,D,E,F,G,H,I).
new10(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=I, K=:=0, new11(A,B,C,D,E,F,G,H,I).
new10(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=I, K=:=0, new11(A,B,C,D,E,F,G,H,I).
new10(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=I, K=:=0, new13(A,B,C,D,E,F,G,H,I).
new9(A,B,C,D,E,F,G,H,I) :- new10(A,B,C,D,E,F,G,H,J).
new8(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=D, K=:=5, new9(A,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=L+M, L=:=D, M=:=5, K=:=0, 
          new8(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=L-M, L=:=N-O, N=:=P*Q, P=:=2, Q=:=D, 
          O=:=B, M=:=F, K=:=0, R=:=0, new7(A,B,C,D,E,F,R,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=L-M, L=:=B, M=:=F, K=:=0, 
          new6(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=B, K=:=5, new5(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=F, K=:=0, new4(A,B,C,D,E,F,G,H,I).
new2 :- A=:=100, B=:=75, C=:= -50, new3(A,D,B,E,C,F,G,H,I).
new1 :- new2.
inv1 :- \+new1.
