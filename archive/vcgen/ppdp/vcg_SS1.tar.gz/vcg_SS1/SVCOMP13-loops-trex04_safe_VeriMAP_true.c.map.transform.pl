new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=0, P=:=Q-R, Q=:=A, 
          R=:=1, new11(F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=0, P=:=Q-R, Q=:=A, 
          R=:=1, new11(F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=D, O=:=0, P=:=Q+R, Q=:=A, 
          R=:=10, new11(F,G,H,I,J,K,L,M).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=B, O=:=0, P=:=Q+R, Q=:=A, 
          R=:=1, new34(P,B,C,D,E,F,G,H,I,J,K,L,M).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=B, O=:=0, P=:=Q+R, Q=:=A, 
          R=:=1, new34(P,B,C,D,E,F,G,H,I,J,K,L,M).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=B, O=:=0, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, new33(A,B,C,N,O,F,G,H,I,J,K,L,M).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, new32(A,N,O,D,E,F,G,H,I,J,K,L,M).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=0, P=:=Q-R, Q=:=A, 
          R=:=1, new16(F,G,H,I,J,K,L,M).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=0, P=:=Q-R, Q=:=A, 
          R=:=1, new16(F,G,H,I,J,K,L,M).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=D, O=:=0, P=:=Q+R, Q=:=A, 
          R=:=10, new16(F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=B, O=:=0, P=:=Q+R, Q=:=A, 
          R=:=1, new25(P,B,C,D,E,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=B, O=:=0, P=:=Q+R, Q=:=A, 
          R=:=1, new25(P,B,C,D,E,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=B, O=:=0, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M).
new23(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, new24(A,B,C,N,O,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, new23(A,N,O,D,E,F,G,H,I,J,K,L,M).
new21(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=B, J=:=0.
new17(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=B, J=:=0, K=:=L-M, L=:=B, M=:=A, 
          new17(A,K,C,D,E,F,G,H).
new17(A,B,C,D,E,F,G,H) :- I=<J, I=:=B, J=:=0, new21(A,B,C,D,E,F,G,H).
new16(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=E, J=:=0, K=:=L-M, L=:=A, M=:=1, 
          new17(K,B,C,D,E,F,G,H).
new16(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=E, J=:=0, K=:=L-M, L=:=A, M=:=1, 
          new17(K,B,C,D,E,F,G,H).
new16(A,B,C,D,E,F,G,H) :- I=:=J, I=:=E, J=:=0, new17(A,B,C,D,E,F,G,H).
new14(A,B,C,D,E,F,G,H) :- I=:=0, new22(I,J,K,L,M,A,B,C,D,E,F,G,H).
new13(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=C, J=:=0, new14(A,B,C,D,E,F,G,H).
new13(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=C, J=:=0, new14(A,B,C,D,E,F,G,H).
new13(A,B,C,D,E,F,G,H) :- I=:=J, I=:=C, J=:=0, new16(A,B,C,D,E,F,G,H).
new12(A,B,C,D,E,F,G,H) :- I=:=J, new13(A,B,C,D,I,F,G,J).
new11(A,B,C,D,E,F,G,H) :- I=:=J, new12(A,B,I,D,E,F,J,H).
new9(A,B,C,D,E,F,G,H) :- I=:=0, new31(I,J,K,L,M,A,B,C,D,E,F,G,H).
new6(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=E, J=:=0, new9(A,B,C,D,E,F,G,H).
new6(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=E, J=:=0, new9(A,B,C,D,E,F,G,H).
new6(A,B,C,D,E,F,G,H) :- I=:=J, I=:=E, J=:=0, new11(A,B,C,D,E,F,G,H).
new5(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=C, J=:=0, K=:=L-M, L=:=A, M=:=1, 
          new6(K,B,C,D,E,F,G,H).
new5(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=C, J=:=0, K=:=L-M, L=:=A, M=:=1, 
          new6(K,B,C,D,E,F,G,H).
new5(A,B,C,D,E,F,G,H) :- I=:=J, I=:=C, J=:=0, new6(A,B,C,D,E,F,G,H).
new4(A,B,C,D,E,F,G,H) :- I=:=J, new5(A,B,C,D,I,J,G,H).
new3(A,B,C,D,E,F,G,H) :- I=:=J, new4(A,B,I,J,E,F,G,H).
new2 :- A=:=1, new3(A,B,C,D,E,F,G,H).
new1 :- new2.
inv1 :- \+new1.
