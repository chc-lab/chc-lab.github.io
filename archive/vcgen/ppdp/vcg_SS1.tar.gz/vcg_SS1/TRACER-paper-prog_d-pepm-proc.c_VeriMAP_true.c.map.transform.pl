new8(A,B) :- C+1=<D, C=:=E+F, E=:=A, F=:=B, D=:=10000.
new5(A,B) :- new5(A,B).
new4(A,B) :- C+1=<D, C=:=B, D=:=10000, E=:=F+G, F=:=A, G=:=1, H=:=I+J, I=:=B, 
          J=:=1, new4(E,H).
new4(A,B) :- C>=D, C=:=B, D=:=10000, new8(A,B).
new3(A,B) :- C>=D, C=:=A, D=:=0, new4(A,B).
new3(A,B) :- C+1=<D, C=:=A, D=:=0, new5(A,B).
new2 :- A=:=0, new3(B,A).
new1 :- new2.
inv1 :- \+new1.
