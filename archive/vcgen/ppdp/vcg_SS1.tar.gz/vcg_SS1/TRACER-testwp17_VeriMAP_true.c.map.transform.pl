new6(A,B) :- C>=D+1, C=:=A, D=:=0.
new6(A,B) :- C+1=<D, C=:=A, D=:=0.
new4(A,B) :- C=:=D, C=:=A, D=:=0, new6(A,B).
new3(A,B) :- C>=D+1, C=:=B, D=:=0, E=:=0, new4(E,B).
new3(A,B) :- C=<D, C=:=B, D=:=0, E=:=1, new4(E,B).
new2 :- new3(A,B).
new1 :- new2.
inv1 :- \+new1.
