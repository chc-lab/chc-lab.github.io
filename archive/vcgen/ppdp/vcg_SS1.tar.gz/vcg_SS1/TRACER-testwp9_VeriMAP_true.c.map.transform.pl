new4(A) :- B+1=<C, B=:=A, C=:=5.
new3(A) :- B>=C+1, B=:=A, C=:=10, new4(A).
new2 :- new3(A).
new1 :- new2.
inv1 :- \+new1.
