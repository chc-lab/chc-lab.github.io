new4(A,B) :- C>=D+1, C=:=A, D=:=50.
new3(A,B) :- C>=D+1, C=:=B, D=:=0, E=:=F+G, F=:=A, G=:=1, H=:=I+J, I=:=E, 
          J=:=1, K=:=L+M, L=:=H, M=:=2, N=:=O+P, O=:=K, P=:=3, new4(N,B).
new3(A,B) :- C=<D, C=:=B, D=:=0, E=:=F+G, F=:=A, G=:=2, H=:=I+J, I=:=E, J=:=1, 
          K=:=L+M, L=:=H, M=:=2, N=:=O+P, O=:=K, P=:=3, new4(N,B).
new2 :- A=:=0, new3(A,B).
new1 :- new2.
inv1 :- \+new1.
