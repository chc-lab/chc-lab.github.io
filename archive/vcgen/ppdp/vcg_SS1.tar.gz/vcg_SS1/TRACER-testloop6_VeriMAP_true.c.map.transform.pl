new9(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=0.
new9(A,B,C,D,E) :- F>=G, F=:=C, G=:=0, H=:=I+J, I=:=A, J=:=1, new4(H,B,C,D,E).
new8(A,B,C,D,E) :- F+1=<G, F=:=E, G=:=0.
new7(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=0, H=:=B, new9(A,H,C,D,E).
new7(A,B,C,D,E) :- F=<G, F=:=D, G=:=0, H=:=I+J, I=:=B, J=:=1, new9(A,H,C,D,E).
new5(A,B,C,D,E) :- new5(A,B,C,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=10, new7(A,B,C,D,E).
new4(A,B,C,D,E) :- F>=G, F=:=A, G=:=10, new8(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G, F=:=C, G=:=0, H=:=0, new4(H,B,C,D,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=0, new5(A,B,C,D,E).
new2 :- A=:=0, B=:=1, new3(C,A,D,E,B).
new1 :- new2.
inv1 :- \+new1.
