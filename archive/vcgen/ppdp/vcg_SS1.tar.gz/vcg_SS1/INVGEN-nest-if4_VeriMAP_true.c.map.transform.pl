new13(A,B,C,D,E) :- F>=G+1, F=:=1, G=:=B.
new13(A,B,C,D,E) :- F=<G, F=:=1, G=:=B, H=:=I+J, I=:=B, J=:=1, new8(A,H,C,D,E).
new10(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=D, H=:=I+J, I=:=B, J=:=1, 
          new10(A,H,C,D,E).
new10(A,B,C,D,E) :- F>=G, F=:=B, G=:=D, H=:=I+J, I=:=C, J=:=1, new4(A,B,H,D,E).
new8(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=D, new13(A,B,C,D,E).
new8(A,B,C,D,E) :- F>=G, F=:=B, G=:=D, H=:=E, new10(A,H,C,D,E).
new7(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=0, H=:=E, new8(A,H,C,D,E).
new7(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0, H=:=E, new8(A,H,C,D,E).
new7(A,B,C,D,E) :- F=:=G, F=:=A, G=:=0, H=:=E, new10(A,H,C,D,E).
new5(A,B,C,D,E) :- new5(A,B,C,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=D, new7(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0, H=:=1, new4(A,B,H,D,E).
new3(A,B,C,D,E) :- F=<G, F=:=E, G=:=0, new5(A,B,C,D,E).
new2(A) :- new3(A,B,C,D,E).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
