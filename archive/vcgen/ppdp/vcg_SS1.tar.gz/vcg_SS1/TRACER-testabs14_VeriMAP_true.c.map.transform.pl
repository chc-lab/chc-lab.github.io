new8(A,B,C) :- D>=E+1, D=:=C, E=:=10.
new7(A,B,C) :- D>=E+1, D=:=B, E=:=10.
new7(A,B,C) :- D=<E, D=:=B, E=:=10, new8(A,B,C).
new5(A,B,C) :- D+1=<E, D=:=B, E=:=A, F=:=G+H, G=:=B, H=:=1, new5(A,F,C).
new5(A,B,C) :- D>=E, D=:=B, E=:=A, new7(A,B,C).
new3(A,B,C) :- D+1=<E, D=:=C, E=:=A, F=:=G+H, G=:=C, H=:=1, new3(A,B,F).
new3(A,B,C) :- D>=E, D=:=C, E=:=A, new5(A,B,C).
new2 :- A=:=0, B=:=0, C=:=10, new3(C,A,B).
new1 :- new2.
inv1 :- \+new1.
