new10(A,B,C) :- D+1=<E, D=:=B, E=:=C.
new8(A,B,C) :- D>=E+1, D=:=A, E=:=0, F=:=G-H, G=:=A, H=:=1, I=:=J-K, J=:=B, 
          K=:=1, new8(F,I,C).
new8(A,B,C) :- D=<E, D=:=A, E=:=0, new10(A,B,C).
new5(A,B,C) :- new5(A,B,C).
new4(A,B,C) :- D+1=<E, D=:=A, E=:=C, F=:=G+H, G=:=A, H=:=1, I=:=J+K, J=:=B, 
          K=:=2, new4(F,I,C).
new4(A,B,C) :- D>=E, D=:=A, E=:=C, new8(A,B,C).
new3(A,B,C) :- D>=E, D=:=C, E=:=0, new4(A,B,C).
new3(A,B,C) :- D+1=<E, D=:=C, E=:=0, new5(A,B,C).
new2 :- A=:=0, B=:=0, new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
