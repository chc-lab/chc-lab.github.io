new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=0, 
          X=:=0, Y=:=2, Z=:=1, A1=:=2, 
          new173(Z,B,A1,X,E,F,G,H,I,Y,K,L,O,P,Q,R,S,T,U).
new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=0, 
          X=:=0, Y=:=2, Z=:=1, A1=:=2, 
          new173(Z,B,A1,X,E,F,G,H,I,Y,K,L,O,P,Q,R,S,T,U).
new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=0, 
          X=:=2, Y=:=1, Z=:=2, new173(Y,B,Z,D,E,F,G,H,I,X,K,L,O,P,Q,R,S,T,U).
new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=J, X=:=1, 
          Y=:=1, Z=:=Y, new237(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new237(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new237(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new237(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new237(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new235(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=0, 
          X=:=0, new232(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=0, 
          X=:=0, new232(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=0, 
          new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=I, X=:=1, 
          Y=:=1, Z=:=Y, new230(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new230(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new230(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new228(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=1, 
          new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new228(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new230(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new228(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new230(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new227(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new228(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new227(A,B,C,D,E,F,G,H,I,J,K,L,T,U,M,N,O,P,Q,R,S).
new225(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new224(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, V=:=1, 
          new225(A,B,C,D,E,F,G,H,I,V,U,T,M,N,O,P,Q,R,S).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=K, U=:=V+W, V=:=L, 
          W=:=1.
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=K, U=:=V+W, V=:=L, 
          W=:=1.
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=K, U=:=V+W, V=:=L, 
          W=:=1, new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=A, U=:=1, 
          new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=A, U=:=1, 
          new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=A, U=:=1, 
          new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=1, U=:=0, 
          new224(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new216(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=A, U=:=0, 
          new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new216(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=A, U=:=0, 
          new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new216(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=A, U=:=0, 
          new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new213(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new216(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new212(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=N, U=:=0, V=:=1, 
          new213(A,B,V,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new212(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=N, U=:=0, V=:=1, 
          new213(A,B,V,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new212(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=N, U=:=0, 
          new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new200(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=0, 
          X=:=0, Y=:=2, new183(A,B,C,X,E,F,G,H,Y,J,K,L,O,P,Q,R,S,T,U).
new200(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=0, 
          X=:=0, Y=:=2, new183(A,B,C,X,E,F,G,H,Y,J,K,L,O,P,Q,R,S,T,U).
new200(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=0, 
          X=:=2, new183(A,B,C,D,E,F,G,H,X,J,K,L,O,P,Q,R,S,T,U).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=J, X=:=1, 
          Y=:=1, Z=:=Y, new200(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new200(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new200(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new200(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new198(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new200(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new195(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new198(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=0, 
          X=:=0, new195(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=0, 
          X=:=0, new195(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=0, 
          new195(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=I, X=:=1, 
          Y=:=1, Z=:=Y, new193(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new193(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new193(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=1, 
          new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new193(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new193(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new191(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new189(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new190(A,B,C,D,E,F,G,H,I,J,K,L,T,U,M,N,O,P,Q,R,S).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new189(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new184(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=B, U=:=1, V=:=W+X, 
          W=:=K, X=:=1, Y=:=1, new186(A,B,C,D,E,F,G,H,Y,J,V,L,M,N,O,P,Q,R,S).
new184(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=B, U=:=1, 
          new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new184(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=B, U=:=1, 
          new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=1, U=:=0, V=:=1, 
          W=:=2, new56(A,V,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=B, U=:=0, 
          new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=B, U=:=0, 
          new184(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=B, U=:=0, 
          new184(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=O, U=:=0, V=:=1, 
          new179(A,B,C,V,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=O, U=:=0, V=:=1, 
          new179(A,B,C,V,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=O, U=:=0, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,T,P,Q,R,S).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=D, U=:=0, 
          new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=D, U=:=0, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=D, U=:=0, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new212(A,B,C,D,E,F,G,H,I,J,K,L,M,T,O,P,Q,R,S).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=J, R=:=1, S=:=2, 
          new117(A,B,C,D,E,F,G,H,I,S,K,L,M,N,O,P).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=J, R=:=1, 
          new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=J, R=:=1, 
          new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=I, R=:=1, S=:=2, 
          new154(A,B,C,D,E,F,G,H,S,J,K,L,M,N,O,P).
new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=I, R=:=1, 
          new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=I, R=:=1, 
          new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=H, R=:=1, S=:=2, 
          new151(A,B,C,D,E,F,G,S,I,J,K,L,M,N,O,P).
new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=H, R=:=1, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=H, R=:=1, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=1, S=:=2, 
          new148(A,B,C,D,E,F,S,H,I,J,K,L,M,N,O,P).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=1, 
          new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=1, 
          new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=N, T=:=0, U=:=0, 
          new144(A,B,C,U,E,F,G,H,I,J,K,L,O,P,Q,R).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=N, T=:=0, U=:=0, 
          new144(A,B,C,U,E,F,G,H,I,J,K,L,O,P,Q,R).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=N, T=:=0, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,O,P,Q,R).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=J, U=:=1, V=:=1, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=J, U=:=1, V=:=0, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=J, U=:=1, V=:=0, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=B, U=:=1, 
          new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=B, U=:=1, V=:=0, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=B, U=:=1, V=:=0, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new140(A,B,C,D,E,F,G,H,I,J,K,L,S,M,N,O,P,Q,R).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=M, T=:=0, U=:=0, 
          new137(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=M, T=:=0, U=:=0, 
          new137(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=M, T=:=0, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=1, V=:=1, 
          W=:=V, new135(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=1, V=:=0, 
          W=:=V, new135(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=1, V=:=0, 
          W=:=V, new135(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new133(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=A, U=:=1, 
          new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new133(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=A, U=:=1, V=:=0, 
          W=:=V, new135(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new133(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=A, U=:=1, V=:=0, 
          W=:=V, new135(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new133(A,B,C,D,E,F,G,H,I,J,K,L,S,M,N,O,P,Q,R).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new132(A,B,C,D,E,F,G,H,I,J,K,L,Q,R,M,N,O,P).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=O, R=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=D, U=:=0, V=:=1, 
          W=:=V, new121(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=D, U=:=0, V=:=0, 
          W=:=V, new121(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=D, U=:=0, V=:=0, 
          W=:=V, new121(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=M, T=:=0, U=:=0, 
          V=:=U, new127(A,B,C,D,E,F,G,H,I,J,K,L,O,P,V,R).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=M, T=:=0, U=:=0, 
          V=:=U, new127(A,B,C,D,E,F,G,H,I,J,K,L,O,P,V,R).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=M, T=:=0, U=:=1, 
          V=:=U, new127(A,B,C,D,E,F,G,H,I,J,K,L,O,P,V,R).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=C, U=:=0, V=:=1, 
          W=:=V, new121(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=C, U=:=0, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=C, U=:=0, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,S,M,N,O,P,Q,R).
new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,Q,R,M,N,O,P).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=1, 
          new131(A,B,C,D,E,F,Q,H,I,J,K,L,M,N,O,P).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=D, S=:=0, T=:=1, U=:=T, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,N,U,P,Q).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=D, S=:=0, T=:=0, 
          U=:=T, new110(A,B,C,D,E,F,G,H,I,J,K,L,N,U,P,Q).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=D, S=:=0, T=:=0, 
          U=:=T, new110(A,B,C,D,E,F,G,H,I,J,K,L,N,U,P,Q).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=N, R=:=0, S=:=4, 
          new116(A,B,C,D,E,F,G,H,I,J,K,L,S,N,O,P).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=N, R=:=0, 
          new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=N, R=:=0, 
          new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=C, S=:=0, T=:=1, U=:=T, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,N,U,P,Q).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=C, S=:=0, 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=C, S=:=0, 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,Q,M,N,O,P).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=J, R=:=1, S=:=2, 
          new106(A,B,C,D,E,F,G,H,I,S,K,L,M,N,O,P).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=J, R=:=1, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=J, R=:=1, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=I, R=:=1, S=:=2, 
          new103(A,B,C,D,E,F,G,H,S,J,K,L,M,N,O,P).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=I, R=:=1, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=I, R=:=1, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=H, R=:=1, S=:=2, 
          new100(A,B,C,D,E,F,G,S,I,J,K,L,M,N,O,P).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=H, R=:=1, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=H, R=:=1, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=1, S=:=2, 
          new97(A,B,C,D,E,F,S,H,I,J,K,L,M,N,O,P).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=1, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=1, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=N, T=:=0, U=:=0, 
          new93(A,B,C,U,E,F,G,H,I,J,K,L,O,P,Q,R).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=N, T=:=0, U=:=0, 
          new93(A,B,C,U,E,F,G,H,I,J,K,L,O,P,Q,R).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=N, T=:=0, 
          new93(A,B,C,D,E,F,G,H,I,J,K,L,O,P,Q,R).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=J, U=:=1, V=:=1, 
          W=:=V, new91(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=J, U=:=1, V=:=0, 
          W=:=V, new91(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=J, U=:=1, V=:=0, 
          W=:=V, new91(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=B, U=:=1, 
          new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=B, U=:=1, V=:=0, 
          W=:=V, new91(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=B, U=:=1, V=:=0, 
          W=:=V, new91(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new89(A,B,C,D,E,F,G,H,I,J,K,L,S,M,N,O,P,Q,R).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=M, T=:=0, U=:=0, 
          new86(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=M, T=:=0, U=:=0, 
          new86(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=M, T=:=0, 
          new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=1, V=:=1, 
          W=:=V, new84(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=1, V=:=0, 
          W=:=V, new84(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=1, V=:=0, 
          W=:=V, new84(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=A, U=:=1, 
          new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=A, U=:=1, V=:=0, 
          W=:=V, new84(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=A, U=:=1, V=:=0, 
          W=:=V, new84(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,S,M,N,O,P,Q,R).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new81(A,B,C,D,E,F,G,H,I,J,K,L,Q,R,M,N,O,P).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=J, R=:=0, S=:=1, 
          new78(A,B,C,D,E,F,G,H,I,S,K,L,M,N,O,P).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=J, R=:=0, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=J, R=:=0, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=I, R=:=0, S=:=1, 
          new75(A,B,C,D,E,F,G,H,S,J,K,L,M,N,O,P).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=I, R=:=0, 
          new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=I, R=:=0, 
          new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=H, R=:=0, S=:=1, 
          new72(A,B,C,D,E,F,G,S,I,J,K,L,M,N,O,P).
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=H, R=:=0, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=H, R=:=0, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=0, S=:=1, 
          new69(A,B,C,D,E,F,S,H,I,J,K,L,M,N,O,P).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=0, 
          new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=0, 
          new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new67(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=3, 
          new67(A,B,C,D,E,F,G,H,I,J,K,L,Q,N,O,P).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=C, U=:=0, 
          new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=C, U=:=0, 
          new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=C, U=:=0, 
          new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=D, V=:=0, W=:=1, 
          X=:=W, new58(A,B,C,D,E,F,G,H,I,J,K,L,X,O,P,Q,R,S,T).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=D, V=:=0, W=:=0, 
          X=:=W, new58(A,B,C,D,E,F,G,H,I,J,K,L,X,O,P,Q,R,S,T).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=D, V=:=0, W=:=0, 
          X=:=W, new58(A,B,C,D,E,F,G,H,I,J,K,L,X,O,P,Q,R,S,T).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=M, U=:=0, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=M, U=:=0, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=M, U=:=0, V=:=2, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,V,Q,R,S).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=C, V=:=0, W=:=1, 
          X=:=W, new58(A,B,C,D,E,F,G,H,I,J,K,L,X,O,P,Q,R,S,T).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=C, V=:=0, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=C, V=:=0, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,T,M,N,O,P,Q,R,S).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,Q,R,S,M,N,O,P).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=1, R=:=0, S=:=1, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,S,N,O,P).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=J, R=:=1, S=:=2, 
          new52(A,B,C,D,E,F,G,H,I,S,K,L,M,N,O,P).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=J, R=:=1, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=J, R=:=1, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=I, R=:=1, S=:=2, 
          new49(A,B,C,D,E,F,G,H,S,J,K,L,M,N,O,P).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=I, R=:=1, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=I, R=:=1, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=H, R=:=1, S=:=2, 
          new46(A,B,C,D,E,F,G,S,I,J,K,L,M,N,O,P).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=H, R=:=1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=H, R=:=1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=1, S=:=2, 
          new43(A,B,C,D,E,F,S,H,I,J,K,L,M,N,O,P).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=1, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=1, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=N, T=:=0, U=:=0, 
          new39(A,B,C,U,E,F,G,H,I,J,K,L,O,P,Q,R).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=N, T=:=0, U=:=0, 
          new39(A,B,C,U,E,F,G,H,I,J,K,L,O,P,Q,R).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=N, T=:=0, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,O,P,Q,R).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=J, U=:=1, V=:=1, 
          W=:=V, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=J, U=:=1, V=:=0, 
          W=:=V, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=J, U=:=1, V=:=0, 
          W=:=V, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=B, U=:=1, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=B, U=:=1, V=:=0, 
          W=:=V, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=B, U=:=1, V=:=0, 
          W=:=V, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,W,P,Q,R,S).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new35(A,B,C,D,E,F,G,H,I,J,K,L,S,M,N,O,P,Q,R).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=M, T=:=0, U=:=0, 
          new32(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=M, T=:=0, U=:=0, 
          new32(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=M, T=:=0, 
          new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=1, V=:=1, 
          W=:=V, new30(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=1, V=:=0, 
          W=:=V, new30(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=1, V=:=0, 
          W=:=V, new30(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=A, U=:=1, 
          new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=A, U=:=1, V=:=0, 
          W=:=V, new30(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=A, U=:=1, V=:=0, 
          W=:=V, new30(A,B,C,D,E,F,G,H,I,J,K,L,W,O,P,Q,R,S).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,S,M,N,O,P,Q,R).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,Q,R,M,N,O,P).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=J, R=:=0, S=:=1, 
          new24(A,B,C,D,E,F,G,H,I,S,K,L,M,N,O,P).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=J, R=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=J, R=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=I, R=:=0, S=:=1, 
          new21(A,B,C,D,E,F,G,H,S,J,K,L,M,N,O,P).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=I, R=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=I, R=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=H, R=:=0, S=:=1, 
          new18(A,B,C,D,E,F,G,S,I,J,K,L,M,N,O,P).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=H, R=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=H, R=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=0, S=:=1, 
          new15(A,B,C,D,E,F,S,H,I,J,K,L,M,N,O,P).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=F, R=:=1, S=:=0, 
          new11(A,B,C,S,E,F,G,H,I,J,K,L,M,N,O,P).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=F, R=:=1, S=:=2, 
          new11(A,B,C,S,E,F,G,H,I,J,K,L,M,N,O,P).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=F, R=:=1, S=:=2, 
          new11(A,B,C,S,E,F,G,H,I,J,K,L,M,N,O,P).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=E, R=:=1, S=:=0, 
          new8(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=E, R=:=1, S=:=2, 
          new8(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=E, R=:=1, S=:=2, 
          new8(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=0, new5(A,B,C,D,E,F,G,H,I,J,K,L,N,O,P,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=1, O=:=1, 
          new4(A,B,C,D,N,O,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L) :- new3(A,B,C,D,E,F,G,H,I,J,K,L,M).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, J=:=2, 
          K=:=0, L=:=0, new2(A,B,C,D,E,F,G,H,I,J,K,L).
inv1 :- \+new1.
