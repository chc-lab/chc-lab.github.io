new10(A,B,C,20,A,B,C) :- D+1=<E, D=:=B, E=:=C.
new8(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=K-L, K=:=A, L=:=1, M=:=N-O, 
          N=:=B, O=:=1, new8(J,M,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=0, new10(A,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G) :- new5(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, M=:=N+O, 
          N=:=B, O=:=2, new4(J,M,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, new8(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=0, new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=0, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, I=:=0, new3(H,I,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
