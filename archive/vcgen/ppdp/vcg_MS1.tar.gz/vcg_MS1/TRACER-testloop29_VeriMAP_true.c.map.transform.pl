new6(A,12,A).
new5(A,B,C) :- D>=E+1, D=:=A, E=:=50, new6(A,B,C).
new5(A,B,C) :- D+1=<E, D=:=A, E=:=50, new6(A,B,C).
new4(A,B,C) :- D=:=E, D=:=A, E=:=50, new5(A,B,C).
new4(A,B,C) :- D>=E+1, D=:=A, E=:=50, new3(A,B,C).
new4(A,B,C) :- D+1=<E, D=:=A, E=:=50, new3(A,B,C).
new3(A,B,C) :- D+1=<E, D=:=A, E=:=100, F=:=G+H, G=:=A, H=:=1, new4(F,B,C).
new3(A,B,C) :- D>=E, D=:=A, E=:=100, new5(A,B,C).
new2(A,B,C) :- D=:=0, new3(D,B,C).
new1 :- new2(A,B,C).
correct :- \+new1.
