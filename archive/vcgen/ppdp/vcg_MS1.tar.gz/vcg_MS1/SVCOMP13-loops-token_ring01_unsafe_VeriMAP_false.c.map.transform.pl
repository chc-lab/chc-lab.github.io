new262(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,M,E,F,G,H,I,J,K,L) :- N=:=O, N=:=F, O=:=1, 
          M=:=0.
new262(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,M,E,F,G,H,I,J,K,L) :- N>=O+1, N=:=F, 
          O=:=1, M=:=2.
new262(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,M,E,F,G,H,I,J,K,L) :- N+1=<O, N=:=F, 
          O=:=1, M=:=2.
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=I, 
          A1=:=0, B1=:=1, 
          new259(A,B,C,D,E,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=I, 
          A1=:=0, new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=I, 
          A1=:=0, new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=H, 
          A1=:=0, B1=:=1, 
          new256(A,B,C,D,E,F,G,B1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=H, 
          A1=:=0, new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=H, 
          A1=:=0, new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new250(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,M,K,L) :- N=:=O, N=:=J, O=:=0, 
          M=:=1.
new250(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=J, N=:=0.
new250(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=J, N=:=0.
new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=I, Z=:=0, 
          A1=:=1, new250(A,B,C,D,E,F,G,H,A1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=H, Z=:=0, 
          A1=:=1, new247(A,B,C,D,E,F,G,A1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=B, C1=:=1, 
          new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- B1>=C1+1, 
          B1=:=M, C1=:=0, D1=:=0, 
          new233(A,B,D1,D,E,F,G,H,I,J,K,L,E1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,F1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- B1+1=<C1, 
          B1=:=M, C1=:=0, D1=:=0, 
          new233(A,B,D1,D,E,F,G,H,I,J,K,L,E1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,F1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- B1=:=C1, 
          B1=:=M, C1=:=0, 
          new233(A,B,C,D,E,F,G,H,I,J,K,L,D1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,E1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=0, F1=:=0, G1=:=H1, 
          new222(A,B,F1,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,H1), 
          new239(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,M,G1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=0, F1=:=0, G1=:=H1, 
          new222(A,B,F1,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,H1), 
          new239(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,M,G1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=M, E1=:=0, F1=:=G1, 
          new222(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,G1), 
          new239(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=A, C1=:=1, 
          new243(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O=:=P, O=:=I, 
          P=:=1, N=:=1.
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=I, 
          P=:=1, N=:=0.
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=I, 
          P=:=1, N=:=0.
new228(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O=:=P, O=:=J, 
          P=:=1, N=:=1.
new228(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=J, 
          P=:=1, N=:=0.
new228(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=J, 
          P=:=1, N=:=0.
new225(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,O,E,F,G,H,I,J,K,L,M,N) :- P>=Q+1, 
          P=:=N, Q=:=0, O=:=0.
new225(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,O,E,F,G,H,I,J,K,L,M,N) :- P+1=<Q, 
          P=:=N, Q=:=0, O=:=0.
new225(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=P, 
          O=:=N, P=:=0.
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=B, 
          P=:=1, N=:=0.
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=B, 
          P=:=1, N=:=0.
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=B, 
          B1=:=1, new228(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new221(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=M, D1=:=0, E1=:=0, F1=:=G1, 
          new222(A,B,E1,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,G1), 
          new225(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new221(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=M, D1=:=0, E1=:=0, F1=:=G1, 
          new222(A,B,E1,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,G1), 
          new225(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new221(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=M, D1=:=0, E1=:=F1, 
          new222(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1), 
          new225(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,M,E1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=A, 
          P=:=1, N=:=0.
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=A, 
          P=:=1, N=:=0.
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=A, 
          B1=:=1, new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=I, 
          A1=:=1, B1=:=2, 
          new217(A,B,C,D,E,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=I, 
          A1=:=1, new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=I, 
          A1=:=1, new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=H, 
          A1=:=1, B1=:=2, 
          new214(A,B,C,D,E,F,G,B1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=H, 
          A1=:=1, new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=H, 
          A1=:=1, new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new208(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,M,K,L) :- N=:=O, N=:=J, O=:=1, 
          M=:=2.
new208(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=J, N=:=1.
new208(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=J, N=:=1.
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=I, Z=:=1, 
          A1=:=2, new208(A,B,C,D,E,F,G,H,A1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=H, Z=:=1, 
          A1=:=2, new205(A,B,C,D,E,F,G,A1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=M, I1=:=5, 
          new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=M, I1=:=5, J1=:=K1+L1, K1=:=N, L1=:=1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,J1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=M, I1=:=5, J1=:=K1+L1, K1=:=N, L1=:=1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,J1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1, H1=:=M, I1=:=5, 
          new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=M, I1=:=5, J1=:=K1+L1, K1=:=N, L1=:=1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,J1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=<I1, H1=:=M, I1=:=5, 
          new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=M, I1=:=5, J1=:=K1+L1, K1=:=N, L1=:=1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,J1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,20,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=K, I1=:=J1+K1, J1=:=L, K1=:=1, 
          new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=K, I1=:=J1+K1, J1=:=L, K1=:=1, 
          new191(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=K, I1=:=J1+K1, J1=:=L, K1=:=1, 
          new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=A, I1=:=1, 
          new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=A, I1=:=1, J1=:=0, K1=:=L1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,J1,K1,L1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=A, I1=:=1, J1=:=0, K1=:=L1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,J1,K1,L1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,M,N,O,P) :- 
          D1+1=<E1, D1=:=N, E1=:=O, F1=:=G1, H1=:=1, 
          new172(A,B,C,D,E,F,G,H,I,H1,G1,F1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=A, I1=:=0, J1=:=0, K1=:=L1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,J1,K1,L1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=A, I1=:=0, 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=A, I1=:=0, 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,Z,A1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,B1,C1).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1=:=D1, C1=:=B, D1=:=1, E1=:=F1+G1, F1=:=K, G1=:=1, H1=:=1, 
          new172(A,B,C,D,E,F,G,H,H1,J,E1,L,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=B, G1=:=1, H1=:=0, I1=:=J1, 
          new169(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=B, G1=:=1, H1=:=0, I1=:=J1, 
          new169(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=B, G1=:=1, H1=:=I1+J1, I1=:=K, J1=:=1, K1=:=1, L1=:=2, 
          M1=:=N1+O1, N1=:=M, O1=:=1, 
          new123(A,B,C,D,E,F,G,H,K1,J,H1,L,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new169(P1,Q1,R1,S1,T1,U1,V1,W1,L1,Y1,Z1,A2,M1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=B, G1=:=0, H1=:=0, I1=:=J1, 
          new169(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=B, G1=:=0, 
          new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=B, G1=:=0, 
          new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new159(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,M,N,O,P,Q,R) :- 
          F1>=G1+1, F1=:=R, G1=:=0, H1=:=1, 
          new162(A,B,C,H1,E,F,G,H,I,J,K,L,I1,J1,K1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,L1,M1,N1).
new159(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,M,N,O,P,Q,R) :- 
          F1+1=<G1, F1=:=R, G1=:=0, H1=:=1, 
          new162(A,B,C,H1,E,F,G,H,I,J,K,L,I1,J1,K1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,L1,M1,N1).
new159(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=R, M1=:=0, N1=:=O1+P1, O1=:=N, P1=:=1, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new159(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=R, M1=:=0, N1=:=1, O1=:=P1+Q1, P1=:=N, Q1=:=1, 
          new115(A,B,C,N1,E,F,G,H,I,J,K,L,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2), 
          new150(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M,O1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new159(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=R, M1=:=0, N1=:=1, O1=:=P1+Q1, P1=:=N, Q1=:=1, 
          new115(A,B,C,N1,E,F,G,H,I,J,K,L,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2), 
          new150(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M,O1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=D, M1=:=0, 
          new159(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,N1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=D, M1=:=0, N1=:=O1+P1, O1=:=N, P1=:=1, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=D, M1=:=0, N1=:=O1+P1, O1=:=N, P1=:=1, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,M,N,O,P,Q,R) :- 
          F1>=G1+1, F1=:=Q, G1=:=0, H1=:=1, 
          new178(A,B,H1,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,M1,N1,O1,P1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,M,N,O,P,Q,R) :- 
          F1+1=<G1, F1=:=Q, G1=:=0, H1=:=1, 
          new178(A,B,H1,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,M1,N1,O1,P1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=Q, M1=:=0, 
          new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=Q, M1=:=0, N1=:=1, 
          new128(A,B,N1,D,E,F,G,H,I,J,K,L,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new157(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=Q, M1=:=0, N1=:=1, 
          new128(A,B,N1,D,E,F,G,H,I,J,K,L,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new157(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=C, M1=:=0, 
          new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,N1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=C, M1=:=0, 
          new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=C, M1=:=0, 
          new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=M, M1=:=0, 
          new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=M, M1=:=0, 
          new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,M,N,O,P,Q,R) :- 
          F1+1=<G1, F1=:=N, G1=:=O, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,H1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,I1).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=N, M1=:=O, N1=:=O1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O1), 
          new153(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,N1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=M, H1=:=5, 
          new139(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=M, H1=:=5, I1=:=J1+K1, J1=:=N, K1=:=1, 
          new133(A,B,C,D,E,F,G,H,I,J,K,L,M,I1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=M, H1=:=5, I1=:=J1+K1, J1=:=N, K1=:=1, 
          new133(A,B,C,D,E,F,G,H,I,J,K,L,M,I1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=M, H1=:=5, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=M, H1=:=5, I1=:=J1+K1, J1=:=N, K1=:=1, 
          new133(A,B,C,D,E,F,G,H,I,J,K,L,M,I1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=<H1, G1=:=M, H1=:=5, 
          new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=M, H1=:=5, I1=:=J1+K1, J1=:=N, K1=:=1, 
          new133(A,B,C,D,E,F,G,H,I,J,K,L,M,I1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=K, H1=:=I1+J1, I1=:=L, J1=:=1, 
          new139(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=K, H1=:=I1+J1, I1=:=L, J1=:=1, 
          new139(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=K, H1=:=I1+J1, I1=:=L, J1=:=1, 
          new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=A, H1=:=1, 
          new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=A, H1=:=1, I1=:=0, J1=:=K1, 
          new133(A,B,C,D,E,F,G,H,I,J,K,L,M,I1,J1,K1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=A, H1=:=1, I1=:=0, J1=:=K1, 
          new133(A,B,C,D,E,F,G,H,I,J,K,L,M,I1,J1,K1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new133(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- 
          Q>=R, Q=:=N, R=:=O.
new133(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O,P) :- 
          C1+1=<D1, C1=:=N, D1=:=O, E1=:=F1, G1=:=1, Z=:=2, Q=:=1, S=:=2, 
          new123(A,B,C,D,E,F,G,H,I,G1,F1,E1,H1,R,I1,T,U,V,W,X,Y,J1,A1,B1).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=A, H1=:=0, I1=:=0, J1=:=K1, 
          new133(A,B,C,D,E,F,G,H,I,J,K,L,M,I1,J1,K1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=A, H1=:=0, 
          new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=A, H1=:=0, 
          new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z,M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=B, F1=:=1, G1=:=0, H1=:=I1, 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=B, F1=:=1, G1=:=0, H1=:=I1, 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=B, F1=:=1, G1=:=H1+I1, H1=:=K, I1=:=1, J1=:=1, K1=:=2, 
          L1=:=M1+N1, M1=:=M, N1=:=1, 
          new123(A,B,C,D,E,F,G,H,J1,J,G1,L,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1), 
          new120(O1,P1,Q1,R1,S1,T1,U1,V1,K1,X1,Y1,Z1,L1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,P,C,Q,E,F,G,H,I,J,K,L,M,N,O) :- R+1=<S, 
          R=:=M, S=:=N, P=:=1, Q=:=2.
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, 
          P=:=M, Q=:=N.
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=B, F1=:=0, G1=:=0, H1=:=I1, 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=B, F1=:=0, 
          new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=B, F1=:=0, 
          new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=R, L1=:=0, M1=:=N1+O1, N1=:=N, O1=:=1, 
          new104(A,B,C,D,E,F,G,H,I,J,K,L,M,M1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=R, L1=:=0, M1=:=1, N1=:=O1+P1, O1=:=N, P1=:=1, 
          new115(A,B,C,M1,E,F,G,H,I,J,K,L,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new104(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,M,N1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=R, L1=:=0, M1=:=1, N1=:=O1+P1, O1=:=N, P1=:=1, 
          new115(A,B,C,M1,E,F,G,H,I,J,K,L,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new104(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,M,N1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=D, L1=:=0, 
          new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, L1=:=0, M1=:=N1+O1, N1=:=N, O1=:=1, 
          new104(A,B,C,D,E,F,G,H,I,J,K,L,M,M1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=D, L1=:=0, M1=:=N1+O1, N1=:=N, O1=:=1, 
          new104(A,B,C,D,E,F,G,H,I,J,K,L,M,M1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=1, 
          new128(A,B,M1,D,E,F,G,H,I,J,K,L,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new110(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=1, 
          new128(A,B,M1,D,E,F,G,H,I,J,K,L,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new110(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new107(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=C, L1=:=0, 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new107(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=C, L1=:=0, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new107(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=C, L1=:=0, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          S=:=T, S=:=M, T=:=0.
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=M, L1=:=0, 
          new107(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=M, L1=:=0, 
          new107(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new104(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          S>=T, S=:=N, T=:=O.
new104(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=N, L1=:=O, M1=:=N1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,N1), 
          new106(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,M1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O=:=P, O=:=D, 
          P=:=0, N=:=1.
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=D, 
          P=:=0, N=:=0.
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=D, 
          P=:=0, N=:=0.
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,O) :- P>=Q+1, 
          P=:=M, Q=:=0, O=:=0.
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,O) :- P+1=<Q, 
          P=:=M, Q=:=0, O=:=0.
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,O) :- P=:=Q, P=:=M, 
          Q=:=0, O=:=1.
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=I, 
          A1=:=1, B1=:=2, 
          new91(A,B,C,D,E,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=I, 
          A1=:=1, new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=I, 
          A1=:=1, new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=H, 
          A1=:=1, B1=:=2, 
          new88(A,B,C,D,E,F,G,B1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=H, 
          A1=:=1, new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=H, 
          A1=:=1, new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new82(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,M,K,L) :- N=:=O, N=:=J, O=:=1, 
          M=:=2.
new82(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=J, N=:=1.
new82(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=J, N=:=1.
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=I, Z=:=1, 
          A1=:=2, new82(A,B,C,D,E,F,G,H,A1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=I, Z=:=1, 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=I, Z=:=1, 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=H, Z=:=1, 
          A1=:=2, new79(A,B,C,D,E,F,G,A1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=H, Z=:=1, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=H, Z=:=1, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=G, Z=:=1, 
          A1=:=2, new76(A,B,C,D,E,F,A1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=G, Z=:=1, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=G, Z=:=1, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=G, 
          A1=:=1, B1=:=2, 
          new85(A,B,C,D,E,F,B1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=G, 
          A1=:=1, new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=G, 
          A1=:=1, new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=O, M1=:=0, N1=:=O1+P1, O1=:=P, P1=:=1, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,N1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1), 
          new96(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new56(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,M,H,I,J,K,L) :- M=:=1.
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,B1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,E1), 
          new99(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,D1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1=:=H1, G1=:=N, H1=:=0, F1=:=4, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,M,N,O,P,Q,R) :- 
          F1>=G1+1, F1=:=N, G1=:=0, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,J1,K1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,M,N,O,P,Q,R) :- 
          F1+1=<G1, F1=:=N, G1=:=0, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,J1,K1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1=:=H1, G1=:=N, H1=:=0, F1=:=4, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1), 
          new21(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,W1,X1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=N, M1=:=0, N1=:=O1, 
          new61(A,B,C,D,E,F,G,H,I,J,K,L,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,O1), 
          new68(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M,N,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=N, M1=:=0, N1=:=O1, 
          new61(A,B,C,D,E,F,G,H,I,J,K,L,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,O1), 
          new68(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M,N,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1=:=H1, G1=:=N, H1=:=0, F1=:=4, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1), 
          new22(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2), 
          new70(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1=:=H1, G1=:=N, H1=:=0, F1=:=4, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1), 
          new22(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2), 
          new71(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2), 
          new60(K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,Y2,Z2).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=N, M1=:=0, N1=:=4, O1=:=P1, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new22(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2), 
          new71(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3), 
          new61(S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,P1), 
          new68(G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,N1,N,O1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O=:=P, O=:=C, 
          P=:=0, N=:=1.
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, A1=:=C, 
          B1=:=0, new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, A1=:=C, 
          B1=:=0, new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=C, C1=:=0, 
          new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=C, C1=:=0, 
          new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=0, L1=:=M1, 
          new104(A,B,C,D,E,F,G,H,I,J,K,L,M,K1,L1,M1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=0, M1=:=N1, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,L1,M1,N1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1+1=<H1, G1=:=P, H1=:=Q, F1=:=1, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O1,P1,Q1,R1,S1,T1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1+1=<H1, G1=:=P, H1=:=Q, I1=:=1, F1=:=2, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new6(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1+1=<H1, G1=:=P, H1=:=Q, I1=:=1, J1=:=2, F1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new7(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2), 
          new17(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1+1=<H1, G1=:=P, H1=:=Q, I1=:=1, J1=:=2, F1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new7(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2), 
          new18(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3), 
          new21(U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,I3,J3).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1+1=<H1, G1=:=P, H1=:=Q, I1=:=1, J1=:=2, F1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new7(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2), 
          new18(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3), 
          new22(U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3), 
          new24(I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          G1+1=<H1, G1=:=P, H1=:=Q, I1=:=1, J1=:=2, F1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new7(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2), 
          new18(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3), 
          new22(U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3), 
          new25(I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4), 
          new52(W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,J4).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=P, M1=:=Q, N1=:=1, O1=:=2, P1=:=3, Q1=:=R1, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2), 
          new7(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3), 
          new18(Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3), 
          new22(C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4), 
          new25(Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4), 
          new53(E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,R1), 
          new54(R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,P1,Q1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=G, Z=:=1, 
          A1=:=2, new202(A,B,C,D,E,F,A1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=G, Z=:=1, 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=G, Z=:=1, 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=G, 
          A1=:=1, B1=:=2, 
          new211(A,B,C,D,E,F,B1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=G, 
          A1=:=1, new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=G, 
          A1=:=1, new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          new220(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1), 
          new221(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,B1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          new220(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,E1), 
          new232(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,D1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=G, Z=:=0, 
          A1=:=1, new244(A,B,C,D,E,F,A1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=G, Z=:=0, 
          new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=G, Z=:=0, 
          new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=G, 
          A1=:=0, B1=:=1, 
          new253(A,B,C,D,E,F,B1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=G, 
          A1=:=0, new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=G, 
          A1=:=0, new253(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=E, Z=:=1, 
          A1=:=0, new262(A,B,A1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=E, Z=:=1, 
          A1=:=2, new262(A,B,A1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=E, Z=:=1, 
          A1=:=2, new262(A,B,A1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=E, 
          A1=:=1, B1=:=0, 
          new265(A,B,B1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=E, 
          A1=:=1, B1=:=2, 
          new265(A,B,B1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=E, 
          A1=:=1, B1=:=2, 
          new265(A,B,B1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new7(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          F1=:=0, new6(A,B,C,D,E,F,G,H,I,J,K,L,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          F1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1), 
          new12(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          F1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1), 
          new13(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2), 
          new17(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          F1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1), 
          new13(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2), 
          new18(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2), 
          new21(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,S2,T2).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N,O,P,Q,R) :- 
          F1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1), 
          new13(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2), 
          new18(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2), 
          new22(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3), 
          new24(S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=0, M1=:=0, N1=:=O1, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new13(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2), 
          new18(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2), 
          new22(N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3), 
          new25(B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4), 
          new26(P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,L1,N,O,M1,N1,O1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new4(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,M,N,G,H,I,J,K,L) :- M=:=1, N=:=1.
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,M) :- 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,M) :- 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1), 
          new5(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,S1,T1,U1,V1,W1,X1).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, J=:=2, 
          K=:=0, L=:=0, 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
correct :- \+new1.
