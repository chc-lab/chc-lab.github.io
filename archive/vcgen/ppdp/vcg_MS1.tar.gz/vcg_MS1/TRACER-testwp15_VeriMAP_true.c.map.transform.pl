new9(A,B,C,10,A,B,C).
new7(A,B,C,D,E,F,G) :- H=<I, H=:=J+K, J=:=B, K=:=C, I=:=0, new9(A,B,C,D,E,F,G).
new4(A,B,C,B) :- D>=E+1, D=:=B, E=:=0, C=:=3.
new4(A,B,A,C) :- D=<E, D=:=B, E=:=0, C=:=1.
new2(A,B,C,D,E,B,C) :- F>=G+1, F=:=B, G=:=0, H=:=2, new3(H,I,D,E,J).
new2(A,B,C,D,E,F,C) :- G=<H, G=:=B, H=:=0, F=:=0, new3(A,I,D,E,J).
new2(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=0, J=:=2, K=:=L, new4(J,M,N,L), 
          new7(N,B,K,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=0, J=:=0, K=:=L, new4(A,M,N,L), 
          new7(N,J,K,D,E,F,G).
new1 :- A=:=0, new2(A,B,C,D,E,F,G).
correct :- \+new1.
