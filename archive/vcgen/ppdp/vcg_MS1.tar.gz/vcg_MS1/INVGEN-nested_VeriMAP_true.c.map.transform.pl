new6(A,B,C,18,A,B,C).
new5(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=B, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, 
          new4(J,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, J=:=K+L, K=:=B, L=:=1, 
          new3(A,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=C, J=:=1, new4(J,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=C, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=1, new3(A,H,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
