new12(A,B,C,D,9,A,B,C,D).
new8(A,B,A,C) :- C=:=D+E, D=:=A, E=:=5.
new9(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, K=:=0, new12(A,B,C,D,E,F,G,H,I).
new9(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=0, new12(A,B,C,D,E,F,G,H,I).
new4(A,B,A,C) :- C=:=D+E, D=:=A, E=:=3.
new2(A,B,C,D,E,A,B,C,D) :- F>=G+1, F=:=D, G=:=0, H=:=A, new3(H,I,E,J,K).
new2(A,B,C,D,E,A,B,C,D) :- F+1=<G, F=:=D, G=:=0, H=:=A, new3(H,I,E,J,K).
new2(A,B,C,D,E,A,B,C,D) :- F=:=G, F=:=D, G=:=0, H=:=A, new7(H,I,E,J,K).
new2(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, L=:=A, M=:=N, O=:=P-Q, 
          P=:=R-S, R=:=M, S=:=A, Q=:=3, new4(L,T,U,N), new9(A,M,O,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=0, L=:=A, M=:=N, O=:=P-Q, 
          P=:=R-S, R=:=M, S=:=A, Q=:=3, new4(L,T,U,N), new9(A,M,O,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=D, K=:=0, L=:=A, M=:=N, O=:=P-Q, P=:=R-S, 
          R=:=M, S=:=A, Q=:=5, new8(L,T,U,N), new9(A,M,O,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
