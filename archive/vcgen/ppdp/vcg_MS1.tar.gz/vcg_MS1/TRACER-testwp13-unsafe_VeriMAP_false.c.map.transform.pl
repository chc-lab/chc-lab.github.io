new7(A,B,7,A,B).
new6(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0, new7(A,B,C,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=50, new6(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0, H=:=I+J, I=:=B, J=:=1, new4(A,H,C,D,E).
new3(A,B,C,D,E) :- F=<G, F=:=B, G=:=0, H=:=I-J, I=:=A, J=:=10, new4(H,B,C,D,E).
new2(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=5, new3(A,B,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
