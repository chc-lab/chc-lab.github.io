new14(A,B,C,22,A,B,C).
new13(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=200, new14(A,B,C,D,E,F,G).
new12(A,B,C,D,E,F,G) :- new7(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=100, new12(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=100, new13(A,B,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=K+L, K=:=B, L=:=1, M=:=N+O, 
          N=:=C, O=:=1, new8(A,J,M,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, J=:=K+L, K=:=B, L=:=1, M=:=N+O, 
          N=:=C, O=:=1, new8(A,J,M,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, new11(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- new7(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=100, new7(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=100, J=:=0, new8(A,B,J,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=K+L, K=:=B, L=:=1, 
          new3(A,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, J=:=K+L, K=:=B, L=:=1, 
          new3(A,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, new3(A,H,C,D,E,F,G).
new1 :- A=:=0, new2(A,B,C,D,E,F,G).
correct :- \+new1.
