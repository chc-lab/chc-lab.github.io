new8(A,B,C,D,11,A,B,C,D).
new6(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, new8(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=0, new8(A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=L*M, L=:=B, M=:=2, 
          new6(A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=L*M, L=:=B, M=:=2, 
          new6(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=A, K=:=B, L=:=M+N, M=:=D, N=:=2, O=:=P+Q, 
          P=:=A, Q=:=1, new3(O,B,C,L,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=B, new5(A,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=K, L=:=0, M=:=1, new3(M,J,K,L,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
