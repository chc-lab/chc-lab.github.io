new23(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=A, O=:=9, P=:=Q+R, Q=:=A, R=:=1, 
          S=:=T+U, T=:=B, U=:=3, new4(P,S,C,D,E,V,G,H,I,J,K,L,M).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=P-Q, P=:=A, Q=:=7, O=:=0, 
          R=:=S+T, S=:=A, T=:=2, U=:=V+W, V=:=B, W=:=1, 
          new4(R,U,C,D,E,X,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=P-Q, P=:=A, Q=:=4, O=:=0, 
          R=:=S+T, S=:=A, T=:=1, U=:=V+W, V=:=B, W=:=2, 
          new4(R,U,C,D,E,X,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=P-Q, P=:=A, Q=:=5, O=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=0, 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=0, 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=C, O=:=0, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=A, O=:=7, 
          new23(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=D, O=:=0, 
          new16(A,B,P,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=A, O=:=9, P=:=Q+R, Q=:=A, R=:=2, 
          S=:=T+U, T=:=B, U=:=1, new4(P,S,C,D,E,V,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,39,A,B,C,D,E,F).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=P-Q, P=:=R*S, R=:=3, S=:=A, 
          Q=:=B, O=:=0, new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=P+Q, P=:=R*S, R=:= -1, S=:=A, 
          Q=:=T*U, T=:=2, U=:=B, O=:=0, new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=P+Q, P=:=R*S, R=:= -1, S=:=A, 
          Q=:=T*U, T=:=2, U=:=B, O=:=0, new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=E, O=:=0, 
          new13(A,B,C,P,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, 
          new5(A,B,C,D,P,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=F, O=:=0, 
          new5(A,B,C,D,P,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=F, O=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=B, O=:=0, 
          new4(A,B,C,D,E,P,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
