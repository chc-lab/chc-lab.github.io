new35(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=8656, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new35(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=8656, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new35(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, N=:=8512, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new28(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, N=:=8656, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new25(A,B,C,D,E,F,G,H,I,J,K) :- new3(A,B,C,D,E,F,G,H,I,J,K).
new21(A,B,C,D,E,46,A,B,C,D,E) :- F=:=G, F=:=D, G=:=5.
new21(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=5, 
          new20(A,B,C,D,E,F,G,H,I,J,K).
new21(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=5, 
          new20(A,B,C,D,E,F,G,H,I,J,K).
new20(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=8640, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new20(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=8640, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new17(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=D, M=:=4, N=:=5, 
          new20(A,B,C,N,E,F,G,H,I,J,K).
new17(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=4, 
          new21(A,B,C,D,E,F,G,H,I,J,K).
new17(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=4, 
          new21(A,B,C,D,E,F,G,H,I,J,K).
new16(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=D, M=:=2, N=:=3, 
          new17(A,B,C,N,E,F,G,H,I,J,K).
new16(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=2, 
          new17(A,B,C,D,E,F,G,H,I,J,K).
new16(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=2, 
          new17(A,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8656, 
          new16(A,B,C,D,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=D, M=:=3, N=:=4, 
          new28(A,B,C,N,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8640, 
          new13(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8640, 
          new14(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8640, 
          new14(A,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, N=:=8466, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=0, N=:=8466, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=E, M=:=0, N=:=8640, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new8(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8512, 
          new10(A,B,C,D,N,F,G,H,I,J,K).
new8(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8512, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new8(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8512, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=D, M=:=0, N=:=2, 
          new35(A,B,C,N,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=0, 
          new35(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=0, 
          new35(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8466, 
          new7(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8466, 
          new8(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8466, 
          new8(A,B,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,46,A,B,C,D,E) :- F>=G+1, F=:=D, G=:=2.
new5(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=D, M=:=2, new6(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=A, M=:=8512, 
          new5(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8512, 
          new6(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=1, M=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, N=:=8466, O=:=0, 
          new3(N,L,M,O,E,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
