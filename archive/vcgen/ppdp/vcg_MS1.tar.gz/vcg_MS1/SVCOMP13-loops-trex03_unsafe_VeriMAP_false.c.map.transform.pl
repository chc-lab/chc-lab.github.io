new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=L, G1=:=0, H1=:=I1-J1, I1=:=C, C>=0, J1=:=H, H>=0, 
          K1=:=L1, M1=:=N1, 
          new6(A,B,H1,D,E,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=L, G1=:=0, H1=:=I1-J1, I1=:=C, C>=0, J1=:=H, H>=0, 
          K1=:=L1, M1=:=N1, 
          new6(A,B,H1,D,E,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=L, G1=:=0, H1=:=I1-J1, I1=:=E, E>=0, J1=:=I, I>=0, 
          K1=:=L1, M1=:=N1, 
          new6(A,B,C,D,H1,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=J, G1=:=0, H1=:=I1-J1, I1=:=A, A>=0, J1=:=G, G>=0, 
          K1=:=L1, M1=:=N1, 
          new6(H1,B,C,D,E,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=J, G1=:=0, H1=:=I1-J1, I1=:=A, A>=0, J1=:=G, G>=0, 
          K1=:=L1, M1=:=N1, 
          new6(H1,B,C,D,E,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=J, G1=:=0, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=E, E>=0, G1=:=0, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=<G1, F1=:=E, E>=0, G1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=E, E>=0, G1=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,23,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=C, C>=0, G1=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=C, C>=0, G1=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=A, A>=0, G1=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=A, A>=0, G1=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=C, C>=0, G1=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=<G1, F1=:=C, C>=0, G1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=A, A>=0, G1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=<G1, F1=:=A, A>=0, G1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new3(A,A).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, G1>=0, H1=:=F1, F1>=0, I1=:=J1, J1>=0, K1=:=I1, I1>=0, 
          L1=:=M1, M1>=0, N1=:=L1, L1>=0, O1=:=1, P1=:=1, Q1=:=1, R1=:=S1, 
          T1=:=U1, new3(V1,G1), new3(W1,J1), new3(X1,M1), 
          new6(H1,F1,K1,I1,N1,L1,O1,P1,Q1,R1,S1,T1,U1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new1 :- 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
correct :- \+new1.
