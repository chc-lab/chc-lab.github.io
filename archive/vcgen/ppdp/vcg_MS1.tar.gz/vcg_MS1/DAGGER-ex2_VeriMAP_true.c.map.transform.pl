new37(A,B,C,D,E,F,G,H,I,J,K,L,46,A,B,C,D,E,F,G,H,I,J,K,L).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=A, 
          A1=:=132, new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=L, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new34(B1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=L, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new34(B1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=L, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=2, 
          new34(B1,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=K, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new31(B1,B,C,D,E,F,G,H,I,J,K,E1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=K, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new31(B1,B,C,D,E,F,G,H,I,J,K,E1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=K, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=4, 
          new31(B1,B,C,D,E,F,G,H,I,J,K,E1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=J, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new28(B1,B,C,D,E,F,G,H,I,J,E1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=J, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new28(B1,B,C,D,E,F,G,H,I,J,E1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=J, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=6, 
          new28(B1,B,C,D,E,F,G,H,I,J,E1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=I, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new25(B1,B,C,D,E,F,G,H,I,E1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=I, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new25(B1,B,C,D,E,F,G,H,I,E1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=I, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=8, 
          new25(B1,B,C,D,E,F,G,H,I,E1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=H, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new22(B1,B,C,D,E,F,G,H,E1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=H, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new22(B1,B,C,D,E,F,G,H,E1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=H, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=10, 
          new22(B1,B,C,D,E,F,G,H,E1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=G, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new19(B1,B,C,D,E,F,G,E1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=G, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new19(B1,B,C,D,E,F,G,E1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=G, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=12, 
          new19(B1,B,C,D,E,F,G,E1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=F, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new16(B1,B,C,D,E,F,E1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=F, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new16(B1,B,C,D,E,F,E1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=F, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=14, 
          new16(B1,B,C,D,E,F,E1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=E, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new13(B1,B,C,D,E,E1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=E, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new13(B1,B,C,D,E,E1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=E, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=16, 
          new13(B1,B,C,D,E,E1,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=D, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new10(B1,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=D, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new10(B1,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=D, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=18, 
          new10(B1,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=C, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new7(B1,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=C, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new7(B1,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=C, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=20, 
          new7(B1,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=B, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new4(B1,B,E1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=1, 
          new4(B1,B,E1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=B, 
          A1=:=0, B1=:=C1+D1, C1=:=A, D1=:=22, 
          new4(B1,B,E1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=0, 
          new3(Z,A1,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
correct :- \+new1.
