new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=G, S=:=0, T=:=U+V, 
          U=:=A, V=:=1, new3(T,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=G, S=:=0, T=:=U+V, 
          U=:=A, V=:=1, new3(T,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=G, S=:=0, T=:=U-V, U=:=A, 
          V=:=1, W=:=X-Y, X=:=E, Y=:=1, new3(T,B,C,D,W,F,G,H,I,J,K,L,M,N,O,P,Q).
new5(A,B,C,D,E,F,G,H,14,A,B,C,D,E,F,G,H).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=100, S=:=E, T=:=U, 
          new6(A,B,C,D,E,F,T,U,I,J,K,L,M,N,O,P,Q).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S, R=:=100, S=:=E, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=A, S=:=100, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S, R=:=A, S=:=100, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, T=:=U, V=:=W, 
          new3(R,S,T,U,V,W,G,H,I,J,K,L,M,N,O,P,Q).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
correct :- \+new1.
