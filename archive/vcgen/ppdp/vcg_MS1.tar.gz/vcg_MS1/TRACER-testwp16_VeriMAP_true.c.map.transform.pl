new7(A,B,C,D,7,A,B,C,D).
new5(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=1000, new7(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=C, K=:=3, L=:=M+N, M=:=A, N=:=1, O=:=P+Q, 
          P=:=L, Q=:=1, new5(O,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, K=:=3, L=:=M+N, M=:=A, N=:=1, 
          new5(L,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=3, L=:=M+N, M=:=A, N=:=1, 
          new5(L,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=B, K=:=0, new4(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=B, K=:=0, L=:=M+N, M=:=A, N=:=1, 
          new5(L,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=B, K=:=0, L=:=M+N, M=:=A, N=:=1, 
          new5(L,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=1, K=:=D, L=:=D, new3(J,K,L,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
