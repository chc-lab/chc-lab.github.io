new6(A,B,C,D,E,F,G,13,A,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=R+S, R=:=B, S=:=1, 
          T=:=U+V, U=:=E, V=:=1, new3(A,B,C,D,T,F,G,H,I,J,K,L,M,N,O).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=R+S, R=:=B, S=:=1, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=0, Q=:=E, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=0, Q=:=E, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=E, Q=:=G, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=B, Q=:=0, R=:=0, S=:=T-U, 
          T=:=V+W, V=:=R, W=:=X+Y, X=:=B, Y=:=1, U=:=1, Z=:=R, A1=:=S, B1=:=Z, 
          new3(A,B,R,S,B1,Z,A1,H,I,J,K,L,M,N,O).
new1 :- A=:=0, new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
correct :- \+new1.
