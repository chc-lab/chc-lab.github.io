new16(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=B, K=:=0, L=:=M+N, M=:=A, N=:=1, 
          new16(L,B,C,D,E,F,G,H,I).
new16(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=B, K=:=0, L=:=M+N, M=:=A, N=:=1, 
          new16(L,B,C,D,E,F,G,H,I).
new15(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, K=:=0, L=:=4, 
          new16(A,B,C,L,E,F,G,H,I).
new15(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=C, K=:=0, L=:=5, new16(A,B,C,L,E,F,G,H,I).
new11(A,B,C,D,A,B,C,D) :- E=:=F, E=:=B, F=:=0.
new11(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new11(K,B,C,D,E,F,G,H).
new11(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=B, J=:=0, K=:=L+M, L=:=A, M=:=1, 
          new11(K,B,C,D,E,F,G,H).
new10(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=C, J=:=0, K=:=4, new11(A,B,C,K,E,F,G,H).
new10(A,B,C,D,E,F,G,H) :- I=<J, I=:=C, J=:=0, K=:=5, new11(A,B,C,K,E,F,G,H).
new9(A,B,18,A,B).
new7(A,B,C,D,E) :- F=:=G, F=:=B, G=:=2, new9(A,B,C,D,E).
new4(A,B,C,D,E,F,G,H) :- I=:=0, new10(I,B,C,D,E,F,G,H).
new3(A,B,C,D,E,F,G,H,I) :- J=:=0, new15(J,B,C,D,E,F,G,H,I).
new2(A,B,C,A,D) :- E>=F+1, E=:=A, F=:=0, D=:=1, new3(G,H,I,J,C,K,L,M,N).
new2(A,B,C,A,D) :- E=<F, E=:=A, F=:=0, D=:=3, new3(G,H,I,J,C,K,L,M,N).
new2(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=0, H=:=1, new4(I,J,K,L,M,N,O,P), 
          new7(A,H,C,D,E).
new2(A,B,C,D,E) :- F=<G, F=:=A, G=:=0, H=:=3, new4(I,J,K,L,M,N,O,P), 
          new7(A,H,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
