new13(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=5, new15(A,B,C,D,E).
new13(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=5, new15(A,B,C,D,E).
new12(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0, new13(A,B,C,D,E).
new12(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=0, new13(A,B,C,D,E).
new10(A,B,C,B) :- D=:=E, D=:=B, E=:=15, C=:=15.
new10(A,B,C,B) :- D>=E+1, D=:=B, E=:=15, C=:=20.
new10(A,B,C,B) :- D+1=<E, D=:=B, E=:=15, C=:=20.
new8(A,B,C,B) :- D=:=E, D=:=B, E=:=5, C=:=5.
new8(A,B,C,D) :- E>=F+1, E=:=B, F=:=5, new10(A,B,C,D).
new8(A,B,C,D) :- E+1=<F, E=:=B, F=:=5, new10(A,B,C,D).
new7(A,B,C,B) :- D=:=E, D=:=B, E=:=0, C=:=0.
new7(A,B,C,D) :- E>=F+1, E=:=B, F=:=0, new8(A,B,C,D).
new7(A,B,C,D) :- E+1=<F, E=:=B, F=:=0, new8(A,B,C,D).
new6(A,21,A).
new5(A,B,C) :- D=:=E, D=:=A, E=:=15, new6(A,B,C).
new4(A,B,C,D) :- new7(A,E,C,D).
new3(A,B,C,D,E) :- new12(A,F,C,D,E).
new2(A,B,A) :- new3(C,D,B,E,F).
new2(A,B,C) :- D=:=E, new4(F,G,E,H), new5(D,B,C).
new1 :- new2(A,B,C).
correct :- \+new1.
