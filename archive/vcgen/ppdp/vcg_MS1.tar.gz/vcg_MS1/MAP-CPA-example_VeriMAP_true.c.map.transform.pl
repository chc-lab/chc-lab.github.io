new6(A,B,13,A,B) :- C>=D+1, C=:=A, D=:=B.
new6(A,B,13,A,B) :- C+1=<D, C=:=A, D=:=B.
new6(A,B,C,D,E) :- F=:=G, F=:=A, G=:=B, new3(A,B,C,D,E).
new5(A,B,13,A,B) :- C>=D+1, C=:=B, D=:=20.
new5(A,B,13,A,B) :- C+1=<D, C=:=B, D=:=20.
new4(A,B,C,D,E) :- F=:=G, F=:=A, G=:=20, new5(A,B,C,D,E).
new4(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=20, H=:=I+J, I=:=A, J=:=1, K=:=L+M, 
          L=:=B, M=:=1, new6(H,K,C,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=20, H=:=I+J, I=:=A, J=:=1, K=:=L+M, 
          L=:=B, M=:=1, new6(H,K,C,D,E).
new3(A,B,C,D,E) :- F>=G+1, F=:=1, G=:=0, new4(A,B,C,D,E).
new2(A,B,C,D,E) :- F=:=0, G=:=0, new3(F,G,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
