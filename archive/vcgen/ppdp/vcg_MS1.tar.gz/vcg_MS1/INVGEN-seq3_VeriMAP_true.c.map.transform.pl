new12(A,B,C,D,E,F,G,32,A,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=0, R=:=S+T, S=:=G, 
          T=:=1, U=:=V-W, V=:=D, W=:=1, new9(A,B,C,U,E,F,R,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=G, Q=:=A, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=F, Q=:=B, R=:=S+T, S=:=F, 
          T=:=1, U=:=V-W, V=:=D, W=:=1, new7(A,B,C,U,E,R,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=F, Q=:=B, R=:=0, 
          new9(A,B,C,D,E,F,R,H,I,J,K,L,M,N,O).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=B, R=:=S+T, S=:=E, 
          T=:=1, U=:=V+W, V=:=D, W=:=1, new5(A,B,C,U,R,F,G,H,I,J,K,L,M,N,O).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=B, R=:=0, 
          new7(A,B,C,D,E,R,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=C, Q=:=A, R=:=S+T, S=:=C, 
          T=:=1, U=:=V+W, V=:=D, W=:=1, new3(A,B,R,U,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=C, Q=:=A, R=:=0, 
          new5(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=0, Q=:=0, 
          new3(A,B,P,Q,E,F,G,H,I,J,K,L,M,N,O).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
correct :- \+new1.
