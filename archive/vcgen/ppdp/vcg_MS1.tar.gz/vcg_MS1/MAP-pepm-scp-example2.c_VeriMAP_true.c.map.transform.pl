new8(A,B,C,11,A,B,C).
new5(A,B,C,D,A,E,C,D) :- E=:=F+G, F=:=B, G=:=D.
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=B, new8(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, M=:=J, 
          new4(J,B,C,M,D,E,F,G,N).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, new6(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, M=:=J, 
          new5(J,B,C,M,N,O,P,Q), new3(N,O,P,D,E,F,G).
new2(A,B,C,D,E,F,G) :- new3(A,B,C,D,E,F,G).
new1 :- A=:=0, B=:=0, C=:=0, new2(A,B,C,D,E,F,G).
correct :- \+new1.
