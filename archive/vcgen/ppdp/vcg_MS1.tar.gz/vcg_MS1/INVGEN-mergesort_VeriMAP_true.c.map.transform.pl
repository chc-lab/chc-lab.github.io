new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=A, 
          A1=:=0, B1=:=C1+D1, C1=:=B, D1=:=1, E1=:=F1+G1, F1=:=E, G1=:=1, 
          new7(A,B1,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=A, 
          A1=:=0, B1=:=C1+D1, C1=:=B, D1=:=1, E1=:=F1+G1, F1=:=E, G1=:=1, 
          new7(A,B1,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=A, 
          A1=:=0, B1=:=C1+D1, C1=:=I, D1=:=1, E1=:=F1+G1, F1=:=E, G1=:=1, 
          new7(A,B,C,D,E1,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=E, 
          A1=:=H, B1=:=C1+D1, C1=:=E, D1=:=1, 
          new16(A,B,C,D,B1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1, Z=:=E, 
          A1=:=H, B1=:=C1+D1, C1=:=L, D1=:=E1*F1, E1=:=J, F1=:=2, 
          new4(A,B,C,D,E,F,G,H,I,J,K,B1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=I, 
          A1=:=H, B1=:=C1+D1, C1=:=I, D1=:=1, E1=:=F1+G1, F1=:=E, G1=:=1, 
          new14(A,B,C,D,E1,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1, Z=:=I, 
          A1=:=H, B1=:=F, 
          new16(A,B,C,D,B1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new12(A,B,C,D,E,F,G,H,I,J,K,L,30,A,B,C,D,E,F,G,H,I,J,K,L).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=G, B1=:=C1+D1, C1=:=B, D1=:=1, E1=:=F1+G1, F1=:=E, G1=:=1, 
          new11(A,B1,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1, Z=:=B, 
          A1=:=G, new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=<A1, Z=:=E, 
          A1=:=C, new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=E, 
          A1=:=C, new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=I, 
          A1=:=H, new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1, Z=:=I, 
          A1=:=H, new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=G, new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1, Z=:=B, 
          A1=:=G, new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=K, 
          A1=:=C, B1=:=C1+D1, C1=:=C, D1=:=1, E1=:=L, F1=:=G1+H1, G1=:=L, 
          H1=:=J, I1=:=B1, J1=:=E1, K1=:=F1, L1=:=E1, 
          new7(A,J1,C,D,L1,E1,F1,I1,K1,J,B1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=<A1, Z=:=K, 
          A1=:=C, B1=:=L, C1=:=D1+E1, D1=:=L, E1=:=J, F1=:=K, G1=:=B1, H1=:=C1, 
          I1=:=B1, 
          new7(A,G1,C,D,I1,B1,C1,F1,H1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=<A1, Z=:=B1+C1, 
          B1=:=L, C1=:=J, A1=:=C, D1=:=E1+F1, E1=:=L, F1=:=G1*H1, G1=:=J, 
          H1=:=2, new5(A,B,C,D,E,F,G,H,I,J,D1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=B1+C1, 
          B1=:=L, C1=:=J, A1=:=C, D1=:=E1*F1, E1=:=J, F1=:=2, 
          new3(A,B,C,D,E,F,G,H,I,D1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=J, 
          A1=:=C, B1=:=1, 
          new4(A,B,C,D,E,F,G,H,I,J,K,B1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=1, 
          new3(A,B,C,D,E,F,G,H,I,Z,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=0, 
          K=:=0, L=:=0, new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
correct :- \+new1.
