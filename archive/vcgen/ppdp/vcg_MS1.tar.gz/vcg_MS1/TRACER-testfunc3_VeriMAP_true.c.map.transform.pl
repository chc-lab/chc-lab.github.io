new13(A,B,C,D,5,A,B,C,D).
new12(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=17, new13(A,B,C,D,E,F,G,H,I).
new12(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=17, new13(A,B,C,D,E,F,G,H,I).
new4(A,B,A,C) :- C=:=D+E, D=:=A, E=:=1.
new2(A,B,C,D,E,F,B,C,D) :- F=:=8, G=:=H+I, H=:=F, I=:=1, new3(G,J,E,K,L).
new2(A,B,C,D,E,F,G,C,D) :- F=:=8, H=:=I+J, I=:=F, J=:=1, G=:=K, L=:=M+N, M=:=G, 
          N=:=2, new4(H,O,P,K), new3(L,Q,E,R,S).
new2(A,B,C,D,E,F,G,H,D) :- F=:=8, I=:=J+K, J=:=F, K=:=1, G=:=L, M=:=N+O, N=:=G, 
          O=:=2, H=:=P, Q=:=R+S, R=:=H, S=:=3, new4(I,T,U,L), new4(M,V,W,P), 
          new3(Q,X,E,Y,Z).
new2(A,B,C,D,E,F,G,H,I) :- J=:=8, K=:=L+M, L=:=J, M=:=1, N=:=O, P=:=Q+R, Q=:=N, 
          R=:=2, S=:=T, U=:=V+W, V=:=S, W=:=3, X=:=Y, new4(K,Z,A1,O), 
          new4(P,B1,C1,T), new4(U,D1,E1,Y), new12(J,N,S,X,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
