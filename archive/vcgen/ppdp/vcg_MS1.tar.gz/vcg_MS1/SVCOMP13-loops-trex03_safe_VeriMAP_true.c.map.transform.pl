new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=L, C1=:=0, D1=:=E1-F1, E1=:=C, C>=0, F1=:=H, H>=0, 
          new6(A,B,D1,D,E,F,G,H,I,G1,K,H1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=L, C1=:=0, D1=:=E1-F1, E1=:=C, C>=0, F1=:=H, H>=0, 
          new6(A,B,D1,D,E,F,G,H,I,G1,K,H1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=L, C1=:=0, D1=:=E1-F1, E1=:=E, E>=0, F1=:=I, I>=0, 
          new6(A,B,C,D,D1,F,G,H,I,G1,K,H1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=J, C1=:=0, D1=:=E1-F1, E1=:=A, A>=0, F1=:=G, G>=0, 
          new6(D1,B,C,D,E,F,G,H,I,G1,K,H1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=J, C1=:=0, D1=:=E1-F1, E1=:=A, A>=0, F1=:=G, G>=0, 
          new6(D1,B,C,D,E,F,G,H,I,G1,K,H1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=J, C1=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=E, E>=0, C1=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=<C1, 
          B1=:=E, E>=0, C1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,21,A,B,C,D,E,F,G,H,I,J,K,L,M).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=E, E>=0, C1=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=C, C>=0, C1=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=A, A>=0, C1=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=C, C>=0, C1=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=<C1, B1=:=C, 
          C>=0, C1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=A, A>=0, C1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=<C1, B1=:=A, 
          A>=0, C1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new3(A,A).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, C1>=0, 
          D1=:=B1, B1>=0, E1=:=F1, F1>=0, G1=:=E1, E1>=0, H1=:=I1, I1>=0, 
          J1=:=H1, H1>=0, K1=:=1, L1=:=1, M1=:=1, N1=:=O1, P1=:=Q1, 
          new3(R1,C1), new3(S1,F1), new3(T1,I1), 
          new6(D1,B1,G1,E1,J1,H1,K1,L1,M1,N1,O1,P1,Q1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
correct :- \+new1.
