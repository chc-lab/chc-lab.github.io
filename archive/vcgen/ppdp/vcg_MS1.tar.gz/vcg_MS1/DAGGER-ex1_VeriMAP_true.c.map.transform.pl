new7(A,B,C,D,E,F,15,A,B,C,D,E,F).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=P+Q, P=:=C, Q=:=R*S, R=:=2, 
          S=:=D, O=:=0, new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=0, P=:=Q+R, Q=:=B, R=:=A, 
          S=:=T-U, T=:=A, U=:=V*W, V=:=2, W=:=P, X=:=Y+Z, Y=:=A1*B1, A1=:=2, 
          B1=:=A, Z=:=P, new3(A,P,S,X,E,C1,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=0, P=:=Q+R, Q=:=B, R=:=A, 
          S=:=T-U, T=:=A, U=:=V*W, V=:=2, W=:=P, X=:=Y+Z, Y=:=A1*B1, A1=:=2, 
          B1=:=A, Z=:=P, new3(A,P,S,X,E,C1,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=E, O=:=0, P=:=Q-R, Q=:=B, R=:=A, 
          S=:=T-U, T=:=A, U=:=V*W, V=:=2, W=:=P, X=:=Y+Z, Y=:=A1*B1, A1=:=2, 
          B1=:=A, Z=:=P, new3(A,P,S,X,E,C1,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, P=:=Q+R, Q=:=C, 
          R=:=S*T, S=:=2, T=:=D, U=:=V+W, V=:=X*Y, X=:= -2, Y=:=C, W=:=D, 
          Z=:=A1+B1, A1=:=P, B1=:=1, new4(Z,U,C,D,C1,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=F, O=:=0, P=:=Q+R, Q=:=C, 
          R=:=S*T, S=:=2, T=:=D, U=:=V+W, V=:=X*Y, X=:= -2, Y=:=C, W=:=D, 
          Z=:=A1+B1, A1=:=P, B1=:=1, new4(Z,U,C,D,C1,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=F, O=:=0, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=0, O=:=0, 
          new3(A,B,N,O,E,P,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
