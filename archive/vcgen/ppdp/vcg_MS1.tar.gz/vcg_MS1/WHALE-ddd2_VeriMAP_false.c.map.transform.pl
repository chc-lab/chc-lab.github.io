new537(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W,X,Y) :- 
          A1>=B1+1, A1=:=O, B1=:=M, Z=:=M.
new537(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W,X,Y) :- 
          A1=<B1, A1=:=O, B1=:=M, Z=:=O.
new388(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1>=W1+1, V1=:=I, W1=:=G, X1=:=1, Y1=:=0, Z1=:=1, A2=:=1, B2=:=1, 
          new389(A,B,X1,Y1,Z1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B2,A2,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new388(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1>=W1+1, V1=:=I, W1=:=G, X1=:=1, Y1=:=0, Z1=:=1, A2=:=1, B2=:=1, 
          new390(A,B,X1,Y1,Z1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B2,A2,V,C2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new388(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=<W1, V1=:=I, W1=:=G, X1=:=1, Y1=:=0, Z1=:=1, A2=:=1, B2=:=1, 
          new389(A,B,X1,Y1,Z1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B2,A2,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new388(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=<W1, V1=:=I, W1=:=G, X1=:=1, Y1=:=0, Z1=:=1, A2=:=1, B2=:=1, 
          new390(A,B,X1,Y1,Z1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B2,A2,V,C2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new377(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=N, S1=:=0, T1=:=0, U1=:=0, 
          new378(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new376(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=N, S1=:=0, T1=:=0, U1=:=1, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new376(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=N, S1=:=0, T1=:=0, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new376(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=N, S1=:=0, T1=:=0, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new375(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=I, S1=:=G, 
          new376(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new375(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1, R1=:=I, S1=:=G, T1=:=0, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new374(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=N, S1=:=0, T1=:=0, U1=:=1, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T1,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new374(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=N, S1=:=0, T1=:=0, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new374(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=N, S1=:=0, T1=:=0, 
          new377(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new373(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=I, S1=:=G, 
          new374(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new373(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=<S1, R1=:=I, S1=:=G, 
          new375(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new371(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=B, S1=:=0, T1=:=1, U1=:=1, 
          new385(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new371(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=B, S1=:=0, T1=:=1, U1=:=1, 
          new385(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new371(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=B, S1=:=0, T1=:=0, U1=:=0, V1=:=1, 
          new387(A,V1,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new367(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=C, S1=:=0, 
          new368(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new367(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=C, S1=:=0, 
          new368(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new367(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=C, S1=:=0, 
          new370(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new365(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=D, S1=:=0, 
          new371(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new365(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=D, S1=:=0, 
          new371(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new365(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=D, S1=:=0, 
          new373(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          D1>=E1+1, D1=:=B1, E1=:=0, F1=:=A, G1=:=B, H1=:=C, I1=:=D, J1=:=E, 
          K1=:=F, L1=:=G, M1=:=H, N1=:=I, O1=:=J, P1=:=K, Q1=:=L, R1=:=M, 
          S1=:=N, T1=:=O, U1=:=P, V1=:=Q, W1=:=R, X1=:=S, Y1=:=T, Z1=:=U, 
          new222(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C1,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          D1+1=<E1, D1=:=B1, E1=:=0, F1=:=A, G1=:=B, H1=:=C, I1=:=D, J1=:=E, 
          K1=:=F, L1=:=G, M1=:=H, N1=:=I, O1=:=J, P1=:=K, Q1=:=L, R1=:=M, 
          S1=:=N, T1=:=O, U1=:=P, V1=:=Q, W1=:=R, X1=:=S, Y1=:=T, Z1=:=U, 
          new222(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C1,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=D1, W2=:=E1, X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, 
          C3=:=K1, D3=:=L1, E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, 
          J3=:=R1, K3=:=S1, L3=:=T1, M3=:=U1, N3=:=V1, O3=:=W1, P3=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4), 
          new235(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,C1,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=D1, W2=:=E1, X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, 
          C3=:=K1, D3=:=L1, E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, 
          J3=:=R1, K3=:=S1, L3=:=T1, M3=:=U1, N3=:=V1, O3=:=W1, P3=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4), 
          new235(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,C1,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=D1, W2=:=E1, X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, 
          C3=:=K1, D3=:=L1, E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, 
          J3=:=R1, K3=:=S1, L3=:=T1, M3=:=U1, N3=:=V1, O3=:=W1, P3=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4), 
          new235(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,C1,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=D1, W2=:=E1, X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, 
          C3=:=K1, D3=:=L1, E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, 
          J3=:=R1, K3=:=S1, L3=:=T1, M3=:=U1, N3=:=V1, O3=:=W1, P3=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4), 
          new235(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,C1,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=D1, M4=:=E1, N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, 
          S4=:=K1, T4=:=L1, U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, 
          Z4=:=R1, A5=:=S1, B5=:=T1, C5=:=U1, D5=:=V1, E5=:=W1, F5=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6), 
          new247(L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,A7,B7,C1,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=D1, M4=:=E1, N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, 
          S4=:=K1, T4=:=L1, U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, 
          Z4=:=R1, A5=:=S1, B5=:=T1, C5=:=U1, D5=:=V1, E5=:=W1, F5=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6), 
          new247(L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,A7,B7,C1,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=D1, M4=:=E1, N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, 
          S4=:=K1, T4=:=L1, U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, 
          Z4=:=R1, A5=:=S1, B5=:=T1, C5=:=U1, D5=:=V1, E5=:=W1, F5=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6), 
          new247(L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,A7,B7,C1,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=D1, M4=:=E1, N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, 
          S4=:=K1, T4=:=L1, U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, 
          Z4=:=R1, A5=:=S1, B5=:=T1, C5=:=U1, D5=:=V1, E5=:=W1, F5=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6), 
          new247(L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,A7,B7,C1,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new47(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new48(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new47(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new48(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new47(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new48(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new47(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=B1, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new48(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=B1, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=B1, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=B1, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=B1, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=B1, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=B1, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=B1, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=B1, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=:=W1, V1=:=U, W1=:=0, X1=:=1, Y1=:=1, Z1=:=A2-B2, A2=:=C2, B2=:=Q, 
          D2=:=0, E2=:=1, F2=:=1, 
          new363(Y1,B,X1,D,D2,F,G,H,I,J,K,L,M,N,O,P,Q,Z1,S,F2,E2,C2,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=:=W1, V1=:=U, W1=:=0, X1=:=1, Y1=:=1, Z1=:=A2-B2, A2=:=C2, B2=:=Q, 
          D2=:=0, E2=:=1, F2=:=1, 
          new364(Y1,B,X1,D,D2,F,G,H,I,J,K,L,M,N,O,P,Q,Z1,S,F2,E2,C2,G2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=E, S1=:=0, 
          new365(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=E, S1=:=0, 
          new365(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=E, S1=:=0, 
          new367(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=:=W1, V1=:=T, W1=:=0, X1=:=Y1-Z1, Y1=:=A2, Z1=:=P, B2=:=C2-D2, 
          C2=:=E2, D2=:=L, F2=:=G2-H2, G2=:=E2, H2=:=B2, 
          new388(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E2,F2,B2,R,X1,T,U,A2,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          E1>=F1+1, E1=:=A, F1=:=0, D1=:=0, G1=:=A, H1=:=B, I1=:=C, J1=:=D, 
          K1=:=D1, L1=:=F, M1=:=G, N1=:=H, O1=:=I, P1=:=J, Q1=:=K, R1=:=L, 
          S1=:=M, T1=:=N, U1=:=O, V1=:=P, W1=:=Q, X1=:=R, Y1=:=S, Z1=:=T, 
          A2=:=U, 
          new222(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,C1,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          E1+1=<F1, E1=:=A, F1=:=0, D1=:=0, G1=:=A, H1=:=B, I1=:=C, J1=:=D, 
          K1=:=D1, L1=:=F, M1=:=G, N1=:=H, O1=:=I, P1=:=J, Q1=:=K, R1=:=L, 
          S1=:=M, T1=:=N, U1=:=O, V1=:=P, W1=:=Q, X1=:=R, Y1=:=S, Z1=:=T, 
          A2=:=U, 
          new222(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,C1,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          D1=:=E1, D1=:=A, E1=:=0, F1=:=A, G1=:=B, H1=:=C, I1=:=D, J1=:=E, 
          K1=:=F, L1=:=G, M1=:=H, N1=:=I, O1=:=J, P1=:=K, Q1=:=L, R1=:=M, 
          S1=:=N, T1=:=O, U1=:=P, V1=:=Q, W1=:=R, X1=:=S, Y1=:=T, Z1=:=U, 
          new222(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C1,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=D1, X2=:=E1, Y2=:=F1, Z2=:=G1, A3=:=H1, B3=:=I1, 
          C3=:=J1, D3=:=K1, E3=:=L1, F3=:=M1, G3=:=N1, H3=:=O1, I3=:=P1, 
          J3=:=Q1, K3=:=R1, L3=:=S1, M3=:=T1, N3=:=U1, O3=:=V1, P3=:=W1, 
          Q3=:=X1, 
          new39(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4), 
          new235(W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,C1,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=D1, X2=:=E1, Y2=:=F1, Z2=:=G1, A3=:=H1, B3=:=I1, 
          C3=:=J1, D3=:=K1, E3=:=L1, F3=:=M1, G3=:=N1, H3=:=O1, I3=:=P1, 
          J3=:=Q1, K3=:=R1, L3=:=S1, M3=:=T1, N3=:=U1, O3=:=V1, P3=:=W1, 
          Q3=:=X1, 
          new41(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4), 
          new235(W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,C1,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=D1, X2=:=E1, Y2=:=F1, Z2=:=G1, A3=:=H1, B3=:=I1, 
          C3=:=J1, D3=:=K1, E3=:=L1, F3=:=M1, G3=:=N1, H3=:=O1, I3=:=P1, 
          J3=:=Q1, K3=:=R1, L3=:=S1, M3=:=T1, N3=:=U1, O3=:=V1, P3=:=W1, 
          Q3=:=X1, 
          new39(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4), 
          new235(W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,C1,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=D1, X2=:=E1, Y2=:=F1, Z2=:=G1, A3=:=H1, B3=:=I1, 
          C3=:=J1, D3=:=K1, E3=:=L1, F3=:=M1, G3=:=N1, H3=:=O1, I3=:=P1, 
          J3=:=Q1, K3=:=R1, L3=:=S1, M3=:=T1, N3=:=U1, O3=:=V1, P3=:=W1, 
          Q3=:=X1, 
          new41(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4), 
          new235(W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,C1,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=A, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=D1, W2=:=E1, X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, 
          C3=:=K1, D3=:=L1, E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, 
          J3=:=R1, K3=:=S1, L3=:=T1, M3=:=U1, N3=:=V1, O3=:=W1, P3=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4), 
          new235(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,C1,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=A, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=D1, W2=:=E1, X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, 
          C3=:=K1, D3=:=L1, E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, 
          J3=:=R1, K3=:=S1, L3=:=T1, M3=:=U1, N3=:=V1, O3=:=W1, P3=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4), 
          new235(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,C1,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=D1, N4=:=E1, O4=:=F1, P4=:=G1, Q4=:=H1, R4=:=I1, 
          S4=:=J1, T4=:=K1, U4=:=L1, V4=:=M1, W4=:=N1, X4=:=O1, Y4=:=P1, 
          Z4=:=Q1, A5=:=R1, B5=:=S1, C5=:=T1, D5=:=U1, E5=:=V1, F5=:=W1, 
          G5=:=X1, 
          new39(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7), 
          new247(M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,B7,C7,C1,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=D1, N4=:=E1, O4=:=F1, P4=:=G1, Q4=:=H1, R4=:=I1, 
          S4=:=J1, T4=:=K1, U4=:=L1, V4=:=M1, W4=:=N1, X4=:=O1, Y4=:=P1, 
          Z4=:=Q1, A5=:=R1, B5=:=S1, C5=:=T1, D5=:=U1, E5=:=V1, F5=:=W1, 
          G5=:=X1, 
          new41(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7), 
          new247(M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,B7,C7,C1,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=D1, N4=:=E1, O4=:=F1, P4=:=G1, Q4=:=H1, R4=:=I1, 
          S4=:=J1, T4=:=K1, U4=:=L1, V4=:=M1, W4=:=N1, X4=:=O1, Y4=:=P1, 
          Z4=:=Q1, A5=:=R1, B5=:=S1, C5=:=T1, D5=:=U1, E5=:=V1, F5=:=W1, 
          G5=:=X1, 
          new39(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7), 
          new247(M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,B7,C7,C1,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=D1, N4=:=E1, O4=:=F1, P4=:=G1, Q4=:=H1, R4=:=I1, 
          S4=:=J1, T4=:=K1, U4=:=L1, V4=:=M1, W4=:=N1, X4=:=O1, Y4=:=P1, 
          Z4=:=Q1, A5=:=R1, B5=:=S1, C5=:=T1, D5=:=U1, E5=:=V1, F5=:=W1, 
          G5=:=X1, 
          new41(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7), 
          new247(M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,B7,C7,C1,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=A, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=D1, M4=:=E1, N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, 
          S4=:=K1, T4=:=L1, U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, 
          Z4=:=R1, A5=:=S1, B5=:=T1, C5=:=U1, D5=:=V1, E5=:=W1, F5=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6), 
          new247(L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,A7,B7,C1,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=A, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=D1, M4=:=E1, N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, 
          S4=:=K1, T4=:=L1, U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, 
          Z4=:=R1, A5=:=S1, B5=:=T1, C5=:=U1, D5=:=V1, E5=:=W1, F5=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6), 
          new247(L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,A7,B7,C1,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D1, D6=:=E1, E6=:=F1, F6=:=G1, G6=:=H1, H6=:=I1, 
          I6=:=J1, J6=:=K1, K6=:=L1, L6=:=M1, M6=:=N1, N6=:=O1, O6=:=P1, 
          P6=:=Q1, Q6=:=R1, R6=:=S1, S6=:=T1, T6=:=U1, U6=:=V1, V6=:=W1, 
          W6=:=X1, 
          new39(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8), 
          new47(M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9), 
          new235(C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,C1,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D1, D6=:=E1, E6=:=F1, F6=:=G1, G6=:=H1, H6=:=I1, 
          I6=:=J1, J6=:=K1, K6=:=L1, L6=:=M1, M6=:=N1, N6=:=O1, O6=:=P1, 
          P6=:=Q1, Q6=:=R1, R6=:=S1, S6=:=T1, T6=:=U1, U6=:=V1, V6=:=W1, 
          W6=:=X1, 
          new39(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8), 
          new48(M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9), 
          new235(C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,C1,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D1, D6=:=E1, E6=:=F1, F6=:=G1, G6=:=H1, H6=:=I1, 
          I6=:=J1, J6=:=K1, K6=:=L1, L6=:=M1, M6=:=N1, N6=:=O1, O6=:=P1, 
          P6=:=Q1, Q6=:=R1, R6=:=S1, S6=:=T1, T6=:=U1, U6=:=V1, V6=:=W1, 
          W6=:=X1, 
          new41(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8), 
          new47(M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9), 
          new235(C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,C1,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1>=Z1+1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D1, D6=:=E1, E6=:=F1, F6=:=G1, G6=:=H1, H6=:=I1, 
          I6=:=J1, J6=:=K1, K6=:=L1, L6=:=M1, M6=:=N1, N6=:=O1, O6=:=P1, 
          P6=:=Q1, Q6=:=R1, R6=:=S1, S6=:=T1, T6=:=U1, U6=:=V1, V6=:=W1, 
          W6=:=X1, 
          new41(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8), 
          new48(M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9), 
          new235(C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,C1,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D1, D6=:=E1, E6=:=F1, F6=:=G1, G6=:=H1, H6=:=I1, 
          I6=:=J1, J6=:=K1, K6=:=L1, L6=:=M1, M6=:=N1, N6=:=O1, O6=:=P1, 
          P6=:=Q1, Q6=:=R1, R6=:=S1, S6=:=T1, T6=:=U1, U6=:=V1, V6=:=W1, 
          W6=:=X1, 
          new39(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8), 
          new47(M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9), 
          new235(C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,C1,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D1, D6=:=E1, E6=:=F1, F6=:=G1, G6=:=H1, H6=:=I1, 
          I6=:=J1, J6=:=K1, K6=:=L1, L6=:=M1, M6=:=N1, N6=:=O1, O6=:=P1, 
          P6=:=Q1, Q6=:=R1, R6=:=S1, S6=:=T1, T6=:=U1, U6=:=V1, V6=:=W1, 
          W6=:=X1, 
          new39(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8), 
          new48(M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9), 
          new235(C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,C1,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D1, D6=:=E1, E6=:=F1, F6=:=G1, G6=:=H1, H6=:=I1, 
          I6=:=J1, J6=:=K1, K6=:=L1, L6=:=M1, M6=:=N1, N6=:=O1, O6=:=P1, 
          P6=:=Q1, Q6=:=R1, R6=:=S1, S6=:=T1, T6=:=U1, U6=:=V1, V6=:=W1, 
          W6=:=X1, 
          new41(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8), 
          new47(M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9), 
          new235(C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,C1,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1+1=<Z1, Y1=:=A, Z1=:=0, A2=:=0, B2=:=A, C2=:=B, D2=:=C, E2=:=D, 
          F2=:=A2, G2=:=F, H2=:=G, I2=:=H, J2=:=I, K2=:=J, L2=:=K, M2=:=L, 
          N2=:=M, O2=:=N, P2=:=O, Q2=:=P, R2=:=Q, S2=:=R, T2=:=S, U2=:=T, 
          V2=:=U, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D1, D6=:=E1, E6=:=F1, F6=:=G1, G6=:=H1, H6=:=I1, 
          I6=:=J1, J6=:=K1, K6=:=L1, L6=:=M1, M6=:=N1, N6=:=O1, O6=:=P1, 
          P6=:=Q1, Q6=:=R1, R6=:=S1, S6=:=T1, T6=:=U1, U6=:=V1, V6=:=W1, 
          W6=:=X1, 
          new41(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7), 
          new43(W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8), 
          new48(M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9), 
          new235(C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,C1,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=A, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new47(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=A, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new48(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=A, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new47(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=A, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new48(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=A, G2=:=0, H2=:=0, I2=:=A, J2=:=B, K2=:=C, L2=:=D, 
          M2=:=H2, N2=:=F, O2=:=G, P2=:=H, Q2=:=I, R2=:=J, S2=:=K, T2=:=L, 
          U2=:=M, V2=:=N, W2=:=O, X2=:=P, Y2=:=Q, Z2=:=R, A3=:=S, B3=:=T, 
          C3=:=U, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          X7=:=Y7, 
          new39(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8), 
          new43(D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,R4,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9), 
          new47(T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,H6,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10), 
          new43(J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,X7,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11), 
          new265(N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,H12,V,W,X,Y,Z,A1,I12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=A, G2=:=0, H2=:=0, I2=:=A, J2=:=B, K2=:=C, L2=:=D, 
          M2=:=H2, N2=:=F, O2=:=G, P2=:=H, Q2=:=I, R2=:=J, S2=:=K, T2=:=L, 
          U2=:=M, V2=:=N, W2=:=O, X2=:=P, Y2=:=Q, Z2=:=R, A3=:=S, B3=:=T, 
          C3=:=U, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          X7=:=Y7, 
          new39(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8), 
          new43(D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,R4,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9), 
          new48(T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,H6,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10), 
          new43(J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,X7,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11), 
          new265(N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,H12,V,W,X,Y,Z,A1,I12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=A, G2=:=0, H2=:=0, I2=:=A, J2=:=B, K2=:=C, L2=:=D, 
          M2=:=H2, N2=:=F, O2=:=G, P2=:=H, Q2=:=I, R2=:=J, S2=:=K, T2=:=L, 
          U2=:=M, V2=:=N, W2=:=O, X2=:=P, Y2=:=Q, Z2=:=R, A3=:=S, B3=:=T, 
          C3=:=U, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          X7=:=Y7, 
          new41(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8), 
          new43(D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,R4,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9), 
          new47(T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,H6,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10), 
          new43(J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,X7,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11), 
          new265(N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,H12,V,W,X,Y,Z,A1,I12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=A, G2=:=0, H2=:=0, I2=:=A, J2=:=B, K2=:=C, L2=:=D, 
          M2=:=H2, N2=:=F, O2=:=G, P2=:=H, Q2=:=I, R2=:=J, S2=:=K, T2=:=L, 
          U2=:=M, V2=:=N, W2=:=O, X2=:=P, Y2=:=Q, Z2=:=R, A3=:=S, B3=:=T, 
          C3=:=U, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          X7=:=Y7, 
          new41(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8), 
          new43(D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,R4,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9), 
          new48(T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,H6,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10), 
          new43(J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,X7,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11), 
          new265(N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,H12,V,W,X,Y,Z,A1,I12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=A, G2=:=0, H2=:=0, I2=:=A, J2=:=B, K2=:=C, L2=:=D, 
          M2=:=H2, N2=:=F, O2=:=G, P2=:=H, Q2=:=I, R2=:=J, S2=:=K, T2=:=L, 
          U2=:=M, V2=:=N, W2=:=O, X2=:=P, Y2=:=Q, Z2=:=R, A3=:=S, B3=:=T, 
          C3=:=U, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          X7=:=Y7, 
          new39(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8), 
          new43(D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,R4,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9), 
          new47(T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,H6,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10), 
          new43(J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,X7,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11), 
          new265(N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,H12,V,W,X,Y,Z,A1,I12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=A, G2=:=0, H2=:=0, I2=:=A, J2=:=B, K2=:=C, L2=:=D, 
          M2=:=H2, N2=:=F, O2=:=G, P2=:=H, Q2=:=I, R2=:=J, S2=:=K, T2=:=L, 
          U2=:=M, V2=:=N, W2=:=O, X2=:=P, Y2=:=Q, Z2=:=R, A3=:=S, B3=:=T, 
          C3=:=U, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          X7=:=Y7, 
          new39(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8), 
          new43(D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,R4,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9), 
          new48(T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,H6,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10), 
          new43(J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,X7,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11), 
          new265(N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,H12,V,W,X,Y,Z,A1,I12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=A, G2=:=0, H2=:=0, I2=:=A, J2=:=B, K2=:=C, L2=:=D, 
          M2=:=H2, N2=:=F, O2=:=G, P2=:=H, Q2=:=I, R2=:=J, S2=:=K, T2=:=L, 
          U2=:=M, V2=:=N, W2=:=O, X2=:=P, Y2=:=Q, Z2=:=R, A3=:=S, B3=:=T, 
          C3=:=U, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          X7=:=Y7, 
          new41(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8), 
          new43(D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,R4,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9), 
          new47(T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,H6,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10), 
          new43(J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,X7,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11), 
          new265(N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,H12,V,W,X,Y,Z,A1,I12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=A, G2=:=0, H2=:=0, I2=:=A, J2=:=B, K2=:=C, L2=:=D, 
          M2=:=H2, N2=:=F, O2=:=G, P2=:=H, Q2=:=I, R2=:=J, S2=:=K, T2=:=L, 
          U2=:=M, V2=:=N, W2=:=O, X2=:=P, Y2=:=Q, Z2=:=R, A3=:=S, B3=:=T, 
          C3=:=U, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          X7=:=Y7, 
          new41(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8), 
          new43(D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,R4,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9), 
          new48(T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,H6,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10), 
          new43(J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,X7,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11), 
          new265(N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,H12,V,W,X,Y,Z,A1,I12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=A, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=A, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=A, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=A, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=C, G2=:=0, 
          new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=C, G2=:=0, 
          new220(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          D1=:=E1, D1=:=C, E1=:=0, F1=:=A, G1=:=B, H1=:=C, I1=:=D, J1=:=E, 
          K1=:=F, L1=:=G, M1=:=H, N1=:=I, O1=:=J, P1=:=K, Q1=:=L, R1=:=M, 
          S1=:=N, T1=:=O, U1=:=P, V1=:=Q, W1=:=R, X1=:=S, Y1=:=T, Z1=:=U, 
          new222(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C1,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=C, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=D1, W2=:=E1, X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, 
          C3=:=K1, D3=:=L1, E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, 
          J3=:=R1, K3=:=S1, L3=:=T1, M3=:=U1, N3=:=V1, O3=:=W1, P3=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4), 
          new235(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,C1,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=C, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=D1, W2=:=E1, X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, 
          C3=:=K1, D3=:=L1, E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, 
          J3=:=R1, K3=:=S1, L3=:=T1, M3=:=U1, N3=:=V1, O3=:=W1, P3=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4), 
          new235(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,C1,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=C, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=D1, M4=:=E1, N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, 
          S4=:=K1, T4=:=L1, U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, 
          Z4=:=R1, A5=:=S1, B5=:=T1, C5=:=U1, D5=:=V1, E5=:=W1, F5=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6), 
          new247(L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,A7,B7,C1,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=C, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=D1, M4=:=E1, N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, 
          S4=:=K1, T4=:=L1, U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, 
          Z4=:=R1, A5=:=S1, B5=:=T1, C5=:=U1, D5=:=V1, E5=:=W1, F5=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6), 
          new247(L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,A7,B7,C1,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=C, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new47(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=C, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new39(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new48(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=C, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new47(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,V,W,X,Y,Z,A1,B1) :- 
          Y1=:=Z1, Y1=:=C, Z1=:=0, A2=:=A, B2=:=B, C2=:=C, D2=:=D, E2=:=E, 
          F2=:=F, G2=:=G, H2=:=H, I2=:=I, J2=:=J, K2=:=K, L2=:=L, M2=:=M, 
          N2=:=N, O2=:=O, P2=:=P, Q2=:=Q, R2=:=R, S2=:=S, T2=:=T, U2=:=U, 
          V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, 
          J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, 
          X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, 
          L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, 
          N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, 
          B6=:=D1, C6=:=E1, D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, 
          I6=:=K1, J6=:=L1, K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, 
          P6=:=R1, Q6=:=S1, R6=:=T1, S6=:=U1, T6=:=V1, U6=:=W1, V6=:=X1, 
          new41(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7), 
          new43(V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8), 
          new48(L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9), 
          new235(B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,C1,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=C, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=C, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=C, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=C, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, L2=:=E, 
          M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, T2=:=M, 
          U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, B3=:=U, 
          C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, 
          Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, 
          E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, 
          S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, 
          G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, 
          U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, 
          I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, 
          W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new265(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=D, G2=:=0, H2=:=0, 
          new219(A,B,C,H2,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=D, G2=:=0, H2=:=0, 
          new219(A,B,C,H2,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=D, G2=:=0, 
          new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=C, G2=:=0, 
          new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=C, G2=:=0, 
          new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=C, G2=:=0, 
          new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=A1, G2=:=0, H2=:=1, 
          new214(A,B,H2,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=A1, G2=:=0, H2=:=1, 
          new214(A,B,H2,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=A1, G2=:=0, 
          new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=Z, G2=:=0, H2=:=1, 
          new211(A,B,C,H2,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=Z, G2=:=0, H2=:=1, 
          new211(A,B,C,H2,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=Z, G2=:=0, 
          new211(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=Y, G2=:=0, H2=:=1, 
          new208(A,B,C,D,E,F,G,H,I,J,K,L,M,H2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=Y, G2=:=0, H2=:=1, 
          new208(A,B,C,D,E,F,G,H,I,J,K,L,M,H2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=Y, G2=:=0, 
          new208(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=X, G2=:=0, H2=:=0, 
          new205(A,B,C,D,H2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=X, G2=:=0, H2=:=0, 
          new205(A,B,C,D,H2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=X, G2=:=0, 
          new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=W, G2=:=0, H2=:=1, 
          new202(H2,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=W, G2=:=0, H2=:=1, 
          new202(H2,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=W, G2=:=0, 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1>=V1+1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new132(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1>=V1+1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new133(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,B2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=<V1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new132(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=<V1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new133(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,B2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X>=Y+1, X=:=W, Y=:=0.
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X+1=<Y, X=:=W, Y=:=0.
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X=:=Y, X=:=W, Y=:=0.
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1>=V1+1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new127(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1>=V1+1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new128(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,B2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=<V1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new127(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=<V1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new128(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,B2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V>=W+1, V=:=C, W=:=0.
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V+1=<W, V=:=C, W=:=0.
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V=:=W, V=:=C, W=:=0.
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,W,X,Y,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U) :- 
          A1>=B1+1, A1=:=C, B1=:=0, Y=:=0, V=:=1, W=:=0, X=:=0, Z=:=Q.
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,W,X,Y,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U) :- 
          A1+1=<B1, A1=:=C, B1=:=0, Y=:=0, V=:=1, W=:=0, X=:=0, Z=:=Q.
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,W,X,Y,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U) :- 
          A1=:=B1, A1=:=C, B1=:=0, Y=:=0, V=:=1, W=:=0, X=:=0, Z=:=Q.
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,V,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          X>=Y+1, X=:=C, Y=:=0, V=:=1, W=:=1.
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,V,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          X+1=<Y, X=:=C, Y=:=0, V=:=1, W=:=1.
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,V,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          X=:=Y, X=:=C, Y=:=0, V=:=1, W=:=1.
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V>=W+1, V=:=N, W=:=0.
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V+1=<W, V=:=N, W=:=0.
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=N, R1=:=0, S1=:=0, T1=:=0, 
          new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T1,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=N, R1=:=0, S1=:=0, T1=:=1, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=N, R1=:=0, S1=:=0, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=N, R1=:=0, S1=:=0, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=I, R1=:=G, 
          new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1, Q1=:=I, R1=:=G, S1=:=0, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=N, R1=:=0, S1=:=0, T1=:=1, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,S1,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=N, R1=:=0, S1=:=0, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=N, R1=:=0, S1=:=0, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=I, R1=:=G, 
          new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=<R1, Q1=:=I, R1=:=G, 
          new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=B, R1=:=0, S1=:=1, T1=:=1, 
          new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T1,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=B, R1=:=0, S1=:=1, T1=:=1, 
          new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T1,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=B, R1=:=0, S1=:=0, T1=:=0, U1=:=1, 
          new125(A,U1,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T1,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W,U) :- 
          X>=Y+1, X=:=A, Y=:=0, V=:=0, W=:=0.
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W,U) :- 
          X+1=<Y, X=:=A, Y=:=0, V=:=0, W=:=0.
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,V,W,X,F,G,H,I,J,K,L,M,N,Y,Z,A1,R,B1,C1,U) :- 
          D1=:=E1, D1=:=A, E1=:=0, C1=:=1, W=:=0, X=:=1, V=:=0, B1=:=P, 
          A1=:=F1-G1, F1=:=Y, G1=:=L, Z=:=H1-I1, H1=:=Y, I1=:=A1.
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W,U) :- 
          X>=Y+1, X=:=A, Y=:=0, V=:=0, W=:=0.
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W,U) :- 
          X+1=<Y, X=:=A, Y=:=0, V=:=0, W=:=0.
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,V,W,X,F,G,H,I,J,K,L,M,N,Y,Z,A1,R,B1,C1,U) :- 
          D1=:=E1, D1=:=A, E1=:=0, C1=:=1, V=:=0, W=:=0, X=:=1, B1=:=P, 
          A1=:=F1-G1, F1=:=Y, G1=:=L, Z=:=H1-I1, H1=:=Y, I1=:=A1.
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=C, R1=:=0, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=C, R1=:=0, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=C, R1=:=0, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=D, R1=:=0, 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=D, R1=:=0, 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=D, R1=:=0, 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X>=Y+1, X=:=W, Y=:=0.
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X+1=<Y, X=:=W, Y=:=0.
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X=:=Y, X=:=W, Y=:=0.
new41(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=T, V1=:=0, W1=:=X1-Y1, X1=:=Z1, Y1=:=P, A2=:=B2-C2, 
          B2=:=D2, C2=:=L, E2=:=F2-G2, F2=:=D2, G2=:=A2, 
          new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D2,E2,A2,R,W1,T,U,Z1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=U, V1=:=0, W1=:=1, X1=:=1, Y1=:=Z1-A2, Z1=:=B2, A2=:=Q, 
          C2=:=0, D2=:=1, E2=:=1, 
          new99(X1,B,W1,D,C2,F,G,H,I,J,K,L,M,N,O,P,Q,Y1,S,E2,D2,B2,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=U, V1=:=0, W1=:=1, X1=:=1, Y1=:=Z1-A2, Z1=:=B2, A2=:=Q, 
          C2=:=0, D2=:=1, E2=:=1, 
          new100(X1,B,W1,D,C2,F,G,H,I,J,K,L,M,N,O,P,Q,Y1,S,E2,D2,B2,F2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          C1=:=D1, C1=:=B1, D1=:=0.
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=B1, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new39(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new47(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=B1, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new39(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new48(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=B1, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new41(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new47(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=B1, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new41(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new48(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=B1, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new39(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new47(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=B1, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new39(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new48(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=B1, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new41(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new47(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=B1, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new41(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new48(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X>=Y+1, X=:=U, Y=:=0.
new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X+1=<Y, X=:=U, Y=:=0.
new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=U, V1=:=0, W1=:=1, X1=:=1, Y1=:=Z1-A2, Z1=:=B2, A2=:=Q, 
          C2=:=0, D2=:=1, E2=:=1, 
          new101(X1,B,W1,D,C2,F,G,H,I,J,K,L,M,N,O,P,Q,Y1,S,E2,D2,B2,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=U, V1=:=0, W1=:=1, X1=:=1, Y1=:=Z1-A2, Z1=:=B2, A2=:=Q, 
          C2=:=0, D2=:=1, E2=:=1, 
          new102(X1,B,W1,D,C2,F,G,H,I,J,K,L,M,N,O,P,Q,Y1,S,E2,D2,B2,F2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=E, R1=:=0, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=E, R1=:=0, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=E, R1=:=0, 
          new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X>=Y+1, X=:=T, Y=:=0.
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X+1=<Y, X=:=T, Y=:=0.
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=T, V1=:=0, W1=:=X1-Y1, X1=:=Z1, Y1=:=P, A2=:=B2-C2, 
          B2=:=D2, C2=:=L, E2=:=F2-G2, F2=:=D2, G2=:=A2, 
          new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D2,E2,A2,R,W1,T,U,Z1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=A, F2=:=0, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, 
          L2=:=G2, M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, 
          T2=:=M, U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, 
          B3=:=U, C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, 
          O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, 
          C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, 
          Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, 
          E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, 
          S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, 
          G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, 
          U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, 
          I7=:=J7, K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, 
          W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new55(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=A, F2=:=0, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, 
          L2=:=G2, M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, 
          T2=:=M, U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, 
          B3=:=U, C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, 
          O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, 
          C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, 
          Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, 
          E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, 
          S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, 
          G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, 
          U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, 
          I7=:=J7, K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, 
          W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new55(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=A, F2=:=0, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, 
          L2=:=G2, M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, 
          T2=:=M, U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, 
          B3=:=U, C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, 
          O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, 
          C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, 
          Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, 
          E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, 
          S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, 
          G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, 
          U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, 
          I7=:=J7, K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, 
          W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new55(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=A, F2=:=0, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, 
          L2=:=G2, M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, 
          T2=:=M, U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, 
          B3=:=U, C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, 
          O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, 
          C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, 
          Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, 
          E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, 
          S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, 
          G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, 
          U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, 
          I7=:=J7, K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, 
          W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new55(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=A, F2=:=0, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, 
          L2=:=G2, M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, 
          T2=:=M, U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, 
          B3=:=U, C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, 
          O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, 
          C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, 
          Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, 
          E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, 
          S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, 
          G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, 
          U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, 
          I7=:=J7, K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, 
          W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new55(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=A, F2=:=0, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, 
          L2=:=G2, M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, 
          T2=:=M, U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, 
          B3=:=U, C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, 
          O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, 
          C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, 
          Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, 
          E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, 
          S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, 
          G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, 
          U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, 
          I7=:=J7, K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, 
          W7=:=X7, 
          new39(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new55(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=A, F2=:=0, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, 
          L2=:=G2, M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, 
          T2=:=M, U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, 
          B3=:=U, C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, 
          O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, 
          C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, 
          Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, 
          E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, 
          S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, 
          G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, 
          U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, 
          I7=:=J7, K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, 
          W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new47(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new55(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=A, F2=:=0, G2=:=0, H2=:=A, I2=:=B, J2=:=C, K2=:=D, 
          L2=:=G2, M2=:=F, N2=:=G, O2=:=H, P2=:=I, Q2=:=J, R2=:=K, S2=:=L, 
          T2=:=M, U2=:=N, V2=:=O, W2=:=P, X2=:=Q, Y2=:=R, Z2=:=S, A3=:=T, 
          B3=:=U, C3=:=D3, E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, 
          O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, 
          C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, 
          Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, 
          E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, 
          S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, 
          G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, 
          U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, 
          I7=:=J7, K7=:=L7, M7=:=N7, O7=:=P7, Q7=:=R7, S7=:=T7, U7=:=V7, 
          W7=:=X7, 
          new41(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8), 
          new43(C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,O4,Q4,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9), 
          new48(S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,W5,Y5,A6,C6,E6,G6,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10), 
          new43(I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,M7,O7,Q7,S7,U7,W7,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11), 
          new55(M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,G12,V,W,X,Y,Z,A1,H12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=A, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new39(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new47(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=A, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new39(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new48(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=A, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new41(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new47(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=A, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new41(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new48(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=C, F2=:=0, 
          new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=C, F2=:=0, 
          new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=C, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new39(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new47(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=C, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new39(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new48(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=C, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new41(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new47(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=C, F2=:=0, G2=:=A, H2=:=B, I2=:=C, J2=:=D, K2=:=E, 
          L2=:=F, M2=:=G, N2=:=H, O2=:=I, P2=:=J, Q2=:=K, R2=:=L, S2=:=M, 
          T2=:=N, U2=:=O, V2=:=P, W2=:=Q, X2=:=R, Y2=:=S, Z2=:=T, A3=:=U, 
          B3=:=C3, D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, 
          P3=:=Q3, R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, 
          D4=:=E4, F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, 
          R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, 
          F5=:=G5, H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, 
          T5=:=U5, V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, 
          H6=:=I6, J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, 
          V6=:=W6, X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          J7=:=K7, L7=:=M7, N7=:=O7, P7=:=Q7, R7=:=S7, T7=:=U7, V7=:=W7, 
          new41(G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8), 
          new43(B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,F4,H4,J4,L4,N4,P4,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9), 
          new48(R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,V5,X5,Z5,B6,D6,F6,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10), 
          new43(H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,L7,N7,P7,R7,T7,V7,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11), 
          new55(L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W11,X11,Y11,Z11,A12,B12,C12,D12,E12,F12,V,W,X,Y,Z,A1,G12,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=D, F2=:=0, G2=:=0, 
          new36(A,B,C,G2,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=D, F2=:=0, G2=:=0, 
          new36(A,B,C,G2,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=D, F2=:=0, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=C, F2=:=0, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=C, F2=:=0, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=C, F2=:=0, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=A1, F2=:=0, G2=:=1, 
          new31(A,B,G2,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=A1, F2=:=0, G2=:=1, 
          new31(A,B,G2,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=A1, F2=:=0, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=Z, F2=:=0, G2=:=1, 
          new28(A,B,C,G2,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=Z, F2=:=0, G2=:=1, 
          new28(A,B,C,G2,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=Z, F2=:=0, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=Y, F2=:=0, G2=:=1, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,G2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=Y, F2=:=0, G2=:=1, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,G2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=Y, F2=:=0, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=X, F2=:=0, G2=:=0, 
          new22(A,B,C,D,G2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=X, F2=:=0, G2=:=0, 
          new22(A,B,C,D,G2,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=X, F2=:=0, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=W, F2=:=0, G2=:=1, 
          new19(G2,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=W, F2=:=0, G2=:=1, 
          new19(G2,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=W, F2=:=0, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,92,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=A1, G2=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=A1, G2=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=Z, G2=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=Z, G2=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2>=F2+1, E2=:=V, F2=:=0, G2=:=1, 
          new16(A,G2,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2+1=<F2, E2=:=V, F2=:=0, G2=:=1, 
          new16(A,G2,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2) :- 
          E2=:=F2, E2=:=V, F2=:=0, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=V, G2=:=0, H2=:=1, 
          new199(A,H2,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=V, G2=:=0, H2=:=1, 
          new199(A,H2,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=G2, F2=:=V, G2=:=0, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1) :- 
          Y1=:=A, Z1=:=A, A2=:=R, B2=:=R, C2=:=D2-E2, D2=:=A, E2=:=R, 
          F2=:=G2-H2, G2=:=A, H2=:=R, I2=:=B, J2=:=C, K2=:=L2-M2, L2=:=I2, 
          M2=:=J2, N2=:=D, O2=:=E, P2=:=F, 
          new537(A,B,C,D,E,F,G,H,I,J,K,Y1,O2,N2,P2,I2,J2,K2,S,T,Z1,A2,C2,F2,B2,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1) :- 
          Z1=:=A, A2=:=A, B2=:=R, C2=:=R, D2=:=E2-F2, E2=:=A, F2=:=R, 
          G2=:=H2-I2, H2=:=A, I2=:=R, J2=:=B, K2=:=C, L2=:=M2-N2, M2=:=J2, 
          N2=:=K2, O2=:=D, P2=:=E, Q2=:=F, 
          new538(A,B,C,D,E,F,G,H,I,J,K,Z1,P2,O2,Q2,J2,K2,L2,S,T,A2,B2,D2,G2,C2,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,F,G,H,I,J,K,L,M,I1,O,P,Q,R,S,T,U,V,W,X,Y,J1,K1,B1) :- 
          F1=:=0, E1=:=0, D1=:=0, H1=:=1, G1=:=0, I1=:=0, J1=:=0, K1=:=0, 
          L1=:=T, M1=:=U, N1=:=V, O1=:=W, P1=:=X, Q1=:=Y, R1=:=D1, S1=:=E1, 
          T1=:=F1, U1=:=G1, V1=:=H1, W1=:=F, X1=:=G, Y1=:=H, Z1=:=I, A2=:=J, 
          B2=:=K, C2=:=L, D2=:=M, E2=:=I1, F2=:=O, G2=:=P, H2=:=Q, I2=:=R, 
          J2=:=S, 
          new3(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,C1,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,T,U,V,W,X,Y,W1,X1,Y1) :- 
          Z1=:=0, A2=:=0, B2=:=0, C2=:=1, D2=:=0, E2=:=0, W1=:=0, X1=:=0, 
          F2=:=T, G2=:=U, H2=:=V, I2=:=W, J2=:=X, K2=:=Y, L2=:=B2, M2=:=A2, 
          N2=:=Z1, O2=:=D2, P2=:=C2, Q2=:=F, R2=:=G, S2=:=H, T2=:=I, U2=:=J, 
          V2=:=K, W2=:=L, X2=:=M, Y2=:=E2, Z2=:=O, A3=:=P, B3=:=Q, C3=:=R, 
          D3=:=S, Y1=:=P1, E3=:=D1, F3=:=E1, G3=:=F1, H3=:=G1, I3=:=H1, 
          J3=:=I1, K3=:=J1, L3=:=K1, M3=:=L1, N3=:=M1, O3=:=N1, P3=:=O1, 
          Q3=:=P1, R3=:=Q1, S3=:=R1, T3=:=S1, U3=:=T1, V3=:=U1, W3=:=V1, 
          X3=:=W1, Y3=:=X1, 
          new4(F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4), 
          new7(E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Y4,Z4,A5,B5,C5,D5,E5,C1,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=0, G2=:=0, H2=:=0, I2=:=1, J2=:=0, K2=:=0, L2=:=0, M2=:=0, 
          N2=:=T, O2=:=U, P2=:=V, Q2=:=W, R2=:=X, S2=:=Y, T2=:=H2, U2=:=G2, 
          V2=:=F2, W2=:=J2, X2=:=I2, Y2=:=F, Z2=:=G, A3=:=H, B3=:=I, C3=:=J, 
          D3=:=K, E3=:=L, F3=:=M, G3=:=K2, H3=:=O, I3=:=P, J3=:=Q, K3=:=R, 
          L3=:=S, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, 
          Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, 
          M4=:=N3, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=L2, A5=:=M2, 
          new4(N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5), 
          new8(O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,N4,P4,R4,T4,V4,X4,Z4,A5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7), 
          new10(J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,T,U,V,W,X,Y,C8,M2,M3,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=0, G2=:=0, H2=:=0, I2=:=1, J2=:=0, K2=:=0, L2=:=0, M2=:=0, 
          N2=:=T, O2=:=U, P2=:=V, Q2=:=W, R2=:=X, S2=:=Y, T2=:=H2, U2=:=G2, 
          V2=:=F2, W2=:=J2, X2=:=I2, Y2=:=F, Z2=:=G, A3=:=H, B3=:=I, C3=:=J, 
          D3=:=K, E3=:=L, F3=:=M, G3=:=K2, H3=:=O, I3=:=P, J3=:=Q, K3=:=R, 
          L3=:=S, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, 
          Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, 
          M4=:=N3, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=L2, A5=:=M2, 
          new4(N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5), 
          new8(O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,N4,P4,R4,T4,V4,X4,Z4,A5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7), 
          new11(J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,T,U,V,W,X,Y,C8,D8,M3,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new1 :- 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
correct :- \+new1.
