new8(A,B,C,D,16,A,B,C,D).
new6(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=B, K=:=0, L=:=M-N, M=:=D, N=:=1, 
          O=:=P-Q, P=:=B, Q=:=1, new5(A,O,C,L,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=B, K=:=0, new8(A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, new6(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=A, L=:=M+N, M=:=C, N=:=1, 
          O=:=P+Q, P=:=B, Q=:=1, new3(A,O,L,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=A, L=:=A, new5(A,B,C,L,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=0, K=:=0, new3(A,J,K,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
