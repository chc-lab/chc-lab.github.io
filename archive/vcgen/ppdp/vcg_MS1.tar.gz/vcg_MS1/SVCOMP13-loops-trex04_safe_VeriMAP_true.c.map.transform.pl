new31(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new32(N,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new32(N,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, 
          new32(A,B,C,D,E,F,G,H,I,J,K).
new28(A,B,C,D,E,F,B,C,D,E) :- G>=H+1, G=:=D, H=:=0, F=:=I-J, I=:=A, J=:=1.
new28(A,B,C,D,E,F,B,C,D,E) :- G+1=<H, G=:=D, H=:=0, F=:=I-J, I=:=A, J=:=1.
new28(A,B,C,D,E,F,B,C,D,E) :- G=:=H, G=:=D, H=:=0, F=:=I+J, I=:=A, J=:=10.
new27(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=A, O=:=1, 
          new28(M,B,C,D,E,F,G,H,I,J).
new27(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=B, L=:=0, M=:=N+O, N=:=A, O=:=1, 
          new28(M,B,C,D,E,F,G,H,I,J).
new27(A,B,C,D,E,F,G,H,I,J) :- K=:=L, K=:=B, L=:=0, new28(A,B,C,D,E,F,G,H,I,J).
new26(A,B,C,D,E,F,G,H,26,A,B,C,D,E,F,G,H).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=B, S=:=0, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=B, S=:=0, T=:=U-V, 
          U=:=B, V=:=A, new21(A,T,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=<S, R=:=B, S=:=0, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=E, S=:=0, T=:=U-V, 
          U=:=A, V=:=1, new21(T,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=E, S=:=0, T=:=U-V, 
          U=:=A, V=:=1, new21(T,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=E, S=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new8(A,B,C,D,E,F,G,H,I,J) :- K=:=0, L=:=M, N=:=O, new27(K,L,M,N,O,F,G,H,I,J).
new11(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H) :- J>=K+1, J=:=C, K=:=0, 
          new7(L,M,N,O,P,I,Q,R,S,T,U).
new11(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H) :- J+1=<K, J=:=C, K=:=0, 
          new7(L,M,N,O,P,I,Q,R,S,T,U).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=C, S=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=C, S=:=0, 
          new8(T,U,V,W,X,Y,Z,A1,B1,C1), 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=C, S=:=0, 
          new8(T,U,V,W,X,Y,Z,A1,B1,C1), 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=N, O=:=P, 
          new31(L,M,N,O,P,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H) :- J>=K+1, J=:=E, K=:=0, 
          new7(L,M,N,O,P,I,Q,R,S,T,U).
new4(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H) :- J+1=<K, J=:=E, K=:=0, 
          new7(L,M,N,O,P,I,Q,R,S,T,U).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=E, S=:=0, T=:=U, V=:=W, 
          new11(A,B,T,D,V,F,U,W,I,J,K,L,M,N,O,P,Q).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=E, S=:=0, T=:=U, V=:=W, 
          new8(X,Y,Z,A1,B1,C1,D1,E1,F1,G1), 
          new11(A,B,T,D,V,F,U,W,I,J,K,L,M,N,O,P,Q).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=E, S=:=0, T=:=U, V=:=W, 
          new8(X,Y,Z,A1,B1,C1,D1,E1,F1,G1), 
          new11(A,B,T,D,V,F,U,W,I,J,K,L,M,N,O,P,Q).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=C, S=:=0, T=:=U-V, 
          U=:=A, V=:=1, new4(T,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=C, S=:=0, T=:=U-V, 
          U=:=A, V=:=1, new4(T,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=C, S=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=1, S=:=T, U=:=V, 
          new3(R,B,S,T,U,V,G,H,I,J,K,L,M,N,O,P,Q).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
correct :- \+new1.
