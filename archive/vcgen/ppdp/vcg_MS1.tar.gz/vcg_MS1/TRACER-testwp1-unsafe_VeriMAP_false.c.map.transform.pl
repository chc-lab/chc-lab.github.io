new7(A,B,C,8,A,B,C).
new5(A,B,C,D,E,F,G) :- H=<I, H=:=J+K, J=:=A, K=:=B, I=:=0, new7(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=0, J=:=3, new5(A,B,J,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=0, J=:=1, new5(A,J,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=2, new3(A,B,J,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=0, J=:= -1, new3(J,B,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
