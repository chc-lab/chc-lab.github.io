new14(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=4, J=:=1, K=:=6, L=:=M+N, M=:=A, 
          N=:=1, new3(L,J,K,D,E,F,G).
new14(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=4, J=:=2, K=:=L+M, L=:=A, M=:=1, 
          new3(K,J,C,D,E,F,G).
new14(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=4, J=:=2, K=:=L+M, L=:=A, M=:=1, 
          new3(K,J,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=3, J=:=1, K=:=5, L=:=M+N, M=:=A, 
          N=:=1, new3(L,J,K,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=3, new14(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=3, new14(A,B,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=2, J=:=3, K=:=4, L=:=M+N, M=:=A, 
          N=:=1, new3(L,J,K,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=2, new11(A,B,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=2, new11(A,B,C,D,E,F,G).
new6(A,B,C,19,A,B,C).
new5(A,B,C,D,E,F,G) :- H=:=I, H=:=C, I=:=6, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=1, J=:=2, K=:=3, L=:=M+N, M=:=A, 
          N=:=1, new3(L,J,K,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=1, new8(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=1, new8(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=10, new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=10, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, I=:=1, new3(H,I,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
