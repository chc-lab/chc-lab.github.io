new8(A,B,C,9,A,B,C).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=J+K, J=:=A, K=:=B, I=:=50, 
          new8(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, J=:=K+L, K=:=A, L=:=1, 
          new6(J,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=0, J=:=K+L, K=:=A, L=:=4, 
          new6(J,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=0, J=:=2, new4(A,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=0, J=:=5, new4(A,J,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, new3(H,B,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
