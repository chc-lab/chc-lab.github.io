new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,P,M,N,O) :- Q=:=R, 
          Q=:=N, R=:=1, P=:=0.
new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,P,M,N,O) :- Q>=R+1, 
          Q=:=N, R=:=1, P=:=2.
new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,P,M,N,O) :- Q+1=<R, 
          Q=:=N, R=:=1, P=:=2.
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=B, G1=:=0, H1=:=I1, J1=:=K1+L1, K1=:=E, L1=:=1, 
          M1=:=0, N1=:=1, 
          new123(I1,M1,C,N1,J1,H1,G,H,I,J,K,L,M,N,O,O1,P1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,Q1,R1).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=B, G1=:=0, H1=:=I1, J1=:=K1+L1, K1=:=E, L1=:=1, 
          M1=:=0, N1=:=1, 
          new123(I1,M1,C,N1,J1,H1,G,H,I,J,K,L,M,N,O,O1,P1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,Q1,R1).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=B, G1=:=0, H1=:=I1, J1=:=K1+L1, K1=:=E, L1=:=1, 
          M1=:=0, N1=:=1, O1=:=2, 
          new48(I1,M1,C,N1,J1,H1,G,H,I,J,K,L,M,N,O,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new162(R1,S1,T1,O1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=B, G1=:=0, H1=:=I1, J1=:=K1+L1, K1=:=E, L1=:=1, 
          M1=:=0, N1=:=1, O1=:=2, 
          new48(I1,M1,C,N1,J1,H1,G,H,I,J,K,L,M,N,O,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new162(R1,S1,T1,O1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=H, G1=:=1, H1=:=I1, J1=:=K1+L1, K1=:=E, L1=:=1, M1=:=0, 
          N1=:=1, 
          new123(I1,M1,C,N1,J1,H1,G,H,I,J,K,L,M,N,O,O1,P1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,Q1,R1).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=H, G1=:=1, 
          new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=H, G1=:=1, 
          new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=H, G1=:=1, H1=:=I1, J1=:=K1+L1, K1=:=E, L1=:=1, M1=:=0, 
          N1=:=1, O1=:=2, 
          new48(I1,M1,C,N1,J1,H1,G,H,I,J,K,L,M,N,O,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new162(R1,S1,T1,O1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=1, G1=:=0, 
          new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=H, G1=:=0, 
          new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=H, G1=:=0, 
          new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=H, G1=:=0, 
          new163(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=M, I1=:=1, 
          new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1>=I1+1, H1=:=P, I1=:=0, J1=:=0, 
          new143(A,B,C,D,E,F,J1,H,I,J,K,L,M,N,O,K1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,L1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1+1=<I1, H1=:=P, I1=:=0, J1=:=0, 
          new143(A,B,C,D,E,F,J1,H,I,J,K,L,M,N,O,K1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,L1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1=:=I1, H1=:=P, I1=:=0, 
          new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,J1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,K1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1>=K1+1, J1=:=P, K1=:=0, L1=:=0, M1=:=N1, 
          new64(A,B,C,D,E,F,L1,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,N1), 
          new149(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,P,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1+1=<K1, J1=:=P, K1=:=0, L1=:=0, M1=:=N1, 
          new64(A,B,C,D,E,F,L1,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,N1), 
          new149(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,P,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=K1, J1=:=P, K1=:=0, L1=:=M1, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M1), 
          new149(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,P,L1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=H, I1=:=1, 
          new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=B, I1=:=1, G1=:=A, J1=:=G1, K1=:=L1+M1, L1=:=J, 
          M1=:=1, N1=:=1, O1=:=1, 
          new123(A,N1,O1,D,E,F,G,H,I,K1,J1,L,M,N,O,P1,Q1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,R1,S1).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=B, I1=:=1, G1=:=A, J1=:=G1, K1=:=L1+M1, L1=:=J, 
          M1=:=1, N1=:=1, O1=:=1, 
          new123(A,N1,O1,D,E,F,G,H,I,K1,J1,L,M,N,O,P1,Q1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,R1,S1).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=B, I1=:=1, J1=:=A, K1=:=J1, L1=:=M1+N1, M1=:=J, 
          N1=:=1, O1=:=1, P1=:=1, Q1=:=2, 
          new48(A,O1,P1,D,E,F,G,H,I,L1,K1,L,M,N,O,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2), 
          new127(T1,U1,Q1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,J1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=B, I1=:=1, J1=:=A, K1=:=J1, L1=:=M1+N1, M1=:=J, 
          N1=:=1, O1=:=1, P1=:=1, Q1=:=2, 
          new48(A,O1,P1,D,E,F,G,H,I,L1,K1,L,M,N,O,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2), 
          new127(T1,U1,Q1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,J1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,53,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=E, I1=:=J, 
          new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=E, I1=:=J, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=E, I1=:=J, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=F, I1=:=K, 
          new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=F, I1=:=K, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=F, I1=:=K, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,H1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,I1).
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=K1, 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,K1), 
          new142(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,J1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=M, I1=:=1, J1=:=O, G1=:=A, K1=:=G1, L1=:=M1+N1, M1=:=J, 
          N1=:=1, O1=:=1, P1=:=1, 
          new123(A,O1,P1,D,E,F,G,H,I,L1,K1,L,M,N,O,Q1,R1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,S1,T1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=M, I1=:=1, 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=M, I1=:=1, 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=M, I1=:=1, J1=:=O, K1=:=A, L1=:=K1, M1=:=N1+O1, N1=:=J, 
          O1=:=1, P1=:=1, Q1=:=1, R1=:=2, 
          new48(A,P1,Q1,D,E,F,G,H,I,M1,L1,L,M,N,O,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2), 
          new127(U1,V1,R1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,K1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=1, I1=:=0, 
          new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, H1=:=M, I1=:=0, 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=M, I1=:=0, 
          new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=M, I1=:=0, 
          new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          I1>=J1+1, I1=:=Q, J1=:=0, K1=:=1, 
          new105(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,L1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,M1).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          I1+1=<J1, I1=:=Q, J1=:=0, K1=:=1, 
          new105(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,L1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,M1).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          I1=:=J1, I1=:=Q, J1=:=0, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,L1).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          I1>=J1+1, I1=:=Q, J1=:=0, K1=:=1, 
          new37(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new20(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,C2,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,D2).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          I1+1=<J1, I1=:=Q, J1=:=0, K1=:=1, 
          new37(A,B,C,D,E,F,G,H,I,J,K,K1,M,N,O,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new20(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,C2,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,D2).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=Q, M1=:=0, N1=:=O1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,O1), 
          new92(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,P,Q,N1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=Q, M1=:=0, N1=:=1, O1=:=P1, 
          new37(A,B,C,D,E,F,G,H,I,J,K,N1,M,N,O,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new16(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,P1), 
          new92(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,P,Q,O1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=Q, M1=:=0, N1=:=1, O1=:=P1, 
          new37(A,B,C,D,E,F,G,H,I,J,K,N1,M,N,O,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new16(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,P1), 
          new92(I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,P,Q,O1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=L, M1=:=0, 
          new98(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,N1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          I1>=J1+1, I1=:=L, J1=:=0, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,L1).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          I1+1=<J1, I1=:=L, J1=:=0, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,L1).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=L, M1=:=0, N1=:=O1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,O1), 
          new92(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,P,Q,N1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=L, M1=:=0, N1=:=O1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,O1), 
          new92(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,P,Q,N1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          I1>=J1+1, I1=:=P, J1=:=0, K1=:=1, 
          new155(A,B,C,D,E,F,K1,H,I,J,K,L,M,N,O,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          I1+1=<J1, I1=:=P, J1=:=0, K1=:=1, 
          new155(A,B,C,D,E,F,K1,H,I,J,K,L,M,N,O,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=P, M1=:=0, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=P, M1=:=0, N1=:=1, 
          new73(A,B,C,D,E,F,N1,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2), 
          new96(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=P, M1=:=0, N1=:=1, 
          new73(A,B,C,D,E,F,N1,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2), 
          new96(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=G, M1=:=0, 
          new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,N1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=G, M1=:=0, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=G, M1=:=0, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=R, M1=:=0, 
          new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=R, M1=:=0, 
          new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,P,Q,I,J,K,L,M,N,O) :- R=:=S, 
          R=:=B, S=:=0, P=:=2, Q=:=1.
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=B, F1=:=0, G1=:=H1, I1=:=J1+K1, J1=:=E, K1=:=1, 
          L1=:=0, M1=:=1, N1=:=2, 
          new48(H1,L1,C,M1,I1,G1,G,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new78(Q1,R1,S1,N1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=B, F1=:=0, G1=:=H1, I1=:=J1+K1, J1=:=E, K1=:=1, 
          L1=:=0, M1=:=1, N1=:=2, 
          new48(H1,L1,C,M1,I1,G1,G,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new78(Q1,R1,S1,N1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=H, F1=:=1, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=H, F1=:=1, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=H, F1=:=1, G1=:=H1, I1=:=J1+K1, J1=:=E, K1=:=1, L1=:=0, 
          M1=:=1, N1=:=2, 
          new48(H1,L1,C,M1,I1,G1,G,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new78(Q1,R1,S1,N1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=1, F1=:=0, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=H, F1=:=0, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=H, F1=:=0, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=H, F1=:=0, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R=:=S, R=:=C, S=:=1, Q=:=1.
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R>=S+1, R=:=C, S=:=1, Q=:=0.
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R+1=<S, R=:=C, S=:=1, Q=:=0.
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R=:=S, R=:=D, S=:=1, Q=:=1.
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R>=S+1, R=:=D, S=:=1, Q=:=0.
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R+1=<S, R=:=D, S=:=1, Q=:=0.
new67(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A,B,C,D,E,F,G,H,I,J,K,R,M,N,O,P,Q) :- 
          S>=T+1, S=:=Q, T=:=0, R=:=0.
new67(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A,B,C,D,E,F,G,H,I,J,K,R,M,N,O,P,Q) :- 
          S+1=<T, S=:=Q, T=:=0, R=:=0.
new67(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- 
          R=:=S, R=:=Q, S=:=0.
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R>=S+1, R=:=M, S=:=1, Q=:=0.
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R+1=<S, R=:=M, S=:=1, Q=:=0.
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=M, H1=:=1, 
          new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1>=J1+1, I1=:=P, J1=:=0, K1=:=0, L1=:=M1, 
          new64(A,B,C,D,E,F,K1,H,I,J,K,L,M,N,O,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M1), 
          new67(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,P,L1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1+1=<J1, I1=:=P, J1=:=0, K1=:=0, L1=:=M1, 
          new64(A,B,C,D,E,F,K1,H,I,J,K,L,M,N,O,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M1), 
          new67(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,P,L1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1=:=J1, I1=:=P, J1=:=0, K1=:=L1, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,L1), 
          new67(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,P,K1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R>=S+1, R=:=H, S=:=1, Q=:=0.
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R+1=<S, R=:=H, S=:=1, Q=:=0.
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=H, H1=:=1, 
          new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,Q,R,N,S,P) :- 
          T=:=U, T=:=B, U=:=1, Q=:=2, R=:=1, S=:=P.
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, H1=:=1, I1=:=A, J1=:=I1, K1=:=L1+M1, L1=:=J, 
          M1=:=1, N1=:=1, O1=:=1, P1=:=2, 
          new48(A,N1,O1,D,E,F,G,H,I,K1,J1,L,M,N,O,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2), 
          new51(S1,T1,P1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,I1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=B, H1=:=1, I1=:=A, J1=:=I1, K1=:=L1+M1, L1=:=J, 
          M1=:=1, N1=:=1, O1=:=1, P1=:=2, 
          new48(A,N1,O1,D,E,F,G,H,I,K1,J1,L,M,N,O,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2), 
          new51(S1,T1,P1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,I1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=E, H1=:=J, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=E, H1=:=J, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=E, H1=:=J, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=F, H1=:=K, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=F, H1=:=K, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=F, H1=:=K, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1=:=J1, 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,J1), 
          new63(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,I1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=M, H1=:=1, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=M, H1=:=1, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=M, H1=:=1, I1=:=O, J1=:=A, K1=:=J1, L1=:=M1+N1, M1=:=J, 
          N1=:=1, O1=:=1, P1=:=1, Q1=:=2, 
          new48(A,O1,P1,D,E,F,G,H,I,L1,K1,L,M,N,O,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2), 
          new51(T1,U1,Q1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,J1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=1, H1=:=0, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=M, H1=:=0, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=M, H1=:=0, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=M, H1=:=0, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=Q, L1=:=0, M1=:=N1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,N1), 
          new26(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,P,Q,M1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=1, N1=:=O1, 
          new37(A,B,C,D,E,F,G,H,I,J,K,M1,M,N,O,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2), 
          new16(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,O1), 
          new26(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,P,Q,N1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=1, N1=:=O1, 
          new37(A,B,C,D,E,F,G,H,I,J,K,M1,M,N,O,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2), 
          new16(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,O1), 
          new26(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,P,Q,N1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=L, L1=:=0, 
          new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=L, L1=:=0, M1=:=N1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,N1), 
          new26(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,P,Q,M1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=L, L1=:=0, M1=:=N1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,N1), 
          new26(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,P,Q,M1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=P, L1=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=P, L1=:=0, M1=:=1, 
          new73(A,B,C,D,E,F,M1,H,I,J,K,L,M,N,O,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new30(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=P, L1=:=0, M1=:=1, 
          new73(A,B,C,D,E,F,M1,H,I,J,K,L,M,N,O,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new30(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=G, L1=:=0, 
          new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,M1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=G, L1=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=G, L1=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          S=:=T, S=:=R, T=:=0.
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=R, L1=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=R, L1=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1>=I1+1, H1=:=G, I1=:=0, 
          new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1+1=<I1, H1=:=G, I1=:=0, 
          new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R=:=S, R=:=L, S=:=0, Q=:=1.
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R>=S+1, R=:=L, S=:=0, Q=:=0.
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R+1=<S, R=:=L, S=:=0, Q=:=0.
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,R) :- 
          S>=T+1, S=:=P, T=:=0, R=:=0.
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,R) :- 
          S+1=<T, S=:=P, T=:=0, R=:=0.
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,R) :- 
          S=:=T, S=:=P, T=:=0, R=:=1.
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R=:=S, R=:=G, S=:=0, Q=:=1.
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=G, H1=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=G, H1=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=K1, J1=:=Q, K1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1=:=J1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,J1), 
          new17(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,I1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,H1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,I1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=K1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,K1), 
          new22(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,J1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,L1), 
          new26(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,P,Q,K1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,P,Q,R) :- 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,J1).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M1), 
          new92(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,P,Q,L1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,Q) :- 
          I1>=J1+1, I1=:=1, J1=:=0, H1=:=1, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,L1,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,N1,O1,P1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,Q) :- 
          I1>=J1+1, I1=:=1, J1=:=0, H1=:=1, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2), 
          new12(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,F2,G2,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H2,I2).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1>=K1+1, J1=:=1, K1=:=0, L1=:=1, M1=:=N1, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2), 
          new13(R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,N1), 
          new14(L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,L1,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=I, F1=:=1, G1=:=0, 
          new177(A,B,C,D,E,F,G1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=I, F1=:=1, G1=:=2, 
          new177(A,B,C,D,E,F,G1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=I, F1=:=1, G1=:=2, 
          new177(A,B,C,D,E,F,G1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=I, G1=:=1, H1=:=0, 
          new180(A,B,C,D,E,F,H1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=I, G1=:=1, H1=:=2, 
          new180(A,B,C,D,E,F,H1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=I, G1=:=1, H1=:=2, 
          new180(A,B,C,D,E,F,H1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,Q) :- 
          H1=:=0, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1), 
          new8(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,J1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,P,Q,R,S,F,G,T,U,V,K,L,W,X,O) :- P=:=1, 
          R=:=2, Q=:=R, S=:=0, T=:=0, U=:=1, V=:=0, W=:=0, X=:=1.
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,P) :- 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,P) :- 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new5(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,X1,Y1).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=0, 
          K=:=0, L=:=0, M=:=0, N=:=0, O=:=0, 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
correct :- \+new1.
