new8(A,B) :- B=:=C-D, C=:=A, D=:=1.
new6(A,B,C,15,A,B,C).
new5(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,B,C) :- F>=G+1, F=:=B, G=:=0, new7(A,D,E).
new4(A,B,C,D,E,B,C) :- F+1=<G, F=:=B, G=:=0, new7(A,D,E).
new4(A,B,C,D,E,B,C) :- F=:=G, F=:=B, G=:=0, new7(A,D,E).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=0, new8(A,J), new3(J,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=0, new8(A,J), new3(J,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=0, new8(A,J), new3(J,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=K, new4(A,J,K,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=0, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- new3(H,B,C,D,E,F,G).
new1 :- A=:=0, new2(A,B,C,D,E,F,G).
correct :- \+new1.
