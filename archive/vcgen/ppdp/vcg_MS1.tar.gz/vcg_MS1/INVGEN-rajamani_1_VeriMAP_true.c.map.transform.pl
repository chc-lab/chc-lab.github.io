new15(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=N*O, N=:=100, O=:=B, P=:=Q*R, 
          Q=:= -1, R=:=C, S=:=T+U, T=:=E, U=:=1, V=:=W+X, W=:=D, X=:=10, 
          new3(A,B,P,V,S,F,G,H,I,J,K).
new15(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=N*O, N=:=100, O=:=B, 
          P=:=Q+R, Q=:=E, R=:=1, S=:=T+U, T=:=D, U=:=10, 
          new3(A,B,C,S,P,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=C, M=:=N*O, N=:=10, O=:=E, 
          new15(A,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=C, M=:=N*O, N=:=10, O=:=E, P=:=Q+R, 
          Q=:=E, R=:=1, S=:=T+U, T=:=D, U=:=10, new3(A,B,C,S,P,F,G,H,I,J,K).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=B, M=:=4, N=:=O+P, O=:=B, P=:=1, 
          Q=:=R+S, R=:=C, S=:=1, T=:=U+V, U=:=E, V=:=1, W=:=X+Y, X=:=D, Y=:=10, 
          new3(A,N,Q,W,T,F,G,H,I,J,K).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=4, N=:=O+P, O=:=E, P=:=1, 
          Q=:=R+S, R=:=D, S=:=10, new3(A,B,C,Q,N,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K).
new8(A,B,C,D,E,19,A,B,C,D,E).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=C, M=:=2, new8(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=B, M=:=4, new7(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=0, N=:=O+P, O=:=B, P=:=1, 
          Q=:=R+S, R=:=C, S=:=100, T=:=U+V, U=:=E, V=:=1, W=:=X+Y, X=:=D, 
          Y=:=10, new3(A,N,Q,W,T,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=0, N=:=O+P, O=:=B, P=:=1, 
          Q=:=R+S, R=:=C, S=:=100, T=:=U+V, U=:=E, V=:=1, W=:=X+Y, X=:=D, 
          Y=:=10, new3(A,N,Q,W,T,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=0, new6(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=0, N=:=0, O=:=0, 
          new3(A,L,M,N,O,F,G,H,I,J,K).
new1 :- A=:=0, new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
