new5(A,B,C,5,A,B,C).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=0, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, J=:=4, K=:=1, new3(J,K,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=0, J=:=100, K=:=2, new3(J,K,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
