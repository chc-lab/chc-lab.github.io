new16(A,B,C,D,E,F,G,30,A,B,C,D,E,F,G).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=G, Q=:=F, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=0, R=:=S-T, S=:=E, 
          T=:=1, U=:=V-W, V=:=B, W=:=1, X=:=Y+Z, Y=:=G, Z=:=1, 
          new15(A,U,C,D,R,F,X,H,I,J,K,L,M,N,O).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=0, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=A, Q=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=A, Q=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=A, Q=:=0, R=:=0, S=:=B, 
          new14(A,B,C,D,E,S,R,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=A, Q=:=0, R=:=B, S=:=T+U, 
          T=:=B, U=:=1, V=:=W+X, W=:=E, X=:=1, 
          new7(A,S,C,R,V,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=A, Q=:=0, R=:=B, S=:=T+U, 
          T=:=B, U=:=1, V=:=W+X, W=:=E, X=:=1, 
          new7(A,S,C,R,V,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=A, Q=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=B, Q=:=C, R=:=B, S=:=0, 
          new7(A,S,R,D,E,F,G,H,I,J,K,L,M,N,O).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=B, Q=:=C, R=:=0, 
          new7(A,R,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=A, Q=:=0, R=:=S+T, S=:=B, 
          T=:=1, new3(A,R,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=A, Q=:=0, R=:=S+T, S=:=B, 
          T=:=1, new3(A,R,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=A, Q=:=0, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=0, Q=:=0, 
          new3(A,Q,C,D,P,F,G,H,I,J,K,L,M,N,O).
new1 :- A=:=0, new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
correct :- \+new1.
