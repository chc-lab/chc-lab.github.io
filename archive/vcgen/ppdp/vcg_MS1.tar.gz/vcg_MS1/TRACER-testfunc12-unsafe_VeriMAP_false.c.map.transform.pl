new11(A,B,C,D,11,A,B,C,D).
new9(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=A, K=:=2, new11(A,B,C,D,E,F,G,H,I).
new6(A,B) :- B=:=1.
new3(A,B,C,D,E,F,B,C,D) :- G>=H+1, G=:=C, H=:=0, F=:=1, new5(I,E,J).
new3(A,B,C,D,E,F,B,C,D) :- G=<H, G=:=C, H=:=0, F=:=2, new5(I,E,J).
new3(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, K=:=0, L=:=1, new6(M,N), 
          new9(L,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=C, K=:=0, L=:=2, new6(M,N), 
          new9(L,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, L=:=2, new3(A,L,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=D, K=:=0, L=:=3, new3(A,L,C,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
