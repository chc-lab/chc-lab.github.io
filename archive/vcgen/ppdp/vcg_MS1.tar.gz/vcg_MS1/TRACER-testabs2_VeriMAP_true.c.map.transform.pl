new6(A,B,C,6,A,B,C).
new4(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, J=:=4, K=:=1, new4(J,K,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=0, J=:=100, K=:=2, new4(J,K,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=1, I=:=4, new3(I,B,H,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
