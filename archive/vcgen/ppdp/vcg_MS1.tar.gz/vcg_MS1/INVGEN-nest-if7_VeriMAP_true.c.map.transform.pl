new13(A,B,C,D,E,24,A,B,C,D,E).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=B, N=:=O+P, O=:=D, P=:=1, 
          new5(A,B,C,N,E,F,G,H,I,J,K).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=B, 
          new13(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=C, new12(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=C, 
          new13(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=0, N=:=O+P, O=:=D, P=:=1, 
          new5(A,B,C,N,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=E, 
          new7(A,B,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=E, N=:=O+P, O=:=C, P=:=1, 
          new4(A,B,N,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=E, N=:=C, 
          new5(A,B,C,N,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=E, N=:=O+P, O=:=B, P=:=1, 
          new3(A,N,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=E, N=:=B, 
          new4(A,B,N,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, new3(A,L,C,D,E,F,G,H,I,J,K).
new1 :- A=:=0, new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
