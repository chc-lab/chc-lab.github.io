new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=A, Q=:=1, R=:=0, S=:=0, 
          T=:=1, U=:=V-W, V=:=X+Y, X=:=Z+A1, Z=:=B1+C1, B1=:=A, C1=:=R, A1=:=T, 
          Y=:=S, W=:=1, new6(U,R,S,T,E,F,D1,H,I,J,K,L,M,N,O).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=R+S, R=:=C, S=:=B, Q=:=1, 
          T=:=U-V, U=:=W+X, W=:=Y+Z, Y=:=A, Z=:=B, X=:=C, V=:=1, A1=:=B1+C1, 
          B1=:=D, C1=:=1, D1=:=0, E1=:=0, 
          new6(T,D1,E1,A1,E,F,F1,H,I,J,K,L,M,N,O).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=E, Q=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=E, Q=:=0, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=A, Q=:=1, R=:=S+T, S=:=C, 
          T=:=D, U=:=0, V=:=W-X, W=:=A, X=:=1, Y=:=Z+A1, Z=:=B, A1=:=1, 
          new6(V,Y,R,U,E,F,B1,H,I,J,K,L,M,N,O).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=R+S, R=:=T+U, T=:=V+W, 
          V=:=A, W=:=B, U=:=D, S=:=C, Q=:=1, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,37,A,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=B, Q=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=B, Q=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=D, Q=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=D, Q=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=F, Q=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=F, Q=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=F, Q=:=0, 
          new17(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=G, Q=:=0, 
          new7(A,B,C,D,E,R,G,H,I,J,K,L,M,N,O).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=G, Q=:=0, 
          new7(A,B,C,D,E,R,G,H,I,J,K,L,M,N,O).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=G, Q=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=A, Q=:=1, 
          new6(A,B,C,D,E,F,R,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=B, Q=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=C, Q=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=D, Q=:=0, 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
correct :- \+new1.
