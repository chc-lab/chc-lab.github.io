new14(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new4(N,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new4(N,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=C, M=:=0, N=:=O+P, O=:=B, P=:=C, 
          new14(A,N,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=0, N=:=O+P, O=:=B, P=:=C, 
          new14(A,N,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=C, M=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,24,A,B,C,D,E).
new8(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new8(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, 
          new11(A,B,N,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- new5(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=D, N=:=O-P, O=:=B, P=:=C, 
          new7(A,N,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=A, M=:=D, new8(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=0, N=:=0, 
          new4(N,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=D, M=:=0, new5(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=0, N=:=0, O=:=P, 
          new3(L,M,N,O,P,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
