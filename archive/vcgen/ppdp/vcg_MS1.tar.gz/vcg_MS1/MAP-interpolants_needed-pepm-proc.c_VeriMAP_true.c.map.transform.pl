new10(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=A, M=:=4, N=:=O+P, O=:=A, P=:=1, 
          Q=:=R+S, R=:=B, S=:=3, new3(N,Q,C,D,T,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=4, 
          new3(A,B,C,D,N,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=C, M=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=C, M=:=0, new3(A,B,C,D,N,F,G,H,I,J,K).
new6(A,B,C,D,E,18,A,B,C,D,E) :- F+1=<G, F=:=H*I, H=:=3, I=:=A, G=:=B.
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          Q=:=R+S, R=:=B, S=:=2, new3(N,Q,C,D,T,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          Q=:=R+S, R=:=B, S=:=2, new3(N,Q,C,D,T,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=D, M=:=0, new9(A,B,N,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, 
          new4(A,B,C,N,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=0, 
          new4(A,B,C,N,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=E, M=:=0, new6(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=0, new3(L,M,C,D,N,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
