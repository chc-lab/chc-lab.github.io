new6(A,B,15,A,B) :- C+1=<D, C=:=B, D=:=100.
new5(A,B,15,A,B) :- C>=D+1, C=:=B, D=:=100.
new5(A,B,C,D,E) :- F=<G, F=:=B, G=:=100, new6(A,B,C,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=50, H=:=I+J, I=:=A, J=:=1, 
          new3(H,B,C,D,E).
new4(A,B,C,D,E) :- F>=G, F=:=A, G=:=50, H=:=I+J, I=:=A, J=:=1, K=:=L+M, L=:=B, 
          M=:=1, new3(H,K,C,D,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=100, new4(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G, F=:=A, G=:=100, new5(A,B,C,D,E).
new2(A,B,C,D,E) :- F=:=0, G=:=50, new3(F,G,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
