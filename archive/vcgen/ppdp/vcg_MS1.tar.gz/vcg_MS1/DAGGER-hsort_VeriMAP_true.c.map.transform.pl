new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=C, U=:=2, V=:=W-X, 
          W=:=B, X=:=1, Y=:=Z-A1, Z=:=B1*C1, B1=:=2, C1=:=B, A1=:=2, 
          D1=:=E1-F1, E1=:=B, F1=:=1, 
          new8(A,D1,C,V,Y,F,G,H,G1,J,K,L,M,N,O,P,Q,R,S).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=C, U=:=3, V=:=B, 
          W=:=X*Y, X=:=2, Y=:=B, new8(A,B,C,V,W,F,G,H,Z,J,K,L,M,N,O,P,Q,R,S).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=B, U=:=1, V=:=W-X, 
          W=:=C, X=:=1, new32(A,B,V,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=B, U=:=2, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=F, U=:=0, 
          new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=F, U=:=0, 
          new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=F, U=:=0, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=V-W, V=:=E, W=:=C, 
          U=:=0, X=:=E, Y=:=Z*A1, Z=:=2, A1=:=E, 
          new8(A,B,C,X,Y,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=0, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=0, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=0, 
          new28(A,B,C,D,E,V,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V-W, V=:=X-Y, X=:=C, 
          Y=:=E, W=:=1, U=:=0, Z=:=A1+B1, A1=:=E, B1=:=1, C1=:=D1+E1, 
          D1=:=F1*G1, F1=:=2, G1=:=E, E1=:=2, 
          new8(A,B,C,Z,C1,F,G,H,H1,J,K,L,M,N,O,P,Q,R,S).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V-W, V=:=A, W=:=C, 
          U=:=0, new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V-W, V=:=B, W=:=1, 
          U=:=0, new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V-W, V=:=B, W=:=1, 
          U=:=0, new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V-W, V=:=C, W=:=2, 
          U=:=0, new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V-W, V=:=C, W=:=2, 
          U=:=0, new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V+W, V=:=X+Y, 
          X=:=Z*A1, Z=:= -2, A1=:=B, Y=:=C, W=:=1, U=:=0, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V+W, V=:=X+Y, 
          X=:=Z*A1, Z=:= -2, A1=:=B, Y=:=C, W=:=1, U=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new13(A,B,C,D,E,F,G,H,I,60,A,B,C,D,E,F,G,H,I).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=V-W, V=:=X*Y, X=:=2, 
          Y=:=D, W=:=E, U=:=0, new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=V-W, V=:=X*Y, 
          X=:=2, Y=:=D, W=:=E, U=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V-W, V=:=X*Y, X=:=2, 
          Y=:=D, W=:=E, U=:=0, new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V-W, V=:=X*Y, 
          X=:=2, Y=:=D, W=:=E, U=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=0, 
          new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=0, 
          new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=0, 
          new25(A,B,C,D,E,F,V,H,I,J,K,L,M,N,O,P,Q,R,S).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=0, 
          new9(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=0, 
          new9(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=V-W, V=:=X-Y, 
          X=:=Z*A1, Z=:=2, A1=:=B, Y=:=A, W=:=1, U=:=0, 
          new8(A,B,C,D,E,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V-W, V=:=X*Y, X=:=2, 
          Y=:=B, W=:=A, U=:=0, new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=V-W, V=:=E, W=:=X*Y, 
          X=:=2, Y=:=B, U=:=0, new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=V-W, V=:=D, W=:=B, 
          U=:=0, new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=V-W, V=:=C, W=:=A, 
          U=:=0, new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=A, U=:=2, 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
correct :- \+new1.
