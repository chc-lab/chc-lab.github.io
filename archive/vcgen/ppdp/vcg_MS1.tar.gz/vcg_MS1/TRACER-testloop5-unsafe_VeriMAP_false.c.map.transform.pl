new10(A,B,11,A,B).
new8(A,B,C,D,E) :- F=:=G, F=:=A, G=:=10, new10(A,B,C,D,E).
new5(A,B,C,D,B) :- E+1=<F, E=:=B, F=:=10, new3(A,C,D).
new5(A,B,C,D,E) :- F>=G, F=:=B, G=:=10, new8(A,B,C,D,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=10, H=:=I, new4(A,I), new5(I,H,C,D,E).
new4(A,B) :- B=:=C+D, C=:=A, D=:=1.
new2(A,B,C,D,B) :- new3(A,C,D).
new2(A,B,C,D,E) :- F=:=G, new4(A,G), new5(G,F,C,D,E).
new1 :- A=:=0, new2(A,B,C,D,E).
correct :- \+new1.
