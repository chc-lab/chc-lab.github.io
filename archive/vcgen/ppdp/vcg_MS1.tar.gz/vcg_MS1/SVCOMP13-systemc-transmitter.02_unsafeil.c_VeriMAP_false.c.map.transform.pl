new337(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=H, E1=:=1, F1=:=0, 
          new340(A,B,C,D,F1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new337(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=H, E1=:=1, F1=:=2, 
          new340(A,B,C,D,F1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new337(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=H, E1=:=1, F1=:=2, 
          new340(A,B,C,D,F1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new334(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,O,G,H,I,J,K,L,M,N) :- P=:=Q, 
          P=:=I, Q=:=1, O=:=0.
new334(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,O,G,H,I,J,K,L,M,N) :- P>=Q+1, 
          P=:=I, Q=:=1, O=:=2.
new334(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,O,G,H,I,J,K,L,M,N) :- P+1=<Q, 
          P=:=I, Q=:=1, O=:=2.
new331(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=H, D1=:=1, E1=:=0, 
          new334(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new331(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=H, D1=:=1, E1=:=2, 
          new334(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new331(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=H, D1=:=1, E1=:=2, 
          new334(A,B,C,D,E1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new325(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=M, E1=:=0, F1=:=1, 
          new328(A,B,C,D,E,F,G,H,I,J,K,L,F1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new325(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=0, 
          new328(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new325(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=0, 
          new328(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=L, E1=:=0, F1=:=1, 
          new325(A,B,C,D,E,F,G,H,I,J,K,F1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=L, E1=:=0, 
          new325(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=L, E1=:=0, 
          new325(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new319(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=K, E1=:=0, F1=:=1, 
          new322(A,B,C,D,E,F,G,H,I,J,F1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new319(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=K, E1=:=0, 
          new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new319(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=K, E1=:=0, 
          new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,O) :- P=:=Q, 
          P=:=N, Q=:=0, O=:=1.
new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O>=P+1, 
          O=:=N, P=:=0.
new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, 
          O=:=N, P=:=0.
new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=M, D1=:=0, E1=:=1, 
          new316(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=M, D1=:=0, 
          new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=M, D1=:=0, 
          new316(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new310(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=L, D1=:=0, E1=:=1, 
          new313(A,B,C,D,E,F,G,H,I,J,K,E1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new310(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=L, D1=:=0, 
          new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new310(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=L, D1=:=0, 
          new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=K, D1=:=0, E1=:=1, 
          new310(A,B,C,D,E,F,G,H,I,J,E1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=K, D1=:=0, 
          new310(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=K, D1=:=0, 
          new310(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new295(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=C, G1=:=1, 
          new304(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new292(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q) :- 
          G1>=H1+1, G1=:=P, H1=:=0, I1=:=0, 
          new295(A,B,C,D,I1,F,G,H,I,J,K,L,M,N,J1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,K1).
new292(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q) :- 
          G1+1=<H1, G1=:=P, H1=:=0, I1=:=0, 
          new295(A,B,C,D,I1,F,G,H,I,J,K,L,M,N,J1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,K1).
new292(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q) :- 
          G1=:=H1, G1=:=P, H1=:=0, 
          new295(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,J1).
new292(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1>=K1+1, J1=:=P, K1=:=0, L1=:=0, M1=:=N1, 
          new274(A,B,C,D,L1,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,N1), 
          new301(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,O,P,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new292(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1+1=<K1, J1=:=P, K1=:=0, L1=:=0, M1=:=N1, 
          new274(A,B,C,D,L1,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,N1), 
          new301(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,O,P,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new292(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=K1, J1=:=P, K1=:=0, L1=:=M1, 
          new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,M1), 
          new301(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,P,L1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new286(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=B, G1=:=1, 
          new305(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new285(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q) :- 
          G1>=H1+1, G1=:=O, H1=:=0, I1=:=0, 
          new286(A,B,C,I1,E,F,G,H,I,J,K,L,M,N,J1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,K1).
new285(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q) :- 
          G1+1=<H1, G1=:=O, H1=:=0, I1=:=0, 
          new286(A,B,C,I1,E,F,G,H,I,J,K,L,M,N,J1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,K1).
new285(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q) :- 
          G1=:=H1, G1=:=O, H1=:=0, 
          new286(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,J1).
new285(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1>=K1+1, J1=:=O, K1=:=0, L1=:=0, M1=:=N1, 
          new268(A,B,C,L1,E,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,N1), 
          new292(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,O,M1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new285(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1+1=<K1, J1=:=O, K1=:=0, L1=:=0, M1=:=N1, 
          new268(A,B,C,L1,E,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,N1), 
          new292(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,O,M1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new285(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=K1, J1=:=O, K1=:=0, L1=:=M1, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,M1), 
          new292(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,L1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new283(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=A, G1=:=1, 
          new306(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new282(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q=:=R, 
          Q=:=J, R=:=1, P=:=1.
new282(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q>=R+1, 
          Q=:=J, R=:=1, P=:=0.
new282(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q+1=<R, 
          Q=:=J, R=:=1, P=:=0.
new281(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q=:=R, 
          Q=:=M, R=:=1, P=:=1.
new281(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q>=R+1, 
          Q=:=M, R=:=1, P=:=0.
new281(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q+1=<R, 
          Q=:=M, R=:=1, P=:=0.
new280(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q=:=R, 
          Q=:=N, R=:=1, P=:=1.
new280(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q>=R+1, 
          Q=:=N, R=:=1, P=:=0.
new280(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q+1=<R, 
          Q=:=N, R=:=1, P=:=0.
new277(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A,B,C,D,E,R,G,H,I,J,K,L,M,N,O,P,Q) :- 
          S>=T+1, S=:=Q, T=:=0, R=:=0.
new277(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A,B,C,D,E,R,G,H,I,J,K,L,M,N,O,P,Q) :- 
          S+1=<T, S=:=Q, T=:=0, R=:=0.
new277(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- 
          R=:=S, R=:=Q, S=:=0.
new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q>=R+1, 
          Q=:=C, R=:=1, P=:=0.
new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q+1=<R, 
          Q=:=C, R=:=1, P=:=0.
new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=C, F1=:=1, 
          new280(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new271(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1>=J1+1, I1=:=P, J1=:=0, K1=:=0, L1=:=M1, 
          new274(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,M1), 
          new277(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,P,L1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new271(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1+1=<J1, I1=:=P, J1=:=0, K1=:=0, L1=:=M1, 
          new274(A,B,C,D,K1,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,M1), 
          new277(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,P,L1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new271(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1=:=J1, I1=:=P, J1=:=0, K1=:=L1, 
          new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,L1), 
          new277(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,O,P,K1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q>=R+1, 
          Q=:=B, R=:=1, P=:=0.
new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q+1=<R, 
          Q=:=B, R=:=1, P=:=0.
new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=B, F1=:=1, 
          new281(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1>=J1+1, I1=:=O, J1=:=0, K1=:=0, L1=:=M1, 
          new268(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,M1), 
          new271(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,L1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1+1=<J1, I1=:=O, J1=:=0, K1=:=0, L1=:=M1, 
          new268(A,B,C,K1,E,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,M1), 
          new271(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,L1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1=:=J1, I1=:=O, J1=:=0, K1=:=L1, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,L1), 
          new271(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,O,K1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q>=R+1, 
          Q=:=A, R=:=1, P=:=0.
new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q+1=<R, 
          Q=:=A, R=:=1, P=:=0.
new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=A, F1=:=1, 
          new282(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=M, E1=:=1, F1=:=2, 
          new263(A,B,C,D,E,F,G,H,I,J,K,L,F1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=1, 
          new263(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=1, 
          new263(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=L, E1=:=1, F1=:=2, 
          new260(A,B,C,D,E,F,G,H,I,J,K,F1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=L, E1=:=1, 
          new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=L, E1=:=1, 
          new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=K, E1=:=1, F1=:=2, 
          new257(A,B,C,D,E,F,G,H,I,J,F1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=K, E1=:=1, 
          new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=K, E1=:=1, 
          new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,O) :- P=:=Q, 
          P=:=N, Q=:=1, O=:=2.
new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O>=P+1, 
          O=:=N, P=:=1.
new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, 
          O=:=N, P=:=1.
new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=M, D1=:=1, E1=:=2, 
          new251(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=M, D1=:=1, 
          new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=M, D1=:=1, 
          new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=L, D1=:=1, E1=:=2, 
          new248(A,B,C,D,E,F,G,H,I,J,K,E1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=L, D1=:=1, 
          new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=L, D1=:=1, 
          new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=K, D1=:=1, E1=:=2, 
          new245(A,B,C,D,E,F,G,H,I,J,E1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=K, D1=:=1, 
          new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=K, D1=:=1, 
          new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          new238(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=A, E1=:=1, 
          new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=A, E1=:=1, 
          new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=A, E1=:=1, 
          new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=1, E1=:=0, F1=:=1, 
          new219(A,B,C,D,E,F,G,H,I,J,K,L,F1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=1, E1=:=0, F1=:=1, G1=:=2, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,F1,N,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new238(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,G1,U1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new225(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=A, E1=:=0, 
          new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new225(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=A, E1=:=0, 
          new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new225(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=A, E1=:=0, 
          new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,E1,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,G1,H1,I1).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=B, E1=:=1, F1=:=1, 
          new219(A,B,C,D,E,F,G,H,I,J,K,L,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=B, E1=:=1, 
          new216(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=B, E1=:=1, 
          new216(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=B, E1=:=1, F1=:=1, G1=:=2, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,F1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new216(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,G1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new209(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=B, E1=:=0, 
          new216(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new209(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=B, E1=:=0, 
          new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new209(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=B, E1=:=0, 
          new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,45,A,B,C,D,E,F,G,H,I,J,K,L,M,N).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=C, E1=:=1, 
          new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=C, E1=:=1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=C, E1=:=1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=C, E1=:=0, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=C, E1=:=0, 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=C, E1=:=0, 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1>=I1+1, H1=:=R, I1=:=0, J1=:=1, 
          new188(A,B,C,D,E,J1,G,H,I,J,K,L,M,N,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1+1=<I1, H1=:=R, I1=:=0, J1=:=1, 
          new188(A,B,C,D,E,J1,G,H,I,J,K,L,M,N,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1=:=I1, H1=:=R, I1=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,J1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,K1).
new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1>=I1+1, H1=:=R, I1=:=0, J1=:=1, 
          new129(A,B,C,D,E,J1,G,H,I,J,K,L,M,N,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1), 
          new52(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,Z1).
new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1+1=<I1, H1=:=R, I1=:=0, J1=:=1, 
          new129(A,B,C,D,E,J1,G,H,I,J,K,L,M,N,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1), 
          new52(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,Z1).
new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=R, M1=:=0, N1=:=O1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,O1), 
          new172(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=R, M1=:=0, N1=:=1, O1=:=P1, 
          new129(A,B,C,D,E,N1,G,H,I,J,K,L,M,N,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2), 
          new53(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,P1), 
          new172(F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,O1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=R, M1=:=0, N1=:=1, O1=:=P1, 
          new129(A,B,C,D,E,N1,G,H,I,J,K,L,M,N,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2), 
          new53(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,P1), 
          new172(F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,O1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=F, M1=:=0, 
          new181(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,N1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1>=I1+1, H1=:=F, I1=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,J1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,K1).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1+1=<I1, H1=:=F, I1=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,J1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,K1).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=F, M1=:=0, N1=:=O1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,O1), 
          new172(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=F, M1=:=0, N1=:=O1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,O1), 
          new172(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1>=I1+1, H1=:=Q, I1=:=0, J1=:=1, 
          new209(A,B,C,D,J1,F,G,H,I,J,K,L,M,N,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1+1=<I1, H1=:=Q, I1=:=0, J1=:=1, 
          new209(A,B,C,D,J1,F,G,H,I,J,K,L,M,N,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=Q, M1=:=0, 
          new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=Q, M1=:=0, N1=:=1, 
          new143(A,B,C,D,N1,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new179(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=Q, M1=:=0, N1=:=1, 
          new143(A,B,C,D,N1,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new179(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=E, M1=:=0, 
          new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,N1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=E, M1=:=0, 
          new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=E, M1=:=0, 
          new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1>=I1+1, H1=:=P, I1=:=0, J1=:=1, 
          new225(A,B,C,J1,E,F,G,H,I,J,K,L,M,N,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          H1+1=<I1, H1=:=P, I1=:=0, J1=:=1, 
          new225(A,B,C,J1,E,F,G,H,I,J,K,L,M,N,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=P, M1=:=0, 
          new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=P, M1=:=0, N1=:=1, 
          new156(A,B,C,N1,E,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new176(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=P, M1=:=0, N1=:=1, 
          new156(A,B,C,N1,E,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new176(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, L1=:=D, M1=:=0, 
          new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,N1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=D, M1=:=0, 
          new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=D, M1=:=0, 
          new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1>=M1+1, L1=:=O, M1=:=0, 
          new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1+1=<M1, L1=:=O, M1=:=0, 
          new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,B,C,P,E,F,G,H,I,J,K,L,M,N) :- Q>=R+1, 
          Q=:=1, R=:=0, O=:=1, P=:=2.
new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=A, D1=:=1, 
          new164(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=A, D1=:=1, 
          new161(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=A, D1=:=1, 
          new161(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new161(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=1, D1=:=0, E1=:=1, F1=:=2, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1), 
          new167(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,F1,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=A, D1=:=0, 
          new161(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=A, D1=:=0, 
          new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=A, D1=:=0, 
          new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,C1,D1,E1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,F1,G1,H1).
new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=B, D1=:=1, 
          new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=B, D1=:=1, 
          new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=B, D1=:=1, E1=:=1, F1=:=2, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,E1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1), 
          new148(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,O,C,D,P,F,G,H,I,J,K,L,M,N) :- Q>=R+1, 
          Q=:=1, R=:=0, O=:=1, P=:=2.
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=B, D1=:=0, 
          new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=B, D1=:=0, 
          new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=B, D1=:=0, 
          new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=C, D1=:=1, 
          new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=C, D1=:=1, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=C, D1=:=1, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,O,D,E,P,G,H,I,J,K,L,M,N) :- Q>=R+1, 
          Q=:=1, R=:=0, O=:=1, P=:=2.
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=C, D1=:=0, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=C, D1=:=0, 
          new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=C, D1=:=0, 
          new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=R, L1=:=0, M1=:=N1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,N1), 
          new115(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=R, L1=:=0, M1=:=1, N1=:=O1, 
          new129(A,B,C,D,E,M1,G,H,I,J,K,L,M,N,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2), 
          new53(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,O1), 
          new115(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=R, L1=:=0, M1=:=1, N1=:=O1, 
          new129(A,B,C,D,E,M1,G,H,I,J,K,L,M,N,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2), 
          new53(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,O1), 
          new115(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=F, L1=:=0, 
          new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,M1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=F, L1=:=0, M1=:=N1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,N1), 
          new115(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=F, L1=:=0, M1=:=N1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,N1), 
          new115(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,M1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=Q, L1=:=0, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=Q, L1=:=0, M1=:=1, 
          new143(A,B,C,D,M1,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new122(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=Q, L1=:=0, M1=:=1, 
          new143(A,B,C,D,M1,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new122(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=E, L1=:=0, 
          new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=E, L1=:=0, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=E, L1=:=0, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=P, L1=:=0, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=P, L1=:=0, M1=:=1, 
          new156(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new119(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=P, L1=:=0, M1=:=1, 
          new156(A,B,C,M1,E,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new119(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, K1=:=D, L1=:=0, 
          new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,M1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, L1=:=0, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=D, L1=:=0, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          S=:=T, S=:=O, T=:=0.
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=O, L1=:=0, 
          new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1+1=<L1, K1=:=O, L1=:=0, 
          new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=E, G1=:=0, 
          new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=E, G1=:=0, 
          new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q=:=R, 
          Q=:=F, R=:=0, P=:=1.
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q>=R+1, 
          Q=:=F, R=:=0, P=:=0.
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q+1=<R, 
          Q=:=F, R=:=0, P=:=0.
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q=:=R, 
          Q=:=E, R=:=0, P=:=1.
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=E, F1=:=0, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=E, F1=:=0, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R>=S+1, R=:=O, S=:=0, Q=:=0.
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R+1=<S, R=:=O, S=:=0, Q=:=0.
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q) :- 
          R=:=S, R=:=O, S=:=0, Q=:=1.
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          D1=:=M, E1=:=1, F1=:=2, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,F1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=1, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=1, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          D1=:=L, E1=:=1, F1=:=2, 
          new94(A,B,C,D,E,F,G,H,I,J,K,F1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=L, E1=:=1, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=L, E1=:=1, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          D1=:=K, E1=:=1, F1=:=2, 
          new91(A,B,C,D,E,F,G,H,I,J,F1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=K, E1=:=1, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=K, E1=:=1, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,O) :- P=:=Q, P=:=N, 
          Q=:=1, O=:=2.
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O>=P+1, 
          O=:=N, P=:=1.
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O+1=<P, 
          O=:=N, P=:=1.
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=M, D1=:=1, E1=:=2, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=M, D1=:=1, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=M, D1=:=1, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=L, D1=:=1, E1=:=2, 
          new82(A,B,C,D,E,F,G,H,I,J,K,E1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=L, D1=:=1, 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=L, D1=:=1, 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=K, D1=:=1, E1=:=2, 
          new79(A,B,C,D,E,F,G,H,I,J,E1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=K, D1=:=1, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=K, D1=:=1, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=J, D1=:=1, E1=:=2, 
          new76(A,B,C,D,E,F,G,H,I,E1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=J, D1=:=1, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=J, D1=:=1, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          D1=:=J, E1=:=1, F1=:=2, 
          new88(A,B,C,D,E,F,G,H,I,F1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=J, E1=:=1, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=J, E1=:=1, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=K1, J1=:=Q, K1=:=0, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,H1), 
          new102(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,G1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,O,K,L,M,N) :- O=:=1.
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,O,P) :- 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,F1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,G1).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1) :- 
          H1=:=I1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,I1), 
          new105(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,H1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1=:=I1, H1=:=P, I1=:=0, G1=:=4, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q) :- 
          G1>=H1+1, G1=:=P, H1=:=0, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,J1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,K1,L1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q) :- 
          G1+1=<H1, G1=:=P, H1=:=0, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,I1,J1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,K1,L1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1=:=I1, H1=:=P, I1=:=0, G1=:=4, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1), 
          new21(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,A2,B2,C2).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1>=K1+1, J1=:=P, K1=:=0, L1=:=M1, 
          new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,M1), 
          new68(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,O,P,L1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1+1=<K1, J1=:=P, K1=:=0, L1=:=M1, 
          new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,M1), 
          new68(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,O,P,L1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1=:=I1, H1=:=P, I1=:=0, G1=:=4, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1), 
          new22(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2), 
          new70(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1=:=I1, H1=:=P, I1=:=0, G1=:=4, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1), 
          new22(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2), 
          new71(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3), 
          new60(R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,H3,I3).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=K1, J1=:=P, K1=:=0, L1=:=4, M1=:=N1, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2), 
          new22(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2), 
          new71(F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3), 
          new61(W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,N1), 
          new68(M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,L1,P,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,P) :- Q=:=R, 
          Q=:=D, R=:=0, P=:=1.
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, F1=:=0, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=D, F1=:=0, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=D, G1=:=0, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=D, G1=:=0, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1=:=L1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,L1), 
          new115(N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,K1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,O,P,Q,R) :- 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,H1,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,I1).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1) :- 
          L1=:=M1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,M1), 
          new172(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,L1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1>=I1+1, H1=:=1, I1=:=0, G1=:=1, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,J1,K1,L1,M1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,N1,O1,P1,Q1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1>=I1+1, H1=:=1, I1=:=0, J1=:=1, G1=:=2, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2), 
          new6(O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1>=I1+1, H1=:=1, I1=:=0, J1=:=1, K1=:=2, G1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new7(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2), 
          new17(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1>=I1+1, H1=:=1, I1=:=0, J1=:=1, K1=:=2, G1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new7(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2), 
          new18(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3), 
          new21(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,M3,N3,O3).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1>=I1+1, H1=:=1, I1=:=0, J1=:=1, K1=:=2, G1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new7(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2), 
          new18(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3), 
          new22(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4), 
          new24(M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          H1>=I1+1, H1=:=1, I1=:=0, J1=:=1, K1=:=2, G1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new7(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2), 
          new18(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3), 
          new22(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4), 
          new25(M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4), 
          new52(D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,S4).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1>=K1+1, J1=:=1, K1=:=0, L1=:=1, M1=:=2, N1=:=3, O1=:=P1, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2), 
          new7(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2), 
          new18(M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3), 
          new22(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4), 
          new25(R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4), 
          new53(I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,P1), 
          new54(X4,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,N1,O1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=J, D1=:=1, E1=:=2, 
          new242(A,B,C,D,E,F,G,H,I,E1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=J, D1=:=1, 
          new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=J, D1=:=1, 
          new242(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          D1=:=J, E1=:=1, F1=:=2, 
          new254(A,B,C,D,E,F,G,H,I,F1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=J, E1=:=1, 
          new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=J, E1=:=1, 
          new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1) :- 
          I1=:=J1, 
          new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,J1), 
          new267(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,O,P,Q) :- 
          new283(A,B,C,D,E,F,G,H,I,J,K,L,M,N,G1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,H1).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=K1, 
          new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,K1), 
          new285(M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=J, D1=:=0, E1=:=1, 
          new307(A,B,C,D,E,F,G,H,I,E1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=J, D1=:=0, 
          new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=J, D1=:=0, 
          new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          D1=:=J, E1=:=0, F1=:=1, 
          new319(A,B,C,D,E,F,G,H,I,F1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=J, E1=:=0, 
          new319(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=J, E1=:=0, 
          new319(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=G, D1=:=1, E1=:=0, 
          new331(A,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=G, D1=:=1, E1=:=2, 
          new331(A,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=G, D1=:=1, E1=:=2, 
          new331(A,B,C,E1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          D1=:=G, E1=:=1, F1=:=0, 
          new337(A,B,C,F1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=G, E1=:=1, F1=:=2, 
          new337(A,B,C,F1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=G, E1=:=1, F1=:=2, 
          new337(A,B,C,F1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,N).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          G1=:=0, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          G1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new12(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          G1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new13(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2), 
          new17(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          G1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new13(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2), 
          new18(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2), 
          new21(J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,A3,B3,C3).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,P,Q) :- 
          G1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new13(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2), 
          new18(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2), 
          new22(J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3), 
          new24(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1) :- 
          J1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1), 
          new13(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2), 
          new18(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2), 
          new22(M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3), 
          new25(D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4), 
          new26(U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,O,P,Q,J,K,L,M,N) :- O=:=1, P=:=1, 
          Q=:=1.
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,O) :- 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,O) :- 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1), 
          new5(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,V1,W1,X1).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=0, H=:=0, I=:=0, J=:=2, 
          K=:=2, L=:=2, M=:=2, N=:=2, 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
correct :- \+new1.
