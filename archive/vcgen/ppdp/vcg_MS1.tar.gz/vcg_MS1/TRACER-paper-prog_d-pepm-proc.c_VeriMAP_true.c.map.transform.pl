new8(A,B,13,A,B) :- C+1=<D, C=:=E+F, E=:=A, F=:=B, D=:=10000.
new5(A,B,C,D,E) :- new5(A,B,C,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=10000, H=:=I+J, I=:=A, J=:=1, K=:=L+M, 
          L=:=B, M=:=1, new4(H,K,C,D,E).
new4(A,B,C,D,E) :- F>=G, F=:=B, G=:=10000, new8(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G, F=:=A, G=:=0, new4(A,B,C,D,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0, new5(A,B,C,D,E).
new2(A,B,C,D,E) :- F=:=0, new3(A,F,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
