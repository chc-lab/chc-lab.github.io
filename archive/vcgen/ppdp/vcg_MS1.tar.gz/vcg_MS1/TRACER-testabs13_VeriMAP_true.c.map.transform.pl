new6(A,B,10,A,B).
new5(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=10, new6(A,B,C,D,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=A, H=:=I+J, I=:=B, J=:=1, new3(A,H,C,D,E).
new3(A,B,C,D,E) :- F>=G, F=:=B, G=:=A, new5(A,B,C,D,E).
new2(A,B,C,D,E) :- F=:=0, G=:=10, new3(G,F,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
