new60(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, P=:=Q+R, Q=:=E, R=:=1, 
          new15(A,B,C,D,P,F,G,H,I,J,K,L,M).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,M).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, P=:=Q+R, Q=:=F, R=:=1, 
          new30(A,B,C,D,E,P,G,H,I,J,K,L,M).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=E, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=E, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=B, 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, P=:=Q+R, Q=:=F, R=:=1, 
          new33(A,B,C,D,E,P,G,H,I,J,K,L,M).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, 
          new44(A,B,C,D,E,F,G,H,I,J,K,L,M).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, 
          new42(A,B,C,D,E,F,G,H,I,J,K,L,M).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=E, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=E, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=B, 
          new38(A,B,C,D,E,F,G,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=F, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=F, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=B, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=B, P=:=Q+R, Q=:=E, 
          R=:=1, new29(A,B,C,D,P,F,G,H,I,J,K,L,M).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=F, 
          new48(A,B,C,D,E,F,G,H,I,J,K,L,M).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=F, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=B, 
          new32(A,B,C,D,E,F,G,H,I,J,K,L,M).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=B, P=:=C, 
          new33(A,B,C,D,E,P,G,H,I,J,K,L,M).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, P=:=C, 
          new30(A,B,C,D,E,P,G,H,I,J,K,L,M).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, P=:=C, 
          new17(A,B,C,D,P,F,G,H,I,J,K,L,M).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=E, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=E, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, P=:=Q+R, Q=:=E, R=:=1, 
          new17(A,B,C,D,P,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=E, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=E, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, P=:=C, 
          new29(A,B,C,D,P,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, P=:=D, Q=:=R-S, R=:=D, 
          S=:=1, new3(A,B,P,Q,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,114,A,B,C,D,E,F).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, P=:=C, 
          new15(A,B,C,D,P,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, P=:=C, 
          new15(A,B,C,D,P,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, P=:=C, 
          new17(A,B,C,D,P,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=B, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=B, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=1, P=:=Q+R, Q=:=D, R=:=1, 
          new4(A,B,P,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=B, new3(A,B,C,N,E,F,G,H,I,J,K,L,M).
new1 :- A=:=0, new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
