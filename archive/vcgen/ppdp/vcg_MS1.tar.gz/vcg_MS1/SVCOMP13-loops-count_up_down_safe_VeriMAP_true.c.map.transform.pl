new7(A,B,C,D,10,A,B,C,D).
new6(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, D>=0, K=:=A, A>=0, 
          new7(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, D>=0, K=:=A, A>=0, 
          new7(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, C>=0, K=:=0, L=:=M-N, M=:=C, C>=0, 
          N=:=1, O=:=P+Q, P=:=D, D>=0, Q=:=1, new4(A,B,L,O,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=C, C>=0, K=:=0, new6(A,B,C,D,E,F,G,H,I).
new3(A,A).
new2(A,B,C,D,E,F,G,H,I) :- J=:=K, K>=0, L=:=J, J>=0, M=:=L, L>=0, N=:=0, 
          new3(O,K), new4(L,J,M,N,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
