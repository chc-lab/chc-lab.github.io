new8(A,B,C,8,A,B,C).
new6(A,B,C,D,E,F,G) :- new6(A,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=4, new8(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=A, new5(A,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=4, J=:=4, new3(A,B,J,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=4, J=:=5, new3(J,B,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
