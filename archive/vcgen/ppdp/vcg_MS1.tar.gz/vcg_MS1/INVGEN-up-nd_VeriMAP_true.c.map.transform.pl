new8(A,B,C,D,E,18,A,B,C,D,E).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=D, M=:=0, new8(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=0, N=:=O+P, O=:=E, P=:=1, 
          Q=:=R-S, R=:=D, S=:=1, new6(A,B,C,Q,N,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=A, 
          new7(A,B,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=O+P, O=:=D, P=:=B, 
          new3(A,B,C,N,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=B, M=:=0, N=:=O+P, O=:=D, P=:=1, 
          new3(A,B,C,N,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=A, N=:=O+P, O=:=C, P=:=1, 
          new4(A,B,N,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=A, N=:=O+P, O=:=C, P=:=1, 
          new5(A,Q,N,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=A, N=:=0, 
          new6(A,B,C,D,N,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=0, new3(A,B,L,M,E,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
