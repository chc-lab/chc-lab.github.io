new10(A,B,C,D,E,F,22,A,B,C,D,E,F).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=P+Q, P=:=B, Q=:=C, O=:=R+S, 
          R=:=T+U, T=:=E, U=:=D, S=:=F, V=:=W+X, W=:=D, X=:=1, 
          new5(A,B,C,V,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=P+Q, P=:=B, Q=:=C, O=:=R+S, 
          R=:=T+U, T=:=E, U=:=D, S=:=F, new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=P+Q, P=:=E, Q=:=F, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=P+Q, P=:=E, Q=:=F, R=:=S+T, 
          S=:=C, T=:=1, new4(A,B,R,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=E, P=:=C, 
          new5(A,B,C,P,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=E, P=:=Q+R, Q=:=B, R=:=1, 
          new3(A,P,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=B, O=:=E, P=:=0, 
          new4(A,B,P,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=F, P=:=0, 
          new3(A,P,C,D,E,F,G,H,I,J,K,L,M).
new1 :- A=:=0, new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
