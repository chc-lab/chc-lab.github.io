new12(A,B,C,D,16,A,B,C,D).
new8(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=C, L=:=M+N, M=:=A, N=:=1, 
          new8(L,B,C,D,E,F,G,H,I).
new8(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=A, K=:=C, L=:=M+N, M=:=B, N=:=1, 
          new3(A,L,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=1, K=:=B, L=:=M+N, M=:=A, N=:=1, 
          new6(L,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=1, K=:=B, new12(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=C, new7(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=A, K=:=C, L=:=D, new8(L,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- new4(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=B, K=:=C, L=:=D, new6(L,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, L=:=1, new3(A,L,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=D, K=:=0, new4(A,B,C,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
