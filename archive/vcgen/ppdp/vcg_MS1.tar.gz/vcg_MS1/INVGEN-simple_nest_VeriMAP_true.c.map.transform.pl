new8(A,B,C,D,E,F,G) :- new3(A,B,C,D,E,F,G).
new6(A,B,C,16,A,B,C).
new5(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=0, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=0, J=:=K-L, K=:=B, L=:=1, M=:=N*O, 
          N=:=2, O=:=C, new4(A,J,M,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=0, new8(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=A, new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=A, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=1, I=:=10, new3(A,I,H,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
