new12(A,B,C,D,E,F,22,A,B,C,D,E,F).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=0, P=:=Q-R, Q=:=D, R=:=1, 
          S=:=T+U, T=:=F, U=:=1, V=:=W+X, W=:=P, X=:=S, 
          new9(A,V,C,P,E,S,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=0, P=:=Q-R, Q=:=C, R=:=1, 
          S=:=T+U, T=:=E, U=:=1, V=:=W+X, W=:=P, X=:=S, 
          new6(A,V,P,D,S,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=C, O=:=0, P=:=E, Q=:=0, R=:=S+T, 
          S=:=P, T=:=Q, new9(A,R,C,P,E,Q,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=A, O=:=200, P=:=0, Q=:=A, R=:=S+T, 
          S=:=Q, T=:=P, new6(A,R,Q,D,P,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=200, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=A, O=:=0, 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
