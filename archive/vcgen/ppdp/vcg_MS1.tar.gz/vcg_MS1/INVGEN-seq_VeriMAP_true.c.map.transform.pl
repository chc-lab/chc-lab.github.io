new9(A,B,C,D,E,F,23,A,B,C,D,E,F).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=0, P=:=Q+R, Q=:=F, R=:=1, 
          S=:=T-U, T=:=D, U=:=1, new7(A,B,C,S,E,P,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=F, O=:=P+Q, P=:=A, Q=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=B, P=:=Q+R, Q=:=E, R=:=1, 
          S=:=T+U, T=:=D, U=:=1, new5(A,B,C,S,P,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=E, O=:=B, P=:=0, 
          new7(A,B,C,D,E,P,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=A, P=:=Q+R, Q=:=C, R=:=1, 
          S=:=T+U, T=:=D, U=:=1, new3(A,B,P,S,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=A, P=:=0, 
          new5(A,B,C,D,P,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=0, O=:=0, 
          new3(A,B,N,O,E,F,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
