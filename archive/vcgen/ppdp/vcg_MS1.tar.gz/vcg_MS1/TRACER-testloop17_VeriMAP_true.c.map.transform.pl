new9(A,B,C,D,15,A,B,C,D).
new8(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, new9(A,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=B, K=:=1, L=:=1, M=:=N+O, N=:=C, O=:=1, 
          P=:=Q+R, Q=:=B, R=:=1, new4(A,P,M,L,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=B, K=:=1, L=:=0, M=:=N+O, N=:=C, O=:=1, 
          P=:=Q+R, Q=:=B, R=:=1, new4(A,P,M,L,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- new5(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=B, K=:=A, new7(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=B, K=:=A, new8(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=1, new4(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=A, K=:=1, new5(A,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=0, K=:=0, L=:=0, new3(A,J,K,L,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
