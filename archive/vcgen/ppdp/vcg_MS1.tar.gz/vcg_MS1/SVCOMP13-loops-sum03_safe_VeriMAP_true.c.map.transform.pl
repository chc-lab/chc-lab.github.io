new14(A,B,C,D,E,F,8,A,B,C,D,E,F).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, P=:=Q+R, Q=:=A, R=:=2, 
          S=:=T+U, T=:=F, F>=0, U=:=1, new6(P,B,C,D,E,S,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, P=:=A, N=:=18446744073709551616+P, 
          P+1=<0, O=:=Q*R, Q=:=F, F>=0, R=:=2, S=:=T+U, T=:=A, U=:=2, V=:=W+X, 
          W=:=F, F>=0, X=:=1, new6(S,B,C,D,E,V,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, P=:=A, N=:=P, P>=0, O=:=Q*R, Q=:=F, 
          F>=0, R=:=2, S=:=T+U, T=:=A, U=:=2, V=:=W+X, W=:=F, F>=0, X=:=1, 
          new6(S,B,C,D,E,V,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, P=:=A, N=:=18446744073709551616+P, 
          P+1=<0, O=:=Q*R, Q=:=F, F>=0, R=:=2, new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, P=:=A, N=:=18446744073709551616+P, 
          P+1=<0, O=:=Q*R, Q=:=F, F>=0, R=:=2, new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, P=:=A, N=:=P, P>=0, O=:=Q*R, Q=:=F, 
          F>=0, R=:=2, new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, P=:=A, N=:=P, P>=0, O=:=Q*R, Q=:=F, 
          F>=0, R=:=2, new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=0, P=:=Q+R, Q=:=A, R=:=2, 
          S=:=T+U, T=:=F, F>=0, U=:=1, new6(P,B,C,D,E,S,G,H,I,J,K,L,M).
new3(A,A).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=0, O=:=P, P>=0, Q=:=O, O>=0, R=:=S, 
          S>=0, T=:=R, R>=0, U=:=0, new3(V,P), new3(W,S), 
          new5(N,Q,O,T,R,U,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
