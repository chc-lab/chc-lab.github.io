new9(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=0, new8(A,B,C,D,E).
new8(A,B,14,A,B).
new7(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=100, new8(A,B,C,D,E).
new7(A,B,C,D,E) :- F=<G, F=:=A, G=:=100, new9(A,B,C,D,E).
new4(A,B,C,D,E) :- new4(A,B,C,D,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=100, H=:=I+J, I=:=B, J=:=1, K=:=L+M, 
          L=:=A, M=:=1, new3(K,H,C,D,E).
new3(A,B,C,D,E) :- F>=G, F=:=A, G=:=100, new7(A,B,C,D,E).
new2(A,B,C,D,E) :- F>=G, F=:=B, G=:=0, H=:=0, new3(H,B,C,D,E).
new2(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=0, new4(A,B,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
