new263(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,M,E,F,G,H,I,J,K,L) :- N=:=O, N=:=F, O=:=1, 
          M=:=0.
new263(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,M,E,F,G,H,I,J,K,L) :- N>=O+1, N=:=F, 
          O=:=1, M=:=2.
new263(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,M,E,F,G,H,I,J,K,L) :- N+1=<O, N=:=F, 
          O=:=1, M=:=2.
new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=I, 
          A1=:=0, B1=:=1, 
          new260(A,B,C,D,E,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=I, 
          A1=:=0, new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=I, 
          A1=:=0, new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=H, 
          A1=:=0, B1=:=1, 
          new257(A,B,C,D,E,F,G,B1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=H, 
          A1=:=0, new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=H, 
          A1=:=0, new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new251(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,M,K,L) :- N=:=O, N=:=J, O=:=0, 
          M=:=1.
new251(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=J, N=:=0.
new251(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=J, N=:=0.
new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=I, Z=:=0, 
          A1=:=1, new251(A,B,C,D,E,F,G,H,A1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=I, 
          Z=:=0, new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=I, 
          Z=:=0, new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=H, Z=:=0, 
          A1=:=1, new248(A,B,C,D,E,F,G,A1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=H, 
          Z=:=0, new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=H, 
          Z=:=0, new248(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new234(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=B, C1=:=1, 
          new243(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- B1>=C1+1, 
          B1=:=M, C1=:=0, D1=:=0, 
          new234(A,B,D1,D,E,F,G,H,I,J,K,L,E1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,F1).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- B1+1=<C1, 
          B1=:=M, C1=:=0, D1=:=0, 
          new234(A,B,D1,D,E,F,G,H,I,J,K,L,E1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,F1).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- B1=:=C1, 
          B1=:=M, C1=:=0, 
          new234(A,B,C,D,E,F,G,H,I,J,K,L,D1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,E1).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=0, F1=:=0, G1=:=H1, 
          new223(A,B,F1,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,H1), 
          new240(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,M,G1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=0, F1=:=0, G1=:=H1, 
          new223(A,B,F1,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,H1), 
          new240(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,M,G1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new233(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=M, E1=:=0, F1=:=G1, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,G1), 
          new240(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new231(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=A, C1=:=1, 
          new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O=:=P, O=:=I, 
          P=:=1, N=:=1.
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=I, 
          P=:=1, N=:=0.
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=I, 
          P=:=1, N=:=0.
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O=:=P, O=:=J, 
          P=:=1, N=:=1.
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=J, 
          P=:=1, N=:=0.
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=J, 
          P=:=1, N=:=0.
new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,O,E,F,G,H,I,J,K,L,M,N) :- P>=Q+1, 
          P=:=N, Q=:=0, O=:=0.
new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,O,E,F,G,H,I,J,K,L,M,N) :- P+1=<Q, 
          P=:=N, Q=:=0, O=:=0.
new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- O=:=P, 
          O=:=N, P=:=0.
new223(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=B, 
          P=:=1, N=:=0.
new223(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=B, 
          P=:=1, N=:=0.
new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=B, 
          B1=:=1, new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=M, D1=:=0, E1=:=0, F1=:=G1, 
          new223(A,B,E1,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,G1), 
          new226(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=M, D1=:=0, E1=:=0, F1=:=G1, 
          new223(A,B,E1,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,G1), 
          new226(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=M, D1=:=0, E1=:=F1, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1), 
          new226(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,M,E1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new221(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=A, 
          P=:=1, N=:=0.
new221(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=A, 
          P=:=1, N=:=0.
new221(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=A, 
          B1=:=1, new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=I, 
          A1=:=1, B1=:=2, 
          new218(A,B,C,D,E,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=I, 
          A1=:=1, new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=I, 
          A1=:=1, new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new212(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=H, 
          A1=:=1, B1=:=2, 
          new215(A,B,C,D,E,F,G,B1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new212(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=H, 
          A1=:=1, new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new212(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=H, 
          A1=:=1, new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new209(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,M,K,L) :- N=:=O, N=:=J, O=:=1, 
          M=:=2.
new209(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=J, N=:=1.
new209(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=J, N=:=1.
new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=I, Z=:=1, 
          A1=:=2, new209(A,B,C,D,E,F,G,H,A1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=I, 
          Z=:=1, new209(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=I, 
          Z=:=1, new209(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=H, Z=:=1, 
          A1=:=2, new206(A,B,C,D,E,F,G,A1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=H, 
          Z=:=1, new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=H, 
          Z=:=1, new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new199(A,B,C,D,E,F,G,H,I,J,K,L,13,A,B,C,D,E,F,G,H,I,J,K,L).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=K, 
          A1=:=B1+C1, B1=:=L, C1=:=1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=K, 
          A1=:=B1+C1, B1=:=L, C1=:=1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=K, 
          A1=:=B1+C1, B1=:=L, C1=:=1, 
          new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=A, 
          A1=:=1, new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=A, 
          A1=:=1, new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=A, 
          A1=:=1, new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=1, 
          A1=:=0, B1=:=C1, D1=:=1, 
          new180(A,B,C,D,E,F,G,H,I,D1,C1,B1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=A, 
          A1=:=0, new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=A, 
          A1=:=0, new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=A, 
          A1=:=0, new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,Z,A1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,B1,C1).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=B, 
          A1=:=1, B1=:=C1+D1, C1=:=K, D1=:=1, E1=:=1, 
          new180(A,B,C,D,E,F,G,H,E1,J,B1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=B, 
          A1=:=1, new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=1, new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=B, 
          A1=:=1, B1=:=C1+D1, C1=:=K, D1=:=1, E1=:=1, F1=:=2, 
          new127(A,B,C,D,E,F,G,H,E1,J,B1,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1), 
          new177(G1,H1,I1,J1,K1,L1,M1,N1,F1,P1,Q1,R1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=B, 
          A1=:=0, new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=B, 
          A1=:=0, new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new162(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=B, 
          A1=:=0, new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1>=D1+1, C1=:=O, D1=:=0, E1=:=1, 
          new162(A,B,C,E1,E,F,G,H,I,J,K,L,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1+1=<D1, C1=:=O, D1=:=0, E1=:=1, 
          new162(A,B,C,E1,E,F,G,H,I,J,K,L,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1=:=D1, C1=:=O, D1=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,E1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,F1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1>=D1+1, C1=:=O, D1=:=0, E1=:=1, 
          new116(A,B,C,E1,E,F,G,H,I,J,K,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1), 
          new52(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,S1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1+1=<D1, C1=:=O, D1=:=0, E1=:=1, 
          new116(A,B,C,E1,E,F,G,H,I,J,K,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1), 
          new52(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,S1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=O, G1=:=0, H1=:=I1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,I1), 
          new149(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,H1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=O, G1=:=0, H1=:=1, I1=:=J1, 
          new116(A,B,C,H1,E,F,G,H,I,J,K,L,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1), 
          new53(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J1), 
          new149(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,I1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=O, G1=:=0, H1=:=1, I1=:=J1, 
          new116(A,B,C,H1,E,F,G,H,I,J,K,L,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1), 
          new53(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J1), 
          new149(X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,I1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=D, G1=:=0, 
          new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,H1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1>=D1+1, C1=:=D, D1=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,E1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,F1).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1+1=<D1, C1=:=D, D1=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,E1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,F1).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=D, G1=:=0, H1=:=I1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,I1), 
          new149(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,H1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=D, G1=:=0, H1=:=I1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,I1), 
          new149(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,H1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1>=D1+1, C1=:=N, D1=:=0, E1=:=1, 
          new186(A,B,E1,D,E,F,G,H,I,J,K,L,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1+1=<D1, C1=:=N, D1=:=0, E1=:=1, 
          new186(A,B,E1,D,E,F,G,H,I,J,K,L,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=N, G1=:=0, 
          new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=N, G1=:=0, H1=:=1, 
          new132(A,B,H1,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1), 
          new153(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=N, G1=:=0, H1=:=1, 
          new132(A,B,H1,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1), 
          new153(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=C, G1=:=0, 
          new152(A,B,C,D,E,F,G,H,I,J,K,L,M,H1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=C, G1=:=0, 
          new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=C, G1=:=0, 
          new153(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=M, G1=:=0, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new149(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=M, G1=:=0, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=K, 
          Z=:=A1+B1, A1=:=L, B1=:=1, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=A, Z=:=1, 
          new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=A, 
          Z=:=1, new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=A, 
          Z=:=1, new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=1, 
          Z=:=0, A1=:=B1, C1=:=1, V=:=2, M=:=1, O=:=2, 
          new127(A,B,C,D,E,F,G,H,I,C1,B1,A1,D1,N,E1,P,Q,R,S,T,U,F1,W,X).
new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=A, Z=:=0, 
          new137(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=A, 
          Z=:=0, new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=A, 
          Z=:=0, new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,Y,Z,M,N,O,P,Q,R,S,T,U,V,W,X,A1,B1).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=B, 
          Z=:=1, new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=B, 
          Z=:=1, new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=B, Z=:=1, 
          A1=:=B1+C1, B1=:=K, C1=:=1, D1=:=1, E1=:=2, 
          new127(A,B,C,D,E,F,G,H,D1,J,A1,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1), 
          new124(F1,G1,H1,I1,J1,K1,L1,M1,E1,O1,P1,Q1,M,N,O,P,Q,R,S,T,U,V,W,X).
new124(A,B,C,D,E,F,G,H,I,J,K,L,A,M,C,N,E,F,G,H,I,J,K,L) :- O>=P+1, O=:=1, 
          P=:=0, M=:=1, N=:=2.
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=B, Z=:=0, 
          new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=B, 
          Z=:=0, new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=B, 
          Z=:=0, new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=O, F1=:=0, G1=:=H1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,H1), 
          new105(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,G1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=O, F1=:=0, G1=:=1, H1=:=I1, 
          new116(A,B,C,G1,E,F,G,H,I,J,K,L,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new53(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I1), 
          new105(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,H1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=O, F1=:=0, G1=:=1, H1=:=I1, 
          new116(A,B,C,G1,E,F,G,H,I,J,K,L,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new53(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I1), 
          new105(W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,H1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=D, F1=:=0, 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,G1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, F1=:=0, G1=:=H1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,H1), 
          new105(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,G1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=D, F1=:=0, G1=:=H1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,H1), 
          new105(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,G1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=N, F1=:=0, 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=N, F1=:=0, G1=:=1, 
          new132(A,B,G1,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1), 
          new109(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=N, F1=:=0, G1=:=1, 
          new132(A,B,G1,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1), 
          new109(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=C, F1=:=0, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M,G1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=C, F1=:=0, 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=C, F1=:=0, 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, 
          P=:=M, Q=:=0.
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=M, F1=:=0, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=M, F1=:=0, 
          new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O=:=P, O=:=D, 
          P=:=0, N=:=1.
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O>=P+1, O=:=D, 
          P=:=0, N=:=0.
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O+1=<P, O=:=D, 
          P=:=0, N=:=0.
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,O) :- P>=Q+1, 
          P=:=M, Q=:=0, O=:=0.
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,O) :- P+1=<Q, 
          P=:=M, Q=:=0, O=:=0.
new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A,B,C,D,E,F,G,H,I,J,K,L,M,O) :- P=:=Q, P=:=M, 
          Q=:=0, O=:=1.
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=I, 
          A1=:=1, B1=:=2, 
          new91(A,B,C,D,E,F,G,H,B1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=I, 
          A1=:=1, new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=I, 
          A1=:=1, new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=H, 
          A1=:=1, B1=:=2, 
          new88(A,B,C,D,E,F,G,B1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=H, 
          A1=:=1, new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=H, 
          A1=:=1, new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new82(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,M,K,L) :- N=:=O, N=:=J, O=:=1, 
          M=:=2.
new82(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=J, N=:=1.
new82(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=J, N=:=1.
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=I, Z=:=1, 
          A1=:=2, new82(A,B,C,D,E,F,G,H,A1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=I, Z=:=1, 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=I, Z=:=1, 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=H, Z=:=1, 
          A1=:=2, new79(A,B,C,D,E,F,G,A1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=H, Z=:=1, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=H, Z=:=1, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=G, Z=:=1, 
          A1=:=2, new76(A,B,C,D,E,F,A1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=G, Z=:=1, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=G, Z=:=1, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=G, 
          A1=:=1, B1=:=2, 
          new85(A,B,C,D,E,F,B1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=G, 
          A1=:=1, new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=G, 
          A1=:=1, new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=O, G1=:=0, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1), 
          new96(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new56(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,M,H,I,J,K,L) :- M=:=1.
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,B1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,E1), 
          new99(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,D1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1=:=E1, D1=:=N, E1=:=0, C1=:=4, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1>=D1+1, C1=:=N, D1=:=0, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,G1,H1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          C1+1=<D1, C1=:=N, D1=:=0, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,G1,H1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1=:=E1, D1=:=N, E1=:=0, C1=:=4, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1), 
          new21(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,T1,U1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=N, G1=:=0, H1=:=I1, 
          new61(A,B,C,D,E,F,G,H,I,J,K,L,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,I1), 
          new68(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,M,N,H1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=N, G1=:=0, H1=:=I1, 
          new61(A,B,C,D,E,F,G,H,I,J,K,L,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,I1), 
          new68(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,M,N,H1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1=:=E1, D1=:=N, E1=:=0, C1=:=4, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1), 
          new22(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new70(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1=:=E1, D1=:=N, E1=:=0, C1=:=4, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1), 
          new22(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2), 
          new71(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2), 
          new60(H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,V2,W2).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=N, G1=:=0, H1=:=4, I1=:=J1, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1), 
          new22(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2), 
          new71(Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2), 
          new61(M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,J1), 
          new68(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,H1,N,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,A,B,C,D,E,F,G,H,I,J,K,L,N) :- O=:=P, O=:=C, 
          P=:=0, N=:=1.
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, A1=:=C, 
          B1=:=0, new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, A1=:=C, 
          B1=:=0, new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=C, C1=:=0, 
          new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=C, C1=:=0, 
          new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,F1), 
          new105(H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,M,N,O) :- 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,C1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,D1).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, 
          new53(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,G1), 
          new149(I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,F1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1>=E1+1, D1=:=1, E1=:=0, C1=:=1, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,I1,J1,K1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1>=E1+1, D1=:=1, E1=:=0, F1=:=1, C1=:=2, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1), 
          new6(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1>=E1+1, D1=:=1, E1=:=0, F1=:=1, G1=:=2, C1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1), 
          new7(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2), 
          new17(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1>=E1+1, D1=:=1, E1=:=0, F1=:=1, G1=:=2, C1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1), 
          new7(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2), 
          new18(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2), 
          new21(L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,Z2,A3).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1>=E1+1, D1=:=1, E1=:=0, F1=:=1, G1=:=2, C1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1), 
          new7(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2), 
          new18(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2), 
          new22(L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3), 
          new24(Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          D1>=E1+1, D1=:=1, E1=:=0, F1=:=1, G1=:=2, C1=:=3, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1), 
          new7(K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2), 
          new18(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2), 
          new22(L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3), 
          new25(Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3), 
          new52(N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,A4).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=1, G1=:=0, H1=:=1, I1=:=2, J1=:=3, K1=:=L1, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2), 
          new7(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2), 
          new18(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3), 
          new22(Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3), 
          new25(E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4), 
          new53(S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,L1), 
          new54(F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,J1,K1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=G, Z=:=1, 
          A1=:=2, new203(A,B,C,D,E,F,A1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=G, Z=:=1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=G, Z=:=1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=G, 
          A1=:=1, B1=:=2, 
          new212(A,B,C,D,E,F,B1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=G, 
          A1=:=1, new212(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=G, 
          A1=:=1, new212(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          new221(A,B,C,D,E,F,G,H,I,J,K,L,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,D1), 
          new222(F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,C1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,M,N) :- 
          new231(A,B,C,D,E,F,G,H,I,J,K,L,B1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,C1).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=:=E1, 
          new221(A,B,C,D,E,F,G,H,I,J,K,L,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,E1), 
          new233(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,D1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=G, Z=:=0, 
          A1=:=1, new245(A,B,C,D,E,F,A1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=G, Z=:=0, 
          new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=G, Z=:=0, 
          new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=G, 
          A1=:=0, B1=:=1, 
          new254(A,B,C,D,E,F,B1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=G, 
          A1=:=0, new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=G, 
          A1=:=0, new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=E, Z=:=1, 
          A1=:=0, new263(A,B,A1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=E, Z=:=1, 
          A1=:=2, new263(A,B,A1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=E, Z=:=1, 
          A1=:=2, new263(A,B,A1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=E, 
          A1=:=1, B1=:=0, 
          new266(A,B,B1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=E, 
          A1=:=1, B1=:=2, 
          new266(A,B,B1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=E, 
          A1=:=1, B1=:=2, 
          new266(A,B,B1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new7(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          C1=:=0, new6(A,B,C,D,E,F,G,H,I,J,K,L,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          C1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1), 
          new12(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          C1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1), 
          new13(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new17(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          C1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1), 
          new13(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new18(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2), 
          new21(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,P2,Q2).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,N,O) :- 
          C1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1), 
          new13(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new18(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2), 
          new22(B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3), 
          new24(P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1), 
          new13(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2), 
          new18(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2), 
          new22(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3), 
          new25(S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3), 
          new26(G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,F1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new4(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,M,N,G,H,I,J,K,L) :- M=:=1, N=:=1.
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,M) :- 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,M) :- 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1), 
          new5(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,P1,Q1,R1).
new1 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=2, H=:=2, I=:=2, J=:=2, 
          K=:=0, L=:=0, 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
correct :- \+new1.
