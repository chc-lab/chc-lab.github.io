new10(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new4(N,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,19,A,B,C,D,E).
new8(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=0, N=:=B, 
          new10(A,N,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=D, M=:=0, N=:=O+P, O=:=B, P=:=1, 
          new10(A,N,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- new5(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=10, 
          new7(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=A, M=:=10, new8(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=0, N=:=0, 
          new4(N,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=1, new3(A,L,C,D,M,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
