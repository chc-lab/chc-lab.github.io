new7(A,B,C,10,A,B,C).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=1, new7(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=B, J=:=K+L, K=:=A, L=:=1, 
          new3(J,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=B, J=:=K+L, K=:=A, L=:=1, 
          new3(J,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=B, new6(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, I=:=10, J=:=0, K=:=L+M, L=:=J, M=:=1, 
          new3(K,I,H,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
