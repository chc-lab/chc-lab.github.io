new4(A,B,3,A,B).
new3(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0, new4(A,B,C,D,E).
new2(A,B,C,D,E) :- F=:=99, G=:=0, new3(G,F,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
