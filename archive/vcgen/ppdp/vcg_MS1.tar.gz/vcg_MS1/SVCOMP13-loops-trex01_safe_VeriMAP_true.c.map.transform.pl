new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=F, S=:=0, T=:=U-V, 
          U=:=B, V=:=A, W=:=X, Y=:=Z-A1, Z=:=E, A1=:=1, 
          new10(A,T,W,D,Y,F,G,X,I,J,K,L,M,N,O,P,Q).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=F, S=:=0, T=:=U-V, 
          U=:=B, V=:=A, W=:=X, Y=:=Z-A1, Z=:=E, A1=:=1, 
          new10(A,T,W,D,Y,F,G,X,I,J,K,L,M,N,O,P,Q).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=F, S=:=0, T=:=U-V, 
          U=:=C, V=:=A, new10(A,B,T,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=C, S=:=0, T=:=U, 
          new13(A,B,C,D,E,T,U,H,I,J,K,L,M,N,O,P,Q).
new11(A,B,C,D,E,F,G,H,10,A,B,C,D,E,F,G,H).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=B, S=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S, R=:=E, S=:=1, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=E, S=:=1, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=E, S=:=D, T=:=U*V, 
          U=:=2, V=:=E, new7(A,B,C,D,T,F,G,H,I,J,K,L,M,N,O,P,Q).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S, R=:=E, S=:=D, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=1, 
          new7(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O,P,Q).
new3(A,B,C,A,B) :- D>=E+1, D=:=A, E=:=0, F=:=1, 
          new4(F,G,H,I,J,K,L,M,C,N,O,P,Q,R,S,T,U).
new3(A,B,C,A,B) :- D+1=<E, D=:=A, E=:=0, F=:=1, 
          new4(F,G,H,I,J,K,L,M,C,N,O,P,Q,R,S,T,U).
new3(A,B,C,A,B) :- D=:=E, D=:=A, E=:=0, F=:=2, 
          new4(F,G,H,I,J,K,L,M,C,N,O,P,Q,R,S,T,U).
new2(A,B,C,D,E) :- F=:=G, new3(F,G,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
