new13(A,B,C,34,A,B,C).
new12(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=0, new13(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=0, new12(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=0, new13(A,B,C,D,E,F,G).
new9(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, J=:=K-L, K=:=A, L=:=1, M=:=N-O, 
          N=:=B, O=:=1, new6(J,M,C,D,E,F,G).
new9(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=0, new11(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=K-L, K=:=A, L=:=1, M=:=N-O, 
          N=:=B, O=:=1, new6(J,M,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=0, new9(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=0, new7(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, J=:=K+L, K=:=A, L=:=1, M=:=N+O, 
          N=:=B, O=:=1, new3(J,M,P,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=0, J=:=K+L, K=:=A, L=:=1, M=:=N+O, 
          N=:=B, O=:=1, new3(J,M,P,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=:=I, H=:=C, I=:=0, new6(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, I=:=0, new3(H,I,J,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
