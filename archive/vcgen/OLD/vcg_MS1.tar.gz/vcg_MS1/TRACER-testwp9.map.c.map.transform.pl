new4(A,16,A).
new3(A,B,C) :- D+1=<E, D=:=A, E=:=5, new4(A,B,C).
new2(A,B,C) :- D>=E+1, D=:=A, E=:=10, new3(A,B,C).
new1 :- new2(A,B,C).
correct :- \+new1.
