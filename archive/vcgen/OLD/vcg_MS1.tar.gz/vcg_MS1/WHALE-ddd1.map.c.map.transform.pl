new284(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W,X,Y) :- 
          A1>=B1+1, A1=:=O, B1=:=M, Z=:=M.
new284(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,Z,T,U,V,W,X,Y) :- 
          A1=<B1, A1=:=O, B1=:=M, Z=:=O.
new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1>=W1+1, V1=:=I, W1=:=G, X1=:=1, Y1=:=0, Z1=:=1, A2=:=1, B2=:=1, 
          new280(A,B,X1,Y1,Z1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B2,A2,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1>=W1+1, V1=:=I, W1=:=G, X1=:=1, Y1=:=0, Z1=:=1, A2=:=1, B2=:=1, 
          new281(A,B,X1,Y1,Z1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B2,A2,V,C2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=<W1, V1=:=I, W1=:=G, X1=:=1, Y1=:=0, Z1=:=1, A2=:=1, B2=:=1, 
          new280(A,B,X1,Y1,Z1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B2,A2,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=<W1, V1=:=I, W1=:=G, X1=:=1, Y1=:=0, Z1=:=1, A2=:=1, B2=:=1, 
          new281(A,B,X1,Y1,Z1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,B2,A2,V,C2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=N, S1=:=0, T1=:=0, U1=:=0, 
          new269(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=N, S1=:=0, T1=:=0, U1=:=1, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=N, S1=:=0, T1=:=0, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=N, S1=:=0, T1=:=0, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=I, S1=:=G, 
          new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1, R1=:=I, S1=:=G, T1=:=0, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=N, S1=:=0, T1=:=0, U1=:=1, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,U1,O,P,Q,R,S,T1,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=N, S1=:=0, T1=:=0, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=N, S1=:=0, T1=:=0, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new264(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=I, S1=:=G, 
          new265(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new264(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=<S1, R1=:=I, S1=:=G, 
          new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=B, S1=:=0, T1=:=1, U1=:=1, 
          new276(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=B, S1=:=0, T1=:=1, U1=:=1, 
          new276(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=B, S1=:=0, T1=:=0, U1=:=0, V1=:=1, 
          new278(A,V1,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,U1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new258(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=C, S1=:=0, 
          new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new258(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=C, S1=:=0, 
          new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new258(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=C, S1=:=0, 
          new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=D, S1=:=0, 
          new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=D, S1=:=0, 
          new262(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=D, S1=:=0, 
          new264(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          X>=Y+1, X=:=V, Y=:=0, Z=:=A, A1=:=B, B1=:=C, C1=:=D, D1=:=E, E1=:=F, 
          F1=:=G, G1=:=H, H1=:=I, I1=:=J, J1=:=K, K1=:=L, L1=:=M, M1=:=N, 
          N1=:=O, O1=:=P, P1=:=Q, Q1=:=R, R1=:=S, S1=:=T, T1=:=U, 
          new113(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          X+1=<Y, X=:=V, Y=:=0, Z=:=A, A1=:=B, B1=:=C, C1=:=D, D1=:=E, E1=:=F, 
          F1=:=G, G1=:=H, H1=:=I, I1=:=J, J1=:=K, K1=:=L, L1=:=M, M1=:=N, 
          N1=:=O, O1=:=P, P1=:=Q, Q1=:=R, R1=:=S, S1=:=T, T1=:=U, 
          new113(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=X, Q2=:=Y, R2=:=Z, S2=:=A1, T2=:=B1, U2=:=C1, V2=:=D1, W2=:=E1, 
          X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, C3=:=K1, D3=:=L1, 
          E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, J3=:=R1, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4), 
          new126(P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,W,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=X, Q2=:=Y, R2=:=Z, S2=:=A1, T2=:=B1, U2=:=C1, V2=:=D1, W2=:=E1, 
          X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, C3=:=K1, D3=:=L1, 
          E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, J3=:=R1, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4), 
          new126(P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,W,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=X, Q2=:=Y, R2=:=Z, S2=:=A1, T2=:=B1, U2=:=C1, V2=:=D1, W2=:=E1, 
          X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, C3=:=K1, D3=:=L1, 
          E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, J3=:=R1, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4), 
          new126(P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,W,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=X, Q2=:=Y, R2=:=Z, S2=:=A1, T2=:=B1, U2=:=C1, V2=:=D1, W2=:=E1, 
          X2=:=F1, Y2=:=G1, Z2=:=H1, A3=:=I1, B3=:=J1, C3=:=K1, D3=:=L1, 
          E3=:=M1, F3=:=N1, G3=:=O1, H3=:=P1, I3=:=Q1, J3=:=R1, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4), 
          new126(P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,W,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5,C5,D5).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=X, G4=:=Y, H4=:=Z, I4=:=A1, J4=:=B1, K4=:=C1, L4=:=D1, M4=:=E1, 
          N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, S4=:=K1, T4=:=L1, 
          U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, Z4=:=R1, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6), 
          new138(F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,U6,V6,W,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=X, G4=:=Y, H4=:=Z, I4=:=A1, J4=:=B1, K4=:=C1, L4=:=D1, M4=:=E1, 
          N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, S4=:=K1, T4=:=L1, 
          U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, Z4=:=R1, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6), 
          new138(F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,U6,V6,W,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=X, G4=:=Y, H4=:=Z, I4=:=A1, J4=:=B1, K4=:=C1, L4=:=D1, M4=:=E1, 
          N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, S4=:=K1, T4=:=L1, 
          U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, Z4=:=R1, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6), 
          new138(F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,U6,V6,W,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=X, G4=:=Y, H4=:=Z, I4=:=A1, J4=:=B1, K4=:=C1, L4=:=D1, M4=:=E1, 
          N4=:=F1, O4=:=G1, P4=:=H1, Q4=:=I1, R4=:=J1, S4=:=K1, T4=:=L1, 
          U4=:=M1, V4=:=N1, W4=:=O1, X4=:=P1, Y4=:=Q1, Z4=:=R1, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6), 
          new138(F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,U6,V6,W,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=X, W5=:=Y, X5=:=Z, Y5=:=A1, Z5=:=B1, A6=:=C1, B6=:=D1, C6=:=E1, 
          D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, I6=:=K1, J6=:=L1, 
          K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, P6=:=R1, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new24(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9), 
          new126(V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,W,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=X, W5=:=Y, X5=:=Z, Y5=:=A1, Z5=:=B1, A6=:=C1, B6=:=D1, C6=:=E1, 
          D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, I6=:=K1, J6=:=L1, 
          K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, P6=:=R1, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new25(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9), 
          new126(V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,W,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=X, W5=:=Y, X5=:=Z, Y5=:=A1, Z5=:=B1, A6=:=C1, B6=:=D1, C6=:=E1, 
          D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, I6=:=K1, J6=:=L1, 
          K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, P6=:=R1, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new24(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9), 
          new126(V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,W,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=X, W5=:=Y, X5=:=Z, Y5=:=A1, Z5=:=B1, A6=:=C1, B6=:=D1, C6=:=E1, 
          D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, I6=:=K1, J6=:=L1, 
          K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, P6=:=R1, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new25(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9), 
          new126(V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,W,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=X, W5=:=Y, X5=:=Z, Y5=:=A1, Z5=:=B1, A6=:=C1, B6=:=D1, C6=:=E1, 
          D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, I6=:=K1, J6=:=L1, 
          K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, P6=:=R1, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new24(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9), 
          new126(V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,W,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=X, W5=:=Y, X5=:=Z, Y5=:=A1, Z5=:=B1, A6=:=C1, B6=:=D1, C6=:=E1, 
          D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, I6=:=K1, J6=:=L1, 
          K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, P6=:=R1, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new25(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9), 
          new126(V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,W,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=X, W5=:=Y, X5=:=Z, Y5=:=A1, Z5=:=B1, A6=:=C1, B6=:=D1, C6=:=E1, 
          D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, I6=:=K1, J6=:=L1, 
          K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, P6=:=R1, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new24(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9), 
          new126(V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,W,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=X, W5=:=Y, X5=:=Z, Y5=:=A1, Z5=:=B1, A6=:=C1, B6=:=D1, C6=:=E1, 
          D6=:=F1, E6=:=G1, F6=:=H1, G6=:=I1, H6=:=J1, I6=:=K1, J6=:=L1, 
          K6=:=M1, L6=:=N1, M6=:=O1, N6=:=P1, O6=:=Q1, P6=:=R1, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new25(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9,H9,I9), 
          new126(V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,W,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1>=U1+1, T1=:=V, U1=:=0, V1=:=A, W1=:=B, X1=:=C, Y1=:=D, Z1=:=E, 
          A2=:=F, B2=:=G, C2=:=H, D2=:=I, E2=:=J, F2=:=K, G2=:=L, H2=:=M, 
          I2=:=N, J2=:=O, K2=:=P, L2=:=Q, M2=:=R, N2=:=S, O2=:=T, P2=:=U, 
          Q2=:=R2, S2=:=T2, U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, 
          E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, 
          S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, 
          G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, 
          U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, 
          I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, 
          W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, 
          K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, 
          Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, K7=:=L7, 
          new16(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8), 
          new20(Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9), 
          new24(G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10), 
          new20(W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10), 
          new156(A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1>=U1+1, T1=:=V, U1=:=0, V1=:=A, W1=:=B, X1=:=C, Y1=:=D, Z1=:=E, 
          A2=:=F, B2=:=G, C2=:=H, D2=:=I, E2=:=J, F2=:=K, G2=:=L, H2=:=M, 
          I2=:=N, J2=:=O, K2=:=P, L2=:=Q, M2=:=R, N2=:=S, O2=:=T, P2=:=U, 
          Q2=:=R2, S2=:=T2, U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, 
          E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, 
          S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, 
          G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, 
          U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, 
          I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, 
          W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, 
          K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, 
          Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, K7=:=L7, 
          new16(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8), 
          new20(Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9), 
          new25(G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10), 
          new20(W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10), 
          new156(A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1>=U1+1, T1=:=V, U1=:=0, V1=:=A, W1=:=B, X1=:=C, Y1=:=D, Z1=:=E, 
          A2=:=F, B2=:=G, C2=:=H, D2=:=I, E2=:=J, F2=:=K, G2=:=L, H2=:=M, 
          I2=:=N, J2=:=O, K2=:=P, L2=:=Q, M2=:=R, N2=:=S, O2=:=T, P2=:=U, 
          Q2=:=R2, S2=:=T2, U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, 
          E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, 
          S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, 
          G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, 
          U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, 
          I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, 
          W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, 
          K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, 
          Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, K7=:=L7, 
          new18(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8), 
          new20(Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9), 
          new24(G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10), 
          new20(W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10), 
          new156(A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1>=U1+1, T1=:=V, U1=:=0, V1=:=A, W1=:=B, X1=:=C, Y1=:=D, Z1=:=E, 
          A2=:=F, B2=:=G, C2=:=H, D2=:=I, E2=:=J, F2=:=K, G2=:=L, H2=:=M, 
          I2=:=N, J2=:=O, K2=:=P, L2=:=Q, M2=:=R, N2=:=S, O2=:=T, P2=:=U, 
          Q2=:=R2, S2=:=T2, U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, 
          E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, 
          S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, 
          G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, 
          U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, 
          I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, 
          W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, 
          K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, 
          Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, K7=:=L7, 
          new18(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8), 
          new20(Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9), 
          new25(G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10), 
          new20(W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10), 
          new156(A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1+1=<U1, T1=:=V, U1=:=0, V1=:=A, W1=:=B, X1=:=C, Y1=:=D, Z1=:=E, 
          A2=:=F, B2=:=G, C2=:=H, D2=:=I, E2=:=J, F2=:=K, G2=:=L, H2=:=M, 
          I2=:=N, J2=:=O, K2=:=P, L2=:=Q, M2=:=R, N2=:=S, O2=:=T, P2=:=U, 
          Q2=:=R2, S2=:=T2, U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, 
          E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, 
          S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, 
          G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, 
          U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, 
          I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, 
          W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, 
          K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, 
          Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, K7=:=L7, 
          new16(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8), 
          new20(Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9), 
          new24(G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10), 
          new20(W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10), 
          new156(A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1+1=<U1, T1=:=V, U1=:=0, V1=:=A, W1=:=B, X1=:=C, Y1=:=D, Z1=:=E, 
          A2=:=F, B2=:=G, C2=:=H, D2=:=I, E2=:=J, F2=:=K, G2=:=L, H2=:=M, 
          I2=:=N, J2=:=O, K2=:=P, L2=:=Q, M2=:=R, N2=:=S, O2=:=T, P2=:=U, 
          Q2=:=R2, S2=:=T2, U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, 
          E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, 
          S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, 
          G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, 
          U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, 
          I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, 
          W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, 
          K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, 
          Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, K7=:=L7, 
          new16(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8), 
          new20(Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9), 
          new25(G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10), 
          new20(W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10), 
          new156(A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1+1=<U1, T1=:=V, U1=:=0, V1=:=A, W1=:=B, X1=:=C, Y1=:=D, Z1=:=E, 
          A2=:=F, B2=:=G, C2=:=H, D2=:=I, E2=:=J, F2=:=K, G2=:=L, H2=:=M, 
          I2=:=N, J2=:=O, K2=:=P, L2=:=Q, M2=:=R, N2=:=S, O2=:=T, P2=:=U, 
          Q2=:=R2, S2=:=T2, U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, 
          E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, 
          S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, 
          G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, 
          U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, 
          I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, 
          W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, 
          K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, 
          Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, K7=:=L7, 
          new18(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8), 
          new20(Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9), 
          new24(G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10), 
          new20(W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10), 
          new156(A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1+1=<U1, T1=:=V, U1=:=0, V1=:=A, W1=:=B, X1=:=C, Y1=:=D, Z1=:=E, 
          A2=:=F, B2=:=G, C2=:=H, D2=:=I, E2=:=J, F2=:=K, G2=:=L, H2=:=M, 
          I2=:=N, J2=:=O, K2=:=P, L2=:=Q, M2=:=R, N2=:=S, O2=:=T, P2=:=U, 
          Q2=:=R2, S2=:=T2, U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, 
          E3=:=F3, G3=:=H3, I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, 
          S3=:=T3, U3=:=V3, W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, 
          G4=:=H4, I4=:=J4, K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, 
          U4=:=V4, W4=:=X4, Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, 
          I5=:=J5, K5=:=L5, M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, 
          W5=:=X5, Y5=:=Z5, A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, 
          K6=:=L6, M6=:=N6, O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, 
          Y6=:=Z6, A7=:=B7, C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, K7=:=L7, 
          new18(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8,K8), 
          new20(Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,E4,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9), 
          new25(G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,U5,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10,E10), 
          new20(W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,K7,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10,Z10), 
          new156(A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,V11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=:=W1, V1=:=U, W1=:=0, X1=:=1, Y1=:=1, Z1=:=A2-B2, A2=:=C2, B2=:=Q, 
          D2=:=0, E2=:=1, F2=:=1, 
          new254(Y1,B,X1,D,D2,F,G,H,I,J,K,L,M,N,O,P,Q,Z1,S,F2,E2,C2,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=:=W1, V1=:=U, W1=:=0, X1=:=1, Y1=:=1, Z1=:=A2-B2, A2=:=C2, B2=:=Q, 
          D2=:=0, E2=:=1, F2=:=1, 
          new255(Y1,B,X1,D,D2,F,G,H,I,J,K,L,M,N,O,P,Q,Z1,S,F2,E2,C2,G2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1>=S1+1, R1=:=E, S1=:=0, 
          new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1+1=<S1, R1=:=E, S1=:=0, 
          new256(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1) :- 
          R1=:=S1, R1=:=E, S1=:=0, 
          new258(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1) :- 
          V1=:=W1, V1=:=T, W1=:=0, X1=:=Y1-Z1, Y1=:=A2, Z1=:=P, B2=:=C2-D2, 
          C2=:=E2, D2=:=L, F2=:=G2-H2, G2=:=E2, H2=:=B2, 
          new279(A,B,C,D,E,F,G,H,I,J,K,L,M,N,E2,F2,B2,R,X1,T,U,A2,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1>=V1+1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new109(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1>=V1+1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new110(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,B2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=<V1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new109(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=<V1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new110(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,B2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X>=Y+1, X=:=W, Y=:=0.
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X+1=<Y, X=:=W, Y=:=0.
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X=:=Y, X=:=W, Y=:=0.
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1>=V1+1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new104(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1>=V1+1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new105(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,B2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=<V1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new104(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=<V1, U1=:=I, V1=:=G, W1=:=1, X1=:=0, Y1=:=1, Z1=:=1, A2=:=1, 
          new105(A,B,W1,X1,Y1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,A2,Z1,V,B2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V>=W+1, V=:=C, W=:=0.
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V+1=<W, V=:=C, W=:=0.
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V=:=W, V=:=C, W=:=0.
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,W,X,Y,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U) :- 
          A1>=B1+1, A1=:=C, B1=:=0, Y=:=0, V=:=1, W=:=0, X=:=0, Z=:=Q.
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,W,X,Y,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U) :- 
          A1+1=<B1, A1=:=C, B1=:=0, Y=:=0, V=:=1, W=:=0, X=:=0, Z=:=Q.
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,W,X,Y,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U) :- 
          A1=:=B1, A1=:=C, B1=:=0, Y=:=0, V=:=1, W=:=0, X=:=0, Z=:=Q.
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,V,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          X>=Y+1, X=:=C, Y=:=0, V=:=1, W=:=1.
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,V,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          X+1=<Y, X=:=C, Y=:=0, V=:=1, W=:=1.
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,V,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          X=:=Y, X=:=C, Y=:=0, V=:=1, W=:=1.
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V>=W+1, V=:=N, W=:=0.
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          V+1=<W, V=:=N, W=:=0.
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=N, R1=:=0, S1=:=0, T1=:=0, 
          new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T1,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=N, R1=:=0, S1=:=0, T1=:=1, 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,T,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=N, R1=:=0, S1=:=0, 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=N, R1=:=0, S1=:=0, 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=I, R1=:=G, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1, Q1=:=I, R1=:=G, S1=:=0, 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=N, R1=:=0, S1=:=0, T1=:=1, 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,T1,O,P,Q,R,S,S1,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=N, R1=:=0, S1=:=0, 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=N, R1=:=0, S1=:=0, 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,S1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=I, R1=:=G, 
          new89(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=<R1, Q1=:=I, R1=:=G, 
          new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=B, R1=:=0, S1=:=1, T1=:=1, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T1,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=B, R1=:=0, S1=:=1, T1=:=1, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T1,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=B, R1=:=0, S1=:=0, T1=:=0, U1=:=1, 
          new102(A,U1,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T1,S1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W,U) :- 
          X>=Y+1, X=:=A, Y=:=0, V=:=0, W=:=0.
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W,U) :- 
          X+1=<Y, X=:=A, Y=:=0, V=:=0, W=:=0.
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,V,W,X,F,G,H,I,J,K,L,M,N,Y,Z,A1,R,B1,C1,U) :- 
          D1=:=E1, D1=:=A, E1=:=0, C1=:=1, W=:=0, X=:=1, V=:=0, B1=:=P, 
          A1=:=F1-G1, F1=:=Y, G1=:=L, Z=:=H1-I1, H1=:=Y, I1=:=A1.
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W,U) :- 
          X>=Y+1, X=:=A, Y=:=0, V=:=0, W=:=0.
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,W,U) :- 
          X+1=<Y, X=:=A, Y=:=0, V=:=0, W=:=0.
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,A,B,V,W,X,F,G,H,I,J,K,L,M,N,Y,Z,A1,R,B1,C1,U) :- 
          D1=:=E1, D1=:=A, E1=:=0, C1=:=1, V=:=0, W=:=0, X=:=1, B1=:=P, 
          A1=:=F1-G1, F1=:=Y, G1=:=L, Z=:=H1-I1, H1=:=Y, I1=:=A1.
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=C, R1=:=0, 
          new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=C, R1=:=0, 
          new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=C, R1=:=0, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=D, R1=:=0, 
          new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=D, R1=:=0, 
          new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=D, R1=:=0, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X>=Y+1, X=:=W, Y=:=0.
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X+1=<Y, X=:=W, Y=:=0.
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X=:=Y, X=:=W, Y=:=0.
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=T, V1=:=0, W1=:=X1-Y1, X1=:=Z1, Y1=:=P, A2=:=B2-C2, 
          B2=:=D2, C2=:=L, E2=:=F2-G2, F2=:=D2, G2=:=A2, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D2,E2,A2,R,W1,T,U,Z1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=U, V1=:=0, W1=:=1, X1=:=1, Y1=:=Z1-A2, Z1=:=B2, A2=:=Q, 
          C2=:=0, D2=:=1, E2=:=1, 
          new76(X1,B,W1,D,C2,F,G,H,I,J,K,L,M,N,O,P,Q,Y1,S,E2,D2,B2,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=U, V1=:=0, W1=:=1, X1=:=1, Y1=:=Z1-A2, Z1=:=B2, A2=:=Q, 
          C2=:=0, D2=:=1, E2=:=1, 
          new77(X1,B,W1,D,C2,F,G,H,I,J,K,L,M,N,O,P,Q,Y1,S,E2,D2,B2,F2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          W=:=X, W=:=V, X=:=0.
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, 
          J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, 
          X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, J7=:=K7, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9), 
          new24(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10), 
          new20(V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10), 
          new32(Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, 
          J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, 
          X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, J7=:=K7, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9), 
          new25(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10), 
          new20(V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10), 
          new32(Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, 
          J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, 
          X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, J7=:=K7, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9), 
          new24(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10), 
          new20(V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10), 
          new32(Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1>=T1+1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, 
          J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, 
          X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, J7=:=K7, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9), 
          new25(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10), 
          new20(V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10), 
          new32(Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, 
          J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, 
          X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, J7=:=K7, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9), 
          new24(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10), 
          new20(V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10), 
          new32(Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, 
          J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, 
          X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, J7=:=K7, 
          new16(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9), 
          new25(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10), 
          new20(V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10), 
          new32(Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, 
          J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, 
          X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, J7=:=K7, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9), 
          new24(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10), 
          new20(V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10), 
          new32(Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1+1=<T1, S1=:=V, T1=:=0, U1=:=A, V1=:=B, W1=:=C, X1=:=D, Y1=:=E, 
          Z1=:=F, A2=:=G, B2=:=H, C2=:=I, D2=:=J, E2=:=K, F2=:=L, G2=:=M, 
          H2=:=N, I2=:=O, J2=:=P, K2=:=Q, L2=:=R, M2=:=S, N2=:=T, O2=:=U, 
          P2=:=Q2, R2=:=S2, T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, 
          D3=:=E3, F3=:=G3, H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, 
          R3=:=S3, T3=:=U3, V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, 
          F4=:=G4, H4=:=I4, J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, 
          T4=:=U4, V4=:=W4, X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, 
          H5=:=I5, J5=:=K5, L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, 
          V5=:=W5, X5=:=Y5, Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, 
          J6=:=K6, L6=:=M6, N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, 
          X6=:=Y6, Z6=:=A7, B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, J7=:=K7, 
          new18(U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8,J8), 
          new20(P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,D4,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9), 
          new25(F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,T5,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10,D10), 
          new20(V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,J7,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10,Y10), 
          new32(Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,U11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X>=Y+1, X=:=U, Y=:=0.
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X+1=<Y, X=:=U, Y=:=0.
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=U, V1=:=0, W1=:=1, X1=:=1, Y1=:=Z1-A2, Z1=:=B2, A2=:=Q, 
          C2=:=0, D2=:=1, E2=:=1, 
          new78(X1,B,W1,D,C2,F,G,H,I,J,K,L,M,N,O,P,Q,Y1,S,E2,D2,B2,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=U, V1=:=0, W1=:=1, X1=:=1, Y1=:=Z1-A2, Z1=:=B2, A2=:=Q, 
          C2=:=0, D2=:=1, E2=:=1, 
          new79(X1,B,W1,D,C2,F,G,H,I,J,K,L,M,N,O,P,Q,Y1,S,E2,D2,B2,F2,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1>=R1+1, Q1=:=E, R1=:=0, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1+1=<R1, Q1=:=E, R1=:=0, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1) :- 
          Q1=:=R1, Q1=:=E, R1=:=0, 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X>=Y+1, X=:=T, Y=:=0.
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          X+1=<Y, X=:=T, Y=:=0.
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1) :- 
          U1=:=V1, U1=:=T, V1=:=0, W1=:=X1-Y1, X1=:=Z1, Y1=:=P, A2=:=B2-C2, 
          B2=:=D2, C2=:=L, E2=:=F2-G2, F2=:=D2, G2=:=A2, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D2,E2,A2,R,W1,T,U,Z1,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,87,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=A1, G2=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=A1, G2=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2>=G2+1, F2=:=Z, G2=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2+1=<G2, F2=:=Z, G2=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, 
          J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, 
          X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, 
          L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, 
          Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, J6=:=K6, L6=:=M6, 
          N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, X6=:=Y6, Z6=:=A7, 
          B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          new16(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9), 
          new24(D4,F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10), 
          new20(T5,V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10), 
          new32(X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, 
          J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, 
          X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, 
          L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, 
          Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, J6=:=K6, L6=:=M6, 
          N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, X6=:=Y6, Z6=:=A7, 
          B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          new16(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9), 
          new25(D4,F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10), 
          new20(T5,V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10), 
          new32(X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, 
          J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, 
          X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, 
          L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, 
          Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, J6=:=K6, L6=:=M6, 
          N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, X6=:=Y6, Z6=:=A7, 
          B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          new18(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9), 
          new24(D4,F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10), 
          new20(T5,V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10), 
          new32(X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, 
          J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, 
          X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, 
          L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=U5, V5=:=W5, X5=:=Y5, 
          Z5=:=A6, B6=:=C6, D6=:=E6, F6=:=G6, H6=:=I6, J6=:=K6, L6=:=M6, 
          N6=:=O6, P6=:=Q6, R6=:=S6, T6=:=U6, V6=:=W6, X6=:=Y6, Z6=:=A7, 
          B7=:=C7, D7=:=E7, F7=:=G7, H7=:=I7, 
          new18(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,J7,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9), 
          new25(D4,F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10), 
          new20(T5,V5,X5,Z5,B6,D6,F6,H6,J6,L6,N6,P6,R6,T6,V6,X6,Z6,B7,D7,F7,H7,C10,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10), 
          new32(X10,Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          X=:=A, Y=:=B, Z=:=C, A1=:=D, B1=:=E, C1=:=F, D1=:=G, E1=:=H, F1=:=I, 
          G1=:=J, H1=:=K, I1=:=L, J1=:=M, K1=:=N, L1=:=O, M1=:=P, N1=:=Q, 
          O1=:=R, P1=:=S, Q1=:=T, R1=:=U, 
          new113(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,W,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=X, O2=:=Y, P2=:=Z, 
          Q2=:=A1, R2=:=B1, S2=:=C1, T2=:=D1, U2=:=E1, V2=:=F1, W2=:=G1, 
          X2=:=H1, Y2=:=I1, Z2=:=J1, A3=:=K1, B3=:=L1, C3=:=M1, D3=:=N1, 
          E3=:=O1, F3=:=P1, G3=:=Q1, H3=:=R1, 
          new16(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4), 
          new126(N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,W,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=X, O2=:=Y, P2=:=Z, 
          Q2=:=A1, R2=:=B1, S2=:=C1, T2=:=D1, U2=:=E1, V2=:=F1, W2=:=G1, 
          X2=:=H1, Y2=:=I1, Z2=:=J1, A3=:=K1, B3=:=L1, C3=:=M1, D3=:=N1, 
          E3=:=O1, F3=:=P1, G3=:=Q1, H3=:=R1, 
          new18(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Z3,A4,B4,C4,D4,E4,F4,G4), 
          new126(N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,W,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,Y4,Z4,A5,B5).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=X, E4=:=Y, F4=:=Z, G4=:=A1, 
          H4=:=B1, I4=:=C1, J4=:=D1, K4=:=E1, L4=:=F1, M4=:=G1, N4=:=H1, 
          O4=:=I1, P4=:=J1, Q4=:=K1, R4=:=L1, S4=:=M1, T4=:=N1, U4=:=O1, 
          V4=:=P1, W4=:=Q1, X4=:=R1, 
          new16(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6), 
          new138(D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,S6,T6,W,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=X, E4=:=Y, F4=:=Z, G4=:=A1, 
          H4=:=B1, I4=:=C1, J4=:=D1, K4=:=E1, L4=:=F1, M4=:=G1, N4=:=H1, 
          O4=:=I1, P4=:=J1, Q4=:=K1, R4=:=L1, S4=:=M1, T4=:=N1, U4=:=O1, 
          V4=:=P1, W4=:=Q1, X4=:=R1, 
          new18(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,Y4,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6), 
          new138(D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4,S6,T6,W,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,Q7).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, 
          J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, 
          X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, 
          L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=X, U5=:=Y, V5=:=Z, W5=:=A1, 
          X5=:=B1, Y5=:=C1, Z5=:=D1, A6=:=E1, B6=:=F1, C6=:=G1, D6=:=H1, 
          E6=:=I1, F6=:=J1, G6=:=K1, H6=:=L1, I6=:=M1, J6=:=N1, K6=:=O1, 
          L6=:=P1, M6=:=Q1, N6=:=R1, 
          new16(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8), 
          new24(D4,F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9), 
          new126(T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,W,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, 
          J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, 
          X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, 
          L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=X, U5=:=Y, V5=:=Z, W5=:=A1, 
          X5=:=B1, Y5=:=C1, Z5=:=D1, A6=:=E1, B6=:=F1, C6=:=G1, D6=:=H1, 
          E6=:=I1, F6=:=J1, G6=:=K1, H6=:=L1, I6=:=M1, J6=:=N1, K6=:=O1, 
          L6=:=P1, M6=:=Q1, N6=:=R1, 
          new16(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8), 
          new25(D4,F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9), 
          new126(T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,W,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, 
          J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, 
          X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, 
          L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=X, U5=:=Y, V5=:=Z, W5=:=A1, 
          X5=:=B1, Y5=:=C1, Z5=:=D1, A6=:=E1, B6=:=F1, C6=:=G1, D6=:=H1, 
          E6=:=I1, F6=:=J1, G6=:=K1, H6=:=L1, I6=:=M1, J6=:=N1, K6=:=O1, 
          L6=:=P1, M6=:=Q1, N6=:=R1, 
          new18(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8), 
          new24(D4,F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9), 
          new126(T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,W,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,V) :- 
          S1=:=A, T1=:=B, U1=:=C, V1=:=D, W1=:=E, X1=:=F, Y1=:=G, Z1=:=H, 
          A2=:=I, B2=:=J, C2=:=K, D2=:=L, E2=:=M, F2=:=N, G2=:=O, H2=:=P, 
          I2=:=Q, J2=:=R, K2=:=S, L2=:=T, M2=:=U, N2=:=O2, P2=:=Q2, R2=:=S2, 
          T2=:=U2, V2=:=W2, X2=:=Y2, Z2=:=A3, B3=:=C3, D3=:=E3, F3=:=G3, 
          H3=:=I3, J3=:=K3, L3=:=M3, N3=:=O3, P3=:=Q3, R3=:=S3, T3=:=U3, 
          V3=:=W3, X3=:=Y3, Z3=:=A4, B4=:=C4, D4=:=E4, F4=:=G4, H4=:=I4, 
          J4=:=K4, L4=:=M4, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, 
          X4=:=Y4, Z4=:=A5, B5=:=C5, D5=:=E5, F5=:=G5, H5=:=I5, J5=:=K5, 
          L5=:=M5, N5=:=O5, P5=:=Q5, R5=:=S5, T5=:=X, U5=:=Y, V5=:=Z, W5=:=A1, 
          X5=:=B1, Y5=:=C1, Z5=:=D1, A6=:=E1, B6=:=F1, C6=:=G1, D6=:=H1, 
          E6=:=I1, F6=:=J1, G6=:=K1, H6=:=L1, I6=:=M1, J6=:=N1, K6=:=O1, 
          L6=:=P1, M6=:=Q1, N6=:=R1, 
          new18(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,O6,P6,Q6,R6,S6,T6,U6,V6,W6,X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7), 
          new20(N2,P2,R2,T2,V2,X2,Z2,B3,D3,F3,H3,J3,L3,N3,P3,R3,T3,V3,X3,Z3,B4,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8), 
          new25(D4,F4,H4,J4,L4,N4,P4,R4,T4,V4,X4,Z4,B5,D5,F5,H5,J5,L5,N5,P5,R5,I8,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9,E9,F9,G9), 
          new126(T5,U5,V5,W5,X5,Y5,Z5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,W,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1=:=A, U1=:=B, V1=:=C, W1=:=D, X1=:=E, Y1=:=F, Z1=:=G, A2=:=H, 
          B2=:=I, C2=:=J, D2=:=K, E2=:=L, F2=:=M, G2=:=N, H2=:=O, I2=:=P, 
          J2=:=Q, K2=:=R, L2=:=S, M2=:=T, N2=:=U, O2=:=P2, Q2=:=R2, S2=:=T2, 
          U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, 
          O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, 
          C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          new16(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8), 
          new20(O2,Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9), 
          new24(E4,G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10), 
          new20(U5,W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10), 
          new156(Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1=:=A, U1=:=B, V1=:=C, W1=:=D, X1=:=E, Y1=:=F, Z1=:=G, A2=:=H, 
          B2=:=I, C2=:=J, D2=:=K, E2=:=L, F2=:=M, G2=:=N, H2=:=O, I2=:=P, 
          J2=:=Q, K2=:=R, L2=:=S, M2=:=T, N2=:=U, O2=:=P2, Q2=:=R2, S2=:=T2, 
          U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, 
          O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, 
          C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          new16(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8), 
          new20(O2,Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9), 
          new25(E4,G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10), 
          new20(U5,W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10), 
          new156(Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1=:=A, U1=:=B, V1=:=C, W1=:=D, X1=:=E, Y1=:=F, Z1=:=G, A2=:=H, 
          B2=:=I, C2=:=J, D2=:=K, E2=:=L, F2=:=M, G2=:=N, H2=:=O, I2=:=P, 
          J2=:=Q, K2=:=R, L2=:=S, M2=:=T, N2=:=U, O2=:=P2, Q2=:=R2, S2=:=T2, 
          U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, 
          O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, 
          C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          new18(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8), 
          new20(O2,Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9), 
          new24(E4,G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10), 
          new20(U5,W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10), 
          new156(Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1) :- 
          T1=:=A, U1=:=B, V1=:=C, W1=:=D, X1=:=E, Y1=:=F, Z1=:=G, A2=:=H, 
          B2=:=I, C2=:=J, D2=:=K, E2=:=L, F2=:=M, G2=:=N, H2=:=O, I2=:=P, 
          J2=:=Q, K2=:=R, L2=:=S, M2=:=T, N2=:=U, O2=:=P2, Q2=:=R2, S2=:=T2, 
          U2=:=V2, W2=:=X2, Y2=:=Z2, A3=:=B3, C3=:=D3, E3=:=F3, G3=:=H3, 
          I3=:=J3, K3=:=L3, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, 
          W3=:=X3, Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, 
          K4=:=L4, M4=:=N4, O4=:=P4, Q4=:=R4, S4=:=T4, U4=:=V4, W4=:=X4, 
          Y4=:=Z4, A5=:=B5, C5=:=D5, E5=:=F5, G5=:=H5, I5=:=J5, K5=:=L5, 
          M5=:=N5, O5=:=P5, Q5=:=R5, S5=:=T5, U5=:=V5, W5=:=X5, Y5=:=Z5, 
          A6=:=B6, C6=:=D6, E6=:=F6, G6=:=H6, I6=:=J6, K6=:=L6, M6=:=N6, 
          O6=:=P6, Q6=:=R6, S6=:=T6, U6=:=V6, W6=:=X6, Y6=:=Z6, A7=:=B7, 
          C7=:=D7, E7=:=F7, G7=:=H7, I7=:=J7, 
          new18(T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,K7,L7,M7,N7,O7,P7,Q7,R7,S7,T7,U7,V7,W7,X7,Y7,Z7,A8,B8,C8,D8,E8,F8,G8,H8,I8), 
          new20(O2,Q2,S2,U2,W2,Y2,A3,C3,E3,G3,I3,K3,M3,O3,Q3,S3,U3,W3,Y3,A4,C4,J8,K8,L8,M8,N8,O8,P8,Q8,R8,S8,T8,U8,V8,W8,X8,Y8,Z8,A9,B9,C9,D9), 
          new25(E4,G4,I4,K4,M4,O4,Q4,S4,U4,W4,Y4,A5,C5,E5,G5,I5,K5,M5,O5,Q5,S5,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9,V9,W9,X9,Y9,Z9,A10,B10,C10), 
          new20(U5,W5,Y5,A6,C6,E6,G6,I6,K6,M6,O6,Q6,S6,U6,W6,Y6,A7,C7,E7,G7,I7,D10,E10,F10,G10,H10,I10,J10,K10,L10,M10,N10,O10,P10,Q10,R10,S10,T10,U10,V10,W10,X10), 
          new156(Y10,Z10,A11,B11,C11,D11,E11,F11,G11,H11,I11,J11,K11,L11,M11,N11,O11,P11,Q11,R11,S11,T11,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1) :- 
          Y1=:=A, Z1=:=A, A2=:=R, B2=:=R, C2=:=D2-E2, D2=:=A, E2=:=R, 
          F2=:=G2-H2, G2=:=A, H2=:=R, I2=:=B, J2=:=C, K2=:=L2-M2, L2=:=I2, 
          M2=:=J2, N2=:=D, O2=:=E, P2=:=F, 
          new284(A,B,C,D,E,F,G,H,I,J,K,Y1,O2,N2,P2,I2,J2,K2,S,T,Z1,A2,C2,F2,B2,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1) :- 
          Z1=:=A, A2=:=A, B2=:=R, C2=:=R, D2=:=E2-F2, E2=:=A, F2=:=R, 
          G2=:=H2-I2, H2=:=A, I2=:=R, J2=:=B, K2=:=C, L2=:=M2-N2, M2=:=J2, 
          N2=:=K2, O2=:=D, P2=:=E, Q2=:=F, 
          new285(A,B,C,D,E,F,G,H,I,J,K,Z1,P2,O2,Q2,J2,K2,L2,S,T,A2,B2,D2,G2,C2,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,F,G,H,I,J,K,L,M,I1,O,P,Q,R,S,T,U,V,W,X,Y,J1,K1,B1) :- 
          F1=:=0, E1=:=0, D1=:=0, H1=:=1, G1=:=0, I1=:=0, J1=:=0, K1=:=0, 
          L1=:=T, M1=:=U, N1=:=V, O1=:=W, P1=:=X, Q1=:=Y, R1=:=D1, S1=:=E1, 
          T1=:=F1, U1=:=G1, V1=:=H1, W1=:=F, X1=:=G, Y1=:=H, Z1=:=I, A2=:=J, 
          B2=:=K, C2=:=L, D2=:=M, E2=:=I1, F2=:=O, G2=:=P, H2=:=Q, I2=:=R, 
          J2=:=S, 
          new3(L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,C1,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,T,U,V,W,X,Y,W1,X1,Y1) :- 
          Z1=:=0, A2=:=0, B2=:=0, C2=:=1, D2=:=0, E2=:=0, W1=:=0, X1=:=0, 
          F2=:=T, G2=:=U, H2=:=V, I2=:=W, J2=:=X, K2=:=Y, L2=:=B2, M2=:=A2, 
          N2=:=Z1, O2=:=D2, P2=:=C2, Q2=:=F, R2=:=G, S2=:=H, T2=:=I, U2=:=J, 
          V2=:=K, W2=:=L, X2=:=M, Y2=:=E2, Z2=:=O, A3=:=P, B3=:=Q, C3=:=R, 
          D3=:=S, Y1=:=P1, E3=:=D1, F3=:=E1, G3=:=F1, H3=:=G1, I3=:=H1, 
          J3=:=I1, K3=:=J1, L3=:=K1, M3=:=L1, N3=:=M1, O3=:=N1, P3=:=O1, 
          Q3=:=P1, R3=:=Q1, S3=:=R1, T3=:=S1, U3=:=T1, V3=:=U1, W3=:=V1, 
          X3=:=W1, Y3=:=X1, 
          new4(F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,Z3,A4,B4,C4,D4,E4,F4,G4,H4,I4,J4,K4,L4,M4,N4,O4,P4,Q4,R4,S4,T4,U4,V4,W4,X4), 
          new7(E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,T3,U3,V3,W3,X3,Y3,Y4,C1,Z4,A5,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=0, G2=:=0, H2=:=0, I2=:=1, J2=:=0, K2=:=0, L2=:=0, M2=:=0, 
          N2=:=T, O2=:=U, P2=:=V, Q2=:=W, R2=:=X, S2=:=Y, T2=:=H2, U2=:=G2, 
          V2=:=F2, W2=:=J2, X2=:=I2, Y2=:=F, Z2=:=G, A3=:=H, B3=:=I, C3=:=J, 
          D3=:=K, E3=:=L, F3=:=M, G3=:=K2, H3=:=O, I3=:=P, J3=:=Q, K3=:=R, 
          L3=:=S, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, 
          Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, 
          M4=:=N3, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=L2, A5=:=M2, 
          new4(N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5), 
          new8(O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,N4,P4,R4,T4,V4,X4,Z4,A5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6), 
          new10(X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,T,U,V,W,X,Y,Q7,M2,M3,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2) :- 
          F2=:=0, G2=:=0, H2=:=0, I2=:=1, J2=:=0, K2=:=0, L2=:=0, M2=:=0, 
          N2=:=T, O2=:=U, P2=:=V, Q2=:=W, R2=:=X, S2=:=Y, T2=:=H2, U2=:=G2, 
          V2=:=F2, W2=:=J2, X2=:=I2, Y2=:=F, Z2=:=G, A3=:=H, B3=:=I, C3=:=J, 
          D3=:=K, E3=:=L, F3=:=M, G3=:=K2, H3=:=O, I3=:=P, J3=:=Q, K3=:=R, 
          L3=:=S, M3=:=N3, O3=:=P3, Q3=:=R3, S3=:=T3, U3=:=V3, W3=:=X3, 
          Y3=:=Z3, A4=:=B4, C4=:=D4, E4=:=F4, G4=:=H4, I4=:=J4, K4=:=L4, 
          M4=:=N3, N4=:=O4, P4=:=Q4, R4=:=S4, T4=:=U4, V4=:=W4, X4=:=Y4, 
          Z4=:=L2, A5=:=M2, 
          new4(N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,B5,C5,D5,E5,F5,G5,H5,I5,J5,K5,L5,M5,N5,O5,P5,Q5,R5,S5,T5,U5,V5,W5,X5,Y5,Z5), 
          new8(O3,Q3,S3,U3,W3,Y3,A4,C4,E4,G4,I4,K4,M4,N4,P4,R4,T4,V4,X4,Z4,A5,A6,B6,C6,D6,E6,F6,G6,H6,I6,J6,K6,L6,M6,N6,O6,P6,Q6,R6,S6,T6,U6,V6,W6), 
          new11(X6,Y6,Z6,A7,B7,C7,D7,E7,F7,G7,H7,I7,J7,K7,L7,M7,N7,O7,P7,T,U,V,W,X,Y,Q7,R7,M3,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
new1 :- 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2).
correct :- \+new1.
