new12(A,B,C,D,45,A,B,C,D).
new10(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, L=:=M+N, M=:=C, N=:=1, 
          O=:=P-Q, P=:=D, Q=:=1, new9(A,B,L,O,E,F,G,H,I).
new10(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=D, K=:=0, new12(A,B,C,D,E,F,G,H,I).
new9(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=L*M, L=:=20, M=:=A, 
          new10(A,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=L+M, L=:=N*O, N=:=6, O=:=B, 
          M=:=128, P=:=Q+R, Q=:=C, R=:=1, S=:=T-U, T=:=D, U=:=1, 
          new7(A,B,P,S,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=L+M, L=:=N*O, N=:=6, O=:=B, 
          M=:=128, P=:=0, new9(A,B,P,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=L+M, L=:=N*O, N=:=6, O=:=B, 
          M=:=128, P=:=Q+R, Q=:=C, R=:=1, S=:=T+U, T=:=D, U=:=1, 
          new5(A,B,P,S,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=L+M, L=:=N*O, N=:=6, O=:=B, 
          M=:=128, P=:=0, new7(A,B,P,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=L*M, L=:=20, M=:=A, N=:=O+P, 
          O=:=C, P=:=1, Q=:=R+S, R=:=D, S=:=1, new3(A,B,N,Q,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=L*M, L=:=20, M=:=A, N=:=0, 
          new5(A,B,N,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=0, K=:=0, new3(A,B,J,K,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
