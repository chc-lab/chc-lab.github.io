new241(A,B,C,D,E,F,G,H,I,A,B,C,J,E,F,G,H,I) :- K=:=L, K=:=F, L=:=1, J=:=0.
new241(A,B,C,D,E,F,G,H,I,A,B,C,J,E,F,G,H,I) :- K>=L+1, K=:=F, L=:=1, J=:=2.
new241(A,B,C,D,E,F,G,H,I,A,B,C,J,E,F,G,H,I) :- K+1=<L, K=:=F, L=:=1, J=:=2.
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=0, V=:=1, 
          new238(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=0, 
          new238(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=0, 
          new238(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new232(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,J) :- K=:=L, K=:=I, L=:=0, J=:=1.
new232(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=I, K=:=0.
new232(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=I, K=:=0.
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=H, T=:=0, U=:=1, 
          new232(A,B,C,D,E,F,G,U,I,J,K,L,M,N,O,P,Q,R).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=H, T=:=0, 
          new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=H, T=:=0, 
          new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=B, W=:=1, 
          new227(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,J,K) :- V>=W+1, V=:=J, W=:=0, 
          X=:=0, new218(A,B,X,D,E,F,G,H,I,Y,L,M,N,O,P,Q,R,S,T,U,Z).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,J,K) :- V+1=<W, V=:=J, W=:=0, 
          X=:=0, new218(A,B,X,D,E,F,G,H,I,Y,L,M,N,O,P,Q,R,S,T,U,Z).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,J,K) :- V=:=W, V=:=J, W=:=0, 
          new218(A,B,C,D,E,F,G,H,I,X,L,M,N,O,P,Q,R,S,T,U,Y).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=J, Y=:=0, 
          Z=:=0, A1=:=B1, 
          new207(A,B,Z,D,E,F,G,H,I,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,B1), 
          new224(D1,E1,F1,G1,H1,I1,J1,K1,L1,J,A1,L,M,N,O,P,Q,R,S,T,U,V,W).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=J, Y=:=0, 
          Z=:=0, A1=:=B1, 
          new207(A,B,Z,D,E,F,G,H,I,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,B1), 
          new224(D1,E1,F1,G1,H1,I1,J1,K1,L1,J,A1,L,M,N,O,P,Q,R,S,T,U,V,W).
new217(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=J, Y=:=0, 
          Z=:=A1, new207(A,B,C,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,A1), 
          new224(C1,D1,E1,F1,G1,H1,I1,J1,K1,J,Z,L,M,N,O,P,Q,R,S,T,U,V,W).
new215(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=A, W=:=1, 
          new228(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new214(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L=:=M, L=:=G, M=:=1, K=:=1.
new214(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L>=M+1, L=:=G, M=:=1, K=:=0.
new214(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L+1=<M, L=:=G, M=:=1, K=:=0.
new213(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L=:=M, L=:=I, M=:=1, K=:=1.
new213(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L>=M+1, L=:=I, M=:=1, K=:=0.
new213(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L+1=<M, L=:=I, M=:=1, K=:=0.
new210(A,B,C,D,E,F,G,H,I,J,K,A,B,C,L,E,F,G,H,I,J,K) :- M>=N+1, M=:=K, N=:=0, 
          L=:=0.
new210(A,B,C,D,E,F,G,H,I,J,K,A,B,C,L,E,F,G,H,I,J,K) :- M+1=<N, M=:=K, N=:=0, 
          L=:=0.
new210(A,B,C,D,E,F,G,H,I,J,K,A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=K, M=:=0.
new207(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L>=M+1, L=:=B, M=:=1, K=:=0.
new207(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L+1=<M, L=:=B, M=:=1, K=:=0.
new207(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=B, V=:=1, 
          new213(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=J, X=:=0, 
          Y=:=0, Z=:=A1, 
          new207(A,B,Y,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,A1), 
          new210(C1,D1,E1,F1,G1,H1,I1,J1,K1,J,Z,L,M,N,O,P,Q,R,S,T,U,V).
new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=J, X=:=0, 
          Y=:=0, Z=:=A1, 
          new207(A,B,Y,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,A1), 
          new210(C1,D1,E1,F1,G1,H1,I1,J1,K1,J,Z,L,M,N,O,P,Q,R,S,T,U,V).
new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=J, X=:=0, 
          Y=:=Z, new207(A,B,C,D,E,F,G,H,I,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,Z), 
          new210(B1,C1,D1,E1,F1,G1,H1,I1,J1,J,Y,L,M,N,O,P,Q,R,S,T,U,V).
new205(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L>=M+1, L=:=A, M=:=1, K=:=0.
new205(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L+1=<M, L=:=A, M=:=1, K=:=0.
new205(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=A, V=:=1, 
          new214(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=1, V=:=2, 
          new202(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=1, 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=1, 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new196(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,J) :- K=:=L, K=:=I, L=:=1, J=:=2.
new196(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=I, K=:=1.
new196(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=I, K=:=1.
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=H, T=:=1, U=:=2, 
          new196(A,B,C,D,E,F,G,U,I,J,K,L,M,N,O,P,Q,R).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=H, T=:=1, 
          new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=H, T=:=1, 
          new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new189(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new21(A,B,C,D,E,F,G,H,I,T,U,J,K,L,M,N,O,P,Q,R,S,V,W).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=A, U=:=1, 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=A, U=:=1, 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=A, U=:=1, 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=1, U=:=0, V=:=1, 
          new189(A,B,C,D,E,F,G,H,V,J,K,L,M,N,O,P,Q,R,S).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=1, U=:=0, V=:=1, 
          W=:=2, new136(A,B,C,D,E,F,G,H,V,X,Y,Z,A1,B1,C1,D1,E1,F1), 
          new188(X,Y,Z,A1,B1,C1,D1,E1,W,J,K,L,M,N,O,P,Q,R,S).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=A, U=:=0, 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=A, U=:=0, 
          new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=A, U=:=0, 
          new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new172(A,B,C,D,E,F,G,H,I,44,A,B,C,D,E,F,G,H,I).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=B, U=:=1, 
          new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=B, U=:=1, 
          new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=B, U=:=1, 
          new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=B, U=:=0, 
          new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=B, U=:=0, 
          new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=B, U=:=0, 
          new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W>=X+1, W=:=L, 
          X=:=0, Y=:=1, new154(A,B,C,Y,E,F,G,H,I,M,N,O,P,Q,R,S,T,U,V).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W+1=<X, W=:=L, 
          X=:=0, Y=:=1, new154(A,B,C,Y,E,F,G,H,I,M,N,O,P,Q,R,S,T,U,V).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W=:=X, W=:=L, 
          X=:=0, new52(A,B,C,D,E,F,G,H,I,Y,M,N,O,P,Q,R,S,T,U,V,Z).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W>=X+1, W=:=L, 
          X=:=0, Y=:=1, new110(A,B,C,Y,E,F,G,H,I,Z,A1,B1,C1,D1,E1,F1,G1,H1), 
          new52(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,M,N,O,P,Q,R,S,T,U,V,J1).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W+1=<X, W=:=L, 
          X=:=0, Y=:=1, new110(A,B,C,Y,E,F,G,H,I,Z,A1,B1,C1,D1,E1,F1,G1,H1), 
          new52(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,M,N,O,P,Q,R,S,T,U,V,J1).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=L, 
          A1=:=0, B1=:=C1, 
          new53(A,B,C,D,E,F,G,H,I,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,C1), 
          new141(E1,F1,G1,H1,I1,J1,K1,L1,M1,B1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=L, 
          A1=:=0, B1=:=1, C1=:=D1, 
          new110(A,B,C,B1,E,F,G,H,I,E1,F1,G1,H1,I1,J1,K1,L1,M1), 
          new53(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,D1), 
          new141(O1,P1,Q1,R1,S1,T1,U1,V1,W1,C1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new147(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=L, 
          A1=:=0, B1=:=1, C1=:=D1, 
          new110(A,B,C,B1,E,F,G,H,I,E1,F1,G1,H1,I1,J1,K1,L1,M1), 
          new53(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,D1), 
          new141(O1,P1,Q1,R1,S1,T1,U1,V1,W1,C1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=D, 
          A1=:=0, new147(A,B,C,D,E,F,G,H,I,J,K,B1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W>=X+1, W=:=D, 
          X=:=0, new52(A,B,C,D,E,F,G,H,I,Y,M,N,O,P,Q,R,S,T,U,V,Z).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W+1=<X, W=:=D, 
          X=:=0, new52(A,B,C,D,E,F,G,H,I,Y,M,N,O,P,Q,R,S,T,U,V,Z).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=D, 
          A1=:=0, B1=:=C1, 
          new53(A,B,C,D,E,F,G,H,I,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,C1), 
          new141(E1,F1,G1,H1,I1,J1,K1,L1,M1,B1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=D, 
          A1=:=0, B1=:=C1, 
          new53(A,B,C,D,E,F,G,H,I,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,C1), 
          new141(E1,F1,G1,H1,I1,J1,K1,L1,M1,B1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W>=X+1, W=:=K, 
          X=:=0, Y=:=1, new175(A,B,Y,D,E,F,G,H,I,M,N,O,P,Q,R,S,T,U,V).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W+1=<X, W=:=K, 
          X=:=0, Y=:=1, new175(A,B,Y,D,E,F,G,H,I,M,N,O,P,Q,R,S,T,U,V).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=K, 
          A1=:=0, new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=K, 
          A1=:=0, B1=:=1, 
          new124(A,B,B1,D,E,F,G,H,I,C1,D1,E1,F1,G1,H1,I1,J1,K1), 
          new145(C1,D1,E1,F1,G1,H1,I1,J1,K1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=K, 
          A1=:=0, B1=:=1, 
          new124(A,B,B1,D,E,F,G,H,I,C1,D1,E1,F1,G1,H1,I1,J1,K1), 
          new145(C1,D1,E1,F1,G1,H1,I1,J1,K1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=C, 
          A1=:=0, new144(A,B,C,D,E,F,G,H,I,J,B1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=C, 
          A1=:=0, new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=C, 
          A1=:=0, new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=J, 
          A1=:=0, new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=J, 
          A1=:=0, new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new22(A,B,C,D,E,F,G,H,I,S,T,J,K,L,M,N,O,P,Q,R,U,V).
new135(A,B,C,D,E,F,G,H,I,J,B,K,D,E,F,G,H,I) :- L>=M+1, L=:=1, M=:=0, J=:=1, 
          K=:=2.
new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=A, T=:=1, 
          new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=A, T=:=1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=A, T=:=1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=1, T=:=0, U=:=1, 
          V=:=2, new136(A,B,C,D,E,F,G,H,U,W,X,Y,Z,A1,B1,C1,D1,E1), 
          new135(W,X,Y,Z,A1,B1,C1,D1,V,J,K,L,M,N,O,P,Q,R).
new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=A, T=:=0, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=A, T=:=0, 
          new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new124(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=A, T=:=0, 
          new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=B, T=:=1, 
          new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=B, T=:=1, 
          new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=B, T=:=1, 
          new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new118(A,B,C,D,E,F,G,H,I,A,J,C,K,E,F,G,H,I) :- L>=M+1, L=:=1, M=:=0, J=:=1, 
          K=:=2.
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=B, T=:=0, 
          new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=B, T=:=0, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=B, T=:=0, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=L, Z=:=0, 
          A1=:=B1, new53(A,B,C,D,E,F,G,H,I,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,B1), 
          new99(D1,E1,F1,G1,H1,I1,J1,K1,L1,A1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=L, 
          Z=:=0, A1=:=1, B1=:=C1, 
          new110(A,B,C,A1,E,F,G,H,I,D1,E1,F1,G1,H1,I1,J1,K1,L1), 
          new53(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,C1), 
          new99(N1,O1,P1,Q1,R1,S1,T1,U1,V1,B1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=L, 
          Z=:=0, A1=:=1, B1=:=C1, 
          new110(A,B,C,A1,E,F,G,H,I,D1,E1,F1,G1,H1,I1,J1,K1,L1), 
          new53(D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,C1), 
          new99(N1,O1,P1,Q1,R1,S1,T1,U1,V1,B1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=D, Z=:=0, 
          new105(A,B,C,D,E,F,G,H,I,J,K,A1,M,N,O,P,Q,R,S,T,U,V,W,X).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=D, 
          Z=:=0, A1=:=B1, 
          new53(A,B,C,D,E,F,G,H,I,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,B1), 
          new99(D1,E1,F1,G1,H1,I1,J1,K1,L1,A1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=D, 
          Z=:=0, A1=:=B1, 
          new53(A,B,C,D,E,F,G,H,I,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,B1), 
          new99(D1,E1,F1,G1,H1,I1,J1,K1,L1,A1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=K, Z=:=0, 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=K, 
          Z=:=0, A1=:=1, new124(A,B,A1,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1), 
          new103(B1,C1,D1,E1,F1,G1,H1,I1,J1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=K, 
          Z=:=0, A1=:=1, new124(A,B,A1,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1), 
          new103(B1,C1,D1,E1,F1,G1,H1,I1,J1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=C, Z=:=0, 
          new102(A,B,C,D,E,F,G,H,I,J,A1,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=C, 
          Z=:=0, new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=C, 
          Z=:=0, new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new99(A,B,C,D,E,F,G,H,I,J,K,L,A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=J, N=:=0.
new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=J, Z=:=0, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=J, Z=:=0, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new94(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L=:=M, L=:=D, M=:=0, K=:=1.
new94(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L>=M+1, L=:=D, M=:=0, K=:=0.
new94(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L+1=<M, L=:=D, M=:=0, K=:=0.
new90(A,B,C,D,E,F,G,H,I,J,K,A,B,C,D,E,F,G,H,I,J,L) :- M>=N+1, M=:=J, N=:=0, 
          L=:=0.
new90(A,B,C,D,E,F,G,H,I,J,K,A,B,C,D,E,F,G,H,I,J,L) :- M+1=<N, M=:=J, N=:=0, 
          L=:=0.
new90(A,B,C,D,E,F,G,H,I,J,K,A,B,C,D,E,F,G,H,I,J,L) :- M=:=N, M=:=J, N=:=0, 
          L=:=1.
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=1, V=:=2, 
          new85(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=1, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=1, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new79(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,J) :- K=:=L, K=:=I, L=:=1, J=:=2.
new79(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=I, K=:=1.
new79(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=I, K=:=1.
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=H, T=:=1, U=:=2, 
          new79(A,B,C,D,E,F,G,U,I,J,K,L,M,N,O,P,Q,R).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=H, T=:=1, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=H, T=:=1, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new76(A,B,C,D,E,F,U,H,I,J,K,L,M,N,O,P,Q,R).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=G, T=:=1, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=G, T=:=1, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=1, V=:=2, 
          new82(A,B,C,D,E,F,V,H,I,J,K,L,M,N,O,P,Q,R,S).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=1, 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=1, 
          new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=L, 
          A1=:=0, new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, 
          new53(A,B,C,D,E,F,G,H,I,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,X), 
          new90(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K,L,M,N,O,P,Q,R,S,T,U,V).
new56(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,J,H,I) :- J=:=1.
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,J,K) :- 
          new52(A,B,C,D,E,F,G,H,I,V,L,M,N,O,P,Q,R,S,T,U,W).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, 
          new53(A,B,C,D,E,F,G,H,I,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Y), 
          new93(A1,B1,C1,D1,E1,F1,G1,H1,I1,X,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X=:=Y, X=:=K, 
          Y=:=0, W=:=4, new55(A,B,C,D,E,F,G,H,I,M,N,O,P,Q,R,S,T,U,V).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W>=X+1, W=:=K, 
          X=:=0, new60(A,B,C,D,E,F,G,H,I,Y,Z,M,N,O,P,Q,R,S,T,U,V,A1,B1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- W+1=<X, W=:=K, 
          X=:=0, new60(A,B,C,D,E,F,G,H,I,Y,Z,M,N,O,P,Q,R,S,T,U,V,A1,B1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X=:=Y, X=:=K, 
          Y=:=0, W=:=4, new56(A,B,C,D,E,F,G,H,I,Z,A1,B1,C1,D1,E1,F1,G1,H1), 
          new21(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,M,N,O,P,Q,R,S,T,U,V,K1,L1).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=K, 
          A1=:=0, B1=:=C1, 
          new61(A,B,C,D,E,F,G,H,I,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,C1), 
          new68(F1,G1,H1,I1,J1,K1,L1,M1,N1,J,K,B1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=K, 
          A1=:=0, B1=:=C1, 
          new61(A,B,C,D,E,F,G,H,I,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,C1), 
          new68(F1,G1,H1,I1,J1,K1,L1,M1,N1,J,K,B1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X=:=Y, X=:=K, 
          Y=:=0, W=:=4, new56(A,B,C,D,E,F,G,H,I,Z,A1,B1,C1,D1,E1,F1,G1,H1), 
          new22(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new70(K1,L1,M1,N1,O1,P1,Q1,R1,S1,M,N,O,P,Q,R,S,T,U,V).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X=:=Y, X=:=K, 
          Y=:=0, W=:=4, new56(A,B,C,D,E,F,G,H,I,Z,A1,B1,C1,D1,E1,F1,G1,H1), 
          new22(Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new71(K1,L1,M1,N1,O1,P1,Q1,R1,S1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2), 
          new60(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,M,N,O,P,Q,R,S,T,U,V,G2,H2).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=K, 
          A1=:=0, B1=:=4, C1=:=D1, 
          new56(A,B,C,D,E,F,G,H,I,E1,F1,G1,H1,I1,J1,K1,L1,M1), 
          new22(E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1), 
          new71(P1,Q1,R1,S1,T1,U1,V1,W1,X1,A2,B2,C2,D2,E2,F2,G2,H2,I2), 
          new61(A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,D1), 
          new68(L2,M2,N2,O2,P2,Q2,R2,S2,T2,B1,K,C1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new53(A,B,C,D,E,F,G,H,I,J,A,B,C,D,E,F,G,H,I,K) :- L=:=M, L=:=C, M=:=0, K=:=1.
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=C, V=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new53(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=C, V=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=C, W=:=0, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=C, W=:=0, 
          new96(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, 
          new53(A,B,C,D,E,F,G,H,I,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,Z), 
          new99(B1,C1,D1,E1,F1,G1,H1,I1,J1,Y,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,J,K,L) :- 
          new52(A,B,C,D,E,F,G,H,I,W,M,N,O,P,Q,R,S,T,U,V,X).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, 
          new53(A,B,C,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,A1), 
          new141(C1,D1,E1,F1,G1,H1,I1,J1,K1,Z,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X>=Y+1, X=:=1, 
          Y=:=0, W=:=1, 
          new27(A,B,C,D,E,F,G,H,I,Z,A1,B1,M,N,O,P,Q,R,S,T,U,V,C1,D1,E1).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X>=Y+1, X=:=1, 
          Y=:=0, Z=:=1, W=:=2, 
          new28(A,B,C,D,E,F,G,H,I,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1), 
          new6(D1,E1,F1,G1,H1,I1,J1,K1,L1,M,N,O,P,Q,R,S,T,U,V).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X>=Y+1, X=:=1, 
          Y=:=0, Z=:=1, A1=:=2, W=:=3, 
          new28(A,B,C,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1), 
          new7(E1,F1,G1,H1,I1,J1,K1,L1,M1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1), 
          new17(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,M,N,O,P,Q,R,S,T,U,V).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X>=Y+1, X=:=1, 
          Y=:=0, Z=:=1, A1=:=2, W=:=3, 
          new28(A,B,C,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1), 
          new7(E1,F1,G1,H1,I1,J1,K1,L1,M1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1), 
          new18(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new21(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,M,N,O,P,Q,R,S,T,U,V,K2,L2).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X>=Y+1, X=:=1, 
          Y=:=0, Z=:=1, A1=:=2, W=:=3, 
          new28(A,B,C,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1), 
          new7(E1,F1,G1,H1,I1,J1,K1,L1,M1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1), 
          new18(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new22(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2), 
          new24(K2,L2,M2,N2,O2,P2,Q2,R2,S2,M,N,O,P,Q,R,S,T,U,V).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- X>=Y+1, X=:=1, 
          Y=:=0, Z=:=1, A1=:=2, W=:=3, 
          new28(A,B,C,D,E,F,G,H,I,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1), 
          new7(E1,F1,G1,H1,I1,J1,K1,L1,M1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1), 
          new18(Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2), 
          new22(Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2), 
          new25(K2,L2,M2,N2,O2,P2,Q2,R2,S2,V2,W2,X2,Y2,Z2,A3,B3,C3,D3), 
          new52(V2,W2,X2,Y2,Z2,A3,B3,C3,D3,E3,M,N,O,P,Q,R,S,T,U,V,F3).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=1, 
          A1=:=0, B1=:=1, C1=:=2, D1=:=3, E1=:=F1, 
          new28(A,B,C,D,E,F,G,H,I,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1), 
          new7(J1,K1,L1,M1,N1,O1,P1,Q1,R1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2), 
          new18(V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2), 
          new22(E2,F2,G2,H2,I2,J2,K2,L2,M2,N2,O2,P2,Q2,R2,S2,T2,U2,V2,W2,X2,Y2,Z2), 
          new25(P2,Q2,R2,S2,T2,U2,V2,W2,X2,A3,B3,C3,D3,E3,F3,G3,H3,I3), 
          new53(A3,B3,C3,D3,E3,F3,G3,H3,I3,J3,K3,L3,M3,N3,O3,P3,Q3,R3,S3,F1), 
          new54(K3,L3,M3,N3,O3,P3,Q3,R3,S3,D1,E1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=G, T=:=1, U=:=2, 
          new193(A,B,C,D,E,F,U,H,I,J,K,L,M,N,O,P,Q,R).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=G, T=:=1, 
          new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=G, T=:=1, 
          new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=1, V=:=2, 
          new199(A,B,C,D,E,F,V,H,I,J,K,L,M,N,O,P,Q,R,S).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, 
          new205(A,B,C,D,E,F,G,H,I,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,X), 
          new206(Z,A1,B1,C1,D1,E1,F1,G1,H1,W,K,L,M,N,O,P,Q,R,S,T,U,V).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,J,K) :- 
          new215(A,B,C,D,E,F,G,H,I,V,L,M,N,O,P,Q,R,S,T,U,W).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, 
          new205(A,B,C,D,E,F,G,H,I,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,Y), 
          new217(A1,B1,C1,D1,E1,F1,G1,H1,I1,X,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=G, T=:=0, U=:=1, 
          new229(A,B,C,D,E,F,U,H,I,J,K,L,M,N,O,P,Q,R).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=G, T=:=0, 
          new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=G, T=:=0, 
          new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=0, V=:=1, 
          new235(A,B,C,D,E,F,V,H,I,J,K,L,M,N,O,P,Q,R,S).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=0, 
          new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=0, 
          new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=E, T=:=1, U=:=0, 
          new241(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=E, T=:=1, U=:=2, 
          new241(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=E, T=:=1, U=:=2, 
          new241(A,B,U,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=E, U=:=1, V=:=0, 
          new244(A,B,V,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=E, U=:=1, V=:=2, 
          new244(A,B,V,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=E, U=:=1, V=:=2, 
          new244(A,B,V,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new7(A,B,C,D,E,F,G,H,I,A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- W=:=0, 
          new6(A,B,C,D,E,F,G,H,I,M,N,O,P,Q,R,S,T,U,V).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- W=:=0, 
          new7(A,B,C,D,E,F,G,H,I,X,Y,Z,A1,B1,C1,D1,E1,F1), 
          new12(X,Y,Z,A1,B1,C1,D1,E1,F1,M,N,O,P,Q,R,S,T,U,V).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- W=:=0, 
          new7(A,B,C,D,E,F,G,H,I,X,Y,Z,A1,B1,C1,D1,E1,F1), 
          new13(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1), 
          new17(G1,H1,I1,J1,K1,L1,M1,N1,O1,M,N,O,P,Q,R,S,T,U,V).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- W=:=0, 
          new7(A,B,C,D,E,F,G,H,I,X,Y,Z,A1,B1,C1,D1,E1,F1), 
          new13(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1), 
          new18(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1), 
          new21(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,M,N,O,P,Q,R,S,T,U,V,A2,B2).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,K,L) :- W=:=0, 
          new7(A,B,C,D,E,F,G,H,I,X,Y,Z,A1,B1,C1,D1,E1,F1), 
          new13(X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1), 
          new18(G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1), 
          new22(P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2), 
          new24(A2,B2,C2,D2,E2,F2,G2,H2,I2,M,N,O,P,Q,R,S,T,U,V).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=0, 
          new7(A,B,C,D,E,F,G,H,I,A1,B1,C1,D1,E1,F1,G1,H1,I1), 
          new13(A1,B1,C1,D1,E1,F1,G1,H1,I1,J1,K1,L1,M1,N1,O1,P1,Q1,R1), 
          new18(J1,K1,L1,M1,N1,O1,P1,Q1,R1,S1,T1,U1,V1,W1,X1,Y1,Z1,A2), 
          new22(S1,T1,U1,V1,W1,X1,Y1,Z1,A2,B2,C2,D2,E2,F2,G2,H2,I2,J2,K2,L2,M2,N2), 
          new25(D2,E2,F2,G2,H2,I2,J2,K2,L2,O2,P2,Q2,R2,S2,T2,U2,V2,W2), 
          new26(O2,P2,Q2,R2,S2,T2,U2,V2,W2,Z,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new4(A,B,C,D,E,F,G,H,I,A,B,C,D,J,K,G,H,I) :- J=:=1, K=:=1.
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,J) :- 
          new3(A,B,C,D,E,F,G,H,I,K,L,M,N,O,P,Q,R,S,T).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,J) :- 
          new4(A,B,C,D,E,F,G,H,I,U,V,W,X,Y,Z,A1,B1,C1), 
          new5(U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,K,L,M,N,O,P,Q,R,S,T,G1,H1,I1).
new1 :- A=:=0, B=:=0, C=:=2, D=:=2, E=:=2, 
          new2(A,B,F,G,H,I,C,D,E,J,K,L,M,N,O,P,Q,R,S,T,U).
correct :- \+new1.
