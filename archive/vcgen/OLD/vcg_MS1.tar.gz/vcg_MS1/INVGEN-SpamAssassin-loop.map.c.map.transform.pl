new43(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=D, P=:=Q+R, Q=:=D, R=:=1, 
          new4(A,B,C,P,E,F,G,H,I,J,K,L,M).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=D, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new41(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=E, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M).
new41(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=E, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=D, P=:=Q+R, Q=:=D, R=:=1, 
          S=:=T+U, T=:=C, U=:=1, new41(A,B,S,P,E,F,G,H,I,J,K,L,M).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=D, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=E, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=E, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=C, 
          new37(A,B,C,D,E,F,G,H,I,J,K,L,M).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=C, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=B, 
          new35(A,B,C,D,E,F,G,H,I,J,K,L,M).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=B, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=D, P=:=Q+R, Q=:=D, R=:=1, 
          S=:=T+U, T=:=C, U=:=1, new33(A,B,S,P,E,F,G,H,I,J,K,L,M).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=D, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=E, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=E, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=C, 
          new29(A,B,C,D,E,F,G,H,I,J,K,L,M).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=C, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=B, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=B, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=C, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=C, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=D, P=:=Q+R, Q=:=D, R=:=1, 
          S=:=T+U, T=:=C, U=:=1, new4(A,B,S,P,E,F,G,H,I,J,K,L,M).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=D, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=E, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=E, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,80,A,B,C,D,E,F).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=C, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=C, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=B, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=B, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=P+Q, P=:=C, Q=:=1, O=:=B, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=P+Q, P=:=C, Q=:=1, O=:=B, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=P+Q, P=:=C, Q=:=1, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=P+Q, P=:=C, Q=:=1, O=:=B, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new3(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=F, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=F, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=B, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=B, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=B, P=:=0, 
          new4(A,B,C,P,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O-P, O=:=E, P=:=4, Q=:=0, 
          new3(A,B,Q,D,E,N,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
