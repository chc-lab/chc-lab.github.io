new11(A,B) :- C>=D+1, C=:=1, D=:=0, B=:=1.
new8(A,30,A).
new5(A,B,C) :- D=:=E, D=:=A, E=:=0, new3(A,B,C).
new5(A,B,C) :- D>=E+1, D=:=A, E=:=0, new8(A,B,C).
new5(A,B,C) :- D+1=<E, D=:=A, E=:=0, new8(A,B,C).
new5(A,B,C) :- D=:=E, D=:=A, E=:=0, new4(A,F), new5(F,B,C).
new4(A,B) :- new11(A,B).
new3(A,B,C) :- new12(A,B,C).
new2(A,B,C) :- new3(A,B,C).
new2(A,B,C) :- new4(A,D), new5(D,B,C).
new1 :- A=:=0, new2(A,B,C).
correct :- \+new1.
