new12(A,22,A).
new7(A,B,C) :- D=:=E, D=:=A, E=:=3, F=:=G+H, G=:=A, H=:=1, new3(F,B,C).
new7(A,B,C) :- D>=E+1, D=:=A, E=:=3, F=:=0, new3(F,B,C).
new7(A,B,C) :- D+1=<E, D=:=A, E=:=3, F=:=0, new3(F,B,C).
new4(A,B,C) :- D=:=E, D=:=A, E=:=2, F=:=G+H, G=:=A, H=:=1, new3(F,B,C).
new4(A,B,C) :- D>=E+1, D=:=A, E=:=2, new7(A,B,C).
new4(A,B,C) :- D+1=<E, D=:=A, E=:=2, new7(A,B,C).
new3(A,B,C) :- D>=E+1, D=:=A, E=:=4, new12(A,B,C).
new2(A,B,C) :- D=:=E, D=:=A, E=:=1, F=:=G+H, G=:=A, H=:=1, new3(F,B,C).
new2(A,B,C) :- D>=E+1, D=:=A, E=:=1, new4(A,B,C).
new2(A,B,C) :- D+1=<E, D=:=A, E=:=1, new4(A,B,C).
new1 :- new2(A,B,C).
correct :- \+new1.
