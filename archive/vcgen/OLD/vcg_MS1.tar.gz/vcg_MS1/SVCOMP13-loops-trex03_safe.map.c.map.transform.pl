new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=L, G1=:=0, H1=:=I1-J1, I1=:=C, C>=0, J1=:=H, H>=0, 
          K1=:=L1, M1=:=N1, 
          new6(A,B,H1,D,E,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=L, G1=:=0, H1=:=I1-J1, I1=:=C, C>=0, J1=:=H, H>=0, 
          K1=:=L1, M1=:=N1, 
          new6(A,B,H1,D,E,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=L, G1=:=0, H1=:=I1-J1, I1=:=E, E>=0, J1=:=I, I>=0, 
          K1=:=L1, M1=:=N1, 
          new6(A,B,C,D,H1,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=J, G1=:=0, H1=:=I1-J1, I1=:=A, A>=0, J1=:=G, G>=0, 
          K1=:=L1, M1=:=N1, 
          new6(H1,B,C,D,E,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=J, G1=:=0, H1=:=I1-J1, I1=:=A, A>=0, J1=:=G, G>=0, 
          K1=:=L1, M1=:=N1, 
          new6(H1,B,C,D,E,F,G,H,I,K1,K,M1,M,L1,N1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=J, G1=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=E, E>=0, G1=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=<G1, F1=:=E, E>=0, G1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,34,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=E, E>=0, G1=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=C, C>=0, G1=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=A, A>=0, G1=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=C, C>=0, G1=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=<G1, F1=:=C, C>=0, G1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=A, A>=0, G1=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=<G1, F1=:=A, A>=0, G1=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new3(A,A).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, G1>=0, H1=:=F1, I1=:=H1, H1>=0, J1=:=K1, K1>=0, L1=:=J1, 
          M1=:=L1, L1>=0, N1=:=O1, O1>=0, P1=:=N1, Q1=:=P1, P1>=0, R1=:=1, 
          S1=:=1, T1=:=1, U1=:=V1, W1=:=X1, new3(Y1,G1), new3(Z1,K1), 
          new3(A2,O1), 
          new6(I1,F1,M1,J1,Q1,N1,R1,S1,T1,U1,V1,W1,X1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new1 :- 
          new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
correct :- \+new1.
