new7(A,B,C,D,E,F,30,A,B,C,D,E,F) :- G>=H+1, G=:=I+J, I=:=D, J=:=E, H=:=K*L, 
          K=:=3, L=:=C.
new7(A,B,C,D,E,F,30,A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=D, J=:=E, H=:=K*L, 
          K=:=3, L=:=C.
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, P=:=Q+R, Q=:=D, R=:=1, 
          S=:=T+U, T=:=E, U=:=2, V=:=W+X, W=:=B, X=:=1, 
          new3(A,V,C,P,S,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=F, O=:=0, P=:=Q+R, Q=:=D, R=:=1, 
          S=:=T+U, T=:=E, U=:=2, V=:=W+X, W=:=B, X=:=1, 
          new3(A,V,C,P,S,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=F, O=:=0, P=:=Q+R, Q=:=D, R=:=2, 
          S=:=T+U, T=:=E, U=:=1, V=:=W+X, W=:=B, X=:=1, 
          new3(A,V,C,P,S,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=B, O=:=C, 
          new6(A,B,C,D,E,P,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=B, O=:=C, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=0, P=:=0, Q=:=0, R=:=0, 
          new3(A,P,C,Q,R,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
