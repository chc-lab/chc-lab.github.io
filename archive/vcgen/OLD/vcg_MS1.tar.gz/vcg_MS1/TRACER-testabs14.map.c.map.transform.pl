new9(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=10, new8(A,B,C,D,E,F,G).
new8(A,B,C,32,A,B,C).
new7(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=10, new8(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=10, new9(A,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new5(A,J,C,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=A, new7(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=A, J=:=K+L, K=:=C, L=:=1, 
          new3(A,B,J,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=A, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, I=:=0, J=:=10, new3(J,H,I,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
