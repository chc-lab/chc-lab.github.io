new21(A,B,C,D,E,F,31,A,B,C,D,E,F).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, P=:=Q+R, Q=:=E, R=:=1, 
          new16(A,B,C,D,P,F,G,H,I,J,K,L,M).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, P=:=Q+R, Q=:=D, 
          R=:=1, new15(A,B,C,P,E,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, P=:=F, 
          new16(A,B,C,D,P,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, P=:=F, 
          new11(A,B,C,P,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, P=:=Q+R, Q=:=D, R=:=1, 
          new9(A,B,C,P,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, P=:=Q+R, Q=:=D, R=:=1, 
          new11(A,B,C,P,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, P=:=C, Q=:=R-S, 
          R=:=C, S=:=1, new3(A,B,Q,D,E,P,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, P=:=F, 
          new15(A,B,C,P,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, P=:=F, 
          new9(A,B,C,P,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, P=:=F, 
          new9(A,B,C,P,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, P=:=F, 
          new11(A,B,C,P,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=B, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=B, P=:=C, Q=:=R-S, R=:=C, 
          S=:=1, new3(A,B,Q,D,E,P,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=1, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=1, P=:=B, 
          new3(A,B,P,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=1, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
