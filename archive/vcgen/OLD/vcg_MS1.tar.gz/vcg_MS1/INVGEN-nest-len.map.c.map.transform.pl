new18(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, 
          new18(J,B,C,D,E,F,G).
new18(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, J=:=K+L, K=:=B, L=:=1, 
          new3(A,J,C,D,E,F,G).
new16(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, 
          new16(J,B,C,D,E,F,G).
new16(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, J=:=1, new18(J,B,C,D,E,F,G).
new14(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, 
          new14(J,B,C,D,E,F,G).
new14(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, J=:=1, new16(J,B,C,D,E,F,G).
new12(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, 
          new12(J,B,C,D,E,F,G).
new12(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, J=:=1, new14(J,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, 
          new10(J,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, J=:=1, new12(J,B,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, 
          new8(J,B,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, J=:=1, new10(J,B,C,D,E,F,G).
new6(A,B,C,21,A,B,C).
new5(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, J=:=K+L, K=:=A, L=:=1, 
          new5(J,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, J=:=1, new8(J,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=B, J=:=1, new5(J,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=B, new6(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=C, new4(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=1, new3(A,H,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
