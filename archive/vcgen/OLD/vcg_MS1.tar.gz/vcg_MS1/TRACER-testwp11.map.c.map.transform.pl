new10(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=B, O=:=5, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,26,A,B,C,D,E,F).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=10, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=A, O=:=10, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=0, P=:=5, 
          new7(A,B,P,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=0, P=:=6, 
          new7(A,B,P,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, P=:=4, 
          new5(P,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=0, P=:=5, 
          new5(P,B,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=0, P=:=2, 
          new3(A,P,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=0, P=:=3, 
          new3(A,P,C,D,E,F,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
