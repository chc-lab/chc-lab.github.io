new7(A,B,C,D,21,A,B,C,D).
new6(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=2, new7(A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- new3(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=B, K=:=C, L=:=M+N, M=:=B, N=:=1, 
          new5(A,L,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=B, K=:=C, new6(A,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=0, L=:=1, new3(A,B,C,L,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=A, K=:=0, L=:=2, new3(A,B,C,L,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
