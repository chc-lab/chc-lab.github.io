new14(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=A, K=:=7, new8(A,B,C,D,E,F,G,H,I).
new12(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, L=:=M+N, M=:=A, N=:=4, 
          new14(L,B,C,D,E,F,G,H,I).
new12(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=0, L=:=M+N, M=:=A, N=:=4, 
          new14(L,B,C,D,E,F,G,H,I).
new12(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=D, K=:=0, new14(A,B,C,D,E,F,G,H,I).
new9(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=A, K=:=3, new12(A,B,C,L,E,F,G,H,I).
new9(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=3, new8(A,B,C,D,E,F,G,H,I).
new8(A,B,C,D,30,A,B,C,D).
new7(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, K=:=0, L=:=M+N, M=:=A, N=:=2, 
          new9(L,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=0, L=:=M+N, M=:=A, N=:=2, 
          new9(L,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=C, K=:=0, new9(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=A, K=:=1, new7(A,B,L,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=1, new8(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=B, K=:=0, L=:=M+N, M=:=A, N=:=1, 
          new4(L,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=B, K=:=0, L=:=M+N, M=:=A, N=:=1, 
          new4(L,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=B, K=:=0, new4(A,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=0, new3(J,K,C,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
