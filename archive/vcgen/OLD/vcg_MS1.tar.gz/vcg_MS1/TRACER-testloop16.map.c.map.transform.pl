new6(A,B,C,26,A,B,C).
new5(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=2, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=:=I, H=:=C, I=:=1, J=:=2, K=:=L+M, L=:=B, M=:=1, 
          new3(A,K,J,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=1, J=:=1, K=:=L+M, L=:=B, M=:=1, 
          new3(A,K,J,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=1, J=:=1, K=:=L+M, L=:=B, M=:=1, 
          new3(A,K,J,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=A, new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=A, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=1, I=:=0, new3(A,I,H,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
