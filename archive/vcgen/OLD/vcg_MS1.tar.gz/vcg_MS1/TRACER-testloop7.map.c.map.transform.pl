new7(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=1, J=:=0, new3(A,J,K,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=1, new3(A,B,J,D,E,F,G).
new6(A,B,C,28,A,B,C).
new5(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=2, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=2, J=:=2, new7(J,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=2, J=:=1, new7(J,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=10, new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=10, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, I=:=1, new3(I,H,J,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
