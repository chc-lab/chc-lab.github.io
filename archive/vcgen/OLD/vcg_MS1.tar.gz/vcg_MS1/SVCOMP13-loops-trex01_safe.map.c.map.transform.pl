new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=F, Q=:=0, R=:=S-T, S=:=B, 
          T=:=A, U=:=V-W, V=:=E, W=:=1, new10(A,R,X,D,U,F,G,H,I,J,K,L,M,N,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=F, Q=:=0, R=:=S-T, S=:=B, 
          T=:=A, U=:=V-W, V=:=E, W=:=1, new10(A,R,X,D,U,F,G,H,I,J,K,L,M,N,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=F, Q=:=0, R=:=S-T, S=:=C, 
          T=:=A, new10(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=0, R=:=S, 
          new13(A,B,C,D,E,R,S,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,23,A,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=B, Q=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=1, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=1, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=D, R=:=S*T, S=:=2, 
          T=:=E, new7(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=D, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=1, 
          new7(A,B,C,D,P,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,A,B) :- D>=E+1, D=:=A, E=:=0, F=:=1, 
          new4(F,G,H,I,J,K,L,C,M,N,O,P,Q,R,S).
new3(A,B,C,A,B) :- D+1=<E, D=:=A, E=:=0, F=:=1, 
          new4(F,G,H,I,J,K,L,C,M,N,O,P,Q,R,S).
new3(A,B,C,A,B) :- D=:=E, D=:=A, E=:=0, F=:=2, 
          new4(F,G,H,I,J,K,L,C,M,N,O,P,Q,R,S).
new2(A,B,C,D,E) :- F=:=G, new3(F,G,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
