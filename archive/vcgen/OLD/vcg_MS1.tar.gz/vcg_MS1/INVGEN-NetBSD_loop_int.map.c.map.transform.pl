new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=A, W=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new7(A,B,C,D,E,F,G,H,I,J,27,A,B,C,D,E,F,G,H,I,J).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=J, W=:=X+Y, 
          X=:=B, Y=:=1, new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W, V=:=J, W=:=X+Y, X=:=B, 
          Y=:=1, new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=<W, V=:=0, W=:=J, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=0, W=:=J, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=X+Y, X=:=G, 
          Y=:=J, W=:=H, Z=:=A1+B1, A1=:=J, B1=:=1, 
          new5(A,B,C,D,E,F,G,H,I,Z,K,L,M,N,O,P,Q,R,S,T,U).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=1, W=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=B, W=:=0, X=:=0, 
          Y=:=0, Z=:=A1-B1, A1=:=C1+D1, C1=:=B, D1=:=1, B1=:=1, E1=:=X, F1=:=X, 
          G1=:=Z, H1=:=Y, I1=:=0, 
          new3(A,B,X,Y,Z,E1,F1,G1,H1,I1,K,L,M,N,O,P,Q,R,S,T,U).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
correct :- \+new1.
