new31(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=J-K, J=:=B, K=:=1, L=:=0, 
          new3(A,B,L,D,E,F,G).
new31(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=J-K, J=:=B, K=:=1, 
          new3(A,B,C,D,E,F,G).
new29(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=B, J=:=K+L, K=:=C, L=:=1, 
          new31(A,B,J,D,E,F,G).
new29(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=B, new9(A,B,C,D,E,F,G).
new27(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=C, new29(A,B,C,D,E,F,G).
new27(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=C, new9(A,B,C,D,E,F,G).
new25(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=J-K, J=:=B, K=:=1, L=:=0, 
          new27(A,B,L,D,E,F,G).
new25(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=J-K, J=:=B, K=:=1, 
          new27(A,B,C,D,E,F,G).
new23(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=B, J=:=K+L, K=:=C, L=:=1, 
          new25(A,B,J,D,E,F,G).
new23(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=B, new9(A,B,C,D,E,F,G).
new21(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=C, new23(A,B,C,D,E,F,G).
new21(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=C, new9(A,B,C,D,E,F,G).
new19(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=J-K, J=:=B, K=:=1, L=:=0, 
          new21(A,B,L,D,E,F,G).
new19(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=J-K, J=:=B, K=:=1, 
          new21(A,B,C,D,E,F,G).
new17(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=B, J=:=K+L, K=:=C, L=:=1, 
          new19(A,B,J,D,E,F,G).
new17(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=B, new9(A,B,C,D,E,F,G).
new16(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=C, new17(A,B,C,D,E,F,G).
new16(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=C, new9(A,B,C,D,E,F,G).
new13(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new13(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new13(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, new16(A,B,C,D,E,F,G).
new9(A,B,C,59,A,B,C).
new8(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=B, new9(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=C, new8(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=C, new9(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, new7(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, new13(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, new6(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=0, J=:=0, new3(A,B,J,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
