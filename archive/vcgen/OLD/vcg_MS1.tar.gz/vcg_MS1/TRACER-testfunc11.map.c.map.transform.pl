new8.
new6(A,19,A).
new5(A,B,C) :- D>=E+1, D=:=A, E=:=1, new6(A,B,C).
new5(A,B,C) :- D+1=<E, D=:=A, E=:=1, new6(A,B,C).
new4(A,B) :- B=:=1, new8.
new3(A,B,A) :- new9(B).
new2(A,B,A) :- new3(C,B,D).
new2(A,B,C) :- D=:=E, new4(F,E), new5(D,B,C).
new1 :- new2(A,B,C).
correct :- \+new1.
