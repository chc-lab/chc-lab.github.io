new16(A,B,C,D,25,A,B,C,D).
new14(A,B,C,D,A,E,F,G) :- H=<I, H=:=B, I=:=A, F=:=J+K, J=:=C, K=:=B, G=:=L*M, 
          L=:=D, M=:=B, E=:=N+O, N=:=B, O=:=1.
new14(A,B,C,D,A,B,C,D) :- E>=F+1, E=:=B, F=:=A.
new9(A,B,C,D,E,F,G,H) :- I=:=1, J=:=0, K=:=1, new14(A,I,J,K,E,F,G,H).
new8(A,B,C,D,E,F,G,H,I) :- J=:=1, K=:=0, L=:=1, new15(A,J,K,L,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=A, K=:=0, new16(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- new4(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, L=:=M+N, M=:=A, N=:=1, 
          new6(L,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=0, L=:=M+N, M=:=A, N=:=1, 
          new6(L,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,A,B,C,D) :- F=:=G, F=:=D, G=:=0, H=:=A, new8(H,I,J,K,E,L,M,N,O).
new3(A,B,C,D,E,F,G,C,D) :- H=:=I, H=:=D, I=:=0, J=:=A, G=:=K, F=:=L-M, L=:=G, 
          M=:=1, N=:=5, new9(J,O,P,Q,R,S,K,T), new8(N,U,V,W,E,X,Y,Z,A1).
new3(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=D, K=:=0, L=:=A, M=:=N, O=:=P-Q, P=:=M, 
          Q=:=1, R=:=5, S=:=T, U=:=V+W, V=:=S, W=:=5, new9(L,X,Y,Z,A1,B1,N,C1), 
          new9(R,D1,E1,F1,G1,H1,T,I1), new6(U,M,S,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=0, new3(A,B,C,L,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=A, K=:=0, new4(A,B,C,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
