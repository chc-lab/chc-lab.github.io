new8(A,B,24,A,B).
new6(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0, new8(A,B,C,D,E).
new6(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=0, new8(A,B,C,D,E).
new5(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=16, new6(A,B,C,D,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=16, new6(A,B,C,D,E).
new3(A,B,C,D,E) :- F=<G, F=:=A, G=:=8, H=:=I+J, I=:=B, J=:=2, K=:=L+M, L=:=A, 
          M=:=1, new3(K,H,C,D,E).
new3(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=8, new5(A,B,C,D,E).
new2(A,B,C,D,E) :- F=:=0, G=:=1, new3(G,F,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
