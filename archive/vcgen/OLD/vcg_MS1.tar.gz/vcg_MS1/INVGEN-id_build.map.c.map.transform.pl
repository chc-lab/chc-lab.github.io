new8(A,B,C,30,A,B,C).
new7(A,B,C,D,E,F,G) :- H+1=<I, H=:=J-K, J=:=L-M, L=:=A, M=:=1, K=:=B, I=:=A, 
          N=:=O+P, O=:=C, P=:=1, new4(A,B,N,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H>=I, H=:=J-K, J=:=L-M, L=:=A, M=:=1, K=:=B, I=:=A, 
          new8(A,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=J-K, J=:=L-M, L=:=A, M=:=1, K=:=B, 
          new7(A,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=J-K, J=:=L-M, L=:=A, M=:=1, K=:=B, 
          new8(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=8, new5(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=8, J=:=K+L, K=:=B, L=:=1, 
          new3(A,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=A, J=:=0, new4(A,B,J,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, new3(A,H,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
