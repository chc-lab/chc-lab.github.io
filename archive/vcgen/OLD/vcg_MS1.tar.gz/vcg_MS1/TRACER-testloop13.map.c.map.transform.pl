new7(A,B,C,D,25,A,B,C,D).
new6(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=A, K=:=0, new7(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, L=:=0, M=:=N+O, N=:=C, O=:=2, 
          new3(L,B,M,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=0, L=:=0, M=:=N+O, N=:=C, O=:=2, 
          new3(L,B,M,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=D, K=:=0, new3(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, K=:=B, L=:=1, M=:=C, 
          new4(L,M,C,N,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=B, L=:=1, M=:=C, 
          new4(L,M,C,N,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=C, K=:=B, new6(A,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=0, K=:=L+M, L=:=B, M=:=1, 
          new3(J,B,K,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
