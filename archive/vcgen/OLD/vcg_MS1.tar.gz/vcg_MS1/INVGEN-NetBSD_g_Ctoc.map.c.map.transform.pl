new18(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, N=:=O+P, O=:=C, P=:=1, 
          Q=:=R+S, R=:=D, S=:=1, T=:=U-V, U=:=E, V=:=1, 
          new7(A,B,N,Q,T,F,G,H,I,J,K).
new16(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=A, 
          new18(A,B,C,D,E,F,G,H,I,J,K).
new16(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=A, new6(A,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=0, M=:=C, 
          new16(A,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=0, M=:=C, 
          new6(A,B,C,D,E,F,G,H,I,J,K).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=A, 
          new14(A,B,C,D,E,F,G,H,I,J,K).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=A, new6(A,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=0, M=:=D, 
          new12(A,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=0, M=:=D, 
          new6(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=1, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,38,A,B,C,D,E).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, N=:=0, O=:=0, 
          new7(A,B,N,O,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=0, N=:=0, O=:=0, 
          new7(A,B,N,O,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=0, M=:=N-O, N=:=A, O=:=1, 
          new5(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=0, M=:=N-O, N=:=A, O=:=1, 
          new6(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=A, new3(A,B,C,D,L,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
