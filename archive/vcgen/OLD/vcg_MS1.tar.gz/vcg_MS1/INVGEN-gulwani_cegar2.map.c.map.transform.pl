new8(A,B,C,D,29,A,B,C,D).
new7(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=D, new8(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=0, K=:=C, new7(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=0, K=:=C, new8(A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, new6(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=0, L=:=B, M=:=N+O, N=:=B, O=:=1, 
          new3(A,M,L,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=0, L=:=B, M=:=N+O, N=:=B, O=:=1, 
          new3(A,M,L,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=A, K=:=0, L=:=M+N, M=:=B, N=:=1, 
          new3(A,L,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=B, K=:=D, new4(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=B, K=:=D, new5(A,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=0, K=:=0, new3(A,J,K,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
