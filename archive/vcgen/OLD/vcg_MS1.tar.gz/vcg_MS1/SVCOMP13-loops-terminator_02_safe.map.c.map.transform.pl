new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=G, S=:=0, T=:=U+V, 
          U=:=A, V=:=1, new7(T,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=G, S=:=0, T=:=U+V, 
          U=:=A, V=:=1, new7(T,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, R=:=G, S=:=0, T=:=U-V, 
          U=:=A, V=:=1, W=:=X-Y, X=:=E, Y=:=1, 
          new7(T,B,C,D,W,F,G,H,I,J,K,L,M,N,O,P,Q).
new12(A,B,C,D,E,F,G,H,33,A,B,C,D,E,F,G,H).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S+1, R=:=E, S=:=100, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=A, S=:=100, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=100, S=:=E, T=:=U, 
          new13(A,B,C,D,E,F,T,U,I,J,K,L,M,N,O,P,Q).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S, R=:=100, S=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=A, S=:=100, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S, R=:=A, S=:=100, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=E, S=:=100, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S, R=:=E, S=:=100, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R+1=<S, R=:=A, S=:=100, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R>=S, R=:=A, S=:=100, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- R=:=S, T=:=U, V=:=W, 
          new3(R,S,T,U,V,W,G,H,I,J,K,L,M,N,O,P,Q).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
correct :- \+new1.
