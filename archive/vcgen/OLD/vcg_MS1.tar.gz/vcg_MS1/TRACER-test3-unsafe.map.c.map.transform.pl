new8(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=10, new7(A,B,C,D,E,F,G).
new7(A,B,C,21,A,B,C).
new4(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=5, new7(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=5, new8(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=5, new8(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, J=:=5, new4(J,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=0, J=:=5, new4(J,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=:=I, H=:=C, I=:=0, J=:=10, new4(A,J,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, I=:=0, new3(H,I,J,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
