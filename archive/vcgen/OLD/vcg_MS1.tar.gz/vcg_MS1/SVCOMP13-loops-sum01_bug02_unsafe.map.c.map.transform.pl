new9(A,B,C,D,E,26,A,B,C,D,E).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=N*O, N=:=C, O=:=2, 
          new7(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=N*O, N=:=C, O=:=2, 
          new7(A,B,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=B, N=:=O+P, O=:=E, P=:=2, 
          Q=:=R-S, R=:=B, S=:=1, T=:=U+V, U=:=A, V=:=1, 
          new4(T,Q,C,D,N,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=A, M=:=B, N=:=O-P, O=:=B, P=:=1, 
          Q=:=R+S, R=:=A, S=:=1, new4(Q,N,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=A, M=:=C, new5(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=C, 
          new6(A,B,C,D,E,F,G,H,I,J,K).
new3(A,A).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=10, M=:=N, N>=0, O=:=M, P=:=0, Q=:=1, 
          new3(R,N), new4(Q,L,O,M,P,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
