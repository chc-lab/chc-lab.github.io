new6(A,B,C,D,E,26,A,B,C,D,E).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=C, M=:=D, 
          new6(A,B,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=D, 
          new6(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=O+P, O=:=C, P=:=1, 
          Q=:=0, R>=S+1, R=:=B, S=:=0, T=:=U+V, U=:=E, V=:=1, 
          new3(A,Q,N,D,T,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=O+P, O=:=C, P=:=1, 
          Q=:=0, R+1=<S, R=:=B, S=:=0, T=:=U+V, U=:=E, V=:=1, 
          new3(A,Q,N,D,T,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, N=:=O+P, O=:=D, P=:=1, 
          Q=:=1, R=:=S, R=:=B, S=:=0, T=:=U+V, U=:=E, V=:=1, 
          new3(A,Q,C,N,T,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=N*O, N=:=2, O=:=A, 
          new4(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=E, M=:=N*O, N=:=2, O=:=A, 
          new5(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=100, M=:=D, N=:=0, 
          new3(L,B,M,D,N,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
