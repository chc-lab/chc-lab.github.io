new61(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=E, P=:=Q+R, Q=:=E, R=:=1, 
          new17(A,B,C,D,P,F,G,H,I,J,K,L,M).
new61(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=C, 
          new61(A,B,C,D,E,F,G,H,I,J,K,L,M).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=E, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=E, P=:=Q+R, Q=:=E, R=:=1, 
          new38(A,B,C,D,P,F,G,H,I,J,K,L,M).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=C, 
          new54(A,B,C,D,E,F,G,H,I,J,K,L,M).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=E, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=F, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=F, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new47(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=F, O=:=D, 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M).
new47(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=F, O=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, P=:=Q+R, Q=:=F, 
          R=:=1, new47(A,B,C,D,E,P,G,H,I,J,K,L,M).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, P=:=Q+R, Q=:=F, 
          R=:=1, new47(A,B,C,D,E,P,G,H,I,J,K,L,M).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, P=:=Q+R, Q=:=E, R=:=1, 
          new38(A,B,C,D,P,F,G,H,I,J,K,L,M).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=E, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=C, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=E, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=F, O=:=P-Q, P=:=D, Q=:=1, 
          new42(A,B,C,D,E,F,G,H,I,J,K,L,M).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=P-Q, P=:=C, Q=:=1, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=P-Q, P=:=C, Q=:=1, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=E, 
          new38(A,B,C,D,E,F,G,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=C, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=E, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, P=:=0, 
          new34(A,B,C,D,E,P,G,H,I,J,K,L,M).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, P=:=0, 
          new34(A,B,C,D,E,P,G,H,I,J,K,L,M).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=P+Q, P=:=E, Q=:=1, O=:=R-S, 
          R=:=C, S=:=1, T=:=U+V, U=:=E, V=:=1, W=:=T, 
          new32(A,W,C,D,T,F,G,H,I,J,K,L,M).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=P+Q, P=:=E, Q=:=1, O=:=R-S, 
          R=:=C, S=:=1, T=:=U+V, U=:=E, V=:=1, W=:=T, 
          new32(A,W,C,D,T,F,G,H,I,J,K,L,M).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=P+Q, P=:=E, Q=:=1, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=P+Q, P=:=E, Q=:=1, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=P+Q, P=:=E, Q=:=1, O=:=C, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=P+Q, P=:=E, Q=:=1, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=P-Q, P=:=C, Q=:=1, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=P-Q, P=:=C, Q=:=1, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=E, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=C, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=E, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=P-Q, P=:=C, Q=:=1, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=P-Q, P=:=C, Q=:=1, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=E, O=:=P-Q, P=:=C, Q=:=1, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=E, 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=C, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=E, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new10(A,B,C,D,E,F,103,A,B,C,D,E,F).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=0, O=:=P-Q, P=:=E, Q=:=1, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=0, O=:=P-Q, P=:=E, Q=:=1, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=P-Q, P=:=E, Q=:=1, O=:=C, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=P-Q, P=:=E, Q=:=1, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=P-Q, P=:=C, Q=:=1, O=:=B, R=:=B, 
          new8(A,B,C,D,R,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=B, O=:=0, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=B, O=:=0, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=B, O=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=0, 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
