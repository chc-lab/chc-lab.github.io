new6(A,B,19,A,B).
new5(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=0, new6(A,B,C,D,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0, new6(A,B,C,D,E).
new3(A,B,C,D,E) :- F=:=G, F=:=A, G=:=0, new5(A,B,C,D,E).
new2(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0, H=:=0, new3(H,B,C,D,E).
new2(A,B,C,D,E) :- F=<G, F=:=B, G=:=0, H=:=1, new3(H,B,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
