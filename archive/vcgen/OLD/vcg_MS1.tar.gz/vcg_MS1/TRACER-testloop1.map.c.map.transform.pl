new8(A,B,C,D,E,26,A,B,C,D,E).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=C, N=:=O+P, O=:=B, P=:=1, 
          new4(A,N,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=B, M=:=C, new7(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=0, N=:=1, 
          new4(A,B,C,N,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=A, M=:=0, N=:=2, 
          new4(A,B,C,N,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=0, new3(A,M,C,D,L,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
