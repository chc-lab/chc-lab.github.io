new6(A,B,23,A,B).
new5(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=B, new6(A,B,C,D,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=B, H=:=I+J, I=:=A, J=:=1, new3(H,B,C,D,E).
new3(A,B,C,D,E) :- F>=G, F=:=A, G=:=B, new5(A,B,C,D,E).
new2(A,B,C,D,E) :- F=:=0, G=:=100, new3(F,G,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
