new15(A,B,C,D,E,30,A,B,C,D,E).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=1, M=:=B, N=:=O+P, O=:=B, P=:=1, 
          new7(A,N,C,D,E,F,G,H,I,J,K).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=1, M=:=B, 
          new15(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=D, N=:=O+P, O=:=B, P=:=1, 
          new9(A,N,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=B, M=:=D, N=:=O+P, O=:=C, P=:=1, 
          new3(A,B,N,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=D, 
          new12(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=B, M=:=D, N=:=E, 
          new9(A,N,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=0, N=:=E, 
          new7(A,N,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=0, N=:=E, 
          new7(A,N,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=0, N=:=E, 
          new9(A,N,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- new4(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=D, 
          new6(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, N=:=1, 
          new3(A,B,N,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=E, M=:=0, new4(A,B,C,D,E,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
