new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=V-W, V=:=X-Y, 
          X=:=Z*A1, Z=:=2, A1=:=C, Y=:=A, W=:=E, U=:=0, B1=:=C1+D1, C1=:=A, 
          D1=:=B, E1=:=F1+G1, F1=:=E, G1=:=F, H1=:=I1+J1, I1=:=C, J1=:=D, 
          K1=:=L1+M1, L1=:=D, M1=:=1, N1=:=O1+P1, O1=:=G, P1=:=1, 
          new9(B1,B,H1,K1,E1,F,N1,H,Q1,J,K,L,M,N,O,P,Q,R,S).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V-W, V=:=X-Y, 
          X=:=Z*A1, Z=:=2, A1=:=C, Y=:=A, W=:=E, U=:=0, B1=:=C1+D1, C1=:=A, 
          D1=:=B, E1=:=F1+G1, F1=:=E, G1=:=F, H1=:=I1+J1, I1=:=C, J1=:=D, 
          K1=:=L1-M1, L1=:=D, M1=:=1, N1=:=O1+P1, O1=:=G, P1=:=1, 
          new9(B1,B,H1,K1,E1,F,N1,H,Q1,J,K,L,M,N,O,P,Q,R,S).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=0, 
          new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=0, 
          new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=0, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=D, U=:=5, 
          new31(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V-W, V=:=B, W=:=F, 
          U=:=0, new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V+W, V=:=X+Y, 
          X=:=Z-A1, Z=:=B, A1=:=B1*C1, B1=:=2, C1=:=D, Y=:=F, W=:=D1*E1, 
          D1=:=2, E1=:=G, U=:=0, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V+W, V=:=X+Y, 
          X=:=Z-A1, Z=:=B, A1=:=B1*C1, B1=:=2, C1=:=D, Y=:=F, W=:=D1*E1, 
          D1=:=2, E1=:=G, U=:=0, new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V+W, V=:=C, W=:=X*Y, 
          X=:=5, Y=:=G, U=:=75, new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V+W, V=:=C, 
          W=:=X*Y, X=:=5, Y=:=G, U=:=75, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V+W, V=:=D, W=:=6, 
          U=:=0, new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V+W, V=:=D, W=:=6, 
          U=:=0, new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=F, U=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=F, U=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=D, U=:=6, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=D, U=:=6, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V+W, V=:=X*Y, X=:=5, 
          Y=:=G, W=:=75, U=:=C, new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V+W, V=:=X*Y, 
          X=:=5, Y=:=G, W=:=75, U=:=C, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new14(A,B,C,D,E,F,G,H,I,73,A,B,C,D,E,F,G,H,I).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V+W, V=:=X*Y, X=:=2, 
          Y=:=D, W=:=Z*A1, Z=:=2, A1=:=G, U=:=B1+C1, B1=:=B, C1=:=F, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=V+W, V=:=X*Y, 
          X=:=2, Y=:=D, W=:=Z*A1, Z=:=2, A1=:=G, U=:=B1+C1, B1=:=B, C1=:=F, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=B, U=:=5, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=B, U=:=5, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V+W, V=:=D, W=:=5, 
          U=:=0, new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=D, U=:=5, 
          new9(A,B,C,D,E,F,G,H,V,J,K,L,M,N,O,P,Q,R,S).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V+W, V=:=D, W=:=5, 
          U=:=0, new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=V-W, V=:=X-Y, 
          X=:=Z*A1, Z=:=2, A1=:=D, Y=:=B, W=:=F, U=:=0, B1=:=0, 
          new7(A,B,C,D,E,F,B1,H,I,J,K,L,M,N,O,P,Q,R,S).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=V-W, V=:=B, W=:=F, 
          U=:=0, new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=<U, T=:=B, U=:=5, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U, T=:=F, U=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=100, U=:=75, V=:= -50, 
          new3(T,B,U,D,V,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
correct :- \+new1.
