new14(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=N*O, N=:=2, O=:=B, P=:=Q+R, 
          Q=:=D, R=:=1, new7(A,B,C,P,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=N*O, N=:=2, O=:=B, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,44,A,B,C,D,E).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=D, M=:=E, N=:=O+P, O=:=C, P=:=1, 
          new4(A,B,N,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=E, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=E, new10(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=E, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=E, 
          new14(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=E, N=:=O+P, O=:=C, P=:=1, 
          new4(A,B,N,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=0, N=:=C, 
          new7(A,B,C,N,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=0, N=:=C, 
          new7(A,B,C,N,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=0, new9(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=E, 
          new5(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=E, N=:=O+P, O=:=B, P=:=1, 
          new3(A,N,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=E, N=:=O*P, O=:=2, P=:=B, 
          new4(A,B,N,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=D, M=:=E, N=:=0, 
          new3(A,N,C,D,E,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
