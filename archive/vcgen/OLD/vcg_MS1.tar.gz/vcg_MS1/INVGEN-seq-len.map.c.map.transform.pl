new16(A,B,C,D,E,61,A,B,C,D,E).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, N=:=O+P, O=:=D, P=:=1, 
          Q=:=R-S, R=:=E, S=:=1, new13(A,B,C,N,Q,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=E, M=:=0, 
          new16(A,B,C,D,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=A, 
          new14(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=B, N=:=O+P, O=:=D, P=:=1, 
          Q=:=R-S, R=:=E, S=:=1, new11(A,B,C,N,Q,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=B, N=:=0, 
          new13(A,B,C,N,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=C, N=:=O+P, O=:=D, P=:=1, 
          Q=:=R-S, R=:=E, S=:=1, new9(A,B,C,N,Q,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=C, N=:=0, 
          new11(A,B,C,N,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=C, N=:=O+P, O=:=D, P=:=1, 
          Q=:=R+S, R=:=E, S=:=1, new7(A,B,C,N,Q,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=C, N=:=0, 
          new9(A,B,C,N,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=B, N=:=O+P, O=:=D, P=:=1, 
          Q=:=R+S, R=:=E, S=:=1, new5(A,B,C,N,Q,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=B, N=:=0, 
          new7(A,B,C,N,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=A, N=:=O+P, O=:=D, P=:=1, 
          Q=:=R+S, R=:=E, S=:=1, new3(A,B,C,N,Q,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=D, M=:=A, N=:=0, 
          new5(A,B,C,N,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=0, new3(A,B,C,L,M,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
