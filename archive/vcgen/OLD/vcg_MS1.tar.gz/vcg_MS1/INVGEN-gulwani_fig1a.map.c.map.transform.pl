new6(A,B,C,23,A,B,C).
new5(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=0, new6(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=0, J=:=K+L, K=:=B, L=:=C, M=:=N+O, 
          N=:=C, O=:=1, new3(A,J,M,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=0, new5(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:= -50, new3(A,H,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
