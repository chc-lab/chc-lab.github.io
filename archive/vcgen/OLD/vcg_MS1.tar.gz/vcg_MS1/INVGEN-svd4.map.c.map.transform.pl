new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=B, R=:=S+T, S=:=D, 
          T=:=1, new11(A,B,C,R,E,F,G,H,I,J,K,L,M,N,O).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=D, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=G, 
          new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=G, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=B, R=:=S+T, S=:=E, 
          T=:=1, new36(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=D, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=B, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=E, Q=:=G, 
          new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=E, Q=:=G, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=B, R=:=S+T, S=:=E, 
          T=:=1, new56(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=B, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=D, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=E, Q=:=G, 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=E, Q=:=G, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=E, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=E, Q=:=G, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=E, Q=:=G, R=:=S+T, S=:=D, 
          T=:=1, new15(A,B,C,R,E,F,G,H,I,J,K,L,M,N,O).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=B, R=:=C, 
          new56(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=G, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=G, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=E, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=B, R=:=S+T, S=:=D, 
          T=:=1, new37(A,B,C,R,E,F,G,H,I,J,K,L,M,N,O).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=G, 
          new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=G, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=D, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=G, 
          new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=G, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=E, Q=:=G, 
          new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=E, Q=:=G, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=B, R=:=S+T, S=:=D, 
          T=:=1, new17(A,B,C,R,E,F,G,H,I,J,K,L,M,N,O).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=G, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=G, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=B, R=:=S-T, S=:=C, 
          T=:=1, new6(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=G, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=G, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=D, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=G, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=G, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=B, R=:=F, 
          new36(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=B, R=:=C, 
          new37(A,B,C,R,E,F,G,H,I,J,K,L,M,N,O).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=A, Q=:=0, R=:=F, 
          new15(A,B,C,R,E,F,G,H,I,J,K,L,M,N,O).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=A, Q=:=0, R=:=F, 
          new15(A,B,C,R,E,F,G,H,I,J,K,L,M,N,O).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=A, Q=:=0, R=:=C, 
          new17(A,B,C,R,E,F,G,H,I,J,K,L,M,N,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=B, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=B, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,174,A,B,C,D,E,F,G).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=B, R=:=F, 
          new11(A,B,C,R,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=1, Q=:=C, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=1, Q=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=C, Q=:=1, R=:=S+T, S=:=C, 
          T=:=1, new8(A,B,C,D,E,R,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=G, Q=:=B, R=:=G, 
          new6(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=G, Q=:=B, R=:=B, 
          new6(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=B, Q=:=G, 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=B, Q=:=G, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
correct :- \+new1.
