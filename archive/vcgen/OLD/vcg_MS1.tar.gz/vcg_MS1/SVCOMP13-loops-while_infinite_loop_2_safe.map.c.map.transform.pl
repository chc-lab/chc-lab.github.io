new5(A,23,A).
new3(A,B,C) :- D=:=E, D=:=A, E=:=0, new3(A,B,C).
new3(A,B,C) :- D>=E+1, D=:=A, E=:=0, new5(A,B,C).
new3(A,B,C) :- D+1=<E, D=:=A, E=:=0, new5(A,B,C).
new2(A,B,C) :- D=:=0, new3(D,B,C).
new1 :- new2(A,B,C).
correct :- \+new1.
