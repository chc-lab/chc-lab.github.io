new10(A,B,C,D,E,F,G,35,A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=R-S, R=:=D, S=:=B, Q=:=T*U, 
          T=:=2, U=:=E, V=:=W+X, W=:=D, X=:=1, 
          new5(A,B,C,V,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=R-S, R=:=D, S=:=B, Q=:=T*U, 
          T=:=2, U=:=E, new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=D, Q=:=C, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=D, Q=:=C, R=:=S+T, S=:=C, 
          T=:=1, new4(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=C, Q=:=R*S, R=:=3, S=:=B, 
          T=:=B, new5(A,B,C,T,E,F,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=C, Q=:=R*S, R=:=3, S=:=B, 
          T=:=U+V, U=:=B, V=:=1, new3(A,T,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=B, Q=:=E, R=:=S*T, S=:=2, 
          T=:=B, new4(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=R*S, R=:=3, S=:=E, Q=:=T+U, 
          T=:=G, U=:=F, V=:=0, new3(A,V,C,D,E,F,G,H,I,J,K,L,M,N,O).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
correct :- \+new1.
