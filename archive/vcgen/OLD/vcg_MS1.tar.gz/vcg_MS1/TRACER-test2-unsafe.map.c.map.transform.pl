new15(A,B,C,24,A,B,C).
new13(A,B,C,D,A,E,F,G) :- H=<I, H=:=B, I=:=A, F=:=J+K, J=:=C, K=:=B, G=:=L*M, 
          L=:=D, M=:=B, E=:=N+O, N=:=B, O=:=1.
new13(A,B,C,D,A,B,C,D) :- E>=F+1, E=:=B, F=:=A.
new8(A,B,C,D,E,F,G,H) :- I=:=1, J=:=0, K=:=1, new13(A,I,J,K,E,F,G,H).
new7(A,B,C,D,E,F,G,H,I) :- J=:=1, K=:=0, L=:=1, new14(A,J,K,L,E,F,G,H,I).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, new15(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=K+L, K=:=A, L=:=1, 
          new6(J,B,C,D,E,F,G).
new3(A,B,C,D,A,B,C) :- E=<F, E=:=A, F=:=0, G=:=A, new7(G,H,I,J,D,K,L,M,N).
new3(A,B,C,D,E,F,C) :- G=<H, G=:=A, H=:=0, I=:=A, F=:=J, E=:=K-L, K=:=F, L=:=1, 
          M=:=5, new8(I,N,O,P,Q,R,J,S), new7(M,T,U,V,D,W,X,Y,Z).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=0, J=:=A, K=:=L, M=:=N-O, N=:=K, O=:=1, 
          P=:=5, Q=:=R, S=:=T+U, T=:=Q, U=:=5, new8(J,V,W,X,Y,Z,L,A1), 
          new8(P,B1,C1,D1,E1,F1,R,G1), new6(S,K,Q,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, new3(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=<I, H=:=A, I=:=0, new4(A,B,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
