new22(A,B,C,D,E,52,A,B,C,D,E) :- F>=G, F=:= -1, G=:=D.
new22(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:= -1, M=:=D, N=:=O+P, O=:=C, P=:=1, 
          new7(A,B,N,D,E,F,G,H,I,J,K).
new21(A,B,C,D,E,52,A,B,C,D,E) :- F>=G, F=:=D, G=:=A.
new21(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=A, 
          new22(A,B,C,D,E,F,G,H,I,J,K).
new20(A,B,C,D,E,52,A,B,C,D,E) :- F>=G, F=:= -1, G=:=B.
new20(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:= -1, M=:=B, 
          new21(A,B,C,D,E,F,G,H,I,J,K).
new17(A,B,C,D,E,52,A,B,C,D,E) :- F>=G, F=:=B, G=:=A.
new17(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=A, 
          new20(A,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=D, 
          new17(A,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=D, 
          new17(A,B,C,D,E,F,G,H,I,J,K).
new14(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=D, N=:=O+P, O=:=C, P=:=1, 
          new7(A,B,N,D,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, N=:=C, 
          new14(A,B,C,N,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=E, M=:=0, N=:=C, 
          new14(A,B,C,N,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=E, M=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K).
new12(A,B,C,D,E,52,A,B,C,D,E) :- F>=G, F=:= -1, G=:=D.
new12(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:= -1, M=:=D, 
          new13(A,B,C,D,N,F,G,H,I,J,K).
new11(A,B,C,D,E,52,A,B,C,D,E) :- F>=G, F=:=D, G=:=A.
new11(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=A, 
          new12(A,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,52,A,B,C,D,E) :- F>=G, F=:= -1, G=:=C.
new10(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:= -1, M=:=C, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new8(A,B,C,D,E,52,A,B,C,D,E) :- F>=G, F=:=C, G=:=A.
new8(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=A, 
          new10(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=C, M=:=A, 
          new8(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=C, M=:=A, N=:=O+P, O=:=B, P=:=1, 
          new4(A,N,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- new5(A,B,C,D,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=N-O, N=:=A, O=:=1, P=:=B, 
          Q=:=R+S, R=:=B, S=:=1, new7(A,B,Q,P,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=A, M=:=0, new4(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=0, N=:=0, new3(A,L,M,N,E,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
