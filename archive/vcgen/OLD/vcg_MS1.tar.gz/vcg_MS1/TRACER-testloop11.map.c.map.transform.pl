new17(A,B,C,31,A,B,C).
new12(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=3, J=:=5, new3(A,J,K,D,E,F,G).
new12(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=3, J=:=5, new3(A,J,K,D,E,F,G).
new12(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=3, new17(A,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=4, new12(A,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=4, new3(A,B,J,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=4, new3(A,B,J,D,E,F,G).
new9(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=1, J=:=2, K=:=4, new3(J,K,L,D,E,F,G).
new9(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=1, J=:=4, new3(A,J,K,D,E,F,G).
new9(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=1, J=:=4, new3(A,J,K,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=3, new9(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=3, new10(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=3, new10(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, J=:=1, K=:=3, new3(J,K,L,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=3, new3(A,J,K,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, J=:=3, new3(A,J,K,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=2, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=2, new7(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=2, new7(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=0, new4(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, I=:=2, new3(H,I,J,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
