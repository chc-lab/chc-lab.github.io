new5(A,B,19,A,B).
new3(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=50, new5(A,B,C,D,E).
new2(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0, H=:=2, I=:=J+K, J=:=H, K=:=1, L=:=M+N, 
          M=:=I, N=:=2, new3(L,B,C,D,E).
new2(A,B,C,D,E) :- F=<G, F=:=B, G=:=0, H=:=47, I=:=J+K, J=:=H, K=:=1, L=:=M+N, 
          M=:=I, N=:=2, new3(L,B,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
