new9(A,B,25,A,B).
new8(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=B, new9(A,B,C,D,E).
new5(A,B,C,D,E) :- new5(A,B,C,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=B, H=:=I+J, I=:=A, J=:=1, new4(H,B,C,D,E).
new4(A,B,C,D,E) :- F>=G, F=:=A, G=:=B, new8(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0, new4(A,B,C,D,E).
new3(A,B,C,D,E) :- F=<G, F=:=B, G=:=0, new5(A,B,C,D,E).
new2(A,B,C,D,E) :- F=:=0, new3(F,B,C,D,E).
new1 :- new2(A,B,C,D,E).
correct :- \+new1.
