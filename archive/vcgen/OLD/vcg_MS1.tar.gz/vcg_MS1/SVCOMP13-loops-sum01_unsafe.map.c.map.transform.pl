new9(A,B,C,D,26,A,B,C,D).
new7(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, new9(A,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=0, new9(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=L*M, L=:=B, M=:=2, 
          new7(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=L*M, L=:=B, M=:=2, 
          new7(A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=10, L=:=M+N, M=:=D, N=:=2, 
          O=:=P+Q, P=:=A, Q=:=1, new4(O,B,C,L,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=A, K=:=10, L=:=M+N, M=:=A, N=:=1, 
          new4(L,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=A, K=:=B, new5(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=B, new6(A,B,C,D,E,F,G,H,I).
new3(A,A).
new2(A,B,C,D,E,F,G,H,I) :- J=:=K, K>=0, L=:=J, M=:=0, N=:=1, new3(O,K), 
          new4(N,L,J,M,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
