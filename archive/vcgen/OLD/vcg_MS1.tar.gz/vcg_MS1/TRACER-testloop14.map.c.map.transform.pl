new8(A,B,C,29,A,B,C).
new7(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:= -1, new8(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=2, J=:=K+L, K=:=A, L=:=1, 
          new4(J,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=2, new8(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=10, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=10, new7(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=0, J=:=0, K=:=0, new4(K,J,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=0, J=:=0, new4(J,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=2, new3(A,B,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
