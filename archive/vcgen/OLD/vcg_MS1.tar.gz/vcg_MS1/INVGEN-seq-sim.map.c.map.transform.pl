new12(A,B,C,D,45,A,B,C,D).
new10(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=D, K=:=0, L=:=M+N, M=:=C, N=:=1, 
          O=:=P-Q, P=:=D, Q=:=1, new9(A,B,L,O,E,F,G,H,I).
new10(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=D, K=:=0, new12(A,B,C,D,E,F,G,H,I).
new9(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=A, new10(A,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=B, L=:=M+N, M=:=C, N=:=1, 
          O=:=P-Q, P=:=D, Q=:=1, new7(A,B,L,O,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=B, L=:=0, new9(A,B,L,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=B, L=:=M+N, M=:=C, N=:=1, 
          O=:=P+Q, P=:=D, Q=:=1, new5(A,B,L,O,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=B, L=:=0, new7(A,B,L,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=A, L=:=M+N, M=:=C, N=:=1, 
          O=:=P+Q, P=:=D, Q=:=1, new3(A,B,L,O,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=A, L=:=0, new5(A,B,L,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=0, K=:=0, new3(A,B,J,K,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
