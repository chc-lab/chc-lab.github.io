new66(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=B, P=:=Q+R, Q=:=D, R=:=1, 
          new17(A,B,C,P,E,F,G,H,I,J,K,L,M).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=F, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=F, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=C, O=:=B, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=C, 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,M).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, P=:=Q+R, Q=:=E, R=:=1, 
          new32(A,B,C,D,P,F,G,H,I,J,K,L,M).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, 
          new54(A,B,C,D,E,F,G,H,I,J,K,L,M).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=C, O=:=B, P=:=Q+R, Q=:=E, R=:=1, 
          new35(A,B,C,D,P,F,G,H,I,J,K,L,M).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=C, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, 
          new44(A,B,C,D,E,F,G,H,I,J,K,L,M).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, 
          new42(A,B,C,D,E,F,G,H,I,J,K,L,M).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=E, 
          new38(A,B,C,D,E,F,G,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, P=:=Q+R, Q=:=D, 
          R=:=1, new31(A,B,C,P,E,F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=E, 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=E, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, O=:=B, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=B, P=:=F, 
          new35(A,B,C,D,P,F,G,H,I,J,K,L,M).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, P=:=F, 
          new32(A,B,C,D,P,F,G,H,I,J,K,L,M).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, P=:=F, 
          new19(A,B,C,P,E,F,G,H,I,J,K,L,M).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=C, O=:=B, P=:=Q+R, Q=:=D, R=:=1, 
          new19(A,B,C,P,E,F,G,H,I,J,K,L,M).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=C, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=D, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=D, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=D, O=:=B, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, O=:=B, P=:=F, 
          new31(A,B,C,P,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=C, O=:=B, P=:=C, Q=:=R-S, R=:=C, 
          S=:=1, new3(A,B,Q,D,E,P,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=C, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new10(A,B,C,D,E,F,134,A,B,C,D,E,F).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=C, O=:=B, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=B, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=1, O=:=C, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=C, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, P=:=F, 
          new17(A,B,C,P,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, P=:=F, 
          new17(A,B,C,P,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, P=:=F, 
          new19(A,B,C,P,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=B, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=B, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=1, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, P=:=B, 
          new3(A,B,P,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
