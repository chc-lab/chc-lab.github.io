new35(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=B, L=:=M+N, M=:=D, N=:=1, 
          new22(A,B,C,L,E,F,G,H,I).
new35(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=D, K=:=B, new9(A,B,C,D,E,F,G,H,I).
new34(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=0, K=:=D, new35(A,B,C,D,E,F,G,H,I).
new34(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=0, K=:=D, new9(A,B,C,D,E,F,G,H,I).
new32(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=B, new7(A,B,C,D,E,F,G,H,I).
new32(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=B, new34(A,B,C,D,E,F,G,H,I).
new29(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=0, new7(A,B,C,D,E,F,G,H,I).
new29(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=0, new7(A,B,C,D,E,F,G,H,I).
new29(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=A, K=:=0, L=:=M+N, M=:=C, N=:=1, 
          new32(A,B,L,D,E,F,G,H,I).
new26(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=0, L=:=0, M=:=0, 
          new22(A,B,M,L,E,F,G,H,I).
new26(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=0, L=:=0, M=:=0, 
          new22(A,B,M,L,E,F,G,H,I).
new26(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=A, K=:=0, new29(A,B,C,D,E,F,G,H,I).
new22(A,B,C,D,E,F,G,H,I) :- new4(A,B,C,D,E,F,G,H,I).
new18(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=0, new7(A,B,C,D,E,F,G,H,I).
new18(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=0, new7(A,B,C,D,E,F,G,H,I).
new18(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=A, K=:=0, new22(A,B,C,D,E,F,G,H,I).
new16(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=B, L=:=M+N, M=:=D, N=:=1, 
          new18(A,B,C,L,E,F,G,H,I).
new16(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=D, K=:=B, new9(A,B,C,D,E,F,G,H,I).
new15(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=0, K=:=D, new16(A,B,C,D,E,F,G,H,I).
new15(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=0, K=:=D, new9(A,B,C,D,E,F,G,H,I).
new13(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, K=:=B, new7(A,B,C,D,E,F,G,H,I).
new13(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=C, K=:=B, new15(A,B,C,D,E,F,G,H,I).
new11(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=0, new7(A,B,C,D,E,F,G,H,I).
new11(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=0, new7(A,B,C,D,E,F,G,H,I).
new11(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=A, K=:=0, new26(A,B,C,D,E,F,G,H,I).
new9(A,B,C,D,58,A,B,C,D).
new8(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=D, K=:=B, new9(A,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=0, K=:=D, new8(A,B,C,D,E,F,G,H,I).
new7(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=0, K=:=D, new9(A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=0, new11(A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=0, new11(A,B,C,D,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=A, K=:=0, L=:=M+N, M=:=C, N=:=1, 
          new13(A,B,L,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=A, K=:=0, new5(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, K=:=0, new5(A,B,C,D,E,F,G,H,I).
new4(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=A, K=:=0, new7(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=B, K=:=0, new4(A,B,C,D,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=0, K=:=0, new3(A,B,J,K,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
