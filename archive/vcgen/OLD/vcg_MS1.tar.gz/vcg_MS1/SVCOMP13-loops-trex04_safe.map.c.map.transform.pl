new31(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new32(N,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new32(N,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, 
          new32(A,B,C,D,E,F,G,H,I,J,K).
new28(A,B,C,D,E,F,B,C,D,E) :- G>=H+1, G=:=D, H=:=0, F=:=I-J, I=:=A, J=:=1.
new28(A,B,C,D,E,F,B,C,D,E) :- G+1=<H, G=:=D, H=:=0, F=:=I-J, I=:=A, J=:=1.
new28(A,B,C,D,E,F,B,C,D,E) :- G=:=H, G=:=D, H=:=0, F=:=I+J, I=:=A, J=:=10.
new27(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=B, L=:=0, M=:=N+O, N=:=A, O=:=1, 
          new28(M,B,C,D,E,F,G,H,I,J).
new27(A,B,C,D,E,F,G,H,I,J) :- K+1=<L, K=:=B, L=:=0, M=:=N+O, N=:=A, O=:=1, 
          new28(M,B,C,D,E,F,G,H,I,J).
new27(A,B,C,D,E,F,G,H,I,J) :- K=:=L, K=:=B, L=:=0, new28(A,B,C,D,E,F,G,H,I,J).
new26(A,B,C,D,E,F,39,A,B,C,D,E,F).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=B, O=:=0, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=B, O=:=0, P=:=Q-R, Q=:=B, 
          R=:=A, new21(A,P,C,D,E,F,G,H,I,J,K,L,M).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=B, O=:=0, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=0, P=:=Q-R, Q=:=A, 
          R=:=1, new21(P,B,C,D,E,F,G,H,I,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=0, P=:=Q-R, Q=:=A, 
          R=:=1, new21(P,B,C,D,E,F,G,H,I,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=E, O=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J) :- K=:=0, L=:=M, N=:=O, new27(K,L,M,N,O,F,G,H,I,J).
new11(A,B,C,D,E,F,G,A,B,C,D,E,F) :- H>=I+1, H=:=C, I=:=0, 
          new7(J,K,L,M,N,G,O,P,Q,R,S).
new11(A,B,C,D,E,F,G,A,B,C,D,E,F) :- H+1=<I, H=:=C, I=:=0, 
          new7(J,K,L,M,N,G,O,P,Q,R,S).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=C, O=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=0, 
          new8(P,Q,R,S,T,U,V,W,X,Y), new18(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=0, 
          new8(P,Q,R,S,T,U,V,W,X,Y), new18(A,B,C,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L=:=0, M=:=N, O=:=P, 
          new31(L,M,N,O,P,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,A,B,C,D,E,F) :- H>=I+1, H=:=E, I=:=0, 
          new7(J,K,L,M,N,G,O,P,Q,R,S).
new4(A,B,C,D,E,F,G,A,B,C,D,E,F) :- H+1=<I, H=:=E, I=:=0, 
          new7(J,K,L,M,N,G,O,P,Q,R,S).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=E, O=:=0, 
          new11(A,B,P,D,Q,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, O=:=0, 
          new8(P,Q,R,S,T,U,V,W,X,Y), new11(A,B,Z,D,A1,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=E, O=:=0, 
          new8(P,Q,R,S,T,U,V,W,X,Y), new11(A,B,Z,D,A1,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, O=:=0, P=:=Q-R, Q=:=A, R=:=1, 
          new4(P,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=0, P=:=Q-R, Q=:=A, R=:=1, 
          new4(P,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=C, O=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=1, O=:=P, Q=:=R, 
          new3(N,B,O,P,Q,R,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
