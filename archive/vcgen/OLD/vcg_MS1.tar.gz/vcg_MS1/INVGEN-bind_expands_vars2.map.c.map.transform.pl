new9(A,B,C,D,E,29,A,B,C,D,E).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=N+O, N=:=A, O=:=D, M=:=P*Q, P=:=E, 
          Q=:=2, R=:=S+T, S=:=D, T=:=1, new6(A,B,C,R,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M, L=:=N+O, N=:=A, O=:=D, M=:=P*Q, P=:=E, 
          Q=:=2, new9(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=C, 
          new7(A,B,C,D,E,F,G,H,I,J,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=C, M=:=N-O, N=:=P*Q, P=:=E, Q=:=2, 
          O=:=B, R=:=0, new6(A,B,C,R,E,F,G,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=A, M=:=B, new5(A,B,C,D,E,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=B, M=:=N*O, N=:=E, O=:=2, 
          new4(A,B,C,D,E,F,G,H,I,J,K).
new2(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=E, M=:=0, 
          new3(A,B,C,D,E,F,G,H,I,J,K).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K).
correct :- \+new1.
