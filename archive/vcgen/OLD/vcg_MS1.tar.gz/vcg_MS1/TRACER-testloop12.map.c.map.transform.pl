new10(A,B,C,17,A,B,C).
new9(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, new10(A,B,C,D,E,F,G).
new7(A,B,C,A,B,C) :- D>=E, D=:=A, E=:=0.
new7(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, new8(A,B,C,D,E,F).
new5(A,B,C,D,B,E) :- F+1=<G, F=:=B, G=:=0, E=:=2, D=:=1.
new5(A,B,C,D,E,F) :- G>=H, G=:=B, H=:=0, I=:=1, new7(A,B,I,D,E,F).
new4(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=0, J=:=1, new9(A,B,J,D,E,F,G).
new3(A,B,C,D,E,B,C) :- F+1=<G, F=:=B, G=:=10, H=:=C, new4(A,H,I,D,E,J,K).
new3(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=10, J=:=C, K=:=L+M, L=:=B, M=:=1, 
          new5(A,J,N,O,P,Q), new3(O,K,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=:=0, I=:=0, new3(H,I,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
