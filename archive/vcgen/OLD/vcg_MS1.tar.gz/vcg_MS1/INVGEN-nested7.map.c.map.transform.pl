new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=F, R=:=S+T, S=:=C, 
          T=:=1, U=:=V+W, V=:=E, W=:=1, new21(A,B,R,D,U,F,G,H,I,J,K,L,M,N,O).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=F, R=:=S+T, S=:=B, 
          T=:=1, new4(A,R,C,D,E,F,G,H,I,J,K,L,M,N,O).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=C, Q=:=R+S, R=:=F, S=:=D, 
          T=:=U+V, U=:=C, V=:=1, new17(A,B,T,D,E,F,G,H,I,J,K,L,M,N,O).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=C, Q=:=R+S, R=:=F, S=:=D, 
          T=:=U+V, U=:=E, V=:=1, new16(A,B,C,D,T,F,G,H,I,J,K,L,M,N,O).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=G, R=:=0, 
          new17(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=G, R=:=S+T, S=:=B, 
          T=:=1, new3(A,R,C,D,E,F,G,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=F, R=:=S-T, S=:=C, 
          T=:=1, U=:=V+W, V=:=E, W=:=1, new11(A,B,R,D,U,F,G,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=F, R=:=S+T, S=:=B, 
          T=:=1, new3(A,R,C,D,E,F,G,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=F, R=:=0, 
          new11(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=F, R=:=S+T, S=:=B, 
          T=:=1, new3(A,R,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=G, R=:=S+T, S=:=E, 
          T=:=1, new9(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=G, R=:=0, 
          new16(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=5, R=:=0, 
          new9(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=5, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=A, Q=:=0, R=:=0, 
          new21(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=A, Q=:=0, R=:=0, 
          new21(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=A, Q=:=0, R=:=S+T, S=:=B, 
          T=:=1, new4(A,R,C,D,E,F,G,H,I,J,K,L,M,N,O).
new6(A,B,C,D,E,F,G,77,A,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, Q=:=R+S, R=:=F, S=:=D, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=B, Q=:=G, R=:=D, 
          new7(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=B, Q=:=G, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=B, Q=:=F, R=:=0, 
          new4(A,R,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=B, Q=:=F, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, Q=:=R+S, R=:=F, S=:=D, 
          T=:=0, new3(A,T,C,D,E,F,G,H,I,J,K,L,M,N,O).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
correct :- \+new1.
