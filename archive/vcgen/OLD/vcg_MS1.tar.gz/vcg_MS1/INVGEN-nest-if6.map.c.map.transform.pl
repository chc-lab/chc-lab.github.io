new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=D, C1=:=C, D1=:=E1+F1, E1=:=D, F1=:=1, 
          new30(A,B,C,D1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1, 
          B1=:=D, C1=:=C, D1=:=E1+F1, E1=:=E, F1=:=1, 
          new5(A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=A, C1=:=0, D1=:=I, E1=:=F1+G1, F1=:=M, G1=:=L, H1=:=I1+J1, 
          I1=:=I, J1=:=1, 
          new17(A,B,C,D,E,F,G,H,H1,D1,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=A, C1=:=0, D1=:=I, E1=:=F1+G1, F1=:=M, G1=:=L, H1=:=I1+J1, 
          I1=:=I, J1=:=1, 
          new17(A,B,C,D,E,F,G,H,H1,D1,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=A, C1=:=0, D1=:=E1+F1, E1=:=M, F1=:=L, G1=:=H1+I1, H1=:=I, 
          I1=:=1, 
          new17(A,B,C,D,E,F,G,H,G1,J,K,L,D1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=A, C1=:=0, D1=:=I, E1=:=F1+G1, F1=:=I, G1=:=1, 
          new19(A,B,C,D,E,F,G,H,E1,D1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=A, C1=:=0, D1=:=I, E1=:=F1+G1, F1=:=I, G1=:=1, 
          new19(A,B,C,D,E,F,G,H,E1,D1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=A, C1=:=0, D1=:=E1+F1, E1=:=I, F1=:=1, 
          new19(A,B,C,D,E,F,G,H,D1,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=I, C1=:=D1-E1, D1=:=C, E1=:=E, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1, 
          B1=:=I, C1=:=D1-E1, D1=:=C, E1=:=E, F1=:=G1+H1, G1=:=J, H1=:=E, 
          new12(A,B,C,D,E,F,F1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=I, C1=:=D1-E1, D1=:=C, E1=:=E, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1, 
          B1=:=I, C1=:=D1-E1, D1=:=C, E1=:=E, F1=:=G1+H1, G1=:=J, H1=:=E, 
          new12(A,B,C,D,E,F,F1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=L, C1=:=1, D1=:=1, E1=:=F1+G1, F1=:=D1, G1=:=L, H1=:=1, 
          new17(A,B,C,D,E,F,G,H,H1,J,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=L, C1=:=1, D1=:=1, E1=:=F1+G1, F1=:=D1, G1=:=L, H1=:=1, 
          new17(A,B,C,D,E,F,G,H,H1,J,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=L, C1=:=1, D1=:=0, E1=:=1, 
          new19(A,B,C,D,E,F,G,H,E1,D1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=D1-E1, D1=:=C, E1=:=E, C1=:=1, F1=:=0, G1=:=H1+I1, H1=:=F1, 
          I1=:=E, 
          new12(A,B,C,D,E,F,G1,H,I,F1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=D1-E1, D1=:=C, E1=:=E, C1=:=1, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=D1-E1, D1=:=C, E1=:=E, C1=:=1, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=A, C1=:=0, D1=:=F, 
          new30(A,B,C,D1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=A, C1=:=0, D1=:=F, 
          new30(A,B,C,D1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=:=C1, 
          B1=:=A, C1=:=0, D1=:=E1+F1, E1=:=E, F1=:=1, 
          new5(A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=D1-E1, D1=:=C, E1=:=E, C1=:=1, F1=:= -1, G1=:=H1+I1, H1=:=F1, 
          I1=:=E, 
          new12(A,B,C,D,E,F,G1,H,I,F1,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1, 
          B1=:=D1-E1, D1=:=C, E1=:=E, C1=:=1, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,70,A,B,C,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1, B1=:=C, 
          C1=:=B, new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=<C1, B1=:=0, 
          C1=:=C, new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1+1, 
          B1=:=0, C1=:=C, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=E, C1=:=H, D1=:=E1+F1, E1=:=E, F1=:=1, G1=:=E, H1=:=1, 
          new10(A,B,C,D,E,D1,G,H,I,J,G1,H1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1, B1=:=E, 
          C1=:=H, new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1>=C1, B1=:=H, 
          C1=:=0, D1=:=0, 
          new5(A,B,C,D,D1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=H, C1=:=0, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1=<C1, B1=:=0, 
          C1=:=C, D1=:=E1-F1, E1=:=C, F1=:=1, 
          new4(A,B,C,D,E,F,G,D1,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1) :- B1+1=<C1, 
          B1=:=C, C1=:=B, 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1).
correct :- \+new1.
