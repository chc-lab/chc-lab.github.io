new7(A,B,C,D,28,A,B,C,D).
new6(A,B,C,D,E,F,G,H,I) :- J=<K, J=:=C, K=:=0, new7(A,B,C,D,E,F,G,H,I).
new6(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, K=:=0, L=:=M+N, M=:=D, N=:=2, 
          O=:=P-Q, P=:=C, Q=:=1, new5(A,B,O,L,E,F,G,H,I).
new5(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=D, K=:=A, new6(A,B,C,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=B, K=:=A, L=:=M+N, M=:=B, N=:=2, 
          O=:=P+Q, P=:=C, Q=:=1, new3(A,L,O,D,E,F,G,H,I).
new3(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=B, K=:=A, L=:=0, new5(A,B,C,L,E,F,G,H,I).
new2(A,B,C,D,E,F,G,H,I) :- J=:=0, K=:=0, new3(A,J,K,D,E,F,G,H,I).
new1 :- new2(A,B,C,D,E,F,G,H,I).
correct :- \+new1.
