new18(A,B,C,33,A,B,C).
new17(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=4, new18(A,B,C,D,E,F,G).
new16(A,B,C,D,E,F,G) :- H=<I, H=:=4, I=:=B, new17(A,B,C,D,E,F,G).
new15(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=0, new16(A,B,C,D,E,F,G).
new14(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=0, new15(A,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=K+L, K=:=B, L=:=2, M=:=N+O, 
          N=:=C, O=:=2, new10(A,J,M,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, J=:=K+L, K=:=B, L=:=2, M=:=N+O, 
          N=:=C, O=:=2, new10(A,J,M,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, new14(A,B,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=2, new10(A,B,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=2, new4(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=C, new8(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=C, new4(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=2, new6(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=2, new4(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=B, new3(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=B, new4(A,B,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
