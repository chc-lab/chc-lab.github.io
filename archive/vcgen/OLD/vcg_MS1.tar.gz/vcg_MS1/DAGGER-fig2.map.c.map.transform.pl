new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=D, Q=:=B, R=:=S*T, S=:= -1, 
          T=:=A, U=:=V*W, V=:= -1, W=:=B, new3(R,U,C,D,E,F,X,H,I,J,K,L,M,N,O).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=D, Q=:=B, 
          new3(A,B,C,D,E,F,R,H,I,J,K,L,M,N,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=A, Q=:=C, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=A, Q=:=C, 
          new3(A,B,C,D,E,F,R,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=A, Q=:=4, R=:=S+T, S=:=A, 
          T=:=1, U=:=V+W, V=:=B, W=:=3, X=:=Y+Z, Y=:=C, Z=:=10, A1=:=B1+C1, 
          B1=:=D, C1=:=10, new3(R,U,X,A1,E,F,D1,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=A, Q=:=4, 
          new3(A,B,C,D,E,F,R,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=E, Q=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=E, Q=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,33,A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=R*S, R=:=3, S=:=A, Q=:=B, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=F, Q=:=0, R=:=S+T, S=:=A, 
          T=:=1, U=:=V+W, V=:=B, W=:=2, new3(R,U,C,D,E,F,X,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=F, Q=:=0, R=:=S+T, S=:=A, 
          T=:=1, U=:=V+W, V=:=B, W=:=2, new3(R,U,C,D,E,F,X,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=F, Q=:=0, 
          new10(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=G, Q=:=0, 
          new4(A,B,C,D,E,R,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=G, Q=:=0, 
          new4(A,B,C,D,E,R,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=G, Q=:=0, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=0, Q=:=P, R=:=Q, S=:=R, 
          new3(S,R,Q,P,E,F,T,H,I,J,K,L,M,N,O).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
correct :- \+new1.
