new52(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new12(A,B,C,D,E,F,G).
new49(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new12(A,B,C,D,E,F,G).
new46(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new12(A,B,C,D,E,F,G).
new43(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=B, new46(A,B,C,D,E,F,G).
new43(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=B, new12(A,B,C,D,E,F,G).
new41(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=A, new43(A,B,C,D,E,F,G).
new41(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new28(A,B,C,D,E,F,G).
new41(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=A, new28(A,B,C,D,E,F,G).
new39(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new41(A,J,C,D,E,F,G).
new39(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new12(A,B,C,D,E,F,G).
new36(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=B, new39(A,B,C,D,E,F,G).
new36(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=B, new12(A,B,C,D,E,F,G).
new33(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new12(A,B,C,D,E,F,G).
new29(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new17(A,J,C,D,E,F,G).
new29(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new12(A,B,C,D,E,F,G).
new28(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=B, new29(A,B,C,D,E,F,G).
new28(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=B, new12(A,B,C,D,E,F,G).
new26(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=B, new33(A,B,C,D,E,F,G).
new26(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=B, new12(A,B,C,D,E,F,G).
new25(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, new26(A,B,C,D,E,F,G).
new25(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=0, new26(A,B,C,D,E,F,G).
new25(A,B,C,D,E,F,G) :- H=:=I, H=:=C, I=:=0, new28(A,B,C,D,E,F,G).
new23(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, new36(A,B,C,D,E,F,G).
new23(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=0, new36(A,B,C,D,E,F,G).
new23(A,B,C,D,E,F,G) :- H=:=I, H=:=C, I=:=0, new28(A,B,C,D,E,F,G).
new21(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, new23(A,B,C,D,E,F,G).
new21(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=0, new23(A,B,C,D,E,F,G).
new21(A,B,C,D,E,F,G) :- H=:=I, H=:=C, I=:=0, new25(A,B,C,D,E,F,G).
new20(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=B, new49(A,B,C,D,E,F,G).
new20(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=B, new12(A,B,C,D,E,F,G).
new19(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=A, new20(A,B,C,D,E,F,G).
new19(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new21(A,B,C,D,E,F,G).
new19(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=A, new21(A,B,C,D,E,F,G).
new17(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=0, new19(A,B,C,D,E,F,G).
new15(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new17(A,J,C,D,E,F,G).
new15(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new12(A,B,C,D,E,F,G).
new12(A,B,C,87,A,B,C).
new11(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=A, J=:=K+L, K=:=B, L=:=1, 
          new3(A,J,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new12(A,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=B, new11(A,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=B, new12(A,B,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=B, new15(A,B,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=B, new12(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=0, new8(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=0, new8(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H=:=I, H=:=C, I=:=0, new10(A,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=B, new52(A,B,C,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=B, new12(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=:=I, H=:=B, I=:=A, new5(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=A, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=A, new6(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=0, new4(A,B,C,D,E,F,G).
new2(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=1, J=:=0, K=:=L-M, L=:=A, M=:=1, 
          new3(K,J,C,D,E,F,G).
new1 :- new2(A,B,C,D,E,F,G).
correct :- \+new1.
