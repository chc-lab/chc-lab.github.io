new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=E, P=:=Q+R, Q=:=D, 
          R=:=1, new12(A,B,C,P,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=E, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=D, O=:=C, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=D, O=:=C, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,44,A,B,C,D,E,F).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=P+Q, P=:=R+S, R=:=E, S=:=C, 
          Q=:=5, O=:=B, T=:=U+V, U=:=C, V=:=2, new4(A,B,T,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=P+Q, P=:=R+S, R=:=E, S=:=C, Q=:=5, 
          O=:=B, new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=0, P=:=Q+R, Q=:=C, R=:=1, 
          S=:=0, new12(A,B,P,S,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=C, O=:=F, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=C, O=:=F, P=:=Q+R, Q=:=B, R=:=4, 
          new3(A,P,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=B, O=:=E, P=:=B, 
          new4(A,B,P,D,E,F,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=P+Q, P=:=F, Q=:=1, O=:=E, R=:=0, 
          new3(A,R,C,D,E,F,G,H,I,J,K,L,M).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M).
correct :- \+new1.
