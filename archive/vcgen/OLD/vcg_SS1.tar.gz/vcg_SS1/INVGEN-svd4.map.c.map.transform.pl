new57(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=B.
new57(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=B, J=:=K+L, K=:=D, L=:=1, 
          new11(A,B,C,J,E,F,G).
new56(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=D.
new56(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=D, new57(A,B,C,D,E,F,G).
new55(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=G.
new55(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=G, new56(A,B,C,D,E,F,G).
new53(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=B.
new53(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=B, J=:=K+L, K=:=E, L=:=1, 
          new27(A,B,C,D,J,F,G).
new52(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=D.
new52(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=D, new53(A,B,C,D,E,F,G).
new51(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=B.
new51(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=B, new52(A,B,C,D,E,F,G).
new50(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new50(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new51(A,B,C,D,E,F,G).
new49(A,B,C,D,E,F,G) :- H>=I+1, H=:=E, I=:=G.
new49(A,B,C,D,E,F,G) :- H=<I, H=:=E, I=:=G, new50(A,B,C,D,E,F,G).
new47(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=B.
new47(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=B, J=:=K+L, K=:=E, L=:=1, 
          new40(A,B,C,D,J,F,G).
new46(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new46(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new47(A,B,C,D,E,F,G).
new45(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=B.
new45(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=B, new46(A,B,C,D,E,F,G).
new44(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=D.
new44(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=D, new45(A,B,C,D,E,F,G).
new43(A,B,C,D,E,F,G) :- H>=I+1, H=:=E, I=:=G.
new43(A,B,C,D,E,F,G) :- H=<I, H=:=E, I=:=G, new44(A,B,C,D,E,F,G).
new41(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=E.
new41(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=E, new43(A,B,C,D,E,F,G).
new40(A,B,C,D,E,F,G) :- H=<I, H=:=E, I=:=G, new41(A,B,C,D,E,F,G).
new40(A,B,C,D,E,F,G) :- H>=I+1, H=:=E, I=:=G, J=:=K+L, K=:=D, L=:=1, 
          new14(A,B,C,J,E,F,G).
new39(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=B.
new39(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=B, J=:=C, new40(A,B,C,D,J,F,G).
new38(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new38(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new39(A,B,C,D,E,F,G).
new37(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=G.
new37(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=G, new38(A,B,C,D,E,F,G).
new36(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new36(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new37(A,B,C,D,E,F,G).
new35(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=E.
new35(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=E, new49(A,B,C,D,E,F,G).
new33(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=B.
new33(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=B, J=:=K+L, K=:=D, L=:=1, 
          new28(A,B,C,J,E,F,G).
new32(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new32(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new33(A,B,C,D,E,F,G).
new31(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=G.
new31(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=G, new32(A,B,C,D,E,F,G).
new29(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=D.
new29(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=D, new31(A,B,C,D,E,F,G).
new28(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=G, new29(A,B,C,D,E,F,G).
new28(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=G, new18(A,B,C,D,E,F,G).
new27(A,B,C,D,E,F,G) :- H=<I, H=:=E, I=:=G, new35(A,B,C,D,E,F,G).
new27(A,B,C,D,E,F,G) :- H>=I+1, H=:=E, I=:=G, new36(A,B,C,D,E,F,G).
new25(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=B.
new25(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=B, J=:=K+L, K=:=D, L=:=1, 
          new16(A,B,C,J,E,F,G).
new24(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new24(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new25(A,B,C,D,E,F,G).
new23(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=G.
new23(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=G, new24(A,B,C,D,E,F,G).
new21(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=B.
new21(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=B, J=:=K-L, K=:=C, L=:=1, 
          new7(A,B,J,D,E,F,G).
new20(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new20(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new21(A,B,C,D,E,F,G).
new19(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=G.
new19(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=G, new20(A,B,C,D,E,F,G).
new18(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new18(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new19(A,B,C,D,E,F,G).
new17(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=D.
new17(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=D, new23(A,B,C,D,E,F,G).
new16(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=G, new17(A,B,C,D,E,F,G).
new16(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=G, new18(A,B,C,D,E,F,G).
new14(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=B, J=:=F, new27(A,B,C,D,J,F,G).
new14(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=B, J=:=C, new28(A,B,C,J,E,F,G).
new13(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=F, new14(A,B,C,J,E,F,G).
new13(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, J=:=F, new14(A,B,C,J,E,F,G).
new13(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, J=:=C, new16(A,B,C,J,E,F,G).
new12(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new12(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new55(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=B, new12(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=B, new13(A,B,C,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=B.
new10(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=B, J=:=F, new11(A,B,C,J,E,F,G).
new9(A,B,C,D,E,F,G) :- H>=I+1, H=:=1, I=:=C.
new9(A,B,C,D,E,F,G) :- H=<I, H=:=1, I=:=C, new10(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=1, J=:=K+L, K=:=C, L=:=1, 
          new9(A,B,C,D,E,J,G).
new5(A,B,C,D,E,F,G) :- new5(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=<I, H=:=G, I=:=B, J=:=G, new7(A,B,J,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=G, I=:=B, J=:=B, new7(A,B,J,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=G, new4(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=B, I=:=G, new5(A,B,C,D,E,F,G).
new2(A) :- new3(A,B,C,D,E,F,G).
new1 :- new2(A).
inv1 :- \+new1.
