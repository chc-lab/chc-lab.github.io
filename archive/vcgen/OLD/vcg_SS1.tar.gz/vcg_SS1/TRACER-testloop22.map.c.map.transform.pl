new7(A,B,C,D) :- E>=F+1, E=:=D, F=:=2.
new6(A,B,C,D) :- new4(A,B,C,D).
new4(A,B,C,D) :- E+1=<F, E=:=B, F=:=C, G=:=H+I, H=:=B, I=:=1, new6(A,G,C,D).
new4(A,B,C,D) :- E>=F, E=:=B, F=:=C, new7(A,B,C,D).
new3(A,B,C,D) :- E>=F+1, E=:=A, F=:=0, G=:=1, new4(A,B,C,G).
new3(A,B,C,D) :- E=<F, E=:=A, F=:=0, G=:=2, new4(A,B,C,G).
new2 :- new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
