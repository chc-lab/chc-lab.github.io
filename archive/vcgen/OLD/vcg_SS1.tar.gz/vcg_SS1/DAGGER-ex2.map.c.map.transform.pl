new45(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=A, N=:=132.
new44(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=L, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new45(O,B,C,D,E,F,G,H,I,J,K,L).
new44(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=L, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new45(O,B,C,D,E,F,G,H,I,J,K,L).
new44(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=L, N=:=0, O=:=P+Q, P=:=A, Q=:=2, 
          new45(O,B,C,D,E,F,G,H,I,J,K,L).
new41(A,B,C,D,E,F,G,H,I,J,K,L) :- new44(A,B,C,D,E,F,G,H,I,J,K,M).
new40(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=K, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new41(O,B,C,D,E,F,G,H,I,J,K,L).
new40(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=K, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new41(O,B,C,D,E,F,G,H,I,J,K,L).
new40(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=K, N=:=0, O=:=P+Q, P=:=A, Q=:=4, 
          new41(O,B,C,D,E,F,G,H,I,J,K,L).
new37(A,B,C,D,E,F,G,H,I,J,K,L) :- new40(A,B,C,D,E,F,G,H,I,J,M,L).
new36(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=J, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new37(O,B,C,D,E,F,G,H,I,J,K,L).
new36(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=J, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new37(O,B,C,D,E,F,G,H,I,J,K,L).
new36(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=J, N=:=0, O=:=P+Q, P=:=A, Q=:=6, 
          new37(O,B,C,D,E,F,G,H,I,J,K,L).
new33(A,B,C,D,E,F,G,H,I,J,K,L) :- new36(A,B,C,D,E,F,G,H,I,M,K,L).
new32(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=I, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new33(O,B,C,D,E,F,G,H,I,J,K,L).
new32(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=I, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new33(O,B,C,D,E,F,G,H,I,J,K,L).
new32(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=I, N=:=0, O=:=P+Q, P=:=A, Q=:=8, 
          new33(O,B,C,D,E,F,G,H,I,J,K,L).
new29(A,B,C,D,E,F,G,H,I,J,K,L) :- new32(A,B,C,D,E,F,G,H,M,J,K,L).
new28(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=H, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new29(O,B,C,D,E,F,G,H,I,J,K,L).
new28(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=H, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new29(O,B,C,D,E,F,G,H,I,J,K,L).
new28(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=H, N=:=0, O=:=P+Q, P=:=A, Q=:=10, 
          new29(O,B,C,D,E,F,G,H,I,J,K,L).
new25(A,B,C,D,E,F,G,H,I,J,K,L) :- new28(A,B,C,D,E,F,G,M,I,J,K,L).
new24(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=G, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new25(O,B,C,D,E,F,G,H,I,J,K,L).
new24(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=G, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new25(O,B,C,D,E,F,G,H,I,J,K,L).
new24(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=G, N=:=0, O=:=P+Q, P=:=A, Q=:=12, 
          new25(O,B,C,D,E,F,G,H,I,J,K,L).
new21(A,B,C,D,E,F,G,H,I,J,K,L) :- new24(A,B,C,D,E,F,M,H,I,J,K,L).
new20(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=F, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new21(O,B,C,D,E,F,G,H,I,J,K,L).
new20(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=F, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new21(O,B,C,D,E,F,G,H,I,J,K,L).
new20(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=F, N=:=0, O=:=P+Q, P=:=A, Q=:=14, 
          new21(O,B,C,D,E,F,G,H,I,J,K,L).
new17(A,B,C,D,E,F,G,H,I,J,K,L) :- new20(A,B,C,D,E,M,G,H,I,J,K,L).
new16(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=E, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new17(O,B,C,D,E,F,G,H,I,J,K,L).
new16(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=E, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new17(O,B,C,D,E,F,G,H,I,J,K,L).
new16(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=E, N=:=0, O=:=P+Q, P=:=A, Q=:=16, 
          new17(O,B,C,D,E,F,G,H,I,J,K,L).
new13(A,B,C,D,E,F,G,H,I,J,K,L) :- new16(A,B,C,D,M,F,G,H,I,J,K,L).
new12(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=D, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new13(O,B,C,D,E,F,G,H,I,J,K,L).
new12(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=D, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new13(O,B,C,D,E,F,G,H,I,J,K,L).
new12(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=D, N=:=0, O=:=P+Q, P=:=A, Q=:=18, 
          new13(O,B,C,D,E,F,G,H,I,J,K,L).
new9(A,B,C,D,E,F,G,H,I,J,K,L) :- new12(A,B,C,M,E,F,G,H,I,J,K,L).
new8(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=C, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new9(O,B,C,D,E,F,G,H,I,J,K,L).
new8(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=C, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new9(O,B,C,D,E,F,G,H,I,J,K,L).
new8(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=C, N=:=0, O=:=P+Q, P=:=A, Q=:=20, 
          new9(O,B,C,D,E,F,G,H,I,J,K,L).
new5(A,B,C,D,E,F,G,H,I,J,K,L) :- new8(A,B,M,D,E,F,G,H,I,J,K,L).
new4(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=B, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new5(O,B,C,D,E,F,G,H,I,J,K,L).
new4(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=B, N=:=0, O=:=P+Q, P=:=A, Q=:=1, 
          new5(O,B,C,D,E,F,G,H,I,J,K,L).
new4(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=B, N=:=0, O=:=P+Q, P=:=A, Q=:=22, 
          new5(O,B,C,D,E,F,G,H,I,J,K,L).
new3(A,B,C,D,E,F,G,H,I,J,K,L) :- new4(A,M,C,D,E,F,G,H,I,J,K,L).
new2 :- A=:=0, new3(A,B,C,D,E,F,G,H,I,J,K,L).
new1 :- new2.
inv1 :- \+new1.
