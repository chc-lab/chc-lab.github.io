new23(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new8(A,B,C,D,E,F,G,H,I,J,K,N,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, P=:=Q-R, Q=:=C, C>=0, 
          R=:=H, H>=0, new17(A,B,P,D,E,F,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, P=:=Q-R, Q=:=C, C>=0, 
          R=:=H, H>=0, new17(A,B,P,D,E,F,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, P=:=Q-R, Q=:=E, E>=0, 
          R=:=I, I>=0, new17(A,B,C,D,P,F,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new23(A,B,C,D,E,F,G,H,I,N,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=J, O=:=0, P=:=Q-R, Q=:=A, A>=0, 
          R=:=G, G>=0, new17(P,B,C,D,E,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=J, O=:=0, P=:=Q-R, Q=:=A, A>=0, 
          R=:=G, G>=0, new17(P,B,C,D,E,F,G,H,I,J,K,L,M).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=J, O=:=0, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, E>=0, O=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=E, E>=0, O=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, E>=0, O=:=0.
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, C>=0, O=:=0.
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=C, C>=0, O=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, A>=0, O=:=0.
new10(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, A>=0, O=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=C, C>=0, O=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=C, C>=0, O=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, A>=0, O=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=A, A>=0, O=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, new8(A,B,C,D,E,F,G,H,I,J,K,N,O).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, new7(A,B,C,D,E,F,G,H,I,N,O,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, O>=0, P=:=N, Q=:=P, P>=0, R=:=1, 
          S=:=1, T=:=1, new6(A,B,C,D,Q,N,R,S,T,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, O>=0, P=:=N, Q=:=P, P>=0, 
          new5(A,B,Q,N,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, O>=0, P=:=N, Q=:=P, P>=0, 
          new4(Q,N,C,D,E,F,G,H,I,J,K,L,M).
new2 :- new3(A,B,C,D,E,F,G,H,I,J,K,L,M).
new1 :- new2.
inv1 :- \+new1.
