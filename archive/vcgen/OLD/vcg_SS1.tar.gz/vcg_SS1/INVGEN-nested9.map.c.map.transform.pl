new8(A,B,C,D,E,F,G) :- H>=I+1, H=:=J-K, J=:=D, K=:=B, I=:=L*M, L=:=2, M=:=E.
new8(A,B,C,D,E,F,G) :- H=<I, H=:=J-K, J=:=D, K=:=B, I=:=L*M, L=:=2, M=:=E, 
          N=:=O+P, O=:=D, P=:=1, new6(A,B,C,N,E,F,G).
new6(A,B,C,D,E,F,G) :- H+1=<I, H=:=D, I=:=C, new8(A,B,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I, H=:=D, I=:=C, J=:=K+L, K=:=C, L=:=1, 
          new5(A,B,J,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=J*K, J=:=3, K=:=B, L=:=B, 
          new6(A,B,C,L,E,F,G).
new5(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=J*K, J=:=3, K=:=B, L=:=M+N, M=:=B, 
          N=:=1, new4(A,L,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=E, J=:=K*L, K=:=2, L=:=B, 
          new5(A,B,J,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=J*K, J=:=3, K=:=E, I=:=L+M, L=:=G, M=:=F, 
          N=:=0, new4(A,N,C,D,E,F,G).
new2(A) :- new3(A,B,C,D,E,F,G).
new1 :- new2(A).
inv1 :- \+new1.
