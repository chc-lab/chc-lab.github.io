new161(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=B, V=:=1, W=:=0, 
          X=:=0, Y=:=0, new8(A,B,W,D,Y,X,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new161(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=B, V=:=1, W=:=0, 
          X=:=0, new8(A,B,C,D,X,W,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new161(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=B, V=:=1, W=:=0, 
          X=:=0, new8(A,B,C,D,X,W,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=B, V=:=0, W=:=0, 
          new161(A,B,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=B, V=:=0, 
          new161(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=B, V=:=0, 
          new161(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=B, Y=:=0, 
          Z=:=2, A1=:=1, new117(A,B,C,D,E,F,G,H,Z,A1,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=B, Y=:=0, 
          new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=B, Y=:=0, 
          new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, Z=:=A1+B1, 
          A1=:=G, B1=:=1, C1=:=0, D1=:=1, 
          new143(Y,C1,C,D,D1,F,Z,X,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=J, Y=:=1, 
          new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=J, Y=:=1, 
          new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=J, Y=:=1, 
          new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=1, Y=:=0, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=J, Y=:=0, 
          new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=J, Y=:=0, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=J, Y=:=0, 
          new144(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new140(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new139(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=R, Y=:=0.
new139(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=R, Y=:=0, 
          Z=:=1, new140(A,B,C,D,E,F,G,H,Z,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new139(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=R, Y=:=0, 
          Z=:=1, new140(A,B,C,D,E,F,G,H,Z,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=B, Z=:=1, 
          A1=:=2, B1=:=1, C1=:=R, 
          new47(A,B,C,D,E,F,G,H,I,J,K,L,M,A1,B1,P,C1,S,T,U,V,W,X).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=B, 
          Z=:=1, A1=:=A, B1=:=A1, C1=:=D1+E1, D1=:=L, E1=:=1, F1=:=1, G1=:=1, 
          new130(A,F1,C,D,G1,F,G,H,I,J,K,C1,B1,N,O,P,Q,A1,S,T,U,V,W,X).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=B, 
          Z=:=1, A1=:=A, B1=:=A1, C1=:=D1+E1, D1=:=L, E1=:=1, F1=:=1, G1=:=1, 
          new130(A,F1,C,D,G1,F,G,H,I,J,K,C1,B1,N,O,P,Q,A1,S,T,U,V,W,X).
new133(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=G, Z=:=L.
new133(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=G, Z=:=L.
new133(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=G, Z=:=L, 
          new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=H, Z=:=M.
new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=H, Z=:=M.
new130(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=H, Z=:=M, 
          new133(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=O, Z=:=1, 
          A1=:=Q, B1=:=A, C1=:=B1, D1=:=E1+F1, E1=:=L, F1=:=1, G1=:=1, H1=:=1, 
          new130(A,G1,C,D,H1,F,G,H,I,J,K,D1,C1,N,O,P,Q,B1,S,T,U,V,W,X).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=O, 
          Z=:=1, new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=O, 
          Z=:=1, new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=1, 
          Z=:=0, new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=O, Z=:=0, 
          new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=O, 
          Z=:=0, new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=O, 
          Z=:=0, new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new123(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,X,R,S,T,U,V,W).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=S, Y=:=0, 
          Z=:=1, new123(A,B,C,D,E,F,G,H,I,J,K,L,M,Z,O,P,Q,R,S,T,U,V,W).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=S, Y=:=0, 
          Z=:=1, new123(A,B,C,D,E,F,G,H,I,J,K,L,M,Z,O,P,Q,R,S,T,U,V,W).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=S, Y=:=0, 
          new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,X,T,U,V,W).
new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=N, Y=:=0, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=N, Y=:=0, 
          new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=N, Y=:=0, 
          new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new139(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,X,S,T,U,V,W).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=B, V=:=1, W=:=0, 
          X=:=0, Y=:=0, Z=:=3, new60(A,B,W,D,Y,X,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=B, V=:=1, W=:=0, 
          X=:=0, Y=:=3, new60(A,B,C,D,X,W,G,H,I,J,K,L,M,N,O,P,Q,Y,S,T).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=B, V=:=1, W=:=0, 
          X=:=0, Y=:=3, new60(A,B,C,D,X,W,G,H,I,J,K,L,M,N,O,P,Q,Y,S,T).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=B, V=:=0, W=:=0, 
          new110(A,B,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=B, V=:=0, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=B, V=:=0, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=S, V=:=0, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=N, Y=:=0, 
          Z=:=1, A1=:=Z, new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=N, Y=:=0, 
          Z=:=0, A1=:=Z, new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=N, Y=:=0, 
          Z=:=0, A1=:=Z, new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=R, X=:=0, 
          Y=:=0, Z=:=Y, new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,T,Z,V).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=R, X=:=0, 
          Y=:=0, Z=:=Y, new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,T,Z,V).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=R, X=:=0, 
          Y=:=1, Z=:=Y, new99(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,T,Z,V).
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=I, Y=:=0, 
          Z=:=1, A1=:=Z, new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=I, Y=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=I, Y=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,W,R,S,T,U,V).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,U,V,R,S,T).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=D, V=:=1, W=:=2, 
          new88(A,B,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=D, V=:=1, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=D, V=:=1, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=C, V=:=1, W=:=2, 
          new85(A,B,W,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=C, V=:=1, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=C, V=:=1, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=S, X=:=0, 
          Y=:=0, new81(A,B,C,D,E,F,G,H,I,J,K,L,M,Y,O,P,Q,T,U,V).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=S, X=:=0, 
          Y=:=0, new81(A,B,C,D,E,F,G,H,I,J,K,L,M,Y,O,P,Q,T,U,V).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=S, X=:=0, 
          new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,T,U,V).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=D, Y=:=1, 
          Z=:=1, A1=:=Z, new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=D, Y=:=1, 
          Z=:=0, A1=:=Z, new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=D, Y=:=1, 
          Z=:=0, A1=:=Z, new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=O, Y=:=1, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=O, Y=:=1, 
          Z=:=0, A1=:=Z, new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=O, Y=:=1, 
          Z=:=0, A1=:=Z, new79(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,W,R,S,T,U,V).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=R, X=:=0, 
          Y=:=0, new74(A,B,C,D,E,F,G,H,Y,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=R, X=:=0, 
          Y=:=0, new74(A,B,C,D,E,F,G,H,Y,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=R, X=:=0, 
          new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=C, Y=:=1, 
          Z=:=1, A1=:=Z, new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=C, Y=:=1, 
          Z=:=0, A1=:=Z, new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=C, Y=:=1, 
          Z=:=0, A1=:=Z, new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=J, Y=:=1, 
          new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=J, Y=:=1, 
          Z=:=0, A1=:=Z, new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=J, Y=:=1, 
          Z=:=0, A1=:=Z, new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,W,R,S,T,U,V).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,U,V,R,S,T).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=D, V=:=0, W=:=1, 
          new66(A,B,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=D, V=:=0, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=D, V=:=0, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=C, V=:=0, W=:=1, 
          new63(A,B,W,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=C, V=:=0, 
          new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=C, V=:=0, 
          new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new109(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=E, V=:=1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=E, V=:=1, W=:=3, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,W,S,T).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=E, V=:=1, W=:=3, 
          new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,W,S,T).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=I, Y=:=0, 
          new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=I, Y=:=0, 
          new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=I, Y=:=0, 
          new117(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=N, Z=:=0, 
          A1=:=1, B1=:=A1, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,B1,V,W,X).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=N, Z=:=0, 
          A1=:=0, B1=:=A1, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,B1,V,W,X).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=N, Z=:=0, 
          A1=:=0, B1=:=A1, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,B1,V,W,X).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=T, Y=:=0, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=T, Y=:=0, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=T, Y=:=0, 
          Z=:=2, new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,V,W).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=I, Z=:=0, 
          A1=:=1, B1=:=A1, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,B1,V,W,X).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=I, Z=:=0, 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=I, Z=:=0, 
          new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,X,R,S,T,U,V,W).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,U,V,W,R,S,T).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=1, V=:=0, W=:=1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,W,S,T).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=D, V=:=1, W=:=2, 
          new43(A,B,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=D, V=:=1, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=D, V=:=1, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=C, V=:=1, W=:=2, 
          new40(A,B,W,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=C, V=:=1, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=C, V=:=1, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=S, X=:=0, 
          Y=:=0, new36(A,B,C,D,E,F,G,H,I,J,K,L,M,Y,O,P,Q,T,U,V).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=S, X=:=0, 
          Y=:=0, new36(A,B,C,D,E,F,G,H,I,J,K,L,M,Y,O,P,Q,T,U,V).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=S, X=:=0, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,T,U,V).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=D, Y=:=1, 
          Z=:=1, A1=:=Z, new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=D, Y=:=1, 
          Z=:=0, A1=:=Z, new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=D, Y=:=1, 
          Z=:=0, A1=:=Z, new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=O, Y=:=1, 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=O, Y=:=1, 
          Z=:=0, A1=:=Z, new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=O, Y=:=1, 
          Z=:=0, A1=:=Z, new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,A1,U,V,W).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,W,R,S,T,U,V).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=R, X=:=0, 
          Y=:=0, new29(A,B,C,D,E,F,G,H,Y,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=R, X=:=0, 
          Y=:=0, new29(A,B,C,D,E,F,G,H,Y,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=R, X=:=0, 
          new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=C, Y=:=1, 
          Z=:=1, A1=:=Z, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=C, Y=:=1, 
          Z=:=0, A1=:=Z, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=C, Y=:=1, 
          Z=:=0, A1=:=Z, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=J, Y=:=1, 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=J, Y=:=1, 
          Z=:=0, A1=:=Z, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=J, Y=:=1, 
          Z=:=0, A1=:=Z, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,A1,T,U,V,W).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,W,R,S,T,U,V).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,U,V,R,S,T).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=D, V=:=0, W=:=1, 
          new21(A,B,C,W,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=D, V=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=D, V=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=C, V=:=0, W=:=1, 
          new18(A,B,W,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=C, V=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=C, V=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=P, V=:=1, W=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,W,O,P,Q,R,S,T).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=P, V=:=1, W=:=2, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,W,O,P,Q,R,S,T).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=P, V=:=1, W=:=2, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,W,O,P,Q,R,S,T).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=K, V=:=1, W=:=0, 
          new11(A,B,C,D,E,F,G,H,W,J,K,L,M,N,O,P,Q,R,S,T).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=K, V=:=1, W=:=2, 
          new11(A,B,C,D,E,F,G,H,W,J,K,L,M,N,O,P,Q,R,S,T).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=K, V=:=1, W=:=2, 
          new11(A,B,C,D,E,F,G,H,W,J,K,L,M,N,O,P,Q,R,S,T).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=E, V=:=1, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=E, V=:=1, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=E, V=:=1, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,S,T,R).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=1, T=:=2, U=:=T, V=:=0, W=:=0, 
          X=:=1, Y=:=0, Z=:=0, A1=:=1, 
          new4(A,S,U,T,E,F,V,H,I,W,X,Y,M,N,Z,A1,Q,R).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q) :- 
          new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q).
inv1 :- \+new1.
