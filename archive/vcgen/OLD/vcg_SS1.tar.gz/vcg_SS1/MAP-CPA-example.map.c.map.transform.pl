new6(A,B) :- C>=D+1, C=:=A, D=:=B.
new6(A,B) :- C+1=<D, C=:=A, D=:=B.
new6(A,B) :- C=:=D, C=:=A, D=:=B, new3(A,B).
new5(A,B) :- C>=D+1, C=:=B, D=:=20.
new5(A,B) :- C+1=<D, C=:=B, D=:=20.
new4(A,B) :- C=:=D, C=:=A, D=:=20, new5(A,B).
new4(A,B) :- C>=D+1, C=:=A, D=:=20, E=:=F+G, F=:=A, G=:=1, H=:=I+J, I=:=B, 
          J=:=1, new6(E,H).
new4(A,B) :- C+1=<D, C=:=A, D=:=20, E=:=F+G, F=:=A, G=:=1, H=:=I+J, I=:=B, 
          J=:=1, new6(E,H).
new3(A,B) :- C>=D+1, C=:=1, D=:=0, new4(A,B).
new2 :- A=:=0, B=:=0, new3(A,B).
new1 :- new2.
inv1 :- \+new1.
