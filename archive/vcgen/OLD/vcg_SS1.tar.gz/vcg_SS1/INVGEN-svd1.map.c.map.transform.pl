new45(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=B.
new45(A,B,C,D,E,F) :- G=<H, G=:=F, H=:=B, I=:=J+K, J=:=D, K=:=1, 
          new14(A,B,C,I,E,F).
new44(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=F.
new44(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=F, new45(A,B,C,D,E,F).
new43(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=B.
new43(A,B,C,D,E,F) :- G=<H, G=:=C, H=:=B, new44(A,B,C,D,E,F).
new42(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=C.
new42(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=C, new43(A,B,C,D,E,F).
new41(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B.
new41(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, new42(A,B,C,D,E,F).
new39(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B.
new39(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, I=:=J+K, J=:=E, K=:=1, 
          new25(A,B,C,D,I,F).
new38(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new38(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, new39(A,B,C,D,E,F).
new37(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B.
new37(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, new38(A,B,C,D,E,F).
new35(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=B.
new35(A,B,C,D,E,F) :- G=<H, G=:=C, H=:=B, I=:=J+K, J=:=E, K=:=1, 
          new28(A,B,C,D,I,F).
new34(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=C.
new34(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=C, new35(A,B,C,D,E,F).
new33(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B.
new33(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, new34(A,B,C,D,E,F).
new32(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new32(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, new33(A,B,C,D,E,F).
new31(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B.
new31(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, new32(A,B,C,D,E,F).
new29(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=E.
new29(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=E, new31(A,B,C,D,E,F).
new28(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, new29(A,B,C,D,E,F).
new28(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B, I=:=J+K, J=:=D, K=:=1, 
          new24(A,B,C,I,E,F).
new27(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=E.
new27(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=E, new37(A,B,C,D,E,F).
new25(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, new27(A,B,C,D,E,F).
new25(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B, I=:=F, new28(A,B,C,D,I,F).
new24(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, I=:=F, new25(A,B,C,D,I,F).
new24(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B, I=:=F, new16(A,B,C,I,E,F).
new23(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new23(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, new41(A,B,C,D,E,F).
new21(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=B.
new21(A,B,C,D,E,F) :- G=<H, G=:=C, H=:=B, I=:=J+K, J=:=D, K=:=1, 
          new16(A,B,C,I,E,F).
new20(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=C.
new20(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=C, new21(A,B,C,D,E,F).
new19(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B.
new19(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, new20(A,B,C,D,E,F).
new17(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new17(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, new19(A,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, new17(A,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B, new9(A,B,C,D,E,F).
new14(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, new23(A,B,C,D,E,F).
new14(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B, I=:=F, new24(A,B,C,I,E,F).
new12(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=B.
new12(A,B,C,D,E,F) :- G=<H, G=:=C, H=:=B, I=:=C, J=:=K-L, K=:=C, L=:=1, 
          new4(A,B,J,D,E,I).
new11(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=C.
new11(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=C, new12(A,B,C,D,E,F).
new10(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=B.
new10(A,B,C,D,E,F) :- G=<H, G=:=C, H=:=B, new11(A,B,C,D,E,F).
new9(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=C.
new9(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=C, new10(A,B,C,D,E,F).
new8(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, I=:=F, new14(A,B,C,I,E,F).
new8(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, I=:=F, new14(A,B,C,I,E,F).
new8(A,B,C,D,E,F) :- G=:=H, G=:=A, H=:=0, I=:=F, new16(A,B,C,I,E,F).
new7(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=B, new8(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=B, new9(A,B,C,D,E,F).
new5(A,B,C,D,E,F) :- new5(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=1, new7(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=0, I=:=B, new4(A,B,I,D,E,F).
new3(A,B,C,D,E,F) :- G=<H, G=:=F, H=:=0, new5(A,B,C,D,E,F).
new2(A) :- new3(A,B,C,D,E,F).
new1 :- new2(A).
inv1 :- \+new1.
