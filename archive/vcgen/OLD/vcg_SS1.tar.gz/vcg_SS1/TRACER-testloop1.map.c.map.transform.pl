new7(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0.
new4(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=C, H=:=I+J, I=:=B, J=:=1, new4(A,H,C,D,E).
new4(A,B,C,D,E) :- F>=G, F=:=B, G=:=C, new7(A,B,C,D,E).
new3(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=0, H=:=1, new4(A,B,C,H,E).
new3(A,B,C,D,E) :- F=<G, F=:=A, G=:=0, H=:=2, new4(A,B,C,H,E).
new2 :- A=:=0, B=:=0, new3(C,B,D,E,A).
new1 :- new2.
inv1 :- \+new1.
