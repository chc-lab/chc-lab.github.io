new16(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=B, J=:=K*L, K=:= -1, L=:=A, M=:=N*O, 
          N=:= -1, O=:=B, new3(J,M,C,D,E,F,G).
new16(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=B, new3(A,B,C,D,E,F,G).
new15(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=C, new16(A,B,C,D,E,F,G).
new15(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=C, new3(A,B,C,D,E,F,G).
new13(A,B,C,D,E,F,G) :- H>=I, H=:=A, I=:=4, J=:=K+L, K=:=A, L=:=1, M=:=N+O, 
          N=:=B, O=:=3, P=:=Q+R, Q=:=C, R=:=10, S=:=T+U, T=:=D, U=:=10, 
          new3(J,M,P,S,E,F,G).
new13(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=4, new3(A,B,C,D,E,F,G).
new12(A,B,C,D,E,F,G) :- H>=I+1, H=:=E, I=:=0, new13(A,B,C,D,E,F,G).
new12(A,B,C,D,E,F,G) :- H+1=<I, H=:=E, I=:=0, new13(A,B,C,D,E,F,G).
new12(A,B,C,D,E,F,G) :- H=:=I, H=:=E, I=:=0, new15(A,B,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- new12(A,B,C,D,H,F,G).
new8(A,B,C,D,E,F,G) :- H>=I+1, H=:=F, I=:=0, J=:=K+L, K=:=A, L=:=1, M=:=N+O, 
          N=:=B, O=:=2, new3(J,M,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H+1=<I, H=:=F, I=:=0, J=:=K+L, K=:=A, L=:=1, M=:=N+O, 
          N=:=B, O=:=2, new3(J,M,C,D,E,F,G).
new8(A,B,C,D,E,F,G) :- H=:=I, H=:=F, I=:=0, new11(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H+1=<I, H=:=J*K, J=:=3, K=:=A, I=:=B.
new5(A,B,C,D,E,F,G) :- new8(A,B,C,D,E,H,G).
new4(A,B,C,D,E,F,G) :- H>=I+1, H=:=G, I=:=0, new5(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=G, I=:=0, new5(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=:=I, H=:=G, I=:=0, new7(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- new4(A,B,C,D,E,F,H).
new2 :- A=:=0, B=:=A, C=:=B, D=:=C, new3(D,C,B,A,E,F,G).
new1 :- new2.
inv1 :- \+new1.
