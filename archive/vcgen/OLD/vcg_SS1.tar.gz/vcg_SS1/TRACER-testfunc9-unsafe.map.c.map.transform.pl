new10(A,B,C) :- D=:=E, D=:=B, E=:=15, F=:=15, G=:=F, new6(G).
new10(A,B,C) :- D>=E+1, D=:=B, E=:=15, F=:=20, G=:=F, new6(G).
new10(A,B,C) :- D+1=<E, D=:=B, E=:=15, F=:=20, G=:=F, new6(G).
new7(A,B,C) :- D=:=E, D=:=B, E=:=5, F=:=5, G=:=F, new6(G).
new7(A,B,C) :- D>=E+1, D=:=B, E=:=5, new10(A,B,C).
new7(A,B,C) :- D+1=<E, D=:=B, E=:=5, new10(A,B,C).
new6(A) :- B=:=C, B=:=A, C=:=15.
new5(A,B,C) :- D=:=E, D=:=B, E=:=0, F=:=0, G=:=F, new6(G).
new5(A,B,C) :- D>=E+1, D=:=B, E=:=0, new7(A,B,C).
new5(A,B,C) :- D+1=<E, D=:=B, E=:=0, new7(A,B,C).
new4(A,B,C) :- new5(A,D,C).
new3(A) :- new4(B,C,A).
new2 :- new3(A).
new1 :- new2.
inv1 :- \+new1.
