new7(A,B,C,D) :- E>=F+1, E=:=D, F=:=0.
new7(A,B,C,D) :- E+1=<F, E=:=D, F=:=0.
new6(A,B,C,D) :- E>=F+1, E=:=D, F=:=G*H, G=:=B, H=:=2, new7(A,B,C,D).
new6(A,B,C,D) :- E+1=<F, E=:=D, F=:=G*H, G=:=B, H=:=2, new7(A,B,C,D).
new5(A,B,C,D) :- E+1=<F, E=:=A, F=:=10, G=:=H+I, H=:=D, I=:=2, J=:=K+L, K=:=A, 
          L=:=1, new4(J,B,C,G).
new5(A,B,C,D) :- E>=F, E=:=A, F=:=10, G=:=H+I, H=:=A, I=:=1, new4(G,B,C,D).
new4(A,B,C,D) :- E=<F, E=:=A, F=:=B, new5(A,B,C,D).
new4(A,B,C,D) :- E>=F+1, E=:=A, F=:=B, new6(A,B,C,D).
new3(A,B,C,D) :- E=:=F, F>=0, G=:=E, H=:=0, I=:=1, new4(I,G,E,H).
new2 :- new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
