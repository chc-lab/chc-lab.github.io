new8(A) :- B=:=C, B=:=A, C=:=3, D=:=E+F, E=:=A, F=:=1, new4(D).
new8(A) :- B>=C+1, B=:=A, C=:=3, D=:=0, new4(D).
new8(A) :- B+1=<C, B=:=A, C=:=3, D=:=0, new4(D).
new5(A) :- B=:=C, B=:=A, C=:=2, D=:=E+F, E=:=A, F=:=1, new4(D).
new5(A) :- B>=C+1, B=:=A, C=:=2, new8(A).
new5(A) :- B+1=<C, B=:=A, C=:=2, new8(A).
new4(A) :- B>=C+1, B=:=A, C=:=4.
new3(A) :- B=:=C, B=:=A, C=:=1, D=:=E+F, E=:=A, F=:=1, new4(D).
new3(A) :- B>=C+1, B=:=A, C=:=1, new5(A).
new3(A) :- B+1=<C, B=:=A, C=:=1, new5(A).
new2 :- new3(A).
new1 :- new2.
inv1 :- \+new1.
