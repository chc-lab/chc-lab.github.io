new5(A,B) :- C>=D+1, C=:=A, D=:=B.
new3(A,B) :- C+1=<D, C=:=A, D=:=B, E=:=F+G, F=:=A, G=:=1, new3(E,B).
new3(A,B) :- C>=D, C=:=A, D=:=B, new5(A,B).
new2 :- A=:=0, B=:=100, new3(A,B).
new1 :- new2.
inv1 :- \+new1.
