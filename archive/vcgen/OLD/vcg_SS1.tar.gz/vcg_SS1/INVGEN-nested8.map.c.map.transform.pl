new8(A,B,C,D,E,F) :- G>=H+1, G=:=I+J, I=:=B, J=:=C, H=:=K+L, K=:=M+N, M=:=E, 
          N=:=D, L=:=F.
new8(A,B,C,D,E,F) :- G=<H, G=:=I+J, I=:=B, J=:=C, H=:=K+L, K=:=M+N, M=:=E, 
          N=:=D, L=:=F, O=:=P+Q, P=:=D, Q=:=1, new6(A,B,C,O,E,F).
new6(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=I+J, I=:=E, J=:=F, new8(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=I+J, I=:=E, J=:=F, K=:=L+M, L=:=C, M=:=1, 
          new5(A,B,K,D,E,F).
new5(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=E, I=:=C, new6(A,B,C,I,E,F).
new5(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=E, I=:=J+K, J=:=B, K=:=1, 
          new4(A,I,C,D,E,F).
new4(A,B,C,D,E,F) :- G+1=<H, G=:=B, H=:=E, I=:=0, new5(A,B,I,D,E,F).
new3(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=F, I=:=0, new4(A,I,C,D,E,F).
new2(A) :- new3(A,B,C,D,E,F).
new1 :- new2(A).
inv1 :- \+new1.
