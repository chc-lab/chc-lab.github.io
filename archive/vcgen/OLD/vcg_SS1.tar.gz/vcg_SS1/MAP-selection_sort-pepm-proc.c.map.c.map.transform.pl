new23(A,B,C,D,E) :- F>=G, F=:= -1, G=:=D.
new23(A,B,C,D,E) :- F+1=<G, F=:= -1, G=:=D, H=:=I+J, I=:=C, J=:=1, 
          new7(A,B,H,D,E).
new22(A,B,C,D,E) :- F>=G, F=:=D, G=:=A.
new22(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=A, new23(A,B,C,D,E).
new21(A,B,C,D,E) :- F>=G, F=:= -1, G=:=B.
new21(A,B,C,D,E) :- F+1=<G, F=:= -1, G=:=B, new22(A,B,C,D,E).
new18(A,B,C,D,E) :- F>=G, F=:=B, G=:=A.
new18(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=A, new21(A,B,C,D,E).
new15(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=D, new18(A,B,C,D,E).
new15(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=D, new18(A,B,C,D,E).
new15(A,B,C,D,E) :- F=:=G, F=:=B, G=:=D, H=:=I+J, I=:=C, J=:=1, new7(A,B,H,D,E).
new14(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0, H=:=C, new15(A,B,C,H,E).
new14(A,B,C,D,E) :- F+1=<G, F=:=E, G=:=0, H=:=C, new15(A,B,C,H,E).
new14(A,B,C,D,E) :- F=:=G, F=:=E, G=:=0, new15(A,B,C,D,E).
new13(A,B,C,D,E) :- new14(A,B,C,D,F).
new12(A,B,C,D,E) :- F>=G, F=:= -1, G=:=D.
new12(A,B,C,D,E) :- F+1=<G, F=:= -1, G=:=D, new13(A,B,C,D,E).
new11(A,B,C,D,E) :- F>=G, F=:=D, G=:=A.
new11(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=A, new12(A,B,C,D,E).
new10(A,B,C,D,E) :- F>=G, F=:= -1, G=:=C.
new10(A,B,C,D,E) :- F+1=<G, F=:= -1, G=:=C, new11(A,B,C,D,E).
new8(A,B,C,D,E) :- F>=G, F=:=C, G=:=A.
new8(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=A, new10(A,B,C,D,E).
new7(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=A, new8(A,B,C,D,E).
new7(A,B,C,D,E) :- F>=G, F=:=C, G=:=A, H=:=I+J, I=:=B, J=:=1, new4(A,H,C,D,E).
new5(A,B,C,D,E) :- new5(A,B,C,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=H-I, H=:=A, I=:=1, J=:=B, K=:=L+M, L=:=B, 
          M=:=1, new7(A,B,K,J,E).
new3(A,B,C,D,E) :- F>=G, F=:=A, G=:=0, new4(A,B,C,D,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0, new5(A,B,C,D,E).
new2 :- A=:=0, B=:=0, C=:=0, new3(D,A,B,C,E).
new1 :- new2.
inv1 :- \+new1.
