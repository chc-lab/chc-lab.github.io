new7(A,B) :- C+1=<D, C=:=A, D=:=0.
new5(A,B) :- C+1=<D, C=:=A, D=:=50, new7(A,B).
new4(A,B) :- C>=D+1, C=:=B, D=:=0, E=:=F+G, F=:=B, G=:=1, new5(A,E).
new4(A,B) :- C=<D, C=:=B, D=:=0, E=:=F-G, F=:=A, G=:=10, new5(E,B).
new3(A,B) :- C>=D+1, C=:=A, D=:=5, new4(A,B).
new2 :- new3(A,B).
new1 :- new2.
inv1 :- \+new1.
