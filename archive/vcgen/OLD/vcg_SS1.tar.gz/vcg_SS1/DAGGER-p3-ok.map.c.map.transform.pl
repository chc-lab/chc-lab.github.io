new152(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=K, O=:=C.
new152(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=C, P=:=Q+R, Q=:=K, 
          R=:=1, new8(A,B,C,D,E,F,G,H,I,J,P,L,M).
new151(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=0.
new151(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=K, O=:=0, 
          new152(A,B,C,D,E,F,G,H,I,J,K,L,M).
new148(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=K, O=:=P-Q, P=:=C, Q=:=5, 
          new150(A,B,C,D,E,F,G,H,I,J,K,L,M).
new148(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=P-Q, P=:=C, Q=:=5, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=0, P=:=62, 
          new14(P,B,C,D,E,F,G,H,I,J,K,L,M).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=G, O=:=0, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, P=:=41, 
          new14(P,B,C,D,E,F,G,H,I,J,K,L,M).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=0, 
          new145(A,B,C,D,E,F,G,H,I,J,K,L,M).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=E, E>=0, O=:=0, P=:=62, 
          new14(P,B,C,D,E,F,G,H,I,J,K,L,M).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=E, E>=0, O=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=B, O=:=44, 
          new136(A,B,C,D,E,F,G,H,I,J,K,L,M).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=B, O=:=44, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=B, O=:=44, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=G, O=:=0, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=0, 
          new135(A,B,C,D,E,F,G,H,I,J,K,L,M).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=2, 
          new131(A,B,C,D,E,F,G,H,I,J,K,L,M).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=2, 
          new131(A,B,C,D,E,F,G,H,I,J,K,L,M).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=2, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=K, O=:=C.
new127(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=C, P=:=Q+R, Q=:=K, 
          R=:=1, new76(A,B,C,D,E,F,G,H,I,J,P,L,M).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=0.
new126(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=K, O=:=0, 
          new127(A,B,C,D,E,F,G,H,I,J,K,L,M).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=2, 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,M).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=2, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=2, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=P-Q, P=:=C, Q=:=5, 
          new126(A,B,C,D,E,F,G,H,I,J,K,L,M).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=33, 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,M).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=33, 
          new120(A,B,C,D,E,F,G,H,I,J,K,L,M).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=33, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=2, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=2, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=2, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M).
new107(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M).
new107(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M).
new107(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new107(A,B,C,D,E,F,G,H,I,J,K,N,M).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=K, O=:=C.
new105(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=C, P=:=Q+R, Q=:=K, 
          R=:=1, new106(A,B,C,D,E,F,G,H,I,J,P,L,M).
new104(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=0.
new104(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=K, O=:=0, 
          new105(A,B,C,D,E,F,G,H,I,J,K,L,M).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=B, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=B, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new98(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=B, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, 
          new98(A,B,C,D,E,F,G,H,I,J,K,L,M).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, 
          new98(A,B,C,D,E,F,G,H,I,J,K,L,M).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=P-Q, P=:=C, Q=:=5, 
          new104(A,B,C,D,E,F,G,H,I,J,K,L,M).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, 
          new95(A,B,C,D,E,F,G,H,I,J,K,L,M).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, 
          new95(A,B,C,D,E,F,G,H,I,J,K,L,M).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new94(A,B,C,D,E,F,G,H,I,J,K,N,M).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new90(A,B,C,D,E,F,G,H,I,J,K,N,M).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, P=:= -1, 
          new87(P,B,C,D,E,F,G,H,I,J,K,L,M).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, P=:= -1, 
          new87(P,B,C,D,E,F,G,H,I,J,K,L,M).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new87(A,B,C,D,E,F,G,H,I,J,K,L,M).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new86(A,B,C,D,E,F,G,H,I,J,K,N,M).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new84(A,B,C,D,E,F,G,H,I,J,K,N,M).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=5, 
          new83(A,B,C,D,E,F,G,H,I,J,K,L,M).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=5, 
          new84(A,B,C,D,E,F,G,H,I,J,K,L,M).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=5, 
          new84(A,B,C,D,E,F,G,H,I,J,K,L,M).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new82(A,B,C,D,E,F,G,N,I,J,K,L,M).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=G, O=:=0, 
          new112(A,B,C,D,E,F,G,H,I,J,K,L,M).
new79(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=0, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=B, 
          new79(A,B,C,D,E,F,G,H,I,J,K,L,M).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=B, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=B, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, P=:=Q+R, Q=:=F, 
          R=:=1, S=:= -1, new21(S,B,C,D,E,P,G,H,I,J,K,L,M).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, P=:=Q+R, Q=:=F, 
          R=:=1, S=:= -1, new21(S,B,C,D,E,P,G,H,I,J,K,L,M).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M).
new67(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=0, P=:= -1, 
          new21(P,B,C,D,E,F,G,H,I,J,K,L,M).
new67(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, P=:=Q-R, Q=:=F, 
          R=:=1, new21(A,B,C,D,E,P,G,H,I,J,K,L,M).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, 
          new67(A,B,C,D,E,F,G,H,I,J,K,L,M).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, 
          new67(A,B,C,D,E,F,G,H,I,J,K,L,M).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,M).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,M).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new35(A,B,C,D,E,F,G,H,I,J,K,L,M).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, P=:=1, 
          new21(A,B,C,D,P,F,G,H,I,J,K,L,M).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, P=:=1, 
          new21(A,B,C,D,P,F,G,H,I,J,K,L,M).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new58(A,B,C,D,E,F,G,H,I,J,K,N,M).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new62(A,B,C,D,E,F,G,H,I,J,K,N,M).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,M).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, P=:=32, 
          new21(P,B,C,D,E,F,G,H,I,J,K,L,M).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, P=:=32, 
          new21(P,B,C,D,E,F,G,H,I,J,K,L,M).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new48(A,B,C,D,E,F,G,H,I,J,K,N,M).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=L, O=:=0, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=L, O=:=0, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=L, O=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new41(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new44(A,B,C,D,E,F,G,H,I,J,K,N,M).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=B, O=:=32, 
          new41(A,B,C,D,E,F,G,H,I,J,K,L,M).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=B, O=:=32, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=B, O=:=32, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=G, O=:=0, P=:= -1, Q=:=0, 
          new21(P,B,C,D,Q,F,G,H,I,J,K,L,M).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=G, O=:=0, P=:=Q-R, Q=:=G, 
          R=:=1, S=:=0, new21(A,B,C,D,S,F,P,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=62, 
          new38(A,B,C,D,E,F,G,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=62, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=62, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new54(A,B,C,D,E,F,G,H,I,J,K,N,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=60, P=:=Q+R, Q=:=G, 
          R=:=1, new35(A,B,C,D,E,F,P,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=60, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=60, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, P=:= -1, 
          new21(P,B,C,D,E,F,G,H,I,J,K,L,M).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=0, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new66(A,B,C,D,E,F,G,H,I,J,K,N,M).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=41, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=41, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=41, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new72(A,B,C,D,E,F,G,H,I,J,K,N,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=40, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=40, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=40, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=2, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=2, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=2, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:= -1, 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,M).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:= -1, 
          new77(A,B,C,D,E,F,G,H,I,J,K,L,M).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:= -1, 
          new77(A,B,C,D,E,F,G,H,I,J,K,L,M).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=92, P=:=1, 
          new21(A,B,C,P,E,F,G,H,I,J,K,L,M).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=92, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M).
new20(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=92, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, P=:= -1, 
          new76(P,B,C,D,E,F,G,H,I,J,K,L,M).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=0, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, D>=0, O=:=0, P=:=0, 
          new19(A,B,C,P,E,F,G,H,I,J,K,L,M).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=D, D>=0, O=:=0, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=K, O=:=C.
new17(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=C, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=0.
new16(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O, N=:=K, O=:=0, 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=K, O=:=P-Q, P=:=C, Q=:=5, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=<O, N=:=F, O=:=0, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=F, O=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=B, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=B, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=B, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=H, O=:=2, P=:=34, 
          new14(P,B,C,D,E,F,G,H,I,J,K,L,M).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=H, O=:=2, 
          new142(A,B,C,D,E,F,G,H,I,J,K,L,M).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=H, O=:=2, 
          new142(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M) :- new9(N,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=D, D>=0, O=:=0, 
          new148(A,B,C,D,E,F,G,H,I,J,K,L,M).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=D, D>=0, O=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=A, O=:= -1, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N+1=<O, N=:=A, O=:= -1, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=O, N=:=A, O=:= -1, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N>=O+1, N=:=1, O=:=0, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M).
new2 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, F=:=0, G=:=1, H=:= -1, 
          new3(H,I,J,C,D,E,F,G,B,K,A,L,M).
new1 :- new2.
inv1 :- \+new1.
