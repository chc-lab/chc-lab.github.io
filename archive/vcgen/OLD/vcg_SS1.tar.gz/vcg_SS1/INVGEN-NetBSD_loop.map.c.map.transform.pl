new6(A,B,C,D,E,F,G) :- H>=I, H=:=E, I=:=J+K, J=:=B, K=:=1.
new6(A,B,C,D,E,F,G) :- H+1=<I, H=:=E, I=:=J+K, J=:=B, K=:=1, L=:=M+N, M=:=E, 
          N=:=1, new4(A,B,C,D,L,F,G).
new5(A,B,C,D,E,F,G) :- H>=I+1, H=:=0, I=:=E.
new5(A,B,C,D,E,F,G) :- H=<I, H=:=0, I=:=E, new6(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H=<I, H=:=E, I=:=G, new5(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H>=I+1, H=:=B, I=:=0, J=:=0, K=:=L-M, L=:=N+O, N=:=J, 
          O=:=P+Q, P=:=B, Q=:=1, M=:=1, R=:=J, S=:=K, T=:=R, 
          new4(A,B,J,K,T,R,S).
new2(A) :- new3(A,B,C,D,E,F,G).
new1 :- new2(A).
inv1 :- \+new1.
