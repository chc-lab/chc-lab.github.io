new6(A,B,C,D,E) :- new6(A,B,C,D,E).
new5(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0.
new5(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=0.
new5(A,B,C,D,E) :- F=:=G, F=:=B, G=:=0, H=:=I+J, I=:=A, J=:=1, new5(H,B,C,D,E).
new4(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=0, H=:=0, new5(H,B,C,D,E).
new4(A,B,C,D,E) :- F=<G, F=:=D, G=:=0, new6(A,B,C,D,E).
new3(A,B,C,D,E) :- F=:=G, new4(A,B,C,F,G).
new2 :- A=:=0, B=:=0, C=:=0, new3(A,B,C,D,E).
new1 :- new2.
inv1 :- \+new1.
