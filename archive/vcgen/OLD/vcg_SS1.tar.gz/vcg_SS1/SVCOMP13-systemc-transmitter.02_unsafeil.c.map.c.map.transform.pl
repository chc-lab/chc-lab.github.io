new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=Q, 
          A1=:=0, B1=:=0, C1=:=2, 
          new301(A,B,C,D,E,B1,G,H,I,J,K,L,C1,N,R,S,T,U,V,W,X,Y).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=Q, 
          A1=:=0, B1=:=0, C1=:=2, 
          new301(A,B,C,D,E,B1,G,H,I,J,K,L,C1,N,R,S,T,U,V,W,X,Y).
new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=Q, 
          A1=:=0, B1=:=2, new301(A,B,C,D,E,F,G,H,I,J,K,L,B1,N,R,S,T,U,V,W,X,Y).
new321(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=N, 
          B1=:=1, C1=:=1, D1=:=C1, 
          new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new321(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=N, B1=:=1, C1=:=0, D1=:=C1, 
          new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new321(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=N, B1=:=1, C1=:=0, D1=:=C1, 
          new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new320(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=C, 
          B1=:=1, new321(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new320(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=C, B1=:=1, C1=:=0, D1=:=C1, 
          new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new320(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=C, B1=:=1, C1=:=0, D1=:=C1, 
          new322(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new317(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new320(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,O,P,Q,R,S,T,U,V,W,X,Y).
new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=P, 
          A1=:=0, B1=:=0, 
          new317(A,B,C,D,B1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=P, 
          A1=:=0, B1=:=0, 
          new317(A,B,C,D,B1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=P, 
          A1=:=0, new317(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new314(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=M, 
          B1=:=1, C1=:=1, D1=:=C1, 
          new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new314(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=M, B1=:=1, C1=:=0, D1=:=C1, 
          new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new314(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=M, B1=:=1, C1=:=0, D1=:=C1, 
          new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=B, 
          B1=:=1, new314(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=B, B1=:=1, C1=:=0, D1=:=C1, 
          new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=B, B1=:=1, C1=:=0, D1=:=C1, 
          new315(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new310(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new313(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,O,P,Q,R,S,T,U,V,W,X,Y).
new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=O, 
          A1=:=0, B1=:=0, 
          new310(A,B,C,B1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=O, 
          A1=:=0, B1=:=0, 
          new310(A,B,C,B1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=O, 
          A1=:=0, new310(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=J, 
          B1=:=1, C1=:=1, D1=:=C1, 
          new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=J, B1=:=1, C1=:=0, D1=:=C1, 
          new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=J, B1=:=1, C1=:=0, D1=:=C1, 
          new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new306(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=A, 
          B1=:=1, new307(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new306(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=A, B1=:=1, C1=:=0, D1=:=C1, 
          new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new306(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=A, B1=:=1, C1=:=0, D1=:=C1, 
          new308(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new305(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new306(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,O,P,Q,R,S,T,U,V,W,X,Y).
new304(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new305(A,B,C,D,E,F,G,H,I,J,K,L,M,N,W,X,Y,O,P,Q,R,S,T,U,V).
new303(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new304(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new301(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=1, X=:=0, 
          Y=:=1, Z=:=2, new227(Y,B,C,Z,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new298(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new301(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=1, 
          new298(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=1, 
          new295(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=1, 
          new295(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new295(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=1, X=:=0, 
          Y=:=1, new303(A,B,C,D,E,F,G,H,I,J,K,L,Y,N,O,P,Q,R,S,T,U,V).
new294(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=0, 
          new295(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new294(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=0, 
          new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new294(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=0, 
          new296(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new291(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new294(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new290(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=P, X=:=0, 
          Y=:=1, new291(A,B,C,Y,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new290(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=P, X=:=0, 
          Y=:=1, new291(A,B,C,Y,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new290(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=P, X=:=0, 
          new227(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new275(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=Q, 
          A1=:=0, B1=:=0, C1=:=2, 
          new251(A,B,C,D,E,B1,G,H,I,J,K,L,M,C1,R,S,T,U,V,W,X,Y).
new275(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=Q, 
          A1=:=0, B1=:=0, C1=:=2, 
          new251(A,B,C,D,E,B1,G,H,I,J,K,L,M,C1,R,S,T,U,V,W,X,Y).
new275(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=Q, 
          A1=:=0, B1=:=2, new251(A,B,C,D,E,F,G,H,I,J,K,L,M,B1,R,S,T,U,V,W,X,Y).
new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=N, 
          B1=:=1, C1=:=1, D1=:=C1, 
          new275(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=N, B1=:=1, C1=:=0, D1=:=C1, 
          new275(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=N, B1=:=1, C1=:=0, D1=:=C1, 
          new275(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new273(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=C, 
          B1=:=1, new274(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new273(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=C, B1=:=1, C1=:=0, D1=:=C1, 
          new275(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new273(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=C, B1=:=1, C1=:=0, D1=:=C1, 
          new275(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,D1,S,T,U,V,W,X,Y,Z).
new270(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new273(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,O,P,Q,R,S,T,U,V,W,X,Y).
new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=P, 
          A1=:=0, B1=:=0, 
          new270(A,B,C,D,B1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=P, 
          A1=:=0, B1=:=0, 
          new270(A,B,C,D,B1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=P, 
          A1=:=0, new270(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=M, 
          B1=:=1, C1=:=1, D1=:=C1, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=M, B1=:=1, C1=:=0, D1=:=C1, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=M, B1=:=1, C1=:=0, D1=:=C1, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=B, 
          B1=:=1, new267(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=B, B1=:=1, C1=:=0, D1=:=C1, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=B, B1=:=1, C1=:=0, D1=:=C1, 
          new268(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,D1,R,S,T,U,V,W,X,Y,Z).
new263(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new266(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,O,P,Q,R,S,T,U,V,W,X,Y).
new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=O, 
          A1=:=0, B1=:=0, 
          new263(A,B,C,B1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=O, 
          A1=:=0, B1=:=0, 
          new263(A,B,C,B1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=O, 
          A1=:=0, new263(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=J, 
          B1=:=1, C1=:=1, D1=:=C1, 
          new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=J, B1=:=1, C1=:=0, D1=:=C1, 
          new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=J, B1=:=1, C1=:=0, D1=:=C1, 
          new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=A, 
          B1=:=1, new260(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=A, B1=:=1, C1=:=0, D1=:=C1, 
          new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=A, B1=:=1, C1=:=0, D1=:=C1, 
          new261(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,Q,R,S,T,U,V,W,X,Y,Z).
new258(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new259(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,O,P,Q,R,S,T,U,V,W,X,Y).
new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new258(A,B,C,D,E,F,G,H,I,J,K,L,M,N,W,X,Y,O,P,Q,R,S,T,U,V).
new254(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new252(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          Y=:=1, new254(A,B,C,D,E,F,G,H,I,J,K,L,M,Y,O,P,Q,R,S,T,U,V).
new252(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new252(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=1, X=:=0, 
          Y=:=1, Z=:=2, new230(A,Y,C,D,Z,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=0, 
          new251(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=0, 
          new252(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=0, 
          new252(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new247(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new250(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new246(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=Q, X=:=0, 
          Y=:=1, new247(A,B,C,D,Y,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new246(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=Q, X=:=0, 
          Y=:=1, new247(A,B,C,D,Y,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new246(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=Q, X=:=0, 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new241(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=C, X=:=1.
new241(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=C, X=:=1, 
          new240(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new241(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=C, X=:=1, 
          new240(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new240(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=1, X=:=0, 
          Y=:=1, Z=:=2, new72(A,B,Y,D,E,Z,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new239(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=C, X=:=0, 
          new240(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new239(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=C, X=:=0, 
          new241(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new239(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=C, X=:=0, 
          new241(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new239(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=R, X=:=0, 
          Y=:=1, new236(A,B,C,D,E,Y,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=R, X=:=0, 
          Y=:=1, new236(A,B,C,D,E,Y,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=R, X=:=0, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,W,S,T,U,V).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=F, X=:=0, 
          new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=F, X=:=0, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=F, X=:=0, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new246(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,W,R,S,T,U,V).
new227(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=E, X=:=0, 
          new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new227(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=E, X=:=0, 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new227(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=E, X=:=0, 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new290(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,W,Q,R,S,T,U,V).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=N, T=:=1, U=:=2, 
          new152(A,B,C,D,E,F,G,H,I,J,K,L,M,U,O,P,Q,R).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=N, T=:=1, 
          new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=N, T=:=1, 
          new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=M, T=:=1, U=:=2, 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,U,N,O,P,Q,R).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=M, T=:=1, 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=M, T=:=1, 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=L, T=:=1, U=:=2, 
          new199(A,B,C,D,E,F,G,H,I,J,K,U,M,N,O,P,Q,R).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=L, T=:=1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=L, T=:=1, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=K, T=:=1, U=:=2, 
          new196(A,B,C,D,E,F,G,H,I,J,U,L,M,N,O,P,Q,R).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=K, T=:=1, 
          new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=K, T=:=1, 
          new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=J, T=:=1, U=:=2, 
          new193(A,B,C,D,E,F,G,H,I,U,K,L,M,N,O,P,Q,R).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=J, T=:=1, 
          new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=J, T=:=1, 
          new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new189(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new192(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=Q, W=:=0, 
          X=:=0, new189(A,B,C,D,E,X,G,H,I,J,K,L,M,N,R,S,T,U).
new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=Q, W=:=0, 
          X=:=0, new189(A,B,C,D,E,X,G,H,I,J,K,L,M,N,R,S,T,U).
new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=Q, W=:=0, 
          new189(A,B,C,D,E,F,G,H,I,J,K,L,M,N,R,S,T,U).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=N, X=:=1, 
          Y=:=1, Z=:=Y, new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=N, X=:=1, 
          Y=:=0, Z=:=Y, new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=N, X=:=1, 
          Y=:=0, Z=:=Y, new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=C, X=:=1, 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=C, X=:=1, 
          Y=:=0, Z=:=Y, new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=C, X=:=1, 
          Y=:=0, Z=:=Y, new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new185(A,B,C,D,E,F,G,H,I,J,K,L,M,N,V,O,P,Q,R,S,T,U).
new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=P, W=:=0, 
          X=:=0, new182(A,B,C,D,X,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=P, W=:=0, 
          X=:=0, new182(A,B,C,D,X,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=P, W=:=0, 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=M, X=:=1, 
          Y=:=1, Z=:=Y, new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=M, X=:=1, 
          Y=:=0, Z=:=Y, new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=M, X=:=1, 
          Y=:=0, Z=:=Y, new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new180(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new178(A,B,C,D,E,F,G,H,I,J,K,L,M,N,V,O,P,Q,R,S,T,U).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=O, W=:=0, 
          X=:=0, new175(A,B,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=O, W=:=0, 
          X=:=0, new175(A,B,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=O, W=:=0, 
          new175(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=J, X=:=1, 
          Y=:=1, Z=:=Y, new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new171(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=1, 
          new172(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new171(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new171(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new171(A,B,C,D,E,F,G,H,I,J,K,L,M,N,V,O,P,Q,R,S,T,U).
new169(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new170(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,T,U,O,P,Q,R).
new165(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=Q, T=:=0, 
          new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=F, W=:=0, 
          X=:=1, Y=:=X, new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Y,Q,R,S,T,U).
new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=F, W=:=0, 
          X=:=0, Y=:=X, new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Y,Q,R,S,T,U).
new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=F, W=:=0, 
          X=:=0, Y=:=X, new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Y,Q,R,S,T,U).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=E, W=:=0, 
          X=:=1, Y=:=X, new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Y,Q,R,S,T,U).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=E, W=:=0, 
          new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=E, W=:=0, 
          new160(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=O, V=:=0, W=:=0, 
          X=:=W, new165(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Q,R,X,T).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=O, V=:=0, W=:=0, 
          X=:=W, new165(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Q,R,X,T).
new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=O, V=:=0, W=:=1, 
          X=:=W, new165(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Q,R,X,T).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=D, W=:=0, 
          X=:=1, Y=:=X, new156(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Y,Q,R,S,T,U).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=D, W=:=0, 
          new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=D, W=:=0, 
          new157(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new155(A,B,C,D,E,F,G,H,I,J,K,L,M,N,U,O,P,Q,R,S,T).
new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new154(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,T,O,P,Q,R).
new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=1, 
          new169(A,B,C,D,E,F,G,H,I,S,K,L,M,N,O,P,Q,R).
new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=F, U=:=0, V=:=1, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,W,R,S).
new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=F, U=:=0, V=:=0, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,W,R,S).
new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=F, U=:=0, V=:=0, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,W,R,S).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=E, U=:=0, V=:=1, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,W,R,S).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=E, U=:=0, 
          new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=E, U=:=0, 
          new146(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=P, T=:=0, U=:=4, 
          new151(A,B,C,D,E,F,G,H,I,J,K,L,M,N,U,P,Q,R).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=P, T=:=0, 
          new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=P, T=:=0, 
          new152(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=D, U=:=0, V=:=1, 
          W=:=V, new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,W,R,S).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=D, U=:=0, 
          new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=D, U=:=0, 
          new143(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,O,P,Q,R).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=N, T=:=1, U=:=2, 
          new138(A,B,C,D,E,F,G,H,I,J,K,L,M,U,O,P,Q,R).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=N, T=:=1, 
          new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=N, T=:=1, 
          new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=M, T=:=1, U=:=2, 
          new135(A,B,C,D,E,F,G,H,I,J,K,L,U,N,O,P,Q,R).
new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=M, T=:=1, 
          new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=M, T=:=1, 
          new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=L, T=:=1, U=:=2, 
          new132(A,B,C,D,E,F,G,H,I,J,K,U,M,N,O,P,Q,R).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=L, T=:=1, 
          new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=L, T=:=1, 
          new132(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=K, T=:=1, U=:=2, 
          new129(A,B,C,D,E,F,G,H,I,J,U,L,M,N,O,P,Q,R).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=K, T=:=1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=K, T=:=1, 
          new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=J, T=:=1, U=:=2, 
          new126(A,B,C,D,E,F,G,H,I,U,K,L,M,N,O,P,Q,R).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=J, T=:=1, 
          new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=J, T=:=1, 
          new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=Q, W=:=0, 
          X=:=0, new122(A,B,C,D,E,X,G,H,I,J,K,L,M,N,R,S,T,U).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=Q, W=:=0, 
          X=:=0, new122(A,B,C,D,E,X,G,H,I,J,K,L,M,N,R,S,T,U).
new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=Q, W=:=0, 
          new122(A,B,C,D,E,F,G,H,I,J,K,L,M,N,R,S,T,U).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=N, X=:=1, 
          Y=:=1, Z=:=Y, new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=N, X=:=1, 
          Y=:=0, Z=:=Y, new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=N, X=:=1, 
          Y=:=0, Z=:=Y, new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=C, X=:=1, 
          new119(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=C, X=:=1, 
          Y=:=0, Z=:=Y, new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=C, X=:=1, 
          Y=:=0, Z=:=Y, new120(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new118(A,B,C,D,E,F,G,H,I,J,K,L,M,N,V,O,P,Q,R,S,T,U).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=P, W=:=0, 
          X=:=0, new115(A,B,C,D,X,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=P, W=:=0, 
          X=:=0, new115(A,B,C,D,X,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=P, W=:=0, 
          new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=M, X=:=1, 
          Y=:=1, Z=:=Y, new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=M, X=:=1, 
          Y=:=0, Z=:=Y, new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=M, X=:=1, 
          Y=:=0, Z=:=Y, new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          new112(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,V,O,P,Q,R,S,T,U).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=O, W=:=0, 
          X=:=0, new108(A,B,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=O, W=:=0, 
          X=:=0, new108(A,B,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=O, W=:=0, 
          new108(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=J, X=:=1, 
          Y=:=1, Z=:=Y, new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new104(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=1, 
          new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new104(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new104(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new106(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new104(A,B,C,D,E,F,G,H,I,J,K,L,M,N,V,O,P,Q,R,S,T,U).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,T,U,O,P,Q,R).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=N, T=:=0, U=:=1, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,U,O,P,Q,R).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=N, T=:=0, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=N, T=:=0, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=M, T=:=0, U=:=1, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,U,N,O,P,Q,R).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=M, T=:=0, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=M, T=:=0, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=L, T=:=0, U=:=1, 
          new94(A,B,C,D,E,F,G,H,I,J,K,U,M,N,O,P,Q,R).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=L, T=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=L, T=:=0, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=K, T=:=0, U=:=1, 
          new91(A,B,C,D,E,F,G,H,I,J,U,L,M,N,O,P,Q,R).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=K, T=:=0, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=K, T=:=0, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=J, T=:=0, U=:=1, 
          new88(A,B,C,D,E,F,G,H,I,U,K,L,M,N,O,P,Q,R).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=J, T=:=0, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=J, T=:=0, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=3, 
          new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,P,Q,R).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=D, X=:=0, 
          new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=D, X=:=0, 
          new227(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=D, X=:=0, 
          new227(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=F, Y=:=0, 
          Z=:=1, A1=:=Z, new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A1,Q,R,S,T,U,V,W).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=F, Y=:=0, 
          Z=:=0, A1=:=Z, new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A1,Q,R,S,T,U,V,W).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=F, Y=:=0, 
          Z=:=0, A1=:=Z, new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A1,Q,R,S,T,U,V,W).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=E, Y=:=0, 
          Z=:=1, A1=:=Z, new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A1,Q,R,S,T,U,V,W).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=E, Y=:=0, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=E, Y=:=0, 
          new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=O, X=:=0, 
          new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=O, X=:=0, 
          new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=O, X=:=0, 
          Y=:=2, new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Y,T,U,V).
new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=D, Y=:=0, 
          Z=:=1, A1=:=Z, new74(A,B,C,D,E,F,G,H,I,J,K,L,M,N,A1,Q,R,S,T,U,V,W).
new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=D, Y=:=0, 
          new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=D, Y=:=0, 
          new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new73(A,B,C,D,E,F,G,H,I,J,K,L,M,N,W,O,P,Q,R,S,T,U,V).
new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,T,U,V,O,P,Q,R).
new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=1, T=:=0, U=:=1, 
          new71(A,B,C,D,E,F,G,H,I,J,K,L,M,N,U,P,Q,R).
new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=N, T=:=1, U=:=2, 
          new68(A,B,C,D,E,F,G,H,I,J,K,L,M,U,O,P,Q,R).
new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=N, T=:=1, 
          new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=N, T=:=1, 
          new68(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=M, T=:=1, U=:=2, 
          new65(A,B,C,D,E,F,G,H,I,J,K,L,U,N,O,P,Q,R).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=M, T=:=1, 
          new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=M, T=:=1, 
          new65(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=L, T=:=1, U=:=2, 
          new62(A,B,C,D,E,F,G,H,I,J,K,U,M,N,O,P,Q,R).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=L, T=:=1, 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=L, T=:=1, 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=K, T=:=1, U=:=2, 
          new59(A,B,C,D,E,F,G,H,I,J,U,L,M,N,O,P,Q,R).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=K, T=:=1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=K, T=:=1, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=J, T=:=1, U=:=2, 
          new56(A,B,C,D,E,F,G,H,I,U,K,L,M,N,O,P,Q,R).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=J, T=:=1, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=J, T=:=1, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=Q, W=:=0, 
          X=:=0, new52(A,B,C,D,E,X,G,H,I,J,K,L,M,N,R,S,T,U).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=Q, W=:=0, 
          X=:=0, new52(A,B,C,D,E,X,G,H,I,J,K,L,M,N,R,S,T,U).
new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=Q, W=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,R,S,T,U).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=N, X=:=1, 
          Y=:=1, Z=:=Y, new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=N, X=:=1, 
          Y=:=0, Z=:=Y, new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=N, X=:=1, 
          Y=:=0, Z=:=Y, new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=C, X=:=1, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=C, X=:=1, 
          Y=:=0, Z=:=Y, new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=C, X=:=1, 
          Y=:=0, Z=:=Y, new50(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,Z,S,T,U,V).
new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,V,O,P,Q,R,S,T,U).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=P, W=:=0, 
          X=:=0, new45(A,B,C,D,X,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=P, W=:=0, 
          X=:=0, new45(A,B,C,D,X,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=P, W=:=0, 
          new45(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=M, X=:=1, 
          Y=:=1, Z=:=Y, new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=M, X=:=1, 
          Y=:=0, Z=:=Y, new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=M, X=:=1, 
          Y=:=0, Z=:=Y, new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new41(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new41(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new41(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Z,R,S,T,U,V).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new41(A,B,C,D,E,F,G,H,I,J,K,L,M,N,V,O,P,Q,R,S,T,U).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=O, W=:=0, 
          X=:=0, new38(A,B,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=O, W=:=0, 
          X=:=0, new38(A,B,C,X,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=O, W=:=0, 
          new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=J, X=:=1, 
          Y=:=1, Z=:=Y, new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=1, 
          new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,Q,R,S,T,U,V).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,V,O,P,Q,R,S,T,U).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,T,U,O,P,Q,R).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=N, T=:=0, U=:=1, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,U,O,P,Q,R).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=N, T=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=N, T=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=M, T=:=0, U=:=1, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,U,N,O,P,Q,R).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=M, T=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=M, T=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=L, T=:=0, U=:=1, 
          new24(A,B,C,D,E,F,G,H,I,J,K,U,M,N,O,P,Q,R).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=L, T=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=L, T=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=K, T=:=0, U=:=1, 
          new21(A,B,C,D,E,F,G,H,I,J,U,L,M,N,O,P,Q,R).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=K, T=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=K, T=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=J, T=:=0, U=:=1, 
          new18(A,B,C,D,E,F,G,H,I,U,K,L,M,N,O,P,Q,R).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=J, T=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=J, T=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=I, T=:=1, U=:=0, 
          new14(A,B,C,D,E,U,G,H,I,J,K,L,M,N,O,P,Q,R).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=I, T=:=1, U=:=2, 
          new14(A,B,C,D,E,U,G,H,I,J,K,L,M,N,O,P,Q,R).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=I, T=:=1, U=:=2, 
          new14(A,B,C,D,E,U,G,H,I,J,K,L,M,N,O,P,Q,R).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=H, T=:=1, U=:=0, 
          new11(A,B,C,D,U,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=H, T=:=1, U=:=2, 
          new11(A,B,C,D,U,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=H, T=:=1, U=:=2, 
          new11(A,B,C,D,U,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=G, T=:=1, U=:=0, 
          new8(A,B,C,U,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=G, T=:=1, U=:=2, 
          new8(A,B,C,U,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=G, T=:=1, U=:=2, 
          new8(A,B,C,U,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,R,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=1, Q=:=1, R=:=1, 
          new4(A,B,C,D,E,F,P,Q,R,J,K,L,M,N,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N) :- new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new1 :- A=:=0, B=:=0, C=:=0, D=:=2, E=:=2, F=:=2, G=:=2, H=:=2, 
          new2(A,B,C,I,J,K,L,M,N,D,E,F,G,H).
inv1 :- \+new1.
