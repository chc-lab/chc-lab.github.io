new8(A,B,C) :- D+1=<E, D=:=A, E=:=B.
new7(A,B,C) :- D>=E+1, D=:=A, E=:=C, F=:=G-H, G=:=B, H=:=1, new4(A,F,C).
new7(A,B,C) :- D=<E, D=:=A, E=:=C, F=:=G+H, G=:=B, H=:=2, new4(A,F,C).
new5(A,B,C) :- new5(A,B,C).
new4(A,B,C) :- D+1=<E, D=:=A, E=:=F*G, F=:=2, G=:=C, H=:=I+J, I=:=A, J=:=1, 
          new7(H,B,C).
new4(A,B,C) :- D>=E, D=:=A, E=:=F*G, F=:=2, G=:=C, new8(A,B,C).
new3(A,B,C) :- D>=E, D=:=C, E=:=1, new4(A,B,C).
new3(A,B,C) :- D+1=<E, D=:=C, E=:=1, new5(A,B,C).
new2 :- A=:=0, B=:=0, new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
