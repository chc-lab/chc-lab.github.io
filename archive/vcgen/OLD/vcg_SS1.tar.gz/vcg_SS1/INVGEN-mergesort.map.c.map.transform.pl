new18(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=A, N=:=0, O=:=P+Q, P=:=B, Q=:=1, 
          R=:=S+T, S=:=E, T=:=1, new7(A,O,C,D,R,F,G,H,I,J,K,L).
new18(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=A, N=:=0, O=:=P+Q, P=:=B, Q=:=1, 
          R=:=S+T, S=:=E, T=:=1, new7(A,O,C,D,R,F,G,H,I,J,K,L).
new18(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=N, M=:=A, N=:=0, O=:=P+Q, P=:=I, Q=:=1, 
          R=:=S+T, S=:=E, T=:=1, new7(A,B,C,D,R,F,G,H,O,J,K,L).
new15(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=E, N=:=H, O=:=P+Q, P=:=E, Q=:=1, 
          new15(A,B,C,D,O,F,G,H,I,J,K,L).
new15(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N, M=:=E, N=:=H, O=:=P+Q, P=:=L, Q=:=R*S, 
          R=:=J, S=:=2, new4(A,B,C,D,E,F,G,H,I,J,K,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=I, N=:=H, O=:=P+Q, P=:=I, Q=:=1, 
          R=:=S+T, S=:=E, T=:=1, new13(A,B,C,D,R,F,G,H,O,J,K,L).
new13(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N, M=:=I, N=:=H, O=:=F, 
          new15(A,B,C,D,O,F,G,H,I,J,K,L).
new11(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=B, N=:=G, O=:=P+Q, P=:=B, Q=:=1, 
          R=:=S+T, S=:=E, T=:=1, new11(A,O,C,D,R,F,G,H,I,J,K,L).
new11(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N, M=:=B, N=:=G, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L).
new10(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=E, N=:=C.
new10(A,B,C,D,E,F,G,H,I,J,K,L) :- M=<N, M=:=E, N=:=C, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L).
new9(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=I, N=:=H, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L).
new9(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N, M=:=I, N=:=H, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L).
new7(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=B, N=:=G, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L).
new7(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N, M=:=B, N=:=G, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L).
new5(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=K, N=:=C, O=:=P+Q, P=:=C, Q=:=1, 
          R=:=L, S=:=T+U, T=:=L, U=:=J, V=:=O, W=:=R, X=:=S, Y=:=R, 
          new7(A,W,C,D,Y,R,S,V,X,J,O,L).
new5(A,B,C,D,E,F,G,H,I,J,K,L) :- M=<N, M=:=K, N=:=C, O=:=L, P=:=Q+R, Q=:=L, 
          R=:=J, S=:=K, T=:=O, U=:=P, V=:=O, new7(A,T,C,D,V,O,P,S,U,J,K,L).
new4(A,B,C,D,E,F,G,H,I,J,K,L) :- M=<N, M=:=O+P, O=:=L, P=:=J, N=:=C, Q=:=R+S, 
          R=:=L, S=:=T*U, T=:=J, U=:=2, new5(A,B,C,D,E,F,G,H,I,J,Q,L).
new4(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=O+P, O=:=L, P=:=J, N=:=C, Q=:=R*S, 
          R=:=J, S=:=2, new3(A,B,C,D,E,F,G,H,I,Q,K,L).
new3(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=J, N=:=C, O=:=1, 
          new4(A,B,C,D,E,F,G,H,I,J,K,O).
new2(A,B,C,D,E,F,G,H,I,J,K,L) :- M=:=1, new3(A,B,C,D,E,F,G,H,I,M,K,L).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L).
inv1 :- \+new1.
