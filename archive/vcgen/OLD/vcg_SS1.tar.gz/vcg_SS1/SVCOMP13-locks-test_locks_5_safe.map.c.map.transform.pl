new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=O, R=:=1.
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=O, R=:=1.
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=O, R=:=1, S=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,P).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=M, R=:=0, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=M, R=:=0, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=M, R=:=0, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=L, R=:=1.
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=L, R=:=1.
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=L, R=:=1, S=:=0, 
          new39(A,B,C,D,E,F,G,H,I,J,K,S,M,N,O,P).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=J, R=:=0, 
          new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=J, R=:=0, 
          new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=J, R=:=0, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=I, R=:=1.
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=I, R=:=1.
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=I, R=:=1, S=:=0, 
          new36(A,B,C,D,E,F,G,H,S,J,K,L,M,N,O,P).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=0, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=0, 
          new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=0, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=F, R=:=1.
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=F, R=:=1.
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=F, R=:=1, S=:=0, 
          new33(A,B,C,D,E,S,G,H,I,J,K,L,M,N,O,P).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=D, R=:=0, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=D, R=:=0, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=D, R=:=0, 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=C, R=:=1.
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=C, R=:=1.
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=C, R=:=1, S=:=0, 
          new30(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=A, R=:=0, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=A, R=:=0, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=A, R=:=0, 
          new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=M, R=:=0, S=:=1, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,P).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=M, R=:=0, S=:=1, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,S,P).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=M, R=:=0, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=J, R=:=0, S=:=1, 
          new22(A,B,C,D,E,F,G,H,I,J,K,S,M,N,O,P).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=J, R=:=0, S=:=1, 
          new22(A,B,C,D,E,F,G,H,I,J,K,S,M,N,O,P).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=J, R=:=0, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=G, R=:=0, S=:=1, 
          new19(A,B,C,D,E,F,G,H,S,J,K,L,M,N,O,P).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=G, R=:=0, S=:=1, 
          new19(A,B,C,D,E,F,G,H,S,J,K,L,M,N,O,P).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=G, R=:=0, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=D, R=:=0, S=:=1, 
          new16(A,B,C,D,E,S,G,H,I,J,K,L,M,N,O,P).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=D, R=:=0, S=:=1, 
          new16(A,B,C,D,E,S,G,H,I,J,K,L,M,N,O,P).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=D, R=:=0, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=A, R=:=0, S=:=1, 
          new13(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=A, R=:=0, S=:=1, 
          new13(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, Q=:=A, R=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=P, R=:=0, S=:=0, T=:=0, 
          U=:=0, V=:=0, W=:=0, new11(A,B,S,D,E,T,G,H,U,J,K,V,M,N,W,P).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=P, R=:=0, S=:=0, T=:=0, 
          U=:=0, V=:=0, W=:=0, new11(A,B,S,D,E,T,G,H,U,J,K,V,M,N,W,P).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=1, R=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, 
          new8(A,B,C,D,E,F,G,H,I,J,K,L,Q,R,O,P).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, 
          new7(A,B,C,D,E,F,G,H,I,Q,R,L,M,N,O,P).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, 
          new6(A,B,C,D,E,F,Q,R,I,J,K,L,M,N,O,P).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, 
          new5(A,B,C,Q,R,F,G,H,I,J,K,L,M,N,O,P).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=R, 
          new4(Q,R,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new2 :- new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new1 :- new2.
inv1 :- \+new1.
