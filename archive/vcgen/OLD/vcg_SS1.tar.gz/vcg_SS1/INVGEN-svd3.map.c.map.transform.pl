new17(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, I=:=J+K, J=:=E, K=:=1, 
          new17(A,B,C,D,I,F).
new17(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B, I=:=J+K, J=:=D, K=:=1, 
          new16(A,B,C,I,E,F).
new16(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, I=:=F, new17(A,B,C,D,I,F).
new16(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B, I=:=F, new12(A,B,C,I,E,F).
new15(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new15(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, I=:=J+K, J=:=D, K=:=1, 
          new10(A,B,C,I,E,F).
new12(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, I=:=J+K, J=:=D, K=:=1, 
          new12(A,B,C,I,E,F).
new12(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B, I=:=C, J=:=K-L, K=:=C, L=:=1, 
          new4(A,B,J,D,E,I).
new10(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, new15(A,B,C,D,E,F).
new10(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B, I=:=F, new16(A,B,C,I,E,F).
new8(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, I=:=F, new10(A,B,C,I,E,F).
new8(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, I=:=F, new10(A,B,C,I,E,F).
new8(A,B,C,D,E,F) :- G=:=H, G=:=A, H=:=0, I=:=F, new12(A,B,C,I,E,F).
new7(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=B, new8(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=B, I=:=C, J=:=K-L, K=:=C, L=:=1, 
          new4(A,B,J,D,E,I).
new5(A,B,C,D,E,F) :- new5(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=1, new7(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=1, I=:=B, new4(A,B,I,D,E,F).
new3(A,B,C,D,E,F) :- G=<H, G=:=F, H=:=1, new5(A,B,C,D,E,F).
new2(A) :- new3(A,B,C,D,E,F).
new1 :- new2(A).
inv1 :- \+new1.
