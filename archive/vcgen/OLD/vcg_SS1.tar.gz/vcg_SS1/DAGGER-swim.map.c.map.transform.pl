new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=G, Q=:=1, R=:=S-T, S=:=A, 
          T=:=1, U=:=V+W, V=:=B, W=:=1, X=:=Y-Z, Y=:=G, Z=:=1, 
          new7(R,U,C,D,E,F,X,H,I,J,K,L,M,N,O).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=F, Q=:=1, R=:=S-T, S=:=C, 
          T=:=1, U=:=V+W, V=:=D, W=:=1, X=:=Y-Z, Y=:=F, Z=:=1, 
          new7(A,B,R,U,E,X,G,H,I,J,K,L,M,N,O).
new41(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=1, R=:=S-T, S=:=E, 
          T=:=1, U=:=V+W, V=:=F, W=:=1, new7(A,B,C,D,R,U,G,H,I,J,K,L,M,N,O).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=D, Q=:=1, R=:=S-T, S=:=D, 
          T=:=1, U=:=V+W, V=:=E, W=:=1, X=:=Y+Z, Y=:=G, Z=:=1, 
          new7(A,B,C,R,U,F,X,H,I,J,K,L,M,N,O).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=J, Q=:=0, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=J, Q=:=0, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=J, Q=:=0, 
          new41(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new38(A,B,C,D,E,F,G,H,I,P,K,L,M,N,O).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=C, Q=:=1, 
          new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=K, Q=:=0, 
          new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=K, Q=:=0, 
          new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new34(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=K, Q=:=0, 
          new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new34(A,B,C,D,E,F,G,H,I,J,P,L,M,N,O).
new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=B, Q=:=1, R=:=S-T, S=:=B, 
          T=:=1, U=:=V+W, V=:=C, W=:=1, X=:=Y+Z, Y=:=F, Z=:=1, 
          new7(A,R,U,D,E,X,G,H,I,J,K,L,M,N,O).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=L, Q=:=0, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=L, Q=:=0, 
          new31(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=L, Q=:=0, 
          new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new30(A,B,C,D,E,F,G,H,I,J,K,P,M,N,O).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=A, Q=:=1, 
          new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=M, Q=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=M, Q=:=0, 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=M, Q=:=0, 
          new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new26(A,B,C,D,E,F,G,H,I,J,K,L,P,N,O).
new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=F, Q=:=1, R=:=S+T, S=:=A, 
          T=:=1, U=:=V-W, V=:=F, W=:=1, new7(R,B,C,D,E,U,G,H,I,J,K,L,M,N,O).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=N, Q=:=0, 
          new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=N, Q=:=0, 
          new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=N, Q=:=0, 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=R+S, R=:=T+U, T=:=V+W, 
          V=:=X+Y, X=:=A, Y=:=B, W=:=D, U=:=E, S=:=F, Q=:=1.
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=R+S, R=:=T+U, T=:=V+W, 
          V=:=B, W=:=C, U=:=D, S=:=G, Q=:=1.
new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=R+S, R=:=T+U, T=:=V+W, V=:=B, 
          W=:=C, U=:=D, S=:=G, Q=:=1, new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=A, Q=:=0.
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=A, Q=:=0, 
          new20(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=B, Q=:=0.
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=B, Q=:=0, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=C, Q=:=0.
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=C, Q=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=D, Q=:=0.
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=D, Q=:=0, 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=E, Q=:=0.
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=E, Q=:=0, 
          new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=F, Q=:=0.
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=F, Q=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=G, Q=:=0.
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=G, Q=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=R+S, R=:=T+U, T=:=V+W, 
          V=:=X+Y, X=:=A, Y=:=B, W=:=D, U=:=E, S=:=F, Q=:=H.
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=R+S, R=:=T+U, T=:=V+W, 
          V=:=X+Y, X=:=A, Y=:=B, W=:=D, U=:=E, S=:=F, Q=:=H.
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=R+S, R=:=T+U, T=:=V+W, 
          V=:=X+Y, X=:=A, Y=:=B, W=:=D, U=:=E, S=:=F, Q=:=H, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=R+S, R=:=T+U, T=:=V+W, 
          V=:=B, W=:=C, U=:=D, S=:=G, Q=:=I.
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=R+S, R=:=T+U, T=:=V+W, 
          V=:=B, W=:=C, U=:=D, S=:=G, Q=:=I.
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=R+S, R=:=T+U, T=:=V+W, 
          V=:=B, W=:=C, U=:=D, S=:=G, Q=:=I, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new22(A,B,C,D,E,F,G,H,I,J,K,L,M,P,O).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=O, Q=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=O, Q=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=O, Q=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,P).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=I, Q=:=1, 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q, P=:=H, Q=:=1, 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=G, Q=:=I, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=F, Q=:=H, 
          new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new2 :- A=:=0, B=:=0, C=:=0, D=:=0, E=:=0, new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new1 :- new2.
inv1 :- \+new1.
