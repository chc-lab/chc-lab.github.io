new11(A,B,C,D,E,F) :- G>=H, G=:=I+J, I=:=A, J=:=1, H=:=E.
new11(A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=A, J=:=1, H=:=E, K=:=L+M, L=:=A, 
          M=:=2, N=:=O+P, O=:=B, P=:=1, new8(K,N,C,D,E,F).
new10(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=A.
new10(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=A, new11(A,B,C,D,E,F).
new9(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=2, new10(A,B,C,D,E,F).
new8(A,B,C,D,E,F) :- G+1=<H, G=:=B, H=:=F, new9(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=I*J, I=:=2, J=:=F, K=:=0, 
          new8(A,K,C,D,E,F).
new6(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=C, I=:=0, J=:=D, K=:=L-M, L=:=D, M=:=C, 
          N=:=O+P, O=:=I, P=:=C, new7(N,B,C,K,J,F).
new5(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=0, new6(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=0, new5(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, new4(A,B,C,D,E,F).
new2 :- new3(A,B,C,D,E,F).
new1 :- new2.
inv1 :- \+new1.
