new9(A,B,C,D) :- E+1=<F, E=:=A, F=:=100.
new8(A,B,C,D) :- E>=F, E=:=C, F=:=0.
new8(A,B,C,D) :- E+1=<F, E=:=C, F=:=0, new9(A,B,C,D).
new7(A,B,C,D) :- E>=F+1, E=:=C, F=:=0, new8(A,B,C,D).
new6(A,B,C,D) :- E+1=<F, E=:=A, F=:=100, G=:=H+I, H=:=A, I=:=C, new6(G,B,C,D).
new6(A,B,C,D) :- E>=F, E=:=A, F=:=100, new7(A,B,C,D).
new5(A,B,C,D) :- E>=F+1, E=:=C, F=:=0, new6(A,B,C,D).
new5(A,B,C,D) :- E=<F, E=:=C, F=:=0, new7(A,B,C,D).
new4(A,B,C,D) :- E=:=F, new5(A,B,E,F).
new3(A,B,C,D) :- E=:=F, new4(E,F,C,D).
new2 :- new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
