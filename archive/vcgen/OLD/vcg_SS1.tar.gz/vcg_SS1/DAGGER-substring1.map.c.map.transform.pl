new9(A,B,C,D) :- E>=F+1, E=:=B, F=:=100.
new7(A,B,C,D) :- E+1=<F, E=:=A, F=:=D, G=:=H+I, H=:=A, I=:=1, J=:=K+L, K=:=B, 
          L=:=1, new7(G,J,C,D).
new7(A,B,C,D) :- E>=F, E=:=A, F=:=D, new9(A,B,C,D).
new6(A,B,C,D) :- E=<F, E=:=C, F=:=D, G=:=C, H=:=0, new7(G,H,C,D).
new5(A,B,C,D) :- E>=F, E=:=C, F=:=0, new6(A,B,C,D).
new4(A,B,C,D) :- E=<F, E=:=D, F=:=100, new5(A,B,C,D).
new3(A,B,C,D) :- E>=F, E=:=D, F=:=0, new4(A,B,C,D).
new2 :- new3(A,B,C,D).
new1 :- new2.
inv1 :- \+new1.
