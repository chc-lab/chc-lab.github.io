new34(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=0, N=:=O-P, O=:=A, P=:=1, 
          new11(F,G,H,I,J,K).
new34(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=0, N=:=O-P, O=:=A, P=:=1, 
          new11(F,G,H,I,J,K).
new34(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=D, M=:=0, N=:=O+P, O=:=A, P=:=10, 
          new11(F,G,H,I,J,K).
new33(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new34(N,B,C,D,E,F,G,H,I,J,K).
new33(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new34(N,B,C,D,E,F,G,H,I,J,K).
new33(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, 
          new34(A,B,C,D,E,F,G,H,I,J,K).
new32(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, new33(A,B,C,L,M,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, new32(A,L,M,D,E,F,G,H,I,J,K).
new25(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=D, M=:=0, N=:=O-P, O=:=A, P=:=1, 
          new16(F,G,H,I,J,K).
new25(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=D, M=:=0, N=:=O-P, O=:=A, P=:=1, 
          new16(F,G,H,I,J,K).
new25(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=D, M=:=0, N=:=O+P, O=:=A, P=:=10, 
          new16(F,G,H,I,J,K).
new24(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new24(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=O+P, O=:=A, P=:=1, 
          new25(N,B,C,D,E,F,G,H,I,J,K).
new24(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, 
          new25(A,B,C,D,E,F,G,H,I,J,K).
new23(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, new24(A,B,C,L,M,F,G,H,I,J,K).
new22(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, new23(A,L,M,D,E,F,G,H,I,J,K).
new21(A,B,C,D,E,F) :- G>=H+1, G=:=B, H=:=0.
new17(A,B,C,D,E,F) :- G>=H+1, G=:=B, H=:=0, I=:=J-K, J=:=B, K=:=A, 
          new17(A,I,C,D,E,F).
new17(A,B,C,D,E,F) :- G=<H, G=:=B, H=:=0, new21(A,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=0, I=:=J-K, J=:=A, K=:=1, 
          new17(I,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=0, I=:=J-K, J=:=A, K=:=1, 
          new17(I,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G=:=H, G=:=E, H=:=0, new17(A,B,C,D,E,F).
new14(A,B,C,D,E,F) :- G=:=0, new22(G,H,I,J,K,A,B,C,D,E,F).
new13(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, new14(A,B,C,D,E,F).
new13(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=0, new14(A,B,C,D,E,F).
new13(A,B,C,D,E,F) :- G=:=H, G=:=C, H=:=0, new16(A,B,C,D,E,F).
new12(A,B,C,D,E,F) :- new13(A,B,C,D,G,F).
new11(A,B,C,D,E,F) :- new12(A,B,G,D,E,F).
new9(A,B,C,D,E,F) :- G=:=0, new31(G,H,I,J,K,A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=0, new9(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=0, new9(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G=:=H, G=:=E, H=:=0, new11(A,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, I=:=J-K, J=:=A, K=:=1, 
          new6(I,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=0, I=:=J-K, J=:=A, K=:=1, 
          new6(I,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G=:=H, G=:=C, H=:=0, new6(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G=:=H, new5(A,B,C,D,G,H).
new3(A,B,C,D,E,F) :- G=:=H, new4(A,B,G,H,E,F).
new2 :- A=:=1, new3(A,B,C,D,E,F).
new1 :- new2.
inv1 :- \+new1.
