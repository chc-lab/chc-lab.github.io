new7(A,B,C,D) :- E>=F, E=:=C, F=:=D.
new6(A,B,C,D) :- E>=F+1, E=:=0, F=:=C.
new6(A,B,C,D) :- E=<F, E=:=0, F=:=C, new7(A,B,C,D).
new5(A,B,C,D) :- E>=F+1, E=:=D, F=:=0, new6(A,B,C,D).
new4(A,B,C,D) :- E>=F+1, E=:=A, F=:=0, G=:=B, H=:=I+J, I=:=B, J=:=1, 
          new3(A,H,G,D).
new4(A,B,C,D) :- E+1=<F, E=:=A, F=:=0, G=:=B, H=:=I+J, I=:=B, J=:=1, 
          new3(A,H,G,D).
new4(A,B,C,D) :- E=:=F, E=:=A, F=:=0, G=:=H+I, H=:=B, I=:=1, new3(A,G,C,D).
new3(A,B,C,D) :- E+1=<F, E=:=B, F=:=D, new4(A,B,C,D).
new3(A,B,C,D) :- E>=F, E=:=B, F=:=D, new5(A,B,C,D).
new2(A) :- B=:=0, C=:=0, new3(A,B,C,D).
new1 :- new2(A).
inv1 :- \+new1.
