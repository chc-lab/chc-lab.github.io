new11(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0.
new11(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0.
new11(A,B,C,D,E,F) :- G=:=H, G=:=A, H=:=0, new6(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G=:=H, I=:=A, G=:=4294967296-I, I+1=<0, H=:=J*K, J=:=F, 
          F>=0, K=:=2, new6(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G=:=H, I=:=A, G=:=I, I>=0, H=:=J*K, J=:=F, F>=0, K=:=2, 
          new6(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G>=H+1, I=:=A, G=:=4294967296-I, I+1=<0, H=:=J*K, J=:=F, 
          F>=0, K=:=2, new11(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G+1=<H, I=:=A, G=:=4294967296-I, I+1=<0, H=:=J*K, J=:=F, 
          F>=0, K=:=2, new11(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G>=H+1, I=:=A, G=:=I, I>=0, H=:=J*K, J=:=F, F>=0, K=:=2, 
          new11(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G+1=<H, I=:=A, G=:=I, I>=0, H=:=J*K, J=:=F, F>=0, K=:=2, 
          new11(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G+1=<H, G=:=F, F>=0, H=:=10, I=:=J+K, J=:=A, K=:=2, 
          L=:=M+N, M=:=F, F>=0, N=:=1, new7(I,B,C,D,E,L).
new6(A,B,C,D,E,F) :- G>=H, G=:=F, F>=0, H=:=10, I=:=J+K, J=:=F, F>=0, K=:=1, 
          new7(A,B,C,D,E,I).
new5(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=0, new6(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G=:=H, H>=0, I=:=G, J=:=I, I>=0, K=:=0, new5(A,B,C,J,G,K).
new3(A,B,C,D,E,F) :- G=:=H, H>=0, I=:=G, J=:=I, I>=0, new4(A,J,G,D,E,F).
new2 :- A=:=0, new3(A,B,C,D,E,F).
new1 :- new2.
inv1 :- \+new1.
