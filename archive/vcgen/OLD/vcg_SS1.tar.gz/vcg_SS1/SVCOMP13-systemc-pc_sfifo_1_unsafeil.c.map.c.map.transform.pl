new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=B, W=:=0, 
          X=:=2, Y=:=1, new38(A,B,C,D,E,F,X,Y,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=B, W=:=0, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=B, W=:=0, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=Q, Y=:=0, 
          Z=:=0, A1=:=2, new85(A,B,C,A1,E,F,G,H,I,J,K,Z,M,N,O,R,S,T,U,V,W).
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=Q, Y=:=0, 
          Z=:=0, A1=:=2, new85(A,B,C,A1,E,F,G,H,I,J,K,Z,M,N,O,R,S,T,U,V,W).
new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=Q, Y=:=0, 
          Z=:=2, new85(A,B,C,Z,E,F,G,H,I,J,K,L,M,N,O,R,S,T,U,V,W).
new101(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=D, Z=:=1, 
          A1=:=1, B1=:=A1, 
          new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,B1,S,T,U,V,W,X).
new101(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=D, 
          Z=:=1, A1=:=0, B1=:=A1, 
          new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,B1,S,T,U,V,W,X).
new101(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=D, 
          Z=:=1, A1=:=0, B1=:=A1, 
          new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,B1,S,T,U,V,W,X).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=M, Z=:=1, 
          new101(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=M, 
          Z=:=1, A1=:=0, B1=:=A1, 
          new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,B1,S,T,U,V,W,X).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=M, 
          Z=:=1, A1=:=0, B1=:=A1, 
          new102(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,B1,S,T,U,V,W,X).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,X,P,Q,R,S,T,U,V,W).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X>=Y+1, X=:=P, Y=:=0, 
          Z=:=0, new97(A,B,C,D,E,F,Z,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X+1=<Y, X=:=P, Y=:=0, 
          Z=:=0, new97(A,B,C,D,E,F,Z,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=:=Y, X=:=P, Y=:=0, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=C, Z=:=1, 
          A1=:=1, B1=:=A1, 
          new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,B1,R,S,T,U,V,W,X).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=C, Z=:=1, 
          A1=:=0, B1=:=A1, 
          new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,B1,R,S,T,U,V,W,X).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=C, Z=:=1, 
          A1=:=0, B1=:=A1, 
          new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,B1,R,S,T,U,V,W,X).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=H, Z=:=1, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=H, Z=:=1, 
          A1=:=0, B1=:=A1, 
          new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,B1,R,S,T,U,V,W,X).
new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=H, Z=:=1, 
          A1=:=0, B1=:=A1, 
          new95(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,B1,R,S,T,U,V,W,X).
new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- 
          new93(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,X,P,Q,R,S,T,U,V,W).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new92(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,V,W,P,Q,R,S,T,U).
new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, X=:=Y+Z, Y=:=E, 
          Z=:=1, A1=:=0, B1=:=1, 
          new91(W,A1,C,B1,X,V,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=H, W=:=1, 
          new88(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=H, W=:=1, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=H, W=:=1, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=1, W=:=0, 
          new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=H, W=:=0, 
          new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=H, W=:=0, 
          new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=H, W=:=0, 
          new86(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new82(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=P, W=:=0.
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=P, W=:=0, 
          X=:=1, new82(A,B,C,D,E,F,X,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=P, W=:=0, 
          X=:=1, new82(A,B,C,D,E,F,X,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          Y=:=2, Z=:=1, A1=:=P, 
          new14(A,B,C,D,E,F,G,H,I,J,K,Y,Z,N,A1,Q,R,S,T,U,V).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          Y=:=A, Z=:=Y, A1=:=B1+C1, B1=:=J, C1=:=1, D1=:=1, E1=:=1, 
          new51(A,D1,E1,D,E,F,G,H,I,A1,Z,L,M,N,O,Y,Q,R,S,T,U,V).
new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          Y=:=A, Z=:=Y, A1=:=B1+C1, B1=:=J, C1=:=1, D1=:=1, E1=:=1, 
          new51(A,D1,E1,D,E,F,G,H,I,A1,Z,L,M,N,O,Y,Q,R,S,T,U,V).
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=E, X=:=J.
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=E, X=:=J.
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=E, X=:=J, 
          new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=F, X=:=K.
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=F, X=:=K.
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=F, X=:=K, 
          new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=Q, Z=:=0, 
          A1=:=0, B1=:=2, new66(A,B,B1,D,E,F,G,H,I,J,K,A1,M,N,O,R,S,T,U,V,W,X).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=Q, Z=:=0, 
          A1=:=0, B1=:=2, new66(A,B,B1,D,E,F,G,H,I,J,K,A1,M,N,O,R,S,T,U,V,W,X).
new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=Q, Z=:=0, 
          A1=:=2, new66(A,B,A1,D,E,F,G,H,I,J,K,L,M,N,O,R,S,T,U,V,W,X).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=D, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,C1,S,T,U,V,W,X,Y).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=D, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,C1,S,T,U,V,W,X,Y).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=D, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,C1,S,T,U,V,W,X,Y).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=M, 
          A1=:=1, new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=M, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,C1,S,T,U,V,W,X,Y).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=M, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new64(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,C1,S,T,U,V,W,X,Y).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Y,P,Q,R,S,T,U,V,W,X).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=P, Z=:=0, 
          A1=:=0, new59(A,B,C,D,E,F,A1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y+1=<Z, Y=:=P, Z=:=0, 
          A1=:=0, new59(A,B,C,D,E,F,A1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=:=Z, Y=:=P, Z=:=0, 
          new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=C, 
          A1=:=1, B1=:=1, C1=:=B1, 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,C1,R,S,T,U,V,W,X,Y).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=C, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,C1,R,S,T,U,V,W,X,Y).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=C, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,C1,R,S,T,U,V,W,X,Y).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=H, 
          A1=:=1, new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=H, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,C1,R,S,T,U,V,W,X,Y).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=H, 
          A1=:=1, B1=:=0, C1=:=B1, 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,C1,R,S,T,U,V,W,X,Y).
new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Y,P,Q,R,S,T,U,V,W,X).
new51(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- 
          new54(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,W,X,P,Q,R,S,T,U,V).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=M, X=:=1, 
          Y=:=O, Z=:=A, A1=:=Z, B1=:=C1+D1, C1=:=J, D1=:=1, E1=:=1, F1=:=1, 
          new51(A,E1,F1,D,E,F,G,H,I,B1,A1,L,M,N,O,Z,Q,R,S,T,U,V).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=M, X=:=1, 
          new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=M, X=:=1, 
          new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=1, X=:=0, 
          new70(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=M, X=:=0, 
          new48(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=M, X=:=0, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=M, X=:=0, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new44(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,V,P,Q,R,S,T,U).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=Q, W=:=0, 
          X=:=1, new44(A,B,C,D,E,F,G,H,I,J,K,X,M,N,O,P,Q,R,S,T,U).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=Q, W=:=0, 
          X=:=1, new44(A,B,C,D,E,F,G,H,I,J,K,X,M,N,O,P,Q,R,S,T,U).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=Q, W=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,V,R,S,T,U).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=L, W=:=0, 
          new40(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=L, W=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=L, W=:=0, 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new81(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,V,Q,R,S,T,U).
new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=Q, T=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=L, W=:=0, X=:=1, 
          Y=:=X, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Y,R,S,T,U).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=L, W=:=0, 
          X=:=0, Y=:=X, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Y,R,S,T,U).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=L, W=:=0, 
          X=:=0, Y=:=X, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Y,R,S,T,U).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=P, V=:=0, W=:=0, 
          X=:=W, new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,R,X,T).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=P, V=:=0, W=:=0, 
          X=:=W, new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,R,X,T).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=P, V=:=0, W=:=1, 
          X=:=W, new33(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,R,X,T).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=G, W=:=0, X=:=1, 
          Y=:=X, new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Y,R,S,T,U).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=G, W=:=0, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=G, W=:=0, 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- 
          new26(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,U,P,Q,R,S,T).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new25(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,S,T,P,Q,R).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=G, W=:=0, 
          new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=G, W=:=0, 
          new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=G, W=:=0, 
          new38(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=L, X=:=0, 
          Y=:=1, Z=:=Y, new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,Z,T,U,V).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=L, X=:=0, 
          Y=:=0, Z=:=Y, new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,Z,T,U,V).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=L, X=:=0, 
          Y=:=0, Z=:=Y, new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,Z,T,U,V).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=R, W=:=0, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=R, W=:=0, 
          new22(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=R, W=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,S,T,U).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=G, X=:=0, 
          Y=:=1, Z=:=Y, new16(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,Z,T,U,V).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=G, X=:=0, 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=G, X=:=0, 
          new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,V,P,Q,R,S,T,U).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,S,T,U,P,Q,R).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=1, T=:=0, U=:=1, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,U,Q,R).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=N, T=:=1, U=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,U,M,N,O,P,Q,R).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=N, T=:=1, U=:=2, 
          new10(A,B,C,D,E,F,G,H,I,J,K,U,M,N,O,P,Q,R).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=N, T=:=1, U=:=2, 
          new10(A,B,C,D,E,F,G,H,I,J,K,U,M,N,O,P,Q,R).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=:=T, S=:=I, T=:=1, U=:=0, 
          new7(A,B,C,D,E,F,U,H,I,J,K,L,M,N,O,P,Q,R).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S>=T+1, S=:=I, T=:=1, U=:=2, 
          new7(A,B,C,D,E,F,U,H,I,J,K,L,M,N,O,P,Q,R).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S+1=<T, S=:=I, T=:=1, U=:=2, 
          new7(A,B,C,D,E,F,U,H,I,J,K,L,M,N,O,P,Q,R).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,Q,R,P).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q=:=1, R=:=2, S=:=R, T=:=0, U=:=0, 
          V=:=1, W=:=0, X=:=0, Y=:=1, new4(A,Q,S,R,T,F,G,U,V,W,K,L,X,Y,O,P).
new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
new1 :- new2(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
inv1 :- \+new1.
