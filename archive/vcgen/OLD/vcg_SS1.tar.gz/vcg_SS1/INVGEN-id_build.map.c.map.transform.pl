new7(A,B,C) :- D>=E, D=:=F-G, F=:=H-I, H=:=A, I=:=1, G=:=B, E=:=A.
new7(A,B,C) :- D+1=<E, D=:=F-G, F=:=H-I, H=:=A, I=:=1, G=:=B, E=:=A, J=:=K+L, 
          K=:=C, L=:=1, new4(A,B,J).
new5(A,B,C) :- D>=E+1, D=:=0, E=:=F-G, F=:=H-I, H=:=A, I=:=1, G=:=B.
new5(A,B,C) :- D=<E, D=:=0, E=:=F-G, F=:=H-I, H=:=A, I=:=1, G=:=B, new7(A,B,C).
new4(A,B,C) :- D+1=<E, D=:=C, E=:=8, new5(A,B,C).
new4(A,B,C) :- D>=E, D=:=C, E=:=8, F=:=G+H, G=:=B, H=:=1, new3(A,F,C).
new3(A,B,C) :- D+1=<E, D=:=B, E=:=A, F=:=0, new4(A,B,F).
new2 :- A=:=0, new3(B,A,C).
new1 :- new2.
inv1 :- \+new1.
