new6(A,B,C) :- D>=E+1, D=:=C, E=:=1.
new3(A,B,C) :- D>=E+1, D=:=A, E=:=B, F=:=G+H, G=:=A, H=:=1, new3(F,B,C).
new3(A,B,C) :- D+1=<E, D=:=A, E=:=B, F=:=G+H, G=:=A, H=:=1, new3(F,B,C).
new3(A,B,C) :- D=:=E, D=:=A, E=:=B, new6(A,B,C).
new2 :- A=:=0, B=:=10, C=:=0, D=:=E+F, E=:=C, F=:=1, new3(D,B,A).
new1 :- new2.
inv1 :- \+new1.
