new8(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=0, I=:=J+K, J=:=B, K=:=A, L=:=M-N, 
          M=:=A, N=:=O*P, O=:=2, P=:=I, Q=:=R+S, R=:=T*U, T=:=2, U=:=A, S=:=I, 
          new3(A,I,L,Q,E,F).
new8(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=0, I=:=J+K, J=:=B, K=:=A, L=:=M-N, 
          M=:=A, N=:=O*P, O=:=2, P=:=I, Q=:=R+S, R=:=T*U, T=:=2, U=:=A, S=:=I, 
          new3(A,I,L,Q,E,F).
new8(A,B,C,D,E,F) :- G=:=H, G=:=E, H=:=0, I=:=J-K, J=:=B, K=:=A, L=:=M-N, 
          M=:=A, N=:=O*P, O=:=2, P=:=I, Q=:=R+S, R=:=T*U, T=:=2, U=:=A, S=:=I, 
          new3(A,I,L,Q,E,F).
new7(A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=C, J=:=K*L, K=:=2, L=:=D, H=:=0.
new5(A,B,C,D,E,F) :- new8(A,B,C,D,G,F).
new4(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=0, I=:=J+K, J=:=C, K=:=L*M, L=:=2, 
          M=:=D, N=:=O+P, O=:=Q*R, Q=:= -2, R=:=C, P=:=D, S=:=T+U, T=:=I, 
          U=:=1, new5(S,N,C,D,E,F).
new4(A,B,C,D,E,F) :- G+1=<H, G=:=F, H=:=0, I=:=J+K, J=:=C, K=:=L*M, L=:=2, 
          M=:=D, N=:=O+P, O=:=Q*R, Q=:= -2, R=:=C, P=:=D, S=:=T+U, T=:=I, 
          U=:=1, new5(S,N,C,D,E,F).
new4(A,B,C,D,E,F) :- G=:=H, G=:=F, H=:=0, new7(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- new4(A,B,C,D,E,G).
new2 :- A=:=0, B=:=0, new3(C,D,A,B,E,F).
new1 :- new2.
inv1 :- \+new1.
