new25(A,B,C) :- D>=E, D=:=C, E=:=F-G, F=:=B, G=:=1, H=:=0, new4(A,B,H).
new25(A,B,C) :- D+1=<E, D=:=C, E=:=F-G, F=:=B, G=:=1, new4(A,B,C).
new24(A,B,C) :- D>=E, D=:=C, E=:=B.
new24(A,B,C) :- D+1=<E, D=:=C, E=:=B, F=:=G+H, G=:=C, H=:=1, new25(A,B,F).
new22(A,B,C) :- D>=E+1, D=:=0, E=:=C.
new22(A,B,C) :- D=<E, D=:=0, E=:=C, new24(A,B,C).
new21(A,B,C) :- D>=E, D=:=C, E=:=F-G, F=:=B, G=:=1, H=:=0, new22(A,B,H).
new21(A,B,C) :- D+1=<E, D=:=C, E=:=F-G, F=:=B, G=:=1, new22(A,B,C).
new20(A,B,C) :- D>=E, D=:=C, E=:=B.
new20(A,B,C) :- D+1=<E, D=:=C, E=:=B, F=:=G+H, G=:=C, H=:=1, new21(A,B,F).
new18(A,B,C) :- D>=E+1, D=:=0, E=:=C.
new18(A,B,C) :- D=<E, D=:=0, E=:=C, new20(A,B,C).
new17(A,B,C) :- D>=E, D=:=C, E=:=F-G, F=:=B, G=:=1, H=:=0, new18(A,B,H).
new17(A,B,C) :- D+1=<E, D=:=C, E=:=F-G, F=:=B, G=:=1, new18(A,B,C).
new16(A,B,C) :- D>=E, D=:=C, E=:=B.
new16(A,B,C) :- D+1=<E, D=:=C, E=:=B, F=:=G+H, G=:=C, H=:=1, new17(A,B,F).
new15(A,B,C) :- D>=E+1, D=:=0, E=:=C.
new15(A,B,C) :- D=<E, D=:=0, E=:=C, new16(A,B,C).
new12(A,B,C) :- D>=E+1, D=:=A, E=:=0, new7(A,B,C).
new12(A,B,C) :- D+1=<E, D=:=A, E=:=0, new7(A,B,C).
new12(A,B,C) :- D=:=E, D=:=A, E=:=0, new15(A,B,C).
new9(A,B,C) :- D>=E, D=:=C, E=:=B.
new8(A,B,C) :- D>=E+1, D=:=0, E=:=C.
new8(A,B,C) :- D=<E, D=:=0, E=:=C, new9(A,B,C).
new7(A,B,C) :- D>=E+1, D=:=C, E=:=0, new8(A,B,C).
new5(A,B,C) :- D>=E+1, D=:=A, E=:=0, new7(A,B,C).
new5(A,B,C) :- D+1=<E, D=:=A, E=:=0, new7(A,B,C).
new5(A,B,C) :- D=:=E, D=:=A, E=:=0, new12(A,B,C).
new4(A,B,C) :- D>=E+1, D=:=A, E=:=0, new5(A,B,C).
new4(A,B,C) :- D+1=<E, D=:=A, E=:=0, new5(A,B,C).
new4(A,B,C) :- D=:=E, D=:=A, E=:=0, new7(A,B,C).
new3(A,B,C) :- D>=E+1, D=:=B, E=:=0, F=:=0, new4(A,B,F).
new2 :- new3(A,B,C).
new1 :- new2.
inv1 :- \+new1.
