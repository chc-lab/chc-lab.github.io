new6(A,B,C,D) :- E=<F, E=:=C, F=:=0.
new6(A,B,C,D) :- E>=F+1, E=:=C, F=:=0, G=:=H+I, H=:=D, I=:=2, J=:=K-L, K=:=C, 
          L=:=1, new5(A,B,J,G).
new5(A,B,C,D) :- E+1=<F, E=:=D, F=:=A, new6(A,B,C,D).
new3(A,B,C,D) :- E+1=<F, E=:=B, F=:=A, G=:=H+I, H=:=B, I=:=2, J=:=K+L, K=:=C, 
          L=:=1, new3(A,G,J,D).
new3(A,B,C,D) :- E>=F, E=:=B, F=:=A, G=:=0, new5(A,B,C,G).
new2 :- A=:=0, B=:=0, new3(C,A,B,D).
new1 :- new2.
inv1 :- \+new1.
