new7(A,B,C) :- D+1=<E, D=:=B, E=:=1, F=:=0, new3(A,F,C).
new7(A,B,C) :- D>=E, D=:=B, E=:=1, new3(A,B,C).
new6(A,B,C) :- D>=E+1, D=:=A, E=:=2.
new5(A,B,C) :- D+1=<E, D=:=A, E=:=2, F=:=2, new7(F,B,C).
new5(A,B,C) :- D>=E, D=:=A, E=:=2, F=:=1, new7(F,B,C).
new4(A,B,C) :- D+1=<E, D=:=C, E=:=10, new5(A,B,C).
new4(A,B,C) :- D>=E, D=:=C, E=:=10, new6(A,B,C).
new3(A,B,C) :- new4(A,B,D).
new2 :- A=:=0, B=:=1, new3(B,A,C).
new1 :- new2.
inv1 :- \+new1.
