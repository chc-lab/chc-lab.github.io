new6(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0.
new6(A,B,C,D,E) :- F>=G, F=:=A, G=:=0, H=:=I+J, I=:=D, J=:=1, new3(A,H,E).
new5(A,B,C,D,E) :- F>=G, F=:=B, G=:=0, H=:=1, new6(A,B,H,D,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=0, H=:=2, I=:=1, J=:=K+L, K=:=D, L=:=1, 
          new3(I,J,E).
new4(A,B,C) :- D=:=C, new5(A,D,E,B,C).
new3(A,B,C) :- D+1=<E, D=:=B, E=:=10, new4(A,B,C).
new2(A) :- B=:=0, C=:=0, new3(B,C,D).
new1 :- new2(A).
inv1 :- \+new1.
