new78(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=8656, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new78(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=8656, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new78(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, N=:=8512, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new70(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=N+O, N=:=D, O=:=2, M=:=0, P=:=8576, 
          new18(P,B,C,D,E,F,G,H,I,J,K).
new70(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=N+O, N=:=D, O=:=2, M=:=0, P=:=8576, 
          new18(P,B,C,D,E,F,G,H,I,J,K).
new70(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=N+O, N=:=D, O=:=2, M=:=0, P=:=8560, 
          new18(P,B,C,D,E,F,G,H,I,J,K).
new69(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=N+O, N=:=H, H>=0, O=:=256, M=:=0, 
          new70(A,B,C,D,E,F,G,H,I,J,K).
new67(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=N+O, N=:=D, O=:=4, M=:=0, P=:=8560, 
          new18(P,B,C,D,E,F,G,H,I,J,K).
new67(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=N+O, N=:=D, O=:=4, M=:=0, P=:=8560, 
          new18(P,B,C,D,E,F,G,H,I,J,K).
new67(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=N+O, N=:=D, O=:=4, M=:=0, 
          new69(A,B,C,D,E,F,G,H,I,J,K).
new64(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=F, M=:=0, 
          new67(A,B,C,D,E,F,G,H,I,J,K).
new64(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=F, M=:=0, 
          new67(A,B,C,D,E,F,G,H,I,J,K).
new64(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=F, M=:=0, 
          new69(A,B,C,D,E,F,G,H,I,J,K).
new60(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=K, M=:=2, N=:=8466, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new60(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=K, M=:=2, N=:=8592, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new60(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=K, M=:=2, N=:=8592, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new56(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=B, M=:=0, N=:=8656, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new47(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=J, M=:=5.
new47(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=J, M=:=5, 
          new46(A,B,C,D,E,F,G,H,I,J,K).
new47(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=J, M=:=5, 
          new46(A,B,C,D,E,F,G,H,I,J,K).
new46(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=B, M=:=0, N=:=8640, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new46(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=B, M=:=0, N=:=8640, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new45(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=J, M=:=4, N=:=5, 
          new46(A,B,C,D,E,F,G,H,I,N,K).
new45(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=J, M=:=4, 
          new47(A,B,C,D,E,F,G,H,I,J,K).
new45(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=J, M=:=4, 
          new47(A,B,C,D,E,F,G,H,I,J,K).
new43(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8672, 
          new45(A,B,C,D,E,F,G,H,I,J,K).
new42(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=J, M=:=2, N=:=3, O=:=8672, 
          new18(O,B,C,D,E,F,G,H,I,N,K).
new42(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=J, M=:=2, N=:=8672, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new42(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=J, M=:=2, N=:=8672, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new40(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8656, 
          new42(A,B,C,D,E,F,G,H,I,J,K).
new40(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8656, 
          new43(A,B,C,D,E,F,G,H,I,J,K).
new40(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8656, 
          new43(A,B,C,D,E,F,G,H,I,J,K).
new39(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=J, M=:=3, N=:=4, 
          new56(A,B,C,D,E,F,G,H,I,N,K).
new39(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=J, M=:=3, 
          new56(A,B,C,D,E,F,G,H,I,J,K).
new39(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=J, M=:=3, 
          new56(A,B,C,D,E,F,G,H,I,J,K).
new37(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8640, 
          new39(A,B,C,D,E,F,G,H,I,J,K).
new37(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8640, 
          new40(A,B,C,D,E,F,G,H,I,J,K).
new37(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8640, 
          new40(A,B,C,D,E,F,G,H,I,J,K).
new34(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8608, N=:=8640, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new34(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8608, 
          new37(A,B,C,D,E,F,G,H,I,J,K).
new34(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8608, 
          new37(A,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8592, N=:=8608, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8592, 
          new34(A,B,C,D,E,F,G,H,I,J,K).
new31(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8592, 
          new34(A,B,C,D,E,F,G,H,I,J,K).
new30(A,B,C,D,E,F,G,H,I,J,K) :- new60(A,B,C,D,E,F,G,H,I,J,L).
new28(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8576, 
          new30(A,B,C,D,E,F,G,H,I,J,K).
new28(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8576, 
          new31(A,B,C,D,E,F,G,H,I,J,K).
new28(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8576, 
          new31(A,B,C,D,E,F,G,H,I,J,K).
new25(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8560, N=:=8576, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new25(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8560, 
          new28(A,B,C,D,E,F,G,H,I,J,K).
new25(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8560, 
          new28(A,B,C,D,E,F,G,H,I,J,K).
new24(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=N+O, N=:=D, O=:=1, M=:=0, 
          new64(A,B,C,D,E,F,G,H,I,J,K).
new24(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=N+O, N=:=D, O=:=1, M=:=0, 
          new64(A,B,C,D,E,F,G,H,I,J,K).
new24(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=N+O, N=:=D, O=:=1, M=:=0, P=:=8560, 
          new18(P,B,C,D,E,F,G,H,I,J,K).
new22(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8544, 
          new24(A,B,C,D,E,F,G,H,I,J,K).
new22(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8544, 
          new25(A,B,C,D,E,F,G,H,I,J,K).
new22(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8544, 
          new25(A,B,C,D,E,F,G,H,I,J,K).
new19(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8528, N=:=8544, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new19(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8528, 
          new22(A,B,C,D,E,F,G,H,I,J,K).
new19(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8528, 
          new22(A,B,C,D,E,F,G,H,I,J,K).
new18(A,B,C,D,E,F,G,H,I,J,K) :- new7(A,B,C,D,E,F,G,H,I,J,K).
new16(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8512, N=:=8528, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new16(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8512, 
          new19(A,B,C,D,E,F,G,H,I,J,K).
new16(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8512, 
          new19(A,B,C,D,E,F,G,H,I,J,K).
new15(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=J, M=:=1, N=:=2, 
          new78(A,B,C,D,E,F,G,H,I,N,K).
new15(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=J, M=:=1, 
          new78(A,B,C,D,E,F,G,H,I,J,K).
new15(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=J, M=:=1, 
          new78(A,B,C,D,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8496, 
          new15(A,B,C,D,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8496, 
          new16(A,B,C,D,E,F,G,H,I,J,K).
new13(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8496, 
          new16(A,B,C,D,E,F,G,H,I,J,K).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=J, M=:=0, N=:=1, O=:=8496, 
          new18(O,B,C,D,E,F,G,H,I,N,K).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=J, M=:=0, N=:=8496, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new12(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=J, M=:=0, N=:=8496, 
          new18(N,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, L=:=A, M=:=8466, 
          new12(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8466, 
          new13(A,B,C,D,E,F,G,H,I,J,K).
new11(A,B,C,D,E,F,G,H,I,J,K) :- L+1=<M, L=:=A, M=:=8466, 
          new13(A,B,C,D,E,F,G,H,I,J,K).
new10(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=J, M=:=2.
new10(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=J, M=:=2, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L=<M, L=:=A, M=:=8512, 
          new10(A,B,C,D,E,F,G,H,I,J,K).
new9(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=A, M=:=8512, 
          new11(A,B,C,D,E,F,G,H,I,J,K).
new7(A,B,C,D,E,F,G,H,I,J,K) :- L>=M+1, L=:=1, M=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, N=:=4294967296-L, L+1=<0, O=:=8466, 
          P=:=0, new7(O,B,C,D,E,F,G,N,M,P,K).
new6(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, N=:=L, L>=0, O=:=8466, P=:=0, 
          new7(O,B,C,D,E,F,G,N,M,P,K).
new5(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, new6(A,B,C,D,E,L,M,H,I,J,K).
new4(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, new5(A,B,C,L,M,F,G,H,I,J,K).
new3(A,B,C,D,E,F,G,H,I,J,K) :- L=:=M, new4(A,L,M,D,E,F,G,H,I,J,K).
new2 :- new3(A,B,C,D,E,F,G,H,I,J,K).
new1 :- new2.
inv1 :- \+new1.
