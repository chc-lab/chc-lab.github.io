new18(A,B,C) :- D>=E, D=:=B, E=:=4.
new17(A,B,C) :- D=<E, D=:=4, E=:=B, new18(A,B,C).
new16(A,B,C) :- D=<E, D=:=C, E=:=0, new17(A,B,C).
new15(A,B,C) :- D>=E, D=:=C, E=:=0, new16(A,B,C).
new11(A,B,C) :- D>=E+1, D=:=A, E=:=0, F=:=G+H, G=:=B, H=:=2, I=:=J+K, J=:=C, 
          K=:=2, new11(A,F,I).
new11(A,B,C) :- D+1=<E, D=:=A, E=:=0, F=:=G+H, G=:=B, H=:=2, I=:=J+K, J=:=C, 
          K=:=2, new11(A,F,I).
new11(A,B,C) :- D=:=E, D=:=A, E=:=0, new15(A,B,C).
new9(A,B,C) :- D=<E, D=:=C, E=:=2, new11(A,B,C).
new9(A,B,C) :- D>=E+1, D=:=C, E=:=2, new5(A,B,C).
new7(A,B,C) :- D=<E, D=:=0, E=:=C, new9(A,B,C).
new7(A,B,C) :- D>=E+1, D=:=0, E=:=C, new5(A,B,C).
new5(A,B,C) :- new5(A,B,C).
new4(A,B,C) :- D=<E, D=:=B, E=:=2, new7(A,B,C).
new4(A,B,C) :- D>=E+1, D=:=B, E=:=2, new5(A,B,C).
new3(A,B,C) :- D=<E, D=:=0, E=:=B, new4(A,B,C).
new3(A,B,C) :- D>=E+1, D=:=0, E=:=B, new5(A,B,C).
new2(A) :- new3(A,B,C).
new1 :- new2(A).
inv1 :- \+new1.
