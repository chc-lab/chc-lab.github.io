new40(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B.
new40(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, I=:=J+K, J=:=E, K=:=1, 
          new11(A,B,C,D,I,F).
new39(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new39(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, new40(A,B,C,D,E,F).
new38(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B.
new38(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, new39(A,B,C,D,E,F).
new36(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B.
new36(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, I=:=J+K, J=:=F, K=:=1, 
          new22(A,B,C,D,E,I).
new35(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=E.
new35(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=E, new36(A,B,C,D,E,F).
new34(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=B.
new34(A,B,C,D,E,F) :- G=<H, G=:=F, H=:=B, new35(A,B,C,D,E,F).
new32(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B.
new32(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, I=:=J+K, J=:=F, K=:=1, 
          new25(A,B,C,D,E,I).
new31(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new31(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, new32(A,B,C,D,E,F).
new30(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B.
new30(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, new31(A,B,C,D,E,F).
new29(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=E.
new29(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=E, new30(A,B,C,D,E,F).
new28(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=B.
new28(A,B,C,D,E,F) :- G=<H, G=:=F, H=:=B, new29(A,B,C,D,E,F).
new26(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=F.
new26(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=F, new28(A,B,C,D,E,F).
new25(A,B,C,D,E,F) :- G=<H, G=:=F, H=:=B, new26(A,B,C,D,E,F).
new25(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=B, I=:=J+K, J=:=E, K=:=1, 
          new21(A,B,C,D,I,F).
new24(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=F.
new24(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=F, new34(A,B,C,D,E,F).
new22(A,B,C,D,E,F) :- G=<H, G=:=F, H=:=B, new24(A,B,C,D,E,F).
new22(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=B, I=:=C, new25(A,B,C,D,E,I).
new21(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, I=:=C, new22(A,B,C,D,E,I).
new21(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B, I=:=C, new13(A,B,C,D,I,F).
new20(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=E.
new20(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=E, new38(A,B,C,D,E,F).
new18(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B.
new18(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, I=:=J+K, J=:=E, K=:=1, 
          new13(A,B,C,D,I,F).
new17(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new17(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, new18(A,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B.
new16(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, new17(A,B,C,D,E,F).
new14(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=E.
new14(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=E, new16(A,B,C,D,E,F).
new13(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, new14(A,B,C,D,E,F).
new13(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B, new6(A,B,C,D,E,F).
new11(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=B, new20(A,B,C,D,E,F).
new11(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=B, I=:=C, new21(A,B,C,D,I,F).
new9(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B.
new9(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, I=:=D, J=:=K-L, K=:=D, L=:=1, 
          new3(A,B,I,J,E,F).
new8(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new8(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, new9(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=B.
new7(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=B, new8(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=D.
new6(A,B,C,D,E,F) :- G=<H, G=:=1, H=:=D, new7(A,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, I=:=C, new11(A,B,C,D,I,F).
new5(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, I=:=C, new11(A,B,C,D,I,F).
new5(A,B,C,D,E,F) :- G=:=H, G=:=A, H=:=0, I=:=C, new13(A,B,C,D,I,F).
new4(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=B, new5(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=B, new6(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=1, I=:=J+K, J=:=D, K=:=1, 
          new4(A,B,I,D,E,F).
new2(A) :- B=:=C, new3(A,C,D,B,E,F).
new1 :- new2(A).
inv1 :- \+new1.
