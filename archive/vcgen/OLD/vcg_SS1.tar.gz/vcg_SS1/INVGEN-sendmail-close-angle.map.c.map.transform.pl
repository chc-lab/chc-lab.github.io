new18(A,B,C,D,E,F) :- G>=H, G=:=B, H=:=C.
new18(A,B,C,D,E,F) :- G+1=<H, G=:=B, H=:=C, new6(A,B,C,D,E,F).
new17(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=B.
new17(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=B, new18(A,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G>=H, G=:=E, H=:=D.
new16(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=D, I=:=J+K, J=:=E, K=:=1, L=:=M+N, 
          M=:=B, N=:=1, new17(A,L,C,D,I,F).
new14(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=E.
new14(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=E, new16(A,B,C,D,E,F).
new12(A,B,C,D,E,F) :- G>=H, G=:=E, H=:=D.
new11(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=E.
new11(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=E, new12(A,B,C,D,E,F).
new10(A,B,C,D,E,F) :- G>=H, G=:=E, H=:=D.
new10(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=D, I=:=J+K, J=:=E, K=:=1, 
          new11(A,B,C,D,I,F).
new9(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=E.
new9(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=E, new10(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G=:=H, G=:=E, H=:=F, new9(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=F, new14(A,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G+1=<H, G=:=E, H=:=F, new14(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, new7(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, new7(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G=:=H, G=:=A, H=:=0, new9(A,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=C, I=:=0, J=:=0, K=:=L-M, L=:=D, M=:=2, 
          new6(A,J,C,D,I,K).
new4(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, new5(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=1, new4(A,B,C,D,E,F).
new2 :- new3(A,B,C,D,E,F).
new1 :- new2.
inv1 :- \+new1.
