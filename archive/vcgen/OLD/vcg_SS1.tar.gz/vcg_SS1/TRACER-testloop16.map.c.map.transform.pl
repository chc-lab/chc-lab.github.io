new5(A,B,C) :- D>=E+1, D=:=C, E=:=2.
new4(A,B,C) :- D=:=E, D=:=C, E=:=1, F=:=2, G=:=H+I, H=:=B, I=:=1, new3(A,G,F).
new4(A,B,C) :- D>=E+1, D=:=C, E=:=1, F=:=1, G=:=H+I, H=:=B, I=:=1, new3(A,G,F).
new4(A,B,C) :- D+1=<E, D=:=C, E=:=1, F=:=1, G=:=H+I, H=:=B, I=:=1, new3(A,G,F).
new3(A,B,C) :- D+1=<E, D=:=B, E=:=A, new4(A,B,C).
new3(A,B,C) :- D>=E, D=:=B, E=:=A, new5(A,B,C).
new2 :- A=:=1, B=:=0, new3(C,B,A).
new1 :- new2.
inv1 :- \+new1.
