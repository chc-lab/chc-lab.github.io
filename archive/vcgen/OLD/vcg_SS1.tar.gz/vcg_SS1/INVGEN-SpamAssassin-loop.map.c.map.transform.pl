new29(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=D.
new29(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=D, I=:=J+K, J=:=D, K=:=1, 
          new4(A,B,C,I,E,F).
new28(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=E.
new28(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=E, new29(A,B,C,D,E,F).
new27(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=D.
new27(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=D, I=:=J+K, J=:=D, K=:=1, L=:=M+N, 
          M=:=C, N=:=1, new28(A,B,L,I,E,F).
new26(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=E.
new26(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=E, new27(A,B,C,D,E,F).
new25(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=C.
new25(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=C, new26(A,B,C,D,E,F).
new24(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=B.
new24(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=B, new25(A,B,C,D,E,F).
new23(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=D.
new23(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=D, I=:=J+K, J=:=D, K=:=1, L=:=M+N, 
          M=:=C, N=:=1, new24(A,B,L,I,E,F).
new22(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=E.
new22(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=E, new23(A,B,C,D,E,F).
new21(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=C.
new21(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=C, new22(A,B,C,D,E,F).
new20(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=B.
new20(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=B, new21(A,B,C,D,E,F).
new17(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=0, new11(A,B,C,D,E,F).
new17(A,B,C,D,E,F) :- G+1=<H, G=:=A, H=:=0, new11(A,B,C,D,E,F).
new17(A,B,C,D,E,F) :- G=:=H, G=:=A, H=:=0, new20(A,B,C,D,E,F).
new16(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=C.
new16(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=C, new17(A,B,C,D,E,F).
new14(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=D.
new14(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=D, I=:=J+K, J=:=D, K=:=1, L=:=M+N, 
          M=:=C, N=:=1, new4(A,B,L,I,E,F).
new13(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=E.
new13(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=E, new14(A,B,C,D,E,F).
new12(A,B,C,D,E,F) :- G>=H+1, G=:=0, H=:=C.
new12(A,B,C,D,E,F) :- G=<H, G=:=0, H=:=C, new13(A,B,C,D,E,F).
new11(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=B.
new11(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=B, new12(A,B,C,D,E,F).
new10(A,B,C,D,E,F) :- G>=H, G=:=I+J, I=:=C, J=:=1, H=:=B.
new10(A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=C, J=:=1, H=:=B, new16(A,B,C,D,E,F).
new8(A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=C, J=:=1, H=:=B, new10(A,B,C,D,E,F).
new8(A,B,C,D,E,F) :- G>=H, G=:=I+J, I=:=C, J=:=1, H=:=B, new11(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- new3(A,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G+1=<H, G=:=D, H=:=F, new8(A,B,C,D,E,F).
new5(A,B,C,D,E,F) :- G>=H, G=:=D, H=:=F, new6(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=B, new5(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=B, new6(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=B, I=:=0, new4(A,B,C,I,E,F).
new2(A) :- B=:=C-D, C=:=E, D=:=4, F=:=0, new3(A,G,F,H,E,B).
new1 :- new2(A).
inv1 :- \+new1.
