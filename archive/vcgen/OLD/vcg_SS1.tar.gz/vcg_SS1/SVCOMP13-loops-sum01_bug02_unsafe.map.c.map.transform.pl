new7(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=0.
new7(A,B,C,D,E) :- F+1=<G, F=:=E, G=:=0.
new6(A,B,C,D,E) :- F>=G+1, F=:=E, G=:=H*I, H=:=C, I=:=2, new7(A,B,C,D,E).
new6(A,B,C,D,E) :- F+1=<G, F=:=E, G=:=H*I, H=:=C, I=:=2, new7(A,B,C,D,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=B, H=:=I+J, I=:=E, J=:=2, K=:=L-M, L=:=B, 
          M=:=1, N=:=O+P, O=:=A, P=:=1, new4(N,K,C,D,H).
new5(A,B,C,D,E) :- F>=G, F=:=A, G=:=B, H=:=I-J, I=:=B, J=:=1, K=:=L+M, L=:=A, 
          M=:=1, new4(K,H,C,D,E).
new4(A,B,C,D,E) :- F=<G, F=:=A, G=:=C, new5(A,B,C,D,E).
new4(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=C, new6(A,B,C,D,E).
new3(A,B,C,D,E) :- F=:=G, G>=0, H=:=F, I=:=0, J=:=1, new4(J,B,H,F,I).
new2 :- A=:=10, new3(B,A,C,D,E).
new1 :- new2.
inv1 :- \+new1.
