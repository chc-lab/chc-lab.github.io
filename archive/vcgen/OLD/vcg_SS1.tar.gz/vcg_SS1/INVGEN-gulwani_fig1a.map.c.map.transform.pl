new5(A,B,C) :- D=<E, D=:=C, E=:=0.
new3(A,B,C) :- D+1=<E, D=:=B, E=:=0, F=:=G+H, G=:=B, H=:=C, I=:=J+K, J=:=C, 
          K=:=1, new3(A,F,I).
new3(A,B,C) :- D>=E, D=:=B, E=:=0, new5(A,B,C).
new2(A) :- B=:= -50, new3(A,B,C).
new1 :- new2(A).
inv1 :- \+new1.
