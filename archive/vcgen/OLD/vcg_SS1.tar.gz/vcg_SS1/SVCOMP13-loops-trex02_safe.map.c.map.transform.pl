new10(A,B,C) :- D=:=E-F, E=:=A, F=:=1, new4(D,B,C).
new8(A,B,C) :- D=:=E-F, E=:=A, F=:=1, new4(D,B,C).
new7(A,B,C) :- D>=E+1, D=:=B, E=:=0, new8(A,B,C).
new7(A,B,C) :- D+1=<E, D=:=B, E=:=0, new8(A,B,C).
new7(A,B,C) :- D=:=E, D=:=B, E=:=0, new10(A,B,C).
new6(A,B,C) :- D>=E+1, D=:=A, E=:=0.
new5(A,B,C) :- D=:=E, new7(A,D,E).
new4(A,B,C) :- D>=E+1, D=:=A, E=:=0, new5(A,B,C).
new4(A,B,C) :- D=<E, D=:=A, E=:=0, new6(A,B,C).
new3(A,B,C) :- new4(D,B,C).
new2(A) :- new3(A,B,C).
new1 :- new2(A).
inv1 :- \+new1.
