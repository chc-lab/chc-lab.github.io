new15(A,B,C,D,E,F,G,H,I) :- J=:=K-L, K=:=E, L=:=1, new11(A,B,M,D,J,F,G,H,I).
new14(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=F, K=:=0, L=:=M-N, M=:=B, N=:=A, 
          new15(A,L,C,D,E,F,G,H,I).
new14(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=F, K=:=0, L=:=M-N, M=:=B, N=:=A, 
          new15(A,L,C,D,E,F,G,H,I).
new14(A,B,C,D,E,F,G,H,I) :- J=:=K, J=:=F, K=:=0, L=:=M-N, M=:=C, N=:=A, 
          new11(A,B,L,D,E,F,G,H,I).
new13(A,B,C,D,E,F,G,H,I) :- J=:=K, new14(A,B,C,D,E,J,K,H,I).
new12(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, K=:=0, new13(A,B,C,D,E,F,G,H,I).
new11(A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=B, K=:=0, new12(A,B,C,D,E,F,G,H,I).
new10(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=E, K=:=2.
new10(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=E, K=:=2, new11(A,B,C,D,E,F,G,H,I).
new8(A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=E, K=:=D, L=:=M*N, M=:=2, N=:=E, 
          new8(A,B,C,D,L,F,G,H,I).
new8(A,B,C,D,E,F,G,H,I) :- J>=K, J=:=E, K=:=D, new10(A,B,C,D,E,F,G,H,I).
new7(A,B) :- C=:=2, D=:=1, new8(C,E,F,G,D,H,I,A,B).
new5(A,B) :- C=:=1, D=:=1, new8(C,E,F,G,D,H,I,A,B).
new4(A,B) :- C>=D+1, C=:=A, D=:=0, new5(A,B).
new4(A,B) :- C+1=<D, C=:=A, D=:=0, new5(A,B).
new4(A,B) :- C=:=D, C=:=A, D=:=0, new7(A,B).
new3(A,B) :- C=:=D, new4(C,D).
new2 :- new3(A,B).
new1 :- new2.
inv1 :- \+new1.
