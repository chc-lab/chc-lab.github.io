new11(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=0.
new10(A,B,C,D,E) :- F+1=<G, F=:=A, G=:=0.
new10(A,B,C,D,E) :- F>=G, F=:=A, G=:=0, new11(A,B,C,D,E).
new8(A,B,C,D,E) :- F>=G+1, F=:=C, G=:=6, new10(A,B,C,D,E).
new6(A,B,C,D,E) :- F>=G+1, F=:=B, G=:=0, H=:=I+J, I=:=C, J=:=4, new8(A,B,H,D,E).
new6(A,B,C,D,E) :- F=<G, F=:=B, G=:=0, H=:=3, new8(A,H,C,D,E).
new4(A,B,C,D,E) :- F>=G+1, F=:=D, G=:=0, H=:=3, new6(A,B,C,D,H).
new4(A,B,C,D,E) :- F=<G, F=:=D, G=:=0, H=:=2, new6(A,B,C,D,H).
new3(A,B,C,D,E) :- F>=G+1, F=:=A, G=:=0, H=:=I+J, I=:=C, J=:=2, new4(A,B,H,D,E).
new3(A,B,C,D,E) :- F=<G, F=:=A, G=:=0, H=:=3, new4(H,B,C,D,E).
new2 :- A=:=0, new3(B,C,A,D,E).
new1 :- new2.
inv1 :- \+new1.
