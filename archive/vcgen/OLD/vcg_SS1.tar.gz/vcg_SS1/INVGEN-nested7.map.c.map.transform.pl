new21(A,B,C,D,E,F,G) :- H+1=<I, H=:=E, I=:=F, J=:=K+L, K=:=C, L=:=1, M=:=N+O, 
          N=:=E, O=:=1, new21(A,B,J,D,M,F,G).
new21(A,B,C,D,E,F,G) :- H>=I, H=:=E, I=:=F, J=:=K+L, K=:=B, L=:=1, 
          new5(A,J,C,D,E,F,G).
new17(A,B,C,D,E,F,G) :- H+1=<I, H=:=C, I=:=J+K, J=:=F, K=:=D, L=:=M+N, M=:=C, 
          N=:=1, new17(A,B,L,D,E,F,G).
new17(A,B,C,D,E,F,G) :- H>=I, H=:=C, I=:=J+K, J=:=F, K=:=D, L=:=M+N, M=:=E, 
          N=:=1, new16(A,B,C,D,L,F,G).
new16(A,B,C,D,E,F,G) :- H+1=<I, H=:=E, I=:=G, J=:=0, new17(A,B,J,D,E,F,G).
new16(A,B,C,D,E,F,G) :- H>=I, H=:=E, I=:=G, J=:=K+L, K=:=B, L=:=1, 
          new4(A,J,C,D,E,F,G).
new11(A,B,C,D,E,F,G) :- H+1=<I, H=:=E, I=:=F, J=:=K-L, K=:=C, L=:=1, M=:=N+O, 
          N=:=E, O=:=1, new11(A,B,J,D,M,F,G).
new11(A,B,C,D,E,F,G) :- H>=I, H=:=E, I=:=F, J=:=K+L, K=:=B, L=:=1, 
          new4(A,J,C,D,E,F,G).
new10(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=F, J=:=0, new11(A,B,C,D,J,F,G).
new10(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=F, J=:=K+L, K=:=B, L=:=1, 
          new4(A,J,C,D,E,F,G).
new9(A,B,C,D,E,F,G) :- H+1=<I, H=:=E, I=:=G, J=:=K+L, K=:=E, L=:=1, 
          new9(A,B,C,D,J,F,G).
new9(A,B,C,D,E,F,G) :- H>=I, H=:=E, I=:=G, J=:=0, new16(A,B,C,D,J,F,G).
new8(A,B,C,D,E,F,G) :- H>=I+1, H=:=D, I=:=5, J=:=0, new9(A,B,C,D,J,F,G).
new8(A,B,C,D,E,F,G) :- H=<I, H=:=D, I=:=5, new10(A,B,C,D,E,F,G).
new7(A,B,C,D,E,F,G) :- H>=I+1, H=:=A, I=:=0, J=:=0, new21(A,B,C,D,J,F,G).
new7(A,B,C,D,E,F,G) :- H+1=<I, H=:=A, I=:=0, J=:=0, new21(A,B,C,D,J,F,G).
new7(A,B,C,D,E,F,G) :- H=:=I, H=:=A, I=:=0, J=:=K+L, K=:=B, L=:=1, 
          new5(A,J,C,D,E,F,G).
new6(A,B,C,D,E,F,G) :- H>=I+1, H=:=C, I=:=J+K, J=:=F, K=:=D.
new5(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=G, J=:=D, new7(A,B,J,D,E,F,G).
new5(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=G, new8(A,B,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H+1=<I, H=:=B, I=:=F, J=:=0, new5(A,J,C,D,E,F,G).
new4(A,B,C,D,E,F,G) :- H>=I, H=:=B, I=:=F, new6(A,B,C,D,E,F,G).
new3(A,B,C,D,E,F,G) :- H=<I, H=:=C, I=:=J+K, J=:=F, K=:=D, L=:=0, 
          new4(A,L,C,D,E,F,G).
new2(A) :- new3(A,B,C,D,E,F,G).
new1 :- new2(A).
inv1 :- \+new1.
