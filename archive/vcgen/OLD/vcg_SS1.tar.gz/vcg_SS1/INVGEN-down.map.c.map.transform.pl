new6(A,B,C,D) :- E=<F, E=:=B, F=:=0.
new6(A,B,C,D) :- E>=F+1, E=:=B, F=:=0, G=:=H-I, H=:=D, I=:=1, J=:=K-L, K=:=B, 
          L=:=1, new5(A,J,C,G).
new5(A,B,C,D) :- E>=F+1, E=:=D, F=:=0, new6(A,B,C,D).
new3(A,B,C,D) :- E+1=<F, E=:=C, F=:=A, G=:=H+I, H=:=C, I=:=1, J=:=K+L, K=:=B, 
          L=:=1, new3(A,J,G,D).
new3(A,B,C,D) :- E>=F, E=:=C, F=:=A, G=:=A, new5(A,B,C,G).
new2 :- A=:=0, B=:=0, new3(C,A,B,D).
new1 :- new2.
inv1 :- \+new1.
