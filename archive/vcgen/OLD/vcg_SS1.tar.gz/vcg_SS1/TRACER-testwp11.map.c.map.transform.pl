new10(A,B,C,D,E,F) :- G>=H+1, G=:=B, H=:=5.
new8(A,B,C,D,E,F) :- G>=H+1, G=:=A, H=:=10.
new8(A,B,C,D,E,F) :- G=<H, G=:=A, H=:=10, new10(A,B,C,D,E,F).
new6(A,B,C,D,E,F) :- G>=H+1, G=:=D, H=:=0, I=:=5, new8(A,B,I,D,E,F).
new6(A,B,C,D,E,F) :- G=<H, G=:=D, H=:=0, I=:=6, new8(A,B,I,D,E,F).
new4(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=0, I=:=4, new6(I,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G=<H, G=:=F, H=:=0, I=:=5, new6(I,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G>=H+1, G=:=E, H=:=0, I=:=2, new4(A,I,C,D,E,F).
new3(A,B,C,D,E,F) :- G=<H, G=:=E, H=:=0, I=:=3, new4(A,I,C,D,E,F).
new2 :- new3(A,B,C,D,E,F).
new1 :- new2.
inv1 :- \+new1.
