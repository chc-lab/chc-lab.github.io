new6(A,B) :- C=:=D, C=:=A, D=:=10.
new4(A,B) :- C+1=<D, C=:=B, D=:=10, new3(A,B).
new4(A,B) :- C>=D, C=:=B, D=:=10, new6(A,B).
new3(A,B) :- C=:=D+E, D=:=A, E=:=1, F=:=C, new4(C,F).
new2(A) :- new3(A,B).
new1 :- A=:=0, new2(A).
inv1 :- \+new1.
