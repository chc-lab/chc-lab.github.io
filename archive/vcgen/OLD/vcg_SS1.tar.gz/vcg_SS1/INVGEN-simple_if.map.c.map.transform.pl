new5(A,B,C) :- D=<E, D=:=C, E=:=0.
new4(A,B,C) :- D>=E+1, D=:=B, E=:=0, F=:=G*H, G=:=2, H=:=C, new3(A,B,F).
new4(A,B,C) :- D=<E, D=:=B, E=:=0, F=:=G*H, G=:=3, H=:=C, new3(A,B,F).
new3(A,B,C) :- D+1=<E, D=:=C, E=:=A, new4(A,B,C).
new3(A,B,C) :- D>=E, D=:=C, E=:=A, new5(A,B,C).
new2 :- A=:=1, new3(B,C,A).
new1 :- new2.
inv1 :- \+new1.
