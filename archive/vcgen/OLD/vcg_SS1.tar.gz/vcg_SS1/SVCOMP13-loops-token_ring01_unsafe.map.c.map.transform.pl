new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=M, E1=:=5.
new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=5, F1=:=G1+H1, G1=:=N, H1=:=1, 
          new231(A,B,C,D,E,F,G,H,I,J,K,L,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=5, F1=:=G1+H1, G1=:=N, H1=:=1, 
          new231(A,B,C,D,E,F,G,H,I,J,K,L,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new246(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=N, G1=:=0, H1=:=0, I1=:=2, J1=:=1, K1=:=2, 
          new177(J1,B,K1,H1,E,F,G,H,I,I1,K,L,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new246(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=N, G1=:=0, H1=:=0, I1=:=2, J1=:=1, K1=:=2, 
          new177(J1,B,K1,H1,E,F,G,H,I,I1,K,L,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new246(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=N, G1=:=0, H1=:=2, I1=:=1, J1=:=2, 
          new177(I1,B,J1,D,E,F,G,H,I,H1,K,L,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=J, H1=:=1, I1=:=1, J1=:=I1, 
          new246(A,B,C,D,E,F,G,H,I,J,K,L,N,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=J, H1=:=1, I1=:=0, J1=:=I1, 
          new246(A,B,C,D,E,F,G,H,I,J,K,L,N,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=J, H1=:=1, I1=:=0, J1=:=I1, 
          new246(A,B,C,D,E,F,G,H,I,J,K,L,N,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=B, H1=:=1, 
          new245(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, H1=:=1, I1=:=0, J1=:=I1, 
          new246(A,B,C,D,E,F,G,H,I,J,K,L,N,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new244(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=B, H1=:=1, I1=:=0, J1=:=I1, 
          new246(A,B,C,D,E,F,G,H,I,J,K,L,N,J1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new241(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          new244(A,B,C,D,E,F,G,H,I,J,K,L,F1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new239(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=M, G1=:=0, H1=:=0, 
          new241(A,B,H1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new239(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=M, G1=:=0, H1=:=0, 
          new241(A,B,H1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new239(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=M, G1=:=0, 
          new241(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new238(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=I, H1=:=1, I1=:=1, J1=:=I1, 
          new239(A,B,C,D,E,F,G,H,I,J,K,L,J1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new238(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=I, H1=:=1, I1=:=0, J1=:=I1, 
          new239(A,B,C,D,E,F,G,H,I,J,K,L,J1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new238(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=I, H1=:=1, I1=:=0, J1=:=I1, 
          new239(A,B,C,D,E,F,G,H,I,J,K,L,J1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1=:=H1, G1=:=A, H1=:=1, 
          new238(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=A, H1=:=1, I1=:=0, J1=:=I1, 
          new239(A,B,C,D,E,F,G,H,I,J,K,L,J1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new237(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=A, H1=:=1, I1=:=0, J1=:=I1, 
          new239(A,B,C,D,E,F,G,H,I,J,K,L,J1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
new236(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          new237(A,B,C,D,E,F,G,H,I,J,K,L,F1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          new236(A,B,C,D,E,F,G,H,I,J,K,L,D1,E1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new234(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          new235(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, F1=:=1, 
          new234(A,B,C,D,E,F,G,H,I,F1,E1,D1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new231(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=N, E1=:=O, 
          new232(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new231(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1>=E1, 
          D1=:=N, E1=:=O, 
          new177(A,B,C,D,E,F,G,H,I,J,K,L,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1>=E1, 
          D1=:=M, E1=:=5, 
          new257(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=M, E1=:=5, F1=:=G1+H1, G1=:=N, H1=:=1, 
          new231(A,B,C,D,E,F,G,H,I,J,K,L,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- D1=<E1, 
          D1=:=M, E1=:=5, 
          new230(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=M, E1=:=5, F1=:=G1+H1, G1=:=N, H1=:=1, 
          new231(A,B,C,D,E,F,G,H,I,J,K,L,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=K, E1=:=F1+G1, F1=:=L, G1=:=1.
new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=K, E1=:=F1+G1, F1=:=L, G1=:=1.
new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=K, E1=:=F1+G1, F1=:=L, G1=:=1, 
          new229(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new224(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=A, E1=:=1, 
          new226(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new224(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=A, E1=:=1, F1=:=0, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new224(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=A, E1=:=1, F1=:=0, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new223(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, 
          new231(A,B,C,D,E,F,G,H,I,J,K,L,M,N,D1,E1,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1=:=E1, D1=:=A, E1=:=0, F1=:=0, 
          new223(A,B,C,D,E,F,G,H,I,J,K,L,M,F1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1>=E1+1, D1=:=A, E1=:=0, 
          new224(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new222(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1) :- 
          D1+1=<E1, D1=:=A, E1=:=0, 
          new224(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1).
new219(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new222(A,B,C,D,E,F,G,H,I,J,K,L,Z,A1,B1,C1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=Q, 
          A1=:=0, B1=:=1, 
          new219(A,B,B1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=Q, 
          A1=:=0, B1=:=1, 
          new219(A,B,B1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=Q, 
          A1=:=0, new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=M, D1=:=N, E1=:=1, F1=:=2, G1=:=H1+I1, H1=:=Q, I1=:=1, 
          new58(A,E1,C,F1,E,F,G,H,I,J,K,L,P,G1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new206(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1, 
          C1=:=M, D1=:=N, E1=:=F1+G1, F1=:=Q, G1=:=1, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,P,E1,R,S,T,U,V,W,X,Y,Z,A1,B1).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=N, F1=:=0, G1=:=0, H1=:=2, I1=:=J1+K1, J1=:=O, K1=:=1, 
          new206(A,B,C,G1,E,F,G,H,H1,J,K,L,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=N, F1=:=0, G1=:=0, H1=:=2, I1=:=J1+K1, J1=:=O, K1=:=1, 
          new206(A,B,C,G1,E,F,G,H,H1,J,K,L,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new204(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=N, F1=:=0, G1=:=2, H1=:=I1+J1, I1=:=O, J1=:=1, 
          new206(A,B,C,D,E,F,G,H,G1,J,K,L,H1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=J, G1=:=1, H1=:=1, I1=:=H1, 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,N,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=J, G1=:=1, H1=:=0, I1=:=H1, 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,N,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=J, G1=:=1, H1=:=0, I1=:=H1, 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,N,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=B, G1=:=1, 
          new203(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=B, G1=:=1, H1=:=0, I1=:=H1, 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,N,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new202(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=B, G1=:=1, H1=:=0, I1=:=H1, 
          new204(A,B,C,D,E,F,G,H,I,J,K,L,N,I1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          new202(A,B,C,D,E,F,G,H,I,J,K,L,E1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=M, F1=:=0, G1=:=0, 
          new199(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1+1=<F1, E1=:=M, F1=:=0, G1=:=0, 
          new199(A,B,G1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new197(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=:=F1, E1=:=M, F1=:=0, 
          new199(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=I, G1=:=1, H1=:=1, I1=:=H1, 
          new197(A,B,C,D,E,F,G,H,I,J,K,L,I1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=I, G1=:=1, H1=:=0, I1=:=H1, 
          new197(A,B,C,D,E,F,G,H,I,J,K,L,I1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=I, G1=:=1, H1=:=0, I1=:=H1, 
          new197(A,B,C,D,E,F,G,H,I,J,K,L,I1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new195(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1=:=G1, F1=:=A, G1=:=1, 
          new196(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new195(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=A, G1=:=1, H1=:=0, I1=:=H1, 
          new197(A,B,C,D,E,F,G,H,I,J,K,L,I1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new195(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=A, G1=:=1, H1=:=0, I1=:=H1, 
          new197(A,B,C,D,E,F,G,H,I,J,K,L,I1,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
new194(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          new195(A,B,C,D,E,F,G,H,I,J,K,L,E1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1).
new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new194(A,B,C,D,E,F,G,H,I,J,K,L,C1,D1,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new190(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- 
          new193(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=B, D1=:=1, E1=:=F1+G1, F1=:=K, G1=:=1, H1=:=1, 
          new190(A,B,C,D,E,F,G,H,H1,J,E1,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=B, D1=:=1, E1=:=0, 
          new187(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=B, D1=:=1, E1=:=0, 
          new187(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new187(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          new206(A,B,C,D,E,F,G,H,I,J,K,L,M,C1,D1,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1=:=D1, 
          C1=:=B, D1=:=0, E1=:=0, 
          new187(A,B,C,D,E,F,G,H,I,J,K,L,E1,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1>=D1+1, 
          C1=:=B, D1=:=0, 
          new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new186(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1) :- C1+1=<D1, 
          C1=:=B, D1=:=0, 
          new188(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1).
new183(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new186(A,B,C,D,E,F,G,H,I,J,K,L,Z,A1,B1,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=R, 
          A1=:=0, B1=:=1, 
          new183(A,B,C,B1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=R, 
          A1=:=0, B1=:=1, 
          new183(A,B,C,B1,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=R, 
          A1=:=0, B1=:=C1+D1, C1=:=N, D1=:=1, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,B1,O,P,Q,R,S,T,U,V,W,X,Y).
new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new182(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,Z,S,T,U,V,W,X,Y).
new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=D, 
          A1=:=0, new179(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=D, 
          A1=:=0, B1=:=C1+D1, C1=:=N, D1=:=1, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,B1,O,P,Q,R,S,T,U,V,W,X,Y).
new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=D, 
          A1=:=0, B1=:=C1+D1, C1=:=N, D1=:=1, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,B1,O,P,Q,R,S,T,U,V,W,X,Y).
new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new218(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Z,R,S,T,U,V,W,X,Y).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=C, 
          A1=:=0, new176(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=C, 
          A1=:=0, new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=C, 
          A1=:=0, new177(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=D, 
          B1=:=0, C1=:=1, D1=:=C1, 
          new167(A,B,C,D,E,F,G,H,I,J,K,L,D1,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=D, B1=:=0, C1=:=0, D1=:=C1, 
          new167(A,B,C,D,E,F,G,H,I,J,K,L,D1,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=D, B1=:=0, C1=:=0, D1=:=C1, 
          new167(A,B,C,D,E,F,G,H,I,J,K,L,D1,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, Z=:=M, 
          A1=:=0, new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=M, 
          A1=:=0, new173(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new167(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, Z=:=M, 
          A1=:=0, B1=:=2, new60(A,B,C,D,E,F,G,H,I,J,K,L,B1,T,U,V,W,X,Y).
new166(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1=:=B1, A1=:=C, 
          B1=:=0, C1=:=1, D1=:=C1, 
          new167(A,B,C,D,E,F,G,H,I,J,K,L,D1,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new166(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1>=B1+1, 
          A1=:=C, B1=:=0, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new166(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z) :- A1+1=<B1, 
          A1=:=C, B1=:=0, 
          new168(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z).
new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=J, U=:=1, V=:=2, 
          new111(A,B,C,D,E,F,G,H,I,V,K,L,M,N,O,P,Q,R,S).
new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=J, U=:=1, 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=J, U=:=1, 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=1, V=:=2, 
          new148(A,B,C,D,E,F,G,H,V,J,K,L,M,N,O,P,Q,R,S).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=1, 
          new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=1, 
          new148(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=1, V=:=2, 
          new145(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=1, 
          new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=1, 
          new145(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=1, V=:=2, 
          new142(A,B,C,D,E,F,V,H,I,J,K,L,M,N,O,P,Q,R,S).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=1, 
          new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=1, 
          new142(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new138(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new141(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=0, 
          X=:=0, new138(A,B,C,X,E,F,G,H,I,J,K,L,O,P,Q,R,S,T,U).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=0, 
          X=:=0, new138(A,B,C,X,E,F,G,H,I,J,K,L,O,P,Q,R,S,T,U).
new136(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=0, 
          new138(A,B,C,D,E,F,G,H,I,J,K,L,O,P,Q,R,S,T,U).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=J, X=:=1, 
          Y=:=1, Z=:=Y, new136(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new136(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new136(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          new135(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new136(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new134(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new136(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new134(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=0, 
          X=:=0, new131(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=0, 
          X=:=0, new131(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new129(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=0, 
          new131(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=I, X=:=1, 
          Y=:=1, Z=:=Y, new129(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new129(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new129(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=1, 
          new128(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new129(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new127(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new129(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new126(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new127(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new125(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new126(A,B,C,D,E,F,G,H,I,J,K,L,T,U,M,N,O,P,Q,R,S).
new121(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=O, U=:=0, V=:=W+X, 
          W=:=P, X=:=1, new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,V,Q,R,S).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=D, X=:=0, 
          Y=:=1, Z=:=Y, new115(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=D, X=:=0, 
          Y=:=0, Z=:=Y, new115(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=D, X=:=0, 
          Y=:=0, Z=:=Y, new115(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=0, 
          X=:=0, Y=:=X, new121(A,B,C,D,E,F,G,H,I,J,K,L,O,P,Y,R,S,T,U).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=0, 
          X=:=0, Y=:=X, new121(A,B,C,D,E,F,G,H,I,J,K,L,O,P,Y,R,S,T,U).
new115(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=0, 
          X=:=1, Y=:=X, new121(A,B,C,D,E,F,G,H,I,J,K,L,O,P,Y,R,S,T,U).
new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=C, X=:=0, 
          Y=:=1, Z=:=Y, new115(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=C, X=:=0, 
          new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new114(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=C, X=:=0, 
          new116(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new113(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new114(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new113(A,B,C,D,E,F,G,H,I,J,K,L,T,U,M,N,O,P,Q,R,S).
new110(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=1, 
          new125(A,B,C,D,E,F,T,H,I,J,K,L,M,N,O,P,Q,R,S).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=D, V=:=0, W=:=1, 
          X=:=W, new104(A,B,C,D,E,F,G,H,I,J,K,L,N,X,P,Q,R,S,T).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=D, V=:=0, W=:=0, 
          X=:=W, new104(A,B,C,D,E,F,G,H,I,J,K,L,N,X,P,Q,R,S,T).
new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=D, V=:=0, W=:=0, 
          X=:=W, new104(A,B,C,D,E,F,G,H,I,J,K,L,N,X,P,Q,R,S,T).
new104(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=N, U=:=0, V=:=4, 
          new110(A,B,C,D,E,F,G,H,I,J,K,L,V,N,O,P,Q,R,S).
new104(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=N, U=:=0, 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new104(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=N, U=:=0, 
          new111(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=:=V, U=:=C, V=:=0, W=:=1, 
          X=:=W, new104(A,B,C,D,E,F,G,H,I,J,K,L,N,X,P,Q,R,S,T).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=C, V=:=0, 
          new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new103(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U+1=<V, U=:=C, V=:=0, 
          new105(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T).
new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new103(A,B,C,D,E,F,G,H,I,J,K,L,T,M,N,O,P,Q,R,S).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=J, U=:=1, V=:=2, 
          new100(A,B,C,D,E,F,G,H,I,V,K,L,M,N,O,P,Q,R,S).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=J, U=:=1, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=J, U=:=1, 
          new100(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=1, V=:=2, 
          new97(A,B,C,D,E,F,G,H,V,J,K,L,M,N,O,P,Q,R,S).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=1, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=1, 
          new97(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=1, V=:=2, 
          new94(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=1, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=1, 
          new94(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=1, V=:=2, 
          new91(A,B,C,D,E,F,V,H,I,J,K,L,M,N,O,P,Q,R,S).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=1, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=1, 
          new91(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new87(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new90(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=0, 
          X=:=0, new87(A,B,C,X,E,F,G,H,I,J,K,L,O,P,Q,R,S,T,U).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=0, 
          X=:=0, new87(A,B,C,X,E,F,G,H,I,J,K,L,O,P,Q,R,S,T,U).
new85(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=0, 
          new87(A,B,C,D,E,F,G,H,I,J,K,L,O,P,Q,R,S,T,U).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=J, X=:=1, 
          Y=:=1, Z=:=Y, new85(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new85(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new85(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          new84(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new85(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new83(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new85(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new83(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=0, 
          X=:=0, new80(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=0, 
          X=:=0, new80(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new78(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=0, 
          new80(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=I, X=:=1, 
          Y=:=1, Z=:=Y, new78(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new78(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new78(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=1, 
          new77(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new78(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new76(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new78(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new75(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new76(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new75(A,B,C,D,E,F,G,H,I,J,K,L,T,U,M,N,O,P,Q,R,S).
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=J, U=:=0, V=:=1, 
          new72(A,B,C,D,E,F,G,H,I,V,K,L,M,N,O,P,Q,R,S).
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=J, U=:=0, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=J, U=:=0, 
          new72(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=0, V=:=1, 
          new69(A,B,C,D,E,F,G,H,V,J,K,L,M,N,O,P,Q,R,S).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=0, 
          new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=0, 
          new69(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=0, V=:=1, 
          new66(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=0, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=0, 
          new66(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=0, V=:=1, 
          new63(A,B,C,D,E,F,V,H,I,J,K,L,M,N,O,P,Q,R,S).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=0, 
          new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=0, 
          new63(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new61(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new62(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=3, 
          new61(A,B,C,D,E,F,G,H,I,J,K,L,T,N,O,P,Q,R,S).
new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- 
          new166(A,B,C,D,E,F,G,H,I,J,K,L,Z,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z+1=<A1, Z=:=N, 
          A1=:=O, new59(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y).
new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1, Z=:=N, 
          A1=:=O, B1=:=2, new60(A,B,C,D,E,F,G,H,I,J,K,L,B1,T,U,V,W,X,Y).
new57(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=:=A1, 
          new58(A,B,C,D,E,F,G,H,I,J,K,L,M,N,Z,A1,Q,R,S,T,U,V,W,X,Y).
new56(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=0, 
          new57(A,B,C,D,E,F,G,H,I,J,K,L,U,T,V,W,X,Y,M,N,O,P,Q,R,S).
new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=P, U=:=Q, V=:=1, 
          new56(A,B,C,D,E,F,G,H,I,J,K,L,V,N,O,P,Q,R,S).
new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, 
          new55(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,T,U,S).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=J, U=:=1, V=:=2, 
          W=:=0, new52(A,B,C,D,E,F,G,H,I,V,K,L,M,N,O,W,Q,R,S).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=J, U=:=1, V=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,V,Q,R,S).
new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=J, U=:=1, V=:=0, 
          new52(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,V,Q,R,S).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=1, V=:=2, 
          new49(A,B,C,D,E,F,G,H,V,J,K,L,M,N,O,P,Q,R,S).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=1, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=1, 
          new49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=1, V=:=2, 
          new46(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=1, 
          new46(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=1, V=:=2, 
          new43(A,B,C,D,E,F,V,H,I,J,K,L,M,N,O,P,Q,R,S).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=1, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=1, 
          new43(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new39(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new42(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=N, W=:=0, 
          X=:=0, new39(A,B,C,X,E,F,G,H,I,J,K,L,O,P,Q,R,S,T,U).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=N, W=:=0, 
          X=:=0, new39(A,B,C,X,E,F,G,H,I,J,K,L,O,P,Q,R,S,T,U).
new37(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=N, W=:=0, 
          new39(A,B,C,D,E,F,G,H,I,J,K,L,O,P,Q,R,S,T,U).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=J, X=:=1, 
          Y=:=1, Z=:=Y, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=J, X=:=1, 
          Y=:=0, Z=:=Y, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=B, X=:=1, 
          new36(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new35(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=B, X=:=1, 
          Y=:=0, Z=:=Y, new37(A,B,C,D,E,F,G,H,I,J,K,L,N,Z,P,Q,R,S,T,U,V).
new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new35(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V>=W+1, V=:=M, W=:=0, 
          X=:=0, new32(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V+1=<W, V=:=M, W=:=0, 
          X=:=0, new32(A,B,X,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new30(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- V=:=W, V=:=M, W=:=0, 
          new32(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=I, X=:=1, 
          Y=:=1, Z=:=Y, new30(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new30(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=I, X=:=1, 
          Y=:=0, Z=:=Y, new30(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W=:=X, W=:=A, X=:=1, 
          new29(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W>=X+1, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new30(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new28(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V) :- W+1=<X, W=:=A, X=:=1, 
          Y=:=0, Z=:=Y, new30(A,B,C,D,E,F,G,H,I,J,K,L,Z,O,P,Q,R,S,T,U,V).
new27(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U) :- 
          new28(A,B,C,D,E,F,G,H,I,J,K,L,V,M,N,O,P,Q,R,S,T,U).
new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new27(A,B,C,D,E,F,G,H,I,J,K,L,T,U,M,N,O,P,Q,R,S).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=J, U=:=0, V=:=1, 
          new24(A,B,C,D,E,F,G,H,I,V,K,L,M,N,O,P,Q,R,S).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=J, U=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=J, U=:=0, 
          new24(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=I, U=:=0, V=:=1, 
          new21(A,B,C,D,E,F,G,H,V,J,K,L,M,N,O,P,Q,R,S).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=I, U=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=I, U=:=0, 
          new21(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=H, U=:=0, V=:=1, 
          new18(A,B,C,D,E,F,G,V,I,J,K,L,M,N,O,P,Q,R,S).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=H, U=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=H, U=:=0, 
          new18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=G, U=:=0, V=:=1, 
          new15(A,B,C,D,E,F,V,H,I,J,K,L,M,N,O,P,Q,R,S).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=G, U=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=G, U=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=F, U=:=1, V=:=0, 
          new11(A,B,C,V,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=F, U=:=1, V=:=2, 
          new11(A,B,C,V,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=F, U=:=1, V=:=2, 
          new11(A,B,C,V,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T=:=U, T=:=E, U=:=1, V=:=0, 
          new8(A,B,V,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T>=U+1, T=:=E, U=:=1, V=:=2, 
          new8(A,B,V,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- T+1=<U, T=:=E, U=:=1, V=:=2, 
          new8(A,B,V,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S) :- 
          new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=0, 
          new5(A,B,C,D,E,F,G,H,I,J,K,L,N,O,P,Q,R,S,M).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M) :- N=:=1, O=:=1, 
          new4(A,B,C,D,N,O,G,H,I,J,K,L,M).
new2(A,B,C,D,E,F,G,H,I,J,K,L) :- new3(A,B,C,D,E,F,G,H,I,J,K,L,M).
new1 :- A=:=0, B=:=0, C=:=2, D=:=2, E=:=2, F=:=2, new2(A,B,G,H,I,J,C,D,E,F,K,L).
inv1 :- \+new1.
