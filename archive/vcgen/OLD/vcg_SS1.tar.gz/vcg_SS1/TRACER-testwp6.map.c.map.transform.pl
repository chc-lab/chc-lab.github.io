new6(A,B) :- C>=D+1, C=:=A, D=:=50.
new4(A,B) :- C>=D+1, C=:=A, D=:=0, E=:=F+G, F=:=A, G=:=3, new6(E,B).
new4(A,B) :- C=<D, C=:=A, D=:=0, E=:=F+G, F=:=A, G=:=5, new6(E,B).
new3(A,B) :- C>=D+1, C=:=B, D=:=0, E=:=1, new4(E,B).
new3(A,B) :- C=<D, C=:=B, D=:=0, E=:=47, new4(E,B).
new2 :- new3(A,B).
new1 :- new2.
inv1 :- \+new1.
