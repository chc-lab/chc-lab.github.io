new11(A,B) :- C=:=D, C=:=B, D=:=2.
new7(A,B,C,D,E,F) :- G>=H+1, G=:=B, H=:=0, I=:=J+K, J=:=A, K=:=1, 
          new7(I,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G+1=<H, G=:=B, H=:=0, I=:=J+K, J=:=A, K=:=1, 
          new7(I,B,C,D,E,F).
new7(A,B,C,D,E,F) :- G=:=H, G=:=B, H=:=0, new11(E,F).
new6(A,B,C,D,E,F) :- G>=H+1, G=:=C, H=:=0, I=:=4, new7(A,B,C,I,E,F).
new6(A,B,C,D,E,F) :- G=<H, G=:=C, H=:=0, I=:=5, new7(A,B,C,I,E,F).
new4(A,B) :- C=:=0, new6(C,D,E,F,A,B).
new3(A,B) :- C>=D+1, C=:=A, D=:=0, E=:=1, new4(A,E).
new3(A,B) :- C=<D, C=:=A, D=:=0, E=:=3, new4(A,E).
new2 :- new3(A,B).
new1 :- new2.
inv1 :- \+new1.
