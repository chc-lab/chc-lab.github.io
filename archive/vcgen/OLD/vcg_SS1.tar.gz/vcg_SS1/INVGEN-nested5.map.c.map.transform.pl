new7(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=B.
new7(A,B,C,D,E) :- F>=G, F=:=D, G=:=B, H=:=I+J, I=:=D, J=:=1, new5(A,B,C,H,E).
new5(A,B,C,D,E) :- F+1=<G, F=:=D, G=:=E, new7(A,B,C,D,E).
new5(A,B,C,D,E) :- F>=G, F=:=D, G=:=E, H=:=I+J, I=:=C, J=:=1, new4(A,B,H,D,E).
new4(A,B,C,D,E) :- F+1=<G, F=:=C, G=:=E, H=:=C, new5(A,B,C,H,E).
new4(A,B,C,D,E) :- F>=G, F=:=C, G=:=E, H=:=I+J, I=:=B, J=:=1, new3(A,H,C,D,E).
new3(A,B,C,D,E) :- F+1=<G, F=:=B, G=:=E, H=:=B, new4(A,B,H,D,E).
new2(A) :- B=:=0, new3(A,B,C,D,E).
new1 :- new2(A).
inv1 :- \+new1.
