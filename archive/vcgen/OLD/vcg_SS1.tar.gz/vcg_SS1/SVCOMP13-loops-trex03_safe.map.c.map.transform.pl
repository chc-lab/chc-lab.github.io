new23(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, 
          new8(A,B,C,D,E,F,G,H,I,J,K,P,M,N,Q).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=L, Q=:=0, R=:=S-T, S=:=C, 
          C>=0, T=:=H, H>=0, new17(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=L, Q=:=0, R=:=S-T, S=:=C, 
          C>=0, T=:=H, H>=0, new17(A,B,R,D,E,F,G,H,I,J,K,L,M,N,O).
new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=L, Q=:=0, R=:=S-T, S=:=E, 
          E>=0, T=:=I, I>=0, new17(A,B,C,D,R,F,G,H,I,J,K,L,M,N,O).
new17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, 
          new23(A,B,C,D,E,F,G,H,I,P,K,L,M,Q,O).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=J, Q=:=0, R=:=S-T, S=:=A, 
          A>=0, T=:=G, G>=0, new17(R,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P+1=<Q, P=:=J, Q=:=0, R=:=S-T, S=:=A, 
          A>=0, T=:=G, G>=0, new17(R,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, P=:=J, Q=:=0, 
          new19(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=E, E>=0, Q=:=0, 
          new15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=E, E>=0, Q=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=E, E>=0, Q=:=0.
new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, C>=0, Q=:=0, 
          new12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=A, A>=0, Q=:=0, 
          new11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=C, C>=0, Q=:=0, 
          new13(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=C, C>=0, Q=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P>=Q+1, P=:=A, A>=0, Q=:=0, 
          new9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=A, A>=0, Q=:=0, 
          new10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, 
          new8(A,B,C,D,E,F,G,H,I,J,K,P,Q,N,O).
new6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, 
          new7(A,B,C,D,E,F,G,H,I,P,Q,L,M,N,O).
new5(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, Q>=0, R=:=P, S=:=R, R>=0, T=:=1, 
          U=:=1, V=:=1, new6(A,B,C,D,S,P,T,U,V,J,K,L,M,N,O).
new4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, Q>=0, R=:=P, S=:=R, R>=0, 
          new5(A,B,S,P,E,F,G,H,I,J,K,L,M,N,O).
new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=:=Q, Q>=0, R=:=P, S=:=R, R>=0, 
          new4(S,P,C,D,E,F,G,H,I,J,K,L,M,N,O).
new2 :- new3(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O).
new1 :- new2.
inv1 :- \+new1.
