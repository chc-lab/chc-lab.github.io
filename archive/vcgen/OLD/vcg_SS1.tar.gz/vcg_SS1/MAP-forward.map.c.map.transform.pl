new9(A,B,C,D,E,F) :- G>=H+1, G=:=F, H=:=0, I=:=J+K, J=:=D, K=:=1, L=:=M+N, 
          M=:=E, N=:=2, O=:=P+Q, P=:=B, Q=:=1, new4(A,O,C,I,L,F).
new9(A,B,C,D,E,F) :- G+1=<H, G=:=F, H=:=0, I=:=J+K, J=:=D, K=:=1, L=:=M+N, 
          M=:=E, N=:=2, O=:=P+Q, P=:=B, Q=:=1, new4(A,O,C,I,L,F).
new9(A,B,C,D,E,F) :- G=:=H, G=:=F, H=:=0, I=:=J+K, J=:=D, K=:=2, L=:=M+N, 
          M=:=E, N=:=1, O=:=P+Q, P=:=B, Q=:=1, new4(A,O,C,I,L,F).
new8(A,B,C,D,E,F) :- G>=H+1, G=:=I+J, I=:=D, J=:=E, H=:=K*L, K=:=3, L=:=C.
new8(A,B,C,D,E,F) :- G+1=<H, G=:=I+J, I=:=D, J=:=E, H=:=K*L, K=:=3, L=:=C.
new7(A,B,C,D,E,F) :- new9(A,B,C,D,E,G).
new5(A,B,C,D,E,F) :- new5(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G+1=<H, G=:=B, H=:=C, new7(A,B,C,D,E,F).
new4(A,B,C,D,E,F) :- G>=H, G=:=B, H=:=C, new8(A,B,C,D,E,F).
new3(A,B,C,D,E,F) :- G>=H, G=:=C, H=:=0, I=:=0, J=:=0, K=:=0, new4(A,I,C,J,K,F).
new3(A,B,C,D,E,F) :- G+1=<H, G=:=C, H=:=0, new5(A,B,C,D,E,F).
new2 :- new3(A,B,C,D,E,F).
new1 :- new2.
inv1 :- \+new1.
