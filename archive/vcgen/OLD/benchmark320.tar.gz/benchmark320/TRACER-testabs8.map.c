# 1 "MAP/SAFE-exbench/TRACER-testabs8.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs8.tmp.c"
# 34 "MAP/SAFE-exbench/TRACER-testabs8.tmp.c"
main(int n){
  int i;

  i=0;n=10;



  while (i < n){ i++; }

  __VERIFIER_assert(!( i>10 ));

}
