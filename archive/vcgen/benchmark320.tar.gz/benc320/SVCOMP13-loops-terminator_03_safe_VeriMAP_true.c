# 1 "MAP/SAFE-exbench/SVCOMP13-loops-terminator_03_safe.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/SVCOMP13-loops-terminator_03_safe.tmp.c"
# 18 "MAP/SAFE-exbench/SVCOMP13-loops-terminator_03_safe.tmp.c"
/*
void __VERIFIER_assert(int cond) {
  if (!(cond)) {
    ERROR: goto ERROR;
  }
  return;
}
int __VERIFIER_nondet_int();
_Bool __VERIFIER_nondet_bool();
*/

main()
{
  int x=__VERIFIER_nondet_int();
  int y=__VERIFIER_nondet_int();

  if (y>0)
  {
    while(x<100)
    {
      x=x+y;
     }
  }

  __VERIFIER_assert(y<=0 || (y>0 && x>=100));
}
