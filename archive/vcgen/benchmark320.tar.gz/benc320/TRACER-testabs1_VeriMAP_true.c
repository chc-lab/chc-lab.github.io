# 1 "MAP/SAFE-exbench/TRACER-testabs1.tmp.c"
# 1 "<command-line>"
# 1 "MAP/SAFE-exbench/TRACER-testabs1.tmp.c"
# 22 "MAP/SAFE-exbench/TRACER-testabs1.tmp.c"
//int error=0;

void main(){
  int x,y,z;


  if(z>0){
    x=4;
    y=1;
  }
  else{
    x=100;
    y=2;
  }


  __VERIFIER_assert(!( x<=0 ));

}
