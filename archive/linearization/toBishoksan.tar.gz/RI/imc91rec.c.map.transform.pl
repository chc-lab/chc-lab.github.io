new2(A,B,A,B) :- C=<D, C=:=B, B>=0, D=:=0.
new2(A,B,C,D) :- E>=F+1, E=:=B, B>=0, F=:=0, G=<H, G=:=A, A>=0, H=:=100, 
          I=:=J+K, J=:=A, A>=0, K=:=11, L=:=M+N, M=:=B, B>=0, N=:=1, 
          new2(I,L,C,D).
new2(A,B,C,D) :- E>=F+1, E=:=B, B>=0, F=:=0, G>=H+1, G=:=A, A>=0, H=:=100, 
          I=:=J-K, J=:=A, A>=0, K=:=10, L=:=M-N, M=:=B, B>=0, N=:=1, 
          new2(I,L,C,D).
new1(A,B) :- C=:=1, new2(A,C,B,D).
incorrect :- A>=101, B>=A-9, new1(A,B).
incorrect :- A>=101, B=<A-11, new1(A,B).
incorrect :- A=<100, B=A+11, C=:=D, E>=F+1, new1(A,E), new1(B,C), new1(D,F).
incorrect :- A=<100, B=A+11, C=:=D, E=<F-1, new1(A,E), new1(B,C), new1(D,F).
inv1 :- \+incorrect.
