new2(A,B,C,A,B,C) :- D>=E, D=:=C, C>=0, E=:=A, A>=0.
new2(A,B,C,D,E,F) :- G+1=<H, G=:=C, C>=0, H=:=A, A>=0, I=:=J+K, J=:=L*M, L=:=2, 
          M=:=B, B>=0, K=:=1, N=:=O+P, O=:=C, C>=0, P=:=1, new2(A,I,N,D,E,F).
new1(A,B) :- C=:=1, D=:=1, new2(A,C,D,E,B,F).
incorrect :- A=:=1, B>=2, new1(A,B).
incorrect :- A=:=1, B=<0, new1(A,B).
incorrect :- A>=2, B=:=A-1, C>=2*D+2, new1(A,C), new1(B,D).
incorrect :- A>=2, B=:=A-1, C=<2*D, new1(A,C), new1(B,D).
inv1 :- \+incorrect.
