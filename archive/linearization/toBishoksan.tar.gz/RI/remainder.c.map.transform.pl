new2(A,B,A,B) :- C+1=<D, C=:=B, B>=0, D=:=A, A>=0.
new2(A,B,C,D) :- E>=F, E=:=B, B>=0, F=:=A, A>=0, G=:=H-I, H=:=B, B>=0, I=:=A, 
          A>=0, new2(A,G,C,D).
new1(A,B,C) :- new2(B,A,D,C).
incorrect :- A=<B-1, C>=A+1, new1(A,B,C).
incorrect :- A=<B-1, C=<A-1, new1(A,B,C).
incorrect :- A=:=B, C>=1, new1(A,B,C).
incorrect :- A=:=B, C=< -1, new1(A,B,C).
incorrect :- A>=B+1, C=:=A-B, D=:=B, E>=F+1, new1(A,B,F), new1(C,D,E).
incorrect :- A>=B+1, C=:=A-B, D=:=B, E=<F-1, new1(A,B,F), new1(C,D,E).
inv1 :- \+incorrect.
