new5(A,B,C,A,D,C) :- E>=F+1, E=:=1, F=:=0, G>=H, G=:=A, A>=0, H=:=10, I>=J, 
          I=:=A, A>=0, J=:=100, K>=L, K=:=A, A>=0, L=:=1000, M+1=<N, M=:=A, 
          A>=0, N=:=10000, D=:=O+P, O=:=B, B>=0, P=:=3.
new5(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=0, I>=J, I=:=A, A>=0, J=:=10, K>=L, 
          K=:=A, A>=0, L=:=100, M>=N, M=:=A, A>=0, N=:=1000, O>=P, O=:=A, A>=0, 
          P=:=10000, Q=:=A, A>=0, Q=:=10000*R+S, S>=0, S=<9999, T=:=U+V, U=:=B, 
          B>=0, V=:=4, new5(R,T,Q,D,E,F).
new4(A,B,C,A,D,C) :- E>=F+1, E=:=1, F=:=0, G>=H, G=:=A, A>=0, H=:=10, I>=J, 
          I=:=A, A>=0, J=:=100, K+1=<L, K=:=A, A>=0, L=:=1000, D=:=M+N, M=:=B, 
          B>=0, N=:=2.
new4(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=0, I>=J, I=:=A, A>=0, J=:=10, K>=L, 
          K=:=A, A>=0, L=:=100, M>=N, M=:=A, A>=0, N=:=1000, O>=P, O=:=A, A>=0, 
          P=:=10000, Q=:=A, A>=0, Q=:=10000*R+S, S>=0, S=<9999, T=:=U+V, U=:=B, 
          B>=0, V=:=4, new4(R,T,Q,D,E,F).
new3(A,B,C,A,D,C) :- E>=F+1, E=:=1, F=:=0, G>=H, G=:=A, A>=0, H=:=10, I+1=<J, 
          I=:=A, A>=0, J=:=100, D=:=K+L, K=:=B, B>=0, L=:=1.
new3(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=0, I>=J, I=:=A, A>=0, J=:=10, K>=L, 
          K=:=A, A>=0, L=:=100, M>=N, M=:=A, A>=0, N=:=1000, O>=P, O=:=A, A>=0, 
          P=:=10000, Q=:=A, A>=0, Q=:=10000*R+S, S>=0, S=<9999, T=:=U+V, U=:=B, 
          B>=0, V=:=4, new3(R,T,Q,D,E,F).
new2(A,B,C,A,B,C) :- D>=E+1, D=:=1, E=:=0, F+1=<G, F=:=A, A>=0, G=:=10.
new2(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=0, I>=J, I=:=A, A>=0, J=:=10, K>=L, 
          K=:=A, A>=0, L=:=100, M>=N, M=:=A, A>=0, N=:=1000, O>=P, O=:=A, A>=0, 
          P=:=10000, Q=:=A, A>=0, Q=:=10000*R+S, S>=0, S=<9999, T=:=U+V, U=:=B, 
          B>=0, V=:=4, new2(R,T,Q,D,E,F).
new1(A,B) :- C=:=1, new2(A,C,D,E,B,F).
new1(A,B) :- C=:=1, new3(A,C,D,E,B,F).
new1(A,B) :- C=:=1, new4(A,C,D,E,B,F).
new1(A,B) :- C=:=1, new5(A,C,D,E,B,F).
incorrect :- A>=0, A=<9, B>=2, new1(A,B).
incorrect :- A>=0, A=<9, B=<0, new1(A,B).
incorrect :- A>=10, B>=C+2, A=:=10*D+E, D>=1, E>=0, E=<9, new1(A,B), new1(D,C).
incorrect :- A>=10, B=<C, A=:=10*D+E, D>=1, E>=0, E=<9, new1(A,B), new1(D,C).
inv1 :- \+incorrect.
