new2(A,B,C,A,B,C) :- D=<E, D=:=A, A>=0, E=:=0.
new2(A,B,C,D,E,F) :- G>=H+1, G=:=A, A>=0, H=:=0, I=:=J+K, J=:=B, B>=0, K=:=1, 
          L=:=A, A>=0, L=:=10*M+N, M>=0, N>=0, N=<9, new2(M,I,L,D,E,F).
new1(A,B) :- C=:=1, D=:=A, A>=0, D=:=10*E+F, E>=0, F>=0, F=<9, 
          new2(E,C,D,G,B,H).
incorrect :- A>=0, A=<9, B>=2, new1(A,B).
incorrect :- A>=0, A=<9, B=<0, new1(A,B).
incorrect :- A>=10, B>=C+2, A=:=10*D+E, D>=1, E>=0, E=<9, new1(A,B), new1(D,C).
incorrect :- A>=10, B=<C, A=:=10*D+E, D>=1, E>=0, E=<9, new1(A,B), new1(D,C).
inv1 :- \+incorrect.
