new2(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, A>=0, G=:=0.
new2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=:=0, A=:=3*N, 
          O+1=<P, O=:=M, M>=0, P=:=2, Q+1=<R, Q=:=M, M>=0, R=:=1, A=:=3*E, 
          S=:=E, E>=0, T=:=U*V, U=:=3, V=:=B, B>=0, new2(S,T,C,M,E,F,G,H,I,J).
new2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=:=1, A=:=3*N+1, 
          O+1=<P, O=:=M, M>=0, P=:=2, Q=:=R, Q=:=M, M>=0, R=:=1, S=:=T-U, 
          T=:=A, A>=0, U=:=1, V=:=W+X, W=:=C, C>=0, X=:=B, B>=0, S=:=3*E, 
          Y=:=E, E>=0, Z=:=A1*B1, A1=:=3, B1=:=B, B>=0, 
          new2(Y,Z,V,M,E,F,G,H,I,J).
new2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=:=2, A=:=3*N+2, 
          O=:=P, O=:=M, M>=0, P=:=2, Q=:=R-S, R=:=A, A>=0, S=:=2, T=:=U+V, 
          U=:=C, C>=0, V=:=W*X, W=:=2, X=:=B, B>=0, Q=:=3*E, Y=:=E, E>=0, 
          Z=:=A1*B1, A1=:=3, B1=:=B, B>=0, new2(Y,Z,T,M,E,F,G,H,I,J).
new1(A,B,C) :- D=:=0, new2(A,B,D,E,F,G,H,C,I,J).
incorrect :- A=0, B>=1, new1(A,C,B).
incorrect :- A=0, B=< -1, new1(A,C,B).
incorrect :- A>=1, B>=0, A=3*B+1, C>=D+E+1, F=3*E, new1(A,E,C), new1(B,F,D).
incorrect :- A>=1, B>=0, A=3*B+1, C=<D+E-1, F=3*E, new1(A,E,C), new1(B,F,D).
incorrect :- A>=2, B>=0, A=3*B+2, C>=D+2*E+1, F=3*E, new1(A,E,C), new1(B,F,D).
incorrect :- A>=2, B>=0, A=3*B+2, C=<D+2*E-1, F=3*E, new1(A,E,C), new1(B,F,D).
incorrect :- A>=3, B>=0, A=3*B, C>=D+1, E=3*F, new1(A,F,C), new1(B,E,D).
incorrect :- A>=3, B>=0, A=3*B, C=<D-1, E=3*F, new1(A,F,C), new1(B,E,D).
inv1 :- \+incorrect.
