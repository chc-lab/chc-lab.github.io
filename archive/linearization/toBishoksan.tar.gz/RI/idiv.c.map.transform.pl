new2(A,B,C,A,B,C) :- D+1=<E, D=:=A, A>=0, E=:=B, B>=0.
new2(A,B,C,D,E,F) :- G>=H, G=:=A, A>=0, H=:=B, B>=0, I=:=J+K, J=:=C, C>=0, 
          K=:=1, L=:=M-N, M=:=A, A>=0, N=:=B, B>=0, new2(L,B,I,D,E,F).
new1(A,B,C) :- D=:=0, new2(A,B,D,E,F,C).
incorrect :- A>=0, A+1=<B, C>=1, new1(A,B,C).
incorrect :- A>=0, A+1=<B, C=< -1, new1(A,B,C).
incorrect :- A>=1, B>=A, C=:=B-A, D=:=A, E>=F+2, new1(B,A,E), new1(C,D,F).
incorrect :- A>=1, B>=A, C=:=B-A, D=:=A, E=<F, new1(B,A,E), new1(C,D,F).
inv1 :- \+incorrect.
