new2(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, G=:=0.
new2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, L=:=0, M=:=B, N=:=O+P, O=:=B, 
          P=:=C, Q=:=M, R=:=S-T, S=:=A, T=:=1, new2(R,N,Q,M,E,F,G,H,I,J).
new1(A,B) :- C=:=2, D=:= -1, E=:=0, F=:=0, new2(A,C,D,E,F,G,B,H,I,J).
incorrect :- A=:=0, B>=3, new1(A,B).
incorrect :- A=:=0, B=<1, new1(A,B).
incorrect :- A=:=1, B>=2, new1(A,B).
incorrect :- A=:=1, B=<0, new1(A,B).
incorrect :- A>=2, B=:=A-1, C=:=A-2, D>=E+F+1, new1(A,D), new1(B,E), new1(C,F).
incorrect :- A>=2, B=:=A-1, C=:=A-2, D=<E+F-1, new1(A,D), new1(B,E), new1(C,F).
inv1 :- \+incorrect.
