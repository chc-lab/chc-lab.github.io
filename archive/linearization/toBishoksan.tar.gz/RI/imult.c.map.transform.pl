new2(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, A>=0, G=:=0.
new2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=:=N-O, N=:=A, A>=0, 
          O=:=2, P=:=Q+R, Q=:=S+T, S=:=C, C>=0, T=:=B, B>=0, R=:=B, B>=0, 
          new2(M,B,P,D,E,F,G,H,I,J).
new1(A,B,C) :- D=1, A=:=2*E, F=:=D, D>=0, G>=H, G=:=F, F>=0, H=:=1, I=:=B, 
          B>=0, J=:=K-L, K=:=A, A>=0, L=:=1, new2(J,B,I,F,D,M,N,C,O,P).
new1(A,B,C) :- D=0, A=:=2*E+1, F=:=D, D>=0, G+1=<H, G=:=F, F>=0, H=:=1, I=:=0, 
          new2(A,B,I,F,D,J,K,C,L,M).
incorrect :- A=:=0, B>=1, new1(C,A,B).
incorrect :- A=:=0, B=< -1, new1(C,A,B).
incorrect :- A=:=B, C=:=D+1, E>=F+B+1, D>=0, new1(A,C,E), new1(B,D,F).
incorrect :- A=:=B, C=:=D+1, E=<F+B-1, D>=0, new1(A,C,E), new1(B,D,F).
inv1 :- \+incorrect.
