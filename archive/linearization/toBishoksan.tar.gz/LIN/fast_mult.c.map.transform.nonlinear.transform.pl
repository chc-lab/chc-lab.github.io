lin7(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, A>=0, G=:=0.
lin7(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=1, A=:=2*N+1, O>=P, 
          O=:=M, M>=0, P=:=1, Q=:=R-S, R=:=A, A>=0, S=:=1, T=:=U+V, U=:=C, 
          C>=0, V=:=B, B>=0, Q=:=2*D, W=:=D, D>=0, X=:=Y*Z, Y=:=2, Z=:=B, B>=0, 
          lin7(W,X,T,D,M,F,G,H,I,J).
lin7(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=0, A=:=2*N, O+1=<P, 
          O=:=M, M>=0, P=:=1, A=:=2*D, Q=:=D, D>=0, R=:=S*T, S=:=2, T=:=B, 
          B>=0, lin7(Q,R,C,D,M,F,G,H,I,J).
lin6(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,F,G,H,I,J) :- K=<L, K=:=A, A>=0, L=:=0, 
          M=<N, M=:=F, F>=0, N=:=0.
lin6(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=A, A>=0, Q=:=0, 
          R>=S+1, R=:=F, F>=0, S=:=0, T=1, F=:=2*U+1, V>=W, V=:=T, T>=0, W=:=1, 
          X=:=Y-Z, Y=:=F, F>=0, Z=:=1, A1=:=B1+C1, B1=:=H, H>=0, C1=:=G, G>=0, 
          X=:=2*I, D1=:=I, I>=0, E1=:=F1*G1, F1=:=2, G1=:=G, G>=0, 
          lin7(D1,E1,A1,I,T,K,L,M,N,O).
lin6(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=A, A>=0, Q=:=0, 
          R>=S+1, R=:=F, F>=0, S=:=0, T=0, F=:=2*U, V+1=<W, V=:=T, T>=0, W=:=1, 
          F=:=2*I, X=:=I, I>=0, Y=:=Z*A1, Z=:=2, A1=:=G, G>=0, 
          lin7(X,Y,H,I,T,K,L,M,N,O).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O) :- P>=Q+1, P=:=A, A>=0, Q=:=0, 
          R=1, A=:=2*S+1, T>=U, T=:=R, R>=0, U=:=1, V=:=W-X, W=:=A, A>=0, 
          X=:=1, Y=:=Z+A1, Z=:=C, C>=0, A1=:=B, B>=0, V=:=2*D, B1=:=D, D>=0, 
          C1=:=D1*E1, D1=:=2, E1=:=B, B>=0, F1=<G1, F1=:=K, K>=0, G1=:=0, 
          lin7(B1,C1,Y,D,R,F,G,H,I,J).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=A, A>=0, V=:=0, 
          W=1, A=:=2*X+1, Y>=Z, Y=:=W, W>=0, Z=:=1, A1=:=B1-C1, B1=:=A, A>=0, 
          C1=:=1, D1=:=E1+F1, E1=:=C, C>=0, F1=:=B, B>=0, A1=:=2*D, G1=:=D, 
          D>=0, H1=:=I1*J1, I1=:=2, J1=:=B, B>=0, K1>=L1+1, K1=:=K, K>=0, 
          L1=:=0, M1=1, K=:=2*N1+1, O1>=P1, O1=:=M1, M1>=0, P1=:=1, Q1=:=R1-S1, 
          R1=:=K, K>=0, S1=:=1, T1=:=U1+V1, U1=:=M, M>=0, V1=:=L, L>=0, 
          Q1=:=2*N, W1=:=N, N>=0, X1=:=Y1*Z1, Y1=:=2, Z1=:=L, L>=0, 
          lin6(G1,H1,D1,D,W,F,G,H,I,J,W1,X1,T1,N,M1,P,Q,R,S,T).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=A, A>=0, V=:=0, 
          W=1, A=:=2*X+1, Y>=Z, Y=:=W, W>=0, Z=:=1, A1=:=B1-C1, B1=:=A, A>=0, 
          C1=:=1, D1=:=E1+F1, E1=:=C, C>=0, F1=:=B, B>=0, A1=:=2*D, G1=:=D, 
          D>=0, H1=:=I1*J1, I1=:=2, J1=:=B, B>=0, K1>=L1+1, K1=:=K, K>=0, 
          L1=:=0, M1=0, K=:=2*N1, O1+1=<P1, O1=:=M1, M1>=0, P1=:=1, K=:=2*N, 
          Q1=:=N, N>=0, R1=:=S1*T1, S1=:=2, T1=:=L, L>=0, 
          lin6(G1,H1,D1,D,W,F,G,H,I,J,Q1,R1,M,N,M1,P,Q,R,S,T).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O) :- P>=Q+1, P=:=A, A>=0, Q=:=0, 
          R=0, A=:=2*S, T+1=<U, T=:=R, R>=0, U=:=1, A=:=2*D, V=:=D, D>=0, 
          W=:=X*Y, X=:=2, Y=:=B, B>=0, Z=<A1, Z=:=K, K>=0, A1=:=0, 
          lin7(V,W,C,D,R,F,G,H,I,J).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=A, A>=0, V=:=0, 
          W=0, A=:=2*X, Y+1=<Z, Y=:=W, W>=0, Z=:=1, A=:=2*D, A1=:=D, D>=0, 
          B1=:=C1*D1, C1=:=2, D1=:=B, B>=0, E1>=F1+1, E1=:=K, K>=0, F1=:=0, 
          G1=1, K=:=2*H1+1, I1>=J1, I1=:=G1, G1>=0, J1=:=1, K1=:=L1-M1, L1=:=K, 
          K>=0, M1=:=1, N1=:=O1+P1, O1=:=M, M>=0, P1=:=L, L>=0, K1=:=2*N, 
          Q1=:=N, N>=0, R1=:=S1*T1, S1=:=2, T1=:=L, L>=0, 
          lin6(A1,B1,C,D,W,F,G,H,I,J,Q1,R1,N1,N,G1,P,Q,R,S,T).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=A, A>=0, V=:=0, 
          W=0, A=:=2*X, Y+1=<Z, Y=:=W, W>=0, Z=:=1, A=:=2*D, A1=:=D, D>=0, 
          B1=:=C1*D1, C1=:=2, D1=:=B, B>=0, E1>=F1+1, E1=:=K, K>=0, F1=:=0, 
          G1=0, K=:=2*H1, I1+1=<J1, I1=:=G1, G1>=0, J1=:=1, K=:=2*N, K1=:=N, 
          N>=0, L1=:=M1*N1, M1=:=2, N1=:=L, L>=0, 
          lin6(A1,B1,C,D,W,F,G,H,I,J,K1,L1,M,N,G1,P,Q,R,S,T).
lin2(A,B,C,D,E,F) :- G=:=0, H=:=0, 
          lin6(A,B,G,I,J,K,L,C,M,N,D,E,H,O,P,Q,R,F,S,T).
lin1 :- A>=1, B>=0, A=2*B+1, C>=D+E+1, F=2*E, lin2(A,E,C,B,F,D).
lin1 :- A>=1, B>=0, A=2*B+1, C=<D+E-1, F=2*E, lin2(A,E,C,B,F,D).
lin1 :- A>=2, B>=0, A=2*B, C>=D+1, E=2*F, lin2(A,F,C,B,E,D).
lin1 :- A>=2, B>=0, A=2*B, C=<D-1, E=2*F, lin2(A,F,C,B,E,D).
inv1 :- \+lin1.
