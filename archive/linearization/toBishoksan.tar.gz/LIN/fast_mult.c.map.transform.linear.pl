incorrect :- A=0, B>=1, new1(A,C,B).
incorrect :- A=0, B=< -1, new1(A,C,B).
inv1 :- \+incorrect.
new1(A,B,C) :- D=:=0, new2(A,B,D,E,F,G,H,C,I,J).
new2(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, A>=0, G=:=0.
new2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=1, A=:=2*N+1, O>=P, 
          O=:=M, M>=0, P=:=1, Q=:=R-S, R=:=A, A>=0, S=:=1, T=:=U+V, U=:=C, 
          C>=0, V=:=B, B>=0, Q=:=2*D, W=:=D, D>=0, X=:=Y*Z, Y=:=2, Z=:=B, B>=0, 
          new2(W,X,T,D,M,F,G,H,I,J).
new2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=0, A=:=2*N, O+1=<P, 
          O=:=M, M>=0, P=:=1, A=:=2*D, Q=:=D, D>=0, R=:=S*T, S=:=2, T=:=B, 
          B>=0, new2(Q,R,C,D,M,F,G,H,I,J).
