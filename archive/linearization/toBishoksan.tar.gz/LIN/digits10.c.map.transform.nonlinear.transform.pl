lin5(A,B,C,A,B,C) :- D=<E, D=:=A, A>=0, E=:=0.
lin5(A,B,C,D,E,F) :- G>=H+1, G=:=A, A>=0, H=:=0, I=:=J+K, J=:=B, B>=0, K=:=1, 
          L=:=A, A>=0, L=:=10*M+N, M>=0, N>=0, N=<9, lin5(M,I,L,D,E,F).
lin4(A,B,C,A,B,C,D,E,F,D,E,F) :- G=<H, G=:=A, A>=0, H=:=0, I=<J, I=:=D, D>=0, 
          J=:=0.
lin4(A,B,C,A,B,C,D,E,F,G,H,I) :- J=<K, J=:=A, A>=0, K=:=0, L>=M+1, L=:=D, D>=0, 
          M=:=0, N=:=O+P, O=:=E, E>=0, P=:=1, Q=:=D, D>=0, Q=:=10*R+S, R>=0, 
          S>=0, S=<9, lin5(R,N,Q,G,H,I).
lin4(A,B,C,D,E,F,G,H,I,G,H,I) :- J>=K+1, J=:=A, A>=0, K=:=0, L=:=M+N, M=:=B, 
          B>=0, N=:=1, O=:=A, A>=0, O=:=10*P+Q, P>=0, Q>=0, Q=<9, R=<S, R=:=G, 
          G>=0, S=:=0, lin5(P,L,O,D,E,F).
lin4(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=A, A>=0, N=:=0, O=:=P+Q, P=:=B, 
          B>=0, Q=:=1, R=:=A, A>=0, R=:=10*S+T, S>=0, T>=0, T=<9, U>=V+1, 
          U=:=G, G>=0, V=:=0, W=:=X+Y, X=:=H, H>=0, Y=:=1, Z=:=G, G>=0, 
          Z=:=10*A1+B1, A1>=0, B1>=0, B1=<9, lin4(S,O,R,D,E,F,A1,W,Z,J,K,L).
lin2(A,B,C,D) :- E=:=1, F=:=A, A>=0, F=:=10*G+H, G>=0, H>=0, H=<9, I=:=1, 
          J=:=C, C>=0, J=:=10*K+L, K>=0, L>=0, L=<9, 
          lin4(G,E,F,M,B,N,K,I,J,O,D,P).
lin1 :- A>=10, B>=C+2, A=:=10*D+E, D>=1, E>=0, E=<9, lin2(A,B,D,C).
lin1 :- A>=10, B=<C, A=:=10*D+E, D>=1, E>=0, E=<9, lin2(A,B,D,C).
inv1 :- \+lin1.
