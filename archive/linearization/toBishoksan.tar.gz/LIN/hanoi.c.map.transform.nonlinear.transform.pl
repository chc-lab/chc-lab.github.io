lin5(A,B,C,A,B,C) :- D>=E, D=:=C, C>=0, E=:=A, A>=0.
lin5(A,B,C,D,E,F) :- G+1=<H, G=:=C, C>=0, H=:=A, A>=0, I=:=J+K, J=:=L*M, L=:=2, 
          M=:=B, B>=0, K=:=1, N=:=O+P, O=:=C, C>=0, P=:=1, lin5(A,I,N,D,E,F).
lin4(A,B,C,A,B,C,D,E,F,D,E,F) :- G>=H, G=:=C, C>=0, H=:=A, A>=0, I>=J, I=:=F, 
          F>=0, J=:=D, D>=0.
lin4(A,B,C,A,B,C,D,E,F,G,H,I) :- J>=K, J=:=C, C>=0, K=:=A, A>=0, L+1=<M, L=:=F, 
          F>=0, M=:=D, D>=0, N=:=O+P, O=:=Q*R, Q=:=2, R=:=E, E>=0, P=:=1, 
          S=:=T+U, T=:=F, F>=0, U=:=1, lin5(D,N,S,G,H,I).
lin4(A,B,C,D,E,F,G,H,I,G,H,I) :- J+1=<K, J=:=C, C>=0, K=:=A, A>=0, L=:=M+N, 
          M=:=O*P, O=:=2, P=:=B, B>=0, N=:=1, Q=:=R+S, R=:=C, C>=0, S=:=1, 
          T>=U, T=:=I, I>=0, U=:=G, G>=0, lin5(A,L,Q,D,E,F).
lin4(A,B,C,D,E,F,G,H,I,J,K,L) :- M+1=<N, M=:=C, C>=0, N=:=A, A>=0, O=:=P+Q, 
          P=:=R*S, R=:=2, S=:=B, B>=0, Q=:=1, T=:=U+V, U=:=C, C>=0, V=:=1, 
          W+1=<X, W=:=I, I>=0, X=:=G, G>=0, Y=:=Z+A1, Z=:=B1*C1, B1=:=2, 
          C1=:=H, H>=0, A1=:=1, D1=:=E1+F1, E1=:=I, I>=0, F1=:=1, 
          lin4(A,O,T,D,E,F,G,Y,D1,J,K,L).
lin2(A,B,C,D) :- E=:=1, F=:=1, G=:=1, H=:=1, lin4(A,E,F,I,B,J,C,G,H,K,D,L).
lin1 :- A>=2, B=:=A-1, C>=2*D+2, lin2(A,C,B,D).
lin1 :- A>=2, B=:=A-1, C=<2*D, lin2(A,C,B,D).
inv1 :- \+lin1.
