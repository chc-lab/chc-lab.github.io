lin5(A,B,C,A,B,C) :- D>=E+1, D=:=C, C>=0, E=:=A, A>=0.
lin5(A,B,C,D,E,F) :- G=<H, G=:=C, C>=0, H=:=A, A>=0, I=:=J+K, J=:=B, B>=0, 
          K=:=C, C>=0, L=:=M+N, M=:=C, C>=0, N=:=1, lin5(A,I,L,D,E,F).
lin4(A,B,C,A,B,C,D,E,F,D,E,F) :- G>=H+1, G=:=C, C>=0, H=:=A, A>=0, I>=J+1, 
          I=:=F, F>=0, J=:=D, D>=0.
lin4(A,B,C,A,B,C,D,E,F,G,H,I) :- J>=K+1, J=:=C, C>=0, K=:=A, A>=0, L=<M, L=:=F, 
          F>=0, M=:=D, D>=0, N=:=O+P, O=:=E, E>=0, P=:=F, F>=0, Q=:=R+S, R=:=F, 
          F>=0, S=:=1, lin5(D,N,Q,G,H,I).
lin4(A,B,C,D,E,F,G,H,I,G,H,I) :- J=<K, J=:=C, C>=0, K=:=A, A>=0, L=:=M+N, 
          M=:=B, B>=0, N=:=C, C>=0, O=:=P+Q, P=:=C, C>=0, Q=:=1, R>=S+1, R=:=I, 
          I>=0, S=:=G, G>=0, lin5(A,L,O,D,E,F).
lin4(A,B,C,D,E,F,G,H,I,J,K,L) :- M=<N, M=:=C, C>=0, N=:=A, A>=0, O=:=P+Q, 
          P=:=B, B>=0, Q=:=C, C>=0, R=:=S+T, S=:=C, C>=0, T=:=1, U=<V, U=:=I, 
          I>=0, V=:=G, G>=0, W=:=X+Y, X=:=H, H>=0, Y=:=I, I>=0, Z=:=A1+B1, 
          A1=:=I, I>=0, B1=:=1, lin4(A,O,R,D,E,F,G,W,Z,J,K,L).
lin2(A,B,C,D) :- E=:=0, F=:=0, G=:=0, H=:=0, lin4(A,E,F,I,B,J,C,G,H,K,D,L).
lin1 :- A>=1, B=:=A-1, C>=A+D+1, lin2(A,C,B,D).
lin1 :- A>=1, B=:=A-1, C=<A+D-1, lin2(A,C,B,D).
inv1 :- \+lin1.
