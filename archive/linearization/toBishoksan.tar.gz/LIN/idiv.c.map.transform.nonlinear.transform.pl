lin5(A,B,C,A,B,C) :- D+1=<E, D=:=A, A>=0, E=:=B, B>=0.
lin5(A,B,C,D,E,F) :- G>=H, G=:=A, A>=0, H=:=B, B>=0, I=:=J+K, J=:=C, C>=0, 
          K=:=1, L=:=M-N, M=:=A, A>=0, N=:=B, B>=0, lin5(L,B,I,D,E,F).
lin4(A,B,C,A,B,C,D,E,F,D,E,F) :- G+1=<H, G=:=A, A>=0, H=:=B, B>=0, I+1=<J, 
          I=:=D, D>=0, J=:=E, E>=0.
lin4(A,B,C,A,B,C,D,E,F,G,H,I) :- J+1=<K, J=:=A, A>=0, K=:=B, B>=0, L>=M, L=:=D, 
          D>=0, M=:=E, E>=0, N=:=O+P, O=:=F, F>=0, P=:=1, Q=:=R-S, R=:=D, D>=0, 
          S=:=E, E>=0, lin5(Q,E,N,G,H,I).
lin4(A,B,C,D,E,F,G,H,I,G,H,I) :- J>=K, J=:=A, A>=0, K=:=B, B>=0, L=:=M+N, 
          M=:=C, C>=0, N=:=1, O=:=P-Q, P=:=A, A>=0, Q=:=B, B>=0, R+1=<S, R=:=G, 
          G>=0, S=:=H, H>=0, lin5(O,B,L,D,E,F).
lin4(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N, M=:=A, A>=0, N=:=B, B>=0, O=:=P+Q, 
          P=:=C, C>=0, Q=:=1, R=:=S-T, S=:=A, A>=0, T=:=B, B>=0, U>=V, U=:=G, 
          G>=0, V=:=H, H>=0, W=:=X+Y, X=:=I, I>=0, Y=:=1, Z=:=A1-B1, A1=:=G, 
          G>=0, B1=:=H, H>=0, lin4(R,B,O,D,E,F,Z,H,W,J,K,L).
lin2(A,B,C,D,E,F) :- G=:=0, H=:=0, lin4(A,B,G,I,J,C,D,E,H,K,L,F).
lin1 :- A>=1, B>=A, C=:=B-A, D=:=A, E>=F+2, lin2(B,A,E,C,D,F).
lin1 :- A>=1, B>=A, C=:=B-A, D=:=A, E=<F, lin2(B,A,E,C,D,F).
inv1 :- \+lin1.
