incorrect :- A>=1, A=:=B, C>=A+1, new1(A,B,C).
incorrect :- A>=1, A=:=B, C=<A-1, new1(A,B,C).
inv1 :- \+incorrect.
new1(A,B,C) :- new2(A,B,C,D).
new2(A,B,A,B) :- C=:=D, C=:=A, A>=0, D=:=B, B>=0.
new2(A,B,C,D) :- E>=F+1, E=:=A, A>=0, F=:=B, B>=0, G>=H+1, G=:=A, A>=0, H=:=B, 
          B>=0, I=:=J-K, J=:=A, A>=0, K=:=B, B>=0, new2(I,B,C,D).
new2(A,B,C,D) :- E+1=<F, E=:=A, A>=0, F=:=B, B>=0, G=<H, G=:=A, A>=0, H=:=B, 
          B>=0, I=:=J-K, J=:=B, B>=0, K=:=A, A>=0, new2(A,I,C,D).
