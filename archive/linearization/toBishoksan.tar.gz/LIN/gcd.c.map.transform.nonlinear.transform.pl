lin7(A,B,A,B) :- C=:=D, C=:=A, A>=0, D=:=B, B>=0.
lin7(A,B,C,D) :- E>=F+1, E=:=A, A>=0, F=:=B, B>=0, G>=H+1, G=:=A, A>=0, H=:=B, 
          B>=0, I=:=J-K, J=:=A, A>=0, K=:=B, B>=0, lin7(I,B,C,D).
lin7(A,B,C,D) :- E+1=<F, E=:=A, A>=0, F=:=B, B>=0, G=<H, G=:=A, A>=0, H=:=B, 
          B>=0, I=:=J-K, J=:=B, B>=0, K=:=A, A>=0, lin7(A,I,C,D).
lin6(A,B,A,B,C,D,C,D) :- E=:=F, E=:=A, A>=0, F=:=B, B>=0, G=:=H, G=:=C, C>=0, 
          H=:=D, D>=0.
lin6(A,B,A,B,C,D,E,F) :- G=:=H, G=:=A, A>=0, H=:=B, B>=0, I>=J+1, I=:=C, C>=0, 
          J=:=D, D>=0, K>=L+1, K=:=C, C>=0, L=:=D, D>=0, M=:=N-O, N=:=C, C>=0, 
          O=:=D, D>=0, lin7(M,D,E,F).
lin6(A,B,A,B,C,D,E,F) :- G=:=H, G=:=A, A>=0, H=:=B, B>=0, I+1=<J, I=:=C, C>=0, 
          J=:=D, D>=0, K=<L, K=:=C, C>=0, L=:=D, D>=0, M=:=N-O, N=:=D, D>=0, 
          O=:=C, C>=0, lin7(C,M,E,F).
lin6(A,B,C,D,E,F,E,F) :- G>=H+1, G=:=A, A>=0, H=:=B, B>=0, I>=J+1, I=:=A, A>=0, 
          J=:=B, B>=0, K=:=L-M, L=:=A, A>=0, M=:=B, B>=0, N=:=O, N=:=E, E>=0, 
          O=:=F, F>=0, lin7(K,B,C,D).
lin6(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=A, A>=0, J=:=B, B>=0, K>=L+1, K=:=A, A>=0, 
          L=:=B, B>=0, M=:=N-O, N=:=A, A>=0, O=:=B, B>=0, P>=Q+1, P=:=E, E>=0, 
          Q=:=F, F>=0, R>=S+1, R=:=E, E>=0, S=:=F, F>=0, T=:=U-V, U=:=E, E>=0, 
          V=:=F, F>=0, lin6(M,B,C,D,T,F,G,H).
lin6(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=A, A>=0, J=:=B, B>=0, K>=L+1, K=:=A, A>=0, 
          L=:=B, B>=0, M=:=N-O, N=:=A, A>=0, O=:=B, B>=0, P+1=<Q, P=:=E, E>=0, 
          Q=:=F, F>=0, R=<S, R=:=E, E>=0, S=:=F, F>=0, T=:=U-V, U=:=F, F>=0, 
          V=:=E, E>=0, lin6(M,B,C,D,E,T,G,H).
lin6(A,B,C,D,E,F,E,F) :- G+1=<H, G=:=A, A>=0, H=:=B, B>=0, I=<J, I=:=A, A>=0, 
          J=:=B, B>=0, K=:=L-M, L=:=B, B>=0, M=:=A, A>=0, N=:=O, N=:=E, E>=0, 
          O=:=F, F>=0, lin7(A,K,C,D).
lin6(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=A, A>=0, J=:=B, B>=0, K=<L, K=:=A, A>=0, 
          L=:=B, B>=0, M=:=N-O, N=:=B, B>=0, O=:=A, A>=0, P>=Q+1, P=:=E, E>=0, 
          Q=:=F, F>=0, R>=S+1, R=:=E, E>=0, S=:=F, F>=0, T=:=U-V, U=:=E, E>=0, 
          V=:=F, F>=0, lin6(A,M,C,D,T,F,G,H).
lin6(A,B,C,D,E,F,G,H) :- I+1=<J, I=:=A, A>=0, J=:=B, B>=0, K=<L, K=:=A, A>=0, 
          L=:=B, B>=0, M=:=N-O, N=:=B, B>=0, O=:=A, A>=0, P+1=<Q, P=:=E, E>=0, 
          Q=:=F, F>=0, R=<S, R=:=E, E>=0, S=:=F, F>=0, T=:=U-V, U=:=F, F>=0, 
          V=:=E, E>=0, lin6(A,M,C,D,E,T,G,H).
lin2(A,B,C,D,E,F) :- lin6(A,B,C,G,D,E,F,H).
lin1 :- A>=1, A=:=B, A=<C-1, D=C-A, E>=F+1, lin2(A,C,E,B,D,F).
lin1 :- A>=1, A=:=B, A=<C-1, D=C-A, E=<F-1, lin2(A,C,E,B,D,F).
lin1 :- A>=1, A=:=B, C>=A+1, D=C-A, E>=F+1, lin2(C,A,E,D,B,F).
lin1 :- A>=1, A=:=B, C>=A+1, D=C-A, E=<F-1, lin2(C,A,E,D,B,F).
inv1 :- \+lin1.
