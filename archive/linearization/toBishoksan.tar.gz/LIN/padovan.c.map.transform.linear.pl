incorrect :- A=:=0, B>=2, new1(A,B).
incorrect :- A=:=0, B=<0, new1(A,B).
incorrect :- A=:=1, B>=1, new1(A,B).
incorrect :- A=:=1, B=< -1, new1(A,B).
incorrect :- A=:=2, B>=1, new1(A,B).
incorrect :- A=:=2, B=< -1, new1(A,B).
inv1 :- \+incorrect.
new1(A,B) :- C=:=1, D=:=C, E=:=0, F=:= -1, G>=H, G=:=A, H=:=1, I=:=0, 
          new2(A,I,D,E,F,J,B,K,L,M).
new1(A,B) :- C=:=1, D=:=C, E=:=0, F=:= -1, G+1=<H, G=:=A, H=:=1, 
          new2(A,C,D,E,F,I,B,J,K,L).
new2(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, G=:=1.
new2(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, L=:=1, M=:=B, N=:=O+P, O=:=C, 
          P=:=E, Q=:=C, R=:=M, S=:=T-U, T=:=A, U=:=1, new2(S,N,R,M,Q,F,G,H,I,J).
