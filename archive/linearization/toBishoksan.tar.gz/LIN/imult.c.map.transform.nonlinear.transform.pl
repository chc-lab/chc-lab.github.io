lin8(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, A>=0, G=:=0.
lin8(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, A>=0, L=:=0, M=:=N-O, N=:=A, A>=0, 
          O=:=2, P=:=Q+R, Q=:=S+T, S=:=C, C>=0, T=:=B, B>=0, R=:=B, B>=0, 
          lin8(M,B,P,D,E,F,G,H,I,J).
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,F,G,H,I,J) :- K=<L, K=:=A, A>=0, L=:=0, 
          M=<N, M=:=F, F>=0, N=:=0.
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=A, A>=0, Q=:=0, 
          R>=S+1, R=:=F, F>=0, S=:=0, T=:=U-V, U=:=F, F>=0, V=:=2, W=:=X+Y, 
          X=:=Z+A1, Z=:=H, H>=0, A1=:=G, G>=0, Y=:=G, G>=0, 
          lin8(T,G,W,I,J,K,L,M,N,O).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O) :- P>=Q+1, P=:=A, A>=0, Q=:=0, 
          R=:=S-T, S=:=A, A>=0, T=:=2, U=:=V+W, V=:=X+Y, X=:=C, C>=0, Y=:=B, 
          B>=0, W=:=B, B>=0, Z=<A1, Z=:=K, K>=0, A1=:=0, 
          lin8(R,B,U,D,E,F,G,H,I,J).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=A, A>=0, V=:=0, 
          W=:=X-Y, X=:=A, A>=0, Y=:=2, Z=:=A1+B1, A1=:=C1+D1, C1=:=C, C>=0, 
          D1=:=B, B>=0, B1=:=B, B>=0, E1>=F1+1, E1=:=K, K>=0, F1=:=0, 
          G1=:=H1-I1, H1=:=K, K>=0, I1=:=2, J1=:=K1+L1, K1=:=M1+N1, M1=:=M, 
          M>=0, N1=:=L, L>=0, L1=:=L, L>=0, 
          lin4(W,B,Z,D,E,F,G,H,I,J,G1,L,J1,N,O,P,Q,R,S,T).
lin2(A,B,C,D,E,F) :- G=1, A=:=2*H, I=:=G, G>=0, J>=K, J=:=I, I>=0, K=:=1, 
          L=:=B, B>=0, M=:=N-O, N=:=A, A>=0, O=:=1, P=1, D=:=2*Q, R=:=P, P>=0, 
          S>=T, S=:=R, R>=0, T=:=1, U=:=E, E>=0, V=:=W-X, W=:=D, D>=0, X=:=1, 
          lin4(M,B,L,I,G,Y,Z,C,A1,B1,V,E,U,R,P,C1,D1,F,E1,F1).
lin2(A,B,C,D,E,F) :- G=1, A=:=2*H, I=:=G, G>=0, J>=K, J=:=I, I>=0, K=:=1, 
          L=:=B, B>=0, M=:=N-O, N=:=A, A>=0, O=:=1, P=0, D=:=2*Q+1, R=:=P, 
          P>=0, S+1=<T, S=:=R, R>=0, T=:=1, U=:=0, 
          lin4(M,B,L,I,G,V,W,C,X,Y,D,E,U,R,P,Z,A1,F,B1,C1).
lin2(A,B,C,D,E,F) :- G=0, A=:=2*H+1, I=:=G, G>=0, J+1=<K, J=:=I, I>=0, K=:=1, 
          L=:=0, M=1, D=:=2*N, O=:=M, M>=0, P>=Q, P=:=O, O>=0, Q=:=1, R=:=E, 
          E>=0, S=:=T-U, T=:=D, D>=0, U=:=1, 
          lin4(A,B,L,I,G,V,W,C,X,Y,S,E,R,O,M,Z,A1,F,B1,C1).
lin2(A,B,C,D,E,F) :- G=0, A=:=2*H+1, I=:=G, G>=0, J+1=<K, J=:=I, I>=0, K=:=1, 
          L=:=0, M=0, D=:=2*N+1, O=:=M, M>=0, P+1=<Q, P=:=O, O>=0, Q=:=1, 
          R=:=0, lin4(A,B,L,I,G,S,T,C,U,V,D,E,R,O,M,W,X,F,Y,Z).
lin1 :- A=:=B, C=:=D+1, E>=F+B+1, D>=0, lin2(A,C,E,B,D,F).
lin1 :- A=:=B, C=:=D+1, E=<F+B-1, D>=0, lin2(A,C,E,B,D,F).
inv1 :- \+lin1.
