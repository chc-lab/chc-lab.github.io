lin14(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,F,G,H,I,J) :- K=<L, K=:=A, L=:=1, M=<N, 
          M=:=F, N=:=1.
lin14(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=A, Q=:=1, R>=S+1, 
          R=:=F, S=:=1, T=:=G, U=:=V+W, V=:=H, W=:=J, X=:=H, Y=:=T, Z=:=A1-B1, 
          A1=:=F, B1=:=1, lin12(Z,U,Y,T,X,K,L,M,N,O).
lin14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O) :- P>=Q+1, P=:=A, Q=:=1, R=:=B, 
          S=:=T+U, T=:=C, U=:=E, V=:=C, W=:=R, X=:=Y-Z, Y=:=A, Z=:=1, A1=<B1, 
          A1=:=K, B1=:=1, lin12(X,S,W,R,V,F,G,H,I,J).
lin14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=A, V=:=1, W=:=B, 
          X=:=Y+Z, Y=:=C, Z=:=E, A1=:=C, B1=:=W, C1=:=D1-E1, D1=:=A, E1=:=1, 
          F1>=G1+1, F1=:=K, G1=:=1, H1=:=L, I1=:=J1+K1, J1=:=M, K1=:=O, L1=:=M, 
          M1=:=H1, N1=:=O1-P1, O1=:=K, P1=:=1, 
          lin14(C1,X,B1,W,A1,F,G,H,I,J,N1,I1,M1,H1,L1,P,Q,R,S,T).
lin12(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, G=:=1.
lin12(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, L=:=1, M=:=B, N=:=O+P, O=:=C, 
          P=:=E, Q=:=C, R=:=M, S=:=T-U, T=:=A, U=:=1, 
          lin12(S,N,R,M,Q,F,G,H,I,J).
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O) :- P=<Q, 
          P=:=A, Q=:=1, R=<S, R=:=F, S=:=1, T=<U, T=:=K, U=:=1.
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=<V, 
          U=:=A, V=:=1, W=<X, W=:=F, X=:=1, Y>=Z+1, Y=:=K, Z=:=1, A1=:=L, 
          B1=:=C1+D1, C1=:=M, D1=:=O, E1=:=M, F1=:=A1, G1=:=H1-I1, H1=:=K, 
          I1=:=1, lin12(G1,B1,F1,A1,E1,P,Q,R,S,T).
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,P,Q,R,S,T) :- U=<V, 
          U=:=A, V=:=1, W>=X+1, W=:=F, X=:=1, Y=:=G, Z=:=A1+B1, A1=:=H, B1=:=J, 
          C1=:=H, D1=:=Y, E1=:=F1-G1, F1=:=F, G1=:=1, H1=<I1, H1=:=P, I1=:=1, 
          lin12(E1,Z,D1,Y,C1,K,L,M,N,O).
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=<A1, 
          Z=:=A, A1=:=1, B1>=C1+1, B1=:=F, C1=:=1, D1=:=G, E1=:=F1+G1, F1=:=H, 
          G1=:=J, H1=:=H, I1=:=D1, J1=:=K1-L1, K1=:=F, L1=:=1, M1>=N1+1, 
          M1=:=P, N1=:=1, O1=:=Q, P1=:=Q1+R1, Q1=:=R, R1=:=T, S1=:=R, T1=:=O1, 
          U1=:=V1-W1, V1=:=P, W1=:=1, 
          lin14(J1,E1,I1,D1,H1,K,L,M,N,O,U1,P1,T1,O1,S1,U,V,W,X,Y).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O,P,Q,R,S,T,P,Q,R,S,T) :- U>=V+1, 
          U=:=A, V=:=1, W=:=B, X=:=Y+Z, Y=:=C, Z=:=E, A1=:=C, B1=:=W, 
          C1=:=D1-E1, D1=:=A, E1=:=1, F1=<G1, F1=:=K, G1=:=1, H1=<I1, H1=:=P, 
          I1=:=1, lin12(C1,X,B1,W,A1,F,G,H,I,J).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, 
          Z=:=A, A1=:=1, B1=:=B, C1=:=D1+E1, D1=:=C, E1=:=E, F1=:=C, G1=:=B1, 
          H1=:=I1-J1, I1=:=A, J1=:=1, K1=<L1, K1=:=K, L1=:=1, M1>=N1+1, M1=:=P, 
          N1=:=1, O1=:=Q, P1=:=Q1+R1, Q1=:=R, R1=:=T, S1=:=R, T1=:=O1, 
          U1=:=V1-W1, V1=:=P, W1=:=1, 
          lin14(H1,C1,G1,B1,F1,F,G,H,I,J,U1,P1,T1,O1,S1,U,V,W,X,Y).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,U,V,W,X,Y) :- Z>=A1+1, 
          Z=:=A, A1=:=1, B1=:=B, C1=:=D1+E1, D1=:=C, E1=:=E, F1=:=C, G1=:=B1, 
          H1=:=I1-J1, I1=:=A, J1=:=1, K1>=L1+1, K1=:=K, L1=:=1, M1=:=L, 
          N1=:=O1+P1, O1=:=M, P1=:=O, Q1=:=M, R1=:=M1, S1=:=T1-U1, T1=:=K, 
          U1=:=1, V1=<W1, V1=:=U, W1=:=1, 
          lin14(H1,C1,G1,B1,F1,F,G,H,I,J,S1,N1,R1,M1,Q1,P,Q,R,S,T).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=A, F1=:=1, G1=:=B, H1=:=I1+J1, I1=:=C, J1=:=E, K1=:=C, 
          L1=:=G1, M1=:=N1-O1, N1=:=A, O1=:=1, P1>=Q1+1, P1=:=K, Q1=:=1, 
          R1=:=L, S1=:=T1+U1, T1=:=M, U1=:=O, V1=:=M, W1=:=R1, X1=:=Y1-Z1, 
          Y1=:=K, Z1=:=1, A2>=B2+1, A2=:=U, B2=:=1, C2=:=V, D2=:=E2+F2, E2=:=W, 
          F2=:=Y, G2=:=W, H2=:=C2, I2=:=J2-K2, J2=:=U, K2=:=1, 
          lin4(M1,H1,L1,G1,K1,F,G,H,I,J,X1,S1,W1,R1,V1,P,Q,R,S,T,I2,D2,H2,C2,G2,Z,A1,B1,C1,D1).
lin2(A,B,C,D,E,F) :- G=:=1, H=:=G, I=:=0, J=:= -1, K>=L, K=:=A, L=:=1, M=:=0, 
          N=:=1, O=:=N, P=:=0, Q=:= -1, R>=S, R=:=C, S=:=1, T=:=0, U=:=1, 
          V=:=U, W=:=0, X=:= -1, Y>=Z, Y=:=E, Z=:=1, A1=:=0, 
          lin4(A,M,H,I,J,B1,B,C1,D1,E1,C,T,O,P,Q,F1,D,G1,H1,I1,E,A1,V,W,X,J1,F,K1,L1,M1).
lin2(A,B,C,D,E,F) :- G=:=1, H=:=G, I=:=0, J=:= -1, K>=L, K=:=A, L=:=1, M=:=0, 
          N=:=1, O=:=N, P=:=0, Q=:= -1, R>=S, R=:=C, S=:=1, T=:=0, U=:=1, 
          V=:=U, W=:=0, X=:= -1, Y+1=<Z, Y=:=E, Z=:=1, 
          lin4(A,M,H,I,J,A1,B,B1,C1,D1,C,T,O,P,Q,E1,D,F1,G1,H1,E,U,V,W,X,I1,F,J1,K1,L1).
lin2(A,B,C,D,E,F) :- G=:=1, H=:=G, I=:=0, J=:= -1, K>=L, K=:=A, L=:=1, M=:=0, 
          N=:=1, O=:=N, P=:=0, Q=:= -1, R+1=<S, R=:=C, S=:=1, T=:=1, U=:=T, 
          V=:=0, W=:= -1, X>=Y, X=:=E, Y=:=1, Z=:=0, 
          lin4(A,M,H,I,J,A1,B,B1,C1,D1,C,N,O,P,Q,E1,D,F1,G1,H1,E,Z,U,V,W,I1,F,J1,K1,L1).
lin2(A,B,C,D,E,F) :- G=:=1, H=:=G, I=:=0, J=:= -1, K>=L, K=:=A, L=:=1, M=:=0, 
          N=:=1, O=:=N, P=:=0, Q=:= -1, R+1=<S, R=:=C, S=:=1, T=:=1, U=:=T, 
          V=:=0, W=:= -1, X+1=<Y, X=:=E, Y=:=1, 
          lin4(A,M,H,I,J,Z,B,A1,B1,C1,C,N,O,P,Q,D1,D,E1,F1,G1,E,T,U,V,W,H1,F,I1,J1,K1).
lin2(A,B,C,D,E,F) :- G=:=1, H=:=G, I=:=0, J=:= -1, K+1=<L, K=:=A, L=:=1, M=:=1, 
          N=:=M, O=:=0, P=:= -1, Q>=R, Q=:=C, R=:=1, S=:=0, T=:=1, U=:=T, 
          V=:=0, W=:= -1, X>=Y, X=:=E, Y=:=1, Z=:=0, 
          lin4(A,G,H,I,J,A1,B,B1,C1,D1,C,S,N,O,P,E1,D,F1,G1,H1,E,Z,U,V,W,I1,F,J1,K1,L1).
lin2(A,B,C,D,E,F) :- G=:=1, H=:=G, I=:=0, J=:= -1, K+1=<L, K=:=A, L=:=1, M=:=1, 
          N=:=M, O=:=0, P=:= -1, Q>=R, Q=:=C, R=:=1, S=:=0, T=:=1, U=:=T, 
          V=:=0, W=:= -1, X+1=<Y, X=:=E, Y=:=1, 
          lin4(A,G,H,I,J,Z,B,A1,B1,C1,C,S,N,O,P,D1,D,E1,F1,G1,E,T,U,V,W,H1,F,I1,J1,K1).
lin2(A,B,C,D,E,F) :- G=:=1, H=:=G, I=:=0, J=:= -1, K+1=<L, K=:=A, L=:=1, M=:=1, 
          N=:=M, O=:=0, P=:= -1, Q+1=<R, Q=:=C, R=:=1, S=:=1, T=:=S, U=:=0, 
          V=:= -1, W>=X, W=:=E, X=:=1, Y=:=0, 
          lin4(A,G,H,I,J,Z,B,A1,B1,C1,C,M,N,O,P,D1,D,E1,F1,G1,E,Y,T,U,V,H1,F,I1,J1,K1).
lin2(A,B,C,D,E,F) :- G=:=1, H=:=G, I=:=0, J=:= -1, K+1=<L, K=:=A, L=:=1, M=:=1, 
          N=:=M, O=:=0, P=:= -1, Q+1=<R, Q=:=C, R=:=1, S=:=1, T=:=S, U=:=0, 
          V=:= -1, W+1=<X, W=:=E, X=:=1, 
          lin4(A,G,H,I,J,Y,B,Z,A1,B1,C,M,N,O,P,C1,D,D1,E1,F1,E,S,T,U,V,G1,F,H1,I1,J1).
lin1 :- A>=3, B=:=A-2, C=:=A-3, D>=E+F+1, lin2(A,D,B,E,C,F).
lin1 :- A>=3, B=:=A-2, C=:=A-3, D=<E+F-1, lin2(A,D,B,E,C,F).
inv1 :- \+lin1.
