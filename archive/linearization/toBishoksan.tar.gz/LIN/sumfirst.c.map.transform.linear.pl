incorrect :- A=:=0, B>=1, new1(A,B).
incorrect :- A=:=0, B=< -1, new1(A,B).
inv1 :- \+incorrect.
new1(A,B) :- C=:=0, D=:=0, new2(A,C,D,E,B,F).
new2(A,B,C,A,B,C) :- D>=E+1, D=:=C, C>=0, E=:=A, A>=0.
new2(A,B,C,D,E,F) :- G=<H, G=:=C, C>=0, H=:=A, A>=0, I=:=J+K, J=:=B, B>=0, 
          K=:=C, C>=0, L=:=M+N, M=:=C, C>=0, N=:=1, new2(A,I,L,D,E,F).
