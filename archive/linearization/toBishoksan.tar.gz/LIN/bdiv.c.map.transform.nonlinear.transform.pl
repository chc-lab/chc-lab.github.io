lin60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=A, A>=0, H1=:=B, B>=0, I1=:=J1+K1, J1=:=B, B>=0, K1=:=B, 
          B>=0, L1=:=M1+N1, M1=:=G, G>=0, N1=:=1, O1>=P1, O1=:=T, T>=0, P1=:=1, 
          Q1=:=R1-S1, R1=:=T, T>=0, S1=:=1, T1=:=U1+V1, U1=:=U, U>=0, V1=:=U, 
          U>=0, 
          lin60(A,I1,C,D,E,F,L1,H,I,J,K,L,M,N,O,P,Q,R,S,Q1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=A, A>=0, H1=:=B, B>=0, I1=:=J1+K1, J1=:=B, B>=0, K1=:=B, 
          B>=0, L1=:=M1+N1, M1=:=G, G>=0, N1=:=1, O1+1=<P1, O1=:=T, T>=0, 
          P1=:=1, Q1=:=R1+S1, R1=:=S, S>=0, S1=:=U, U>=0, 
          lin8(A,I1,C,D,E,F,L1,H,I,J,K,L,M,N,O,P,Q,R,Q1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=A, A>=0, H1=:=B, B>=0, I1>=J1, I1=:=T, T>=0, J1=:=1, 
          K1=:=L1-M1, L1=:=T, T>=0, M1=:=1, N1=:=O1+P1, O1=:=U, U>=0, P1=:=U, 
          U>=0, 
          lin17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,K1,N1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin60(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=A, A>=0, H1=:=B, B>=0, I1+1=<J1, I1=:=T, T>=0, J1=:=1, 
          K1=:=L1+M1, L1=:=S, S>=0, M1=:=U, U>=0, 
          lin18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,K1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=D, D>=0, H1=:=1, I1=:=J1-K1, J1=:=D, D>=0, K1=:=1, 
          L1=:=M1+N1, M1=:=E, E>=0, N1=:=E, E>=0, O1>=P1, O1=:=Q, Q>=0, P1=:=R, 
          R>=0, Q1=:=R1+S1, R1=:=R, R>=0, S1=:=R, R>=0, T1=:=U1+V1, U1=:=W, 
          W>=0, V1=:=1, 
          lin49(A,B,C,I1,L1,F,G,H,I,J,K,L,M,N,O,P,Q,Q1,S,T,U,V,T1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=D, D>=0, H1=:=1, I1=:=J1-K1, J1=:=D, D>=0, K1=:=1, 
          L1=:=M1+N1, M1=:=E, E>=0, N1=:=E, E>=0, O1+1=<P1, O1=:=Q, Q>=0, 
          P1=:=R, R>=0, 
          lin15(A,B,C,I1,L1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=D, D>=0, H1=:=1, I1=:=J1+K1, J1=:=C, C>=0, K1=:=E, 
          E>=0, L1>=M1, L1=:=Q, Q>=0, M1=:=R, R>=0, N1=:=O1+P1, O1=:=R, R>=0, 
          P1=:=R, R>=0, Q1=:=R1+S1, R1=:=W, W>=0, S1=:=1, 
          lin9(A,B,I1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,N1,S,T,U,V,Q1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin49(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=D, D>=0, H1=:=1, I1=:=J1+K1, J1=:=C, C>=0, K1=:=E, 
          E>=0, L1+1=<M1, L1=:=Q, Q>=0, M1=:=R, R>=0, 
          lin18(A,B,I1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R, Q=:=A, A>=0, R=:=B, B>=0, 
          S=:=T+U, T=:=B, B>=0, U=:=B, B>=0, V=:=W+X, W=:=G, G>=0, X=:=1, 
          lin47(A,S,C,D,E,F,V,H,I,J,K,L,M,N,O,P).
lin47(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=A, A>=0, R=:=B, B>=0, 
          lin12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
lin18(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,I,J,K,L,M,N,O,P) :- Q=<R, 
          Q=:=B, B>=0, R=:=F, F>=0, S=<T, S=:=J, J>=0, T=:=N, N>=0.
lin18(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=<Z, 
          Y=:=B, B>=0, Z=:=F, F>=0, A1>=B1+1, A1=:=J, J>=0, B1=:=N, N>=0, 
          J=:=2*P, C1=:=P, P>=0, D1=:=E1-F1, E1=:=O, O>=0, F1=:=1, G1>=H1, 
          G1=:=I, I>=0, H1=:=C1, C1>=0, I1=:=J1-K1, J1=:=I, I>=0, K1=:=C1, 
          C1>=0, L1=:=D1, D1>=0, M1=:=1, 
          lin11(I1,C1,K,L1,M1,N,D1,P,Q,R,S,T,U,V,W,X).
lin18(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=<Z, 
          Y=:=B, B>=0, Z=:=F, F>=0, A1>=B1+1, A1=:=J, J>=0, B1=:=N, N>=0, 
          J=:=2*P, C1=:=P, P>=0, D1=:=E1-F1, E1=:=O, O>=0, F1=:=1, G1+1=<H1, 
          G1=:=I, I>=0, H1=:=C1, C1>=0, 
          lin12(I,C1,K,L,M,N,D1,P,Q,R,S,T,U,V,W,X).
lin18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Q,R,S,T,U,V,W,X) :- 
          Y>=Z+1, Y=:=B, B>=0, Z=:=F, F>=0, B=:=2*H, A1=:=H, H>=0, B1=:=C1-D1, 
          C1=:=G, G>=0, D1=:=1, E1>=F1, E1=:=A, A>=0, F1=:=A1, A1>=0, 
          G1=:=H1-I1, H1=:=A, A>=0, I1=:=A1, A1>=0, J1=:=B1, B1>=0, K1=:=1, 
          L1=<M1, L1=:=R, R>=0, M1=:=V, V>=0, 
          lin11(G1,A1,C,J1,K1,F,B1,H,I,J,K,L,M,N,O,P).
lin18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1>=N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1=:=P1-Q1, P1=:=A, A>=0, Q1=:=I1, I1>=0, R1=:=J1, J1>=0, 
          S1=:=1, T1>=U1+1, T1=:=R, R>=0, U1=:=V, V>=0, R=:=2*X, V1=:=X, X>=0, 
          W1=:=X1-Y1, X1=:=W, W>=0, Y1=:=1, Z1>=A2, Z1=:=Q, Q>=0, A2=:=V1, 
          V1>=0, B2=:=C2-D2, C2=:=Q, Q>=0, D2=:=V1, V1>=0, E2=:=W1, W1>=0, 
          F2=:=1, 
          lin14(O1,I1,C,R1,S1,F,J1,H,I,J,K,L,M,N,O,P,B2,V1,S,E2,F2,V,W1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1>=N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1=:=P1-Q1, P1=:=A, A>=0, Q1=:=I1, I1>=0, R1=:=J1, J1>=0, 
          S1=:=1, T1>=U1+1, T1=:=R, R>=0, U1=:=V, V>=0, R=:=2*X, V1=:=X, X>=0, 
          W1=:=X1-Y1, X1=:=W, W>=0, Y1=:=1, Z1+1=<A2, Z1=:=Q, Q>=0, A2=:=V1, 
          V1>=0, 
          lin15(O1,I1,C,R1,S1,F,J1,H,I,J,K,L,M,N,O,P,Q,V1,S,T,U,V,W1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Q,R,S,T,U,V,W,X) :- 
          Y>=Z+1, Y=:=B, B>=0, Z=:=F, F>=0, B=:=2*H, A1=:=H, H>=0, B1=:=C1-D1, 
          C1=:=G, G>=0, D1=:=1, E1+1=<F1, E1=:=A, A>=0, F1=:=A1, A1>=0, G1=<H1, 
          G1=:=R, R>=0, H1=:=V, V>=0, lin12(A,A1,C,D,E,F,B1,H,I,J,K,L,M,N,O,P).
lin18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1+1=<N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1>=P1+1, O1=:=R, R>=0, P1=:=V, V>=0, R=:=2*X, Q1=:=X, X>=0, 
          R1=:=S1-T1, S1=:=W, W>=0, T1=:=1, U1>=V1, U1=:=Q, Q>=0, V1=:=Q1, 
          Q1>=0, W1=:=X1-Y1, X1=:=Q, Q>=0, Y1=:=Q1, Q1>=0, Z1=:=R1, R1>=0, 
          A2=:=1, 
          lin17(A,I1,C,D,E,F,J1,H,I,J,K,L,M,N,O,P,W1,Q1,S,Z1,A2,V,R1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1+1=<N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1>=P1+1, O1=:=R, R>=0, P1=:=V, V>=0, R=:=2*X, Q1=:=X, X>=0, 
          R1=:=S1-T1, S1=:=W, W>=0, T1=:=1, U1+1=<V1, U1=:=Q, Q>=0, V1=:=Q1, 
          Q1>=0, 
          lin18(A,I1,C,D,E,F,J1,H,I,J,K,L,M,N,O,P,Q,Q1,S,T,U,V,R1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin17(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=<Z, 
          Y=:=B, B>=0, Z=:=F, F>=0, A1>=B1, A1=:=L, L>=0, B1=:=1, C1=:=D1-E1, 
          D1=:=L, L>=0, E1=:=1, F1=:=G1+H1, G1=:=M, M>=0, H1=:=M, M>=0, 
          lin11(I,J,K,C1,F1,N,O,P,Q,R,S,T,U,V,W,X).
lin17(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=<Z, 
          Y=:=B, B>=0, Z=:=F, F>=0, A1+1=<B1, A1=:=L, L>=0, B1=:=1, C1=:=D1+E1, 
          D1=:=K, K>=0, E1=:=M, M>=0, lin12(I,J,C1,L,M,N,O,P,Q,R,S,T,U,V,W,X).
lin17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1>=N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1=:=P1-Q1, P1=:=A, A>=0, Q1=:=I1, I1>=0, R1=:=J1, J1>=0, 
          S1=:=1, T1>=U1, T1=:=T, T>=0, U1=:=1, V1=:=W1-X1, W1=:=T, T>=0, 
          X1=:=1, Y1=:=Z1+A2, Z1=:=U, U>=0, A2=:=U, U>=0, 
          lin14(O1,I1,C,R1,S1,F,J1,H,I,J,K,L,M,N,O,P,Q,R,S,V1,Y1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1>=N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1=:=P1-Q1, P1=:=A, A>=0, Q1=:=I1, I1>=0, R1=:=J1, J1>=0, 
          S1=:=1, T1+1=<U1, T1=:=T, T>=0, U1=:=1, V1=:=W1+X1, W1=:=S, S>=0, 
          X1=:=U, U>=0, 
          lin15(O1,I1,C,R1,S1,F,J1,H,I,J,K,L,M,N,O,P,Q,R,V1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1+1=<N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1>=P1, O1=:=T, T>=0, P1=:=1, Q1=:=R1-S1, R1=:=T, T>=0, 
          S1=:=1, T1=:=U1+V1, U1=:=U, U>=0, V1=:=U, U>=0, 
          lin17(A,I1,C,D,E,F,J1,H,I,J,K,L,M,N,O,P,Q,R,S,Q1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1+1=<N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1+1=<P1, O1=:=T, T>=0, P1=:=1, Q1=:=R1+S1, R1=:=S, S>=0, 
          S1=:=U, U>=0, 
          lin18(A,I1,C,D,E,F,J1,H,I,J,K,L,M,N,O,P,Q,R,Q1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Q,R,S,T,U,V,W,X) :- Y>=Z, 
          Y=:=D, D>=0, Z=:=1, A1=:=B1-C1, B1=:=D, D>=0, C1=:=1, D1=:=E1+F1, 
          E1=:=E, E>=0, F1=:=E, E>=0, G1=<H1, G1=:=R, R>=0, H1=:=V, V>=0, 
          lin11(A,B,C,A1,D1,F,G,H,I,J,K,L,M,N,O,P).
lin15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=D, D>=0, H1=:=1, I1=:=J1-K1, J1=:=D, D>=0, K1=:=1, 
          L1=:=M1+N1, M1=:=E, E>=0, N1=:=E, E>=0, O1>=P1+1, O1=:=R, R>=0, 
          P1=:=V, V>=0, R=:=2*X, Q1=:=X, X>=0, R1=:=S1-T1, S1=:=W, W>=0, 
          T1=:=1, U1>=V1, U1=:=Q, Q>=0, V1=:=Q1, Q1>=0, W1=:=X1-Y1, X1=:=Q, 
          Q>=0, Y1=:=Q1, Q1>=0, Z1=:=R1, R1>=0, A2=:=1, 
          lin14(A,B,C,I1,L1,F,G,H,I,J,K,L,M,N,O,P,W1,Q1,S,Z1,A2,V,R1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=D, D>=0, H1=:=1, I1=:=J1-K1, J1=:=D, D>=0, K1=:=1, 
          L1=:=M1+N1, M1=:=E, E>=0, N1=:=E, E>=0, O1>=P1+1, O1=:=R, R>=0, 
          P1=:=V, V>=0, R=:=2*X, Q1=:=X, X>=0, R1=:=S1-T1, S1=:=W, W>=0, 
          T1=:=1, U1+1=<V1, U1=:=Q, Q>=0, V1=:=Q1, Q1>=0, 
          lin15(A,B,C,I1,L1,F,G,H,I,J,K,L,M,N,O,P,Q,Q1,S,T,U,V,R1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Q,R,S,T,U,V,W,X) :- 
          Y+1=<Z, Y=:=D, D>=0, Z=:=1, A1=:=B1+C1, B1=:=C, C>=0, C1=:=E, E>=0, 
          D1=<E1, D1=:=R, R>=0, E1=:=V, V>=0, 
          lin12(A,B,A1,D,E,F,G,H,I,J,K,L,M,N,O,P).
lin15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=D, D>=0, H1=:=1, I1=:=J1+K1, J1=:=C, C>=0, K1=:=E, 
          E>=0, L1>=M1+1, L1=:=R, R>=0, M1=:=V, V>=0, R=:=2*X, N1=:=X, X>=0, 
          O1=:=P1-Q1, P1=:=W, W>=0, Q1=:=1, R1>=S1, R1=:=Q, Q>=0, S1=:=N1, 
          N1>=0, T1=:=U1-V1, U1=:=Q, Q>=0, V1=:=N1, N1>=0, W1=:=O1, O1>=0, 
          X1=:=1, 
          lin17(A,B,I1,D,E,F,G,H,I,J,K,L,M,N,O,P,T1,N1,S,W1,X1,V,O1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin15(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=D, D>=0, H1=:=1, I1=:=J1+K1, J1=:=C, C>=0, K1=:=E, 
          E>=0, L1>=M1+1, L1=:=R, R>=0, M1=:=V, V>=0, R=:=2*X, N1=:=X, X>=0, 
          O1=:=P1-Q1, P1=:=W, W>=0, Q1=:=1, R1+1=<S1, R1=:=Q, Q>=0, S1=:=N1, 
          N1>=0, 
          lin18(A,B,I1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,N1,S,T,U,V,O1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=D, D>=0, H1=:=1, I1=:=J1-K1, J1=:=D, D>=0, K1=:=1, 
          L1=:=M1+N1, M1=:=E, E>=0, N1=:=E, E>=0, O1>=P1, O1=:=T, T>=0, P1=:=1, 
          Q1=:=R1-S1, R1=:=T, T>=0, S1=:=1, T1=:=U1+V1, U1=:=U, U>=0, V1=:=U, 
          U>=0, 
          lin14(A,B,C,I1,L1,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,Q1,T1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=D, D>=0, H1=:=1, I1=:=J1-K1, J1=:=D, D>=0, K1=:=1, 
          L1=:=M1+N1, M1=:=E, E>=0, N1=:=E, E>=0, O1+1=<P1, O1=:=T, T>=0, 
          P1=:=1, Q1=:=R1+S1, R1=:=S, S>=0, S1=:=U, U>=0, 
          lin15(A,B,C,I1,L1,F,G,H,I,J,K,L,M,N,O,P,Q,R,Q1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=D, D>=0, H1=:=1, I1=:=J1+K1, J1=:=C, C>=0, K1=:=E, 
          E>=0, L1>=M1, L1=:=T, T>=0, M1=:=1, N1=:=O1-P1, O1=:=T, T>=0, P1=:=1, 
          Q1=:=R1+S1, R1=:=U, U>=0, S1=:=U, U>=0, 
          lin17(A,B,I1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,N1,Q1,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin14(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=D, D>=0, H1=:=1, I1=:=J1+K1, J1=:=C, C>=0, K1=:=E, 
          E>=0, L1+1=<M1, L1=:=T, T>=0, M1=:=1, N1=:=O1+P1, O1=:=S, S>=0, 
          P1=:=U, U>=0, 
          lin18(A,B,I1,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,N1,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin12(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H) :- I=<J, I=:=B, B>=0, J=:=F, F>=0.
lin12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=B, B>=0, R=:=F, F>=0, 
          B=:=2*H, S=:=H, H>=0, T=:=U-V, U=:=G, G>=0, V=:=1, W>=X, W=:=A, A>=0, 
          X=:=S, S>=0, Y=:=Z-A1, Z=:=A, A>=0, A1=:=S, S>=0, B1=:=T, T>=0, 
          C1=:=1, lin11(Y,S,C,B1,C1,F,T,H,I,J,K,L,M,N,O,P).
lin12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R+1, Q=:=B, B>=0, R=:=F, F>=0, 
          B=:=2*H, S=:=H, H>=0, T=:=U-V, U=:=G, G>=0, V=:=1, W+1=<X, W=:=A, 
          A>=0, X=:=S, S>=0, lin12(A,S,C,D,E,F,T,H,I,J,K,L,M,N,O,P).
lin11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q>=R, Q=:=D, D>=0, R=:=1, S=:=T-U, 
          T=:=D, D>=0, U=:=1, V=:=W+X, W=:=E, E>=0, X=:=E, E>=0, 
          lin11(A,B,C,S,V,F,G,H,I,J,K,L,M,N,O,P).
lin11(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- Q+1=<R, Q=:=D, D>=0, R=:=1, S=:=T+U, 
          T=:=C, C>=0, U=:=E, E>=0, lin12(A,B,S,D,E,F,G,H,I,J,K,L,M,N,O,P).
lin10(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,I,B,J,K,L,M,N,O) :- P=<Q, 
          P=:=B, B>=0, Q=:=F, F>=0, R=<S, R=:=B, B>=0, S=:=M, M>=0.
lin10(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=<Y, 
          X=:=B, B>=0, Y=:=F, F>=0, Z>=A1+1, Z=:=B, B>=0, A1=:=M, M>=0, 
          B=:=2*O, B1=:=O, O>=0, C1=:=D1-E1, D1=:=N, N>=0, E1=:=1, F1>=G1, 
          F1=:=I, I>=0, G1=:=B1, B1>=0, H1=:=I1-J1, I1=:=I, I>=0, J1=:=B1, 
          B1>=0, K1=:=C1, C1>=0, L1=:=1, 
          lin11(H1,B1,J,K1,L1,M,C1,O,P,Q,R,S,T,U,V,W).
lin10(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W) :- X=<Y, 
          X=:=B, B>=0, Y=:=F, F>=0, Z>=A1+1, Z=:=B, B>=0, A1=:=M, M>=0, 
          B=:=2*O, B1=:=O, O>=0, C1=:=D1-E1, D1=:=N, N>=0, E1=:=1, F1+1=<G1, 
          F1=:=I, I>=0, G1=:=B1, B1>=0, 
          lin12(I,B1,J,K,L,M,C1,O,P,Q,R,S,T,U,V,W).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,Q,B,R,S,T,U,V,W) :- X>=Y+1, 
          X=:=B, B>=0, Y=:=F, F>=0, B=:=2*H, Z=:=H, H>=0, A1=:=B1-C1, B1=:=G, 
          G>=0, C1=:=1, D1>=E1, D1=:=A, A>=0, E1=:=Z, Z>=0, F1=:=G1-H1, G1=:=A, 
          A>=0, H1=:=Z, Z>=0, I1=:=A1, A1>=0, J1=:=1, K1=<L1, K1=:=B, B>=0, 
          L1=:=U, U>=0, lin11(F1,Z,C,I1,J1,F,A1,H,I,J,K,L,M,N,O,P).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=B, B>=0, G1=:=F, F>=0, B=:=2*H, H1=:=H, H>=0, 
          I1=:=J1-K1, J1=:=G, G>=0, K1=:=1, L1>=M1, L1=:=A, A>=0, M1=:=H1, 
          H1>=0, N1=:=O1-P1, O1=:=A, A>=0, P1=:=H1, H1>=0, Q1=:=I1, I1>=0, 
          R1=:=1, S1>=T1+1, S1=:=B, B>=0, T1=:=U, U>=0, B=:=2*W, U1=:=W, W>=0, 
          V1=:=W1-X1, W1=:=V, V>=0, X1=:=1, Y1>=Z1, Y1=:=Q, Q>=0, Z1=:=U1, 
          U1>=0, A2=:=B2-C2, B2=:=Q, Q>=0, C2=:=U1, U1>=0, D2=:=V1, V1>=0, 
          E2=:=1, 
          lin14(N1,H1,C,Q1,R1,F,I1,H,I,J,K,L,M,N,O,P,A2,U1,R,D2,E2,U,V1,W,X,Y,Z,A1,B1,C1,D1,E1).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=B, B>=0, G1=:=F, F>=0, B=:=2*H, H1=:=H, H>=0, 
          I1=:=J1-K1, J1=:=G, G>=0, K1=:=1, L1>=M1, L1=:=A, A>=0, M1=:=H1, 
          H1>=0, N1=:=O1-P1, O1=:=A, A>=0, P1=:=H1, H1>=0, Q1=:=I1, I1>=0, 
          R1=:=1, S1>=T1+1, S1=:=B, B>=0, T1=:=U, U>=0, B=:=2*W, U1=:=W, W>=0, 
          V1=:=W1-X1, W1=:=V, V>=0, X1=:=1, Y1+1=<Z1, Y1=:=Q, Q>=0, Z1=:=U1, 
          U1>=0, 
          lin15(N1,H1,C,Q1,R1,F,I1,H,I,J,K,L,M,N,O,P,Q,U1,R,S,T,U,V1,W,X,Y,Z,A1,B1,C1,D1,E1).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,Q,B,R,S,T,U,V,W) :- X>=Y+1, 
          X=:=B, B>=0, Y=:=F, F>=0, B=:=2*H, Z=:=H, H>=0, A1=:=B1-C1, B1=:=G, 
          G>=0, C1=:=1, D1+1=<E1, D1=:=A, A>=0, E1=:=Z, Z>=0, F1=<G1, F1=:=B, 
          B>=0, G1=:=U, U>=0, lin12(A,Z,C,D,E,F,A1,H,I,J,K,L,M,N,O,P).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=B, B>=0, G1=:=F, F>=0, B=:=2*H, H1=:=H, H>=0, 
          I1=:=J1-K1, J1=:=G, G>=0, K1=:=1, L1+1=<M1, L1=:=A, A>=0, M1=:=H1, 
          H1>=0, N1>=O1+1, N1=:=B, B>=0, O1=:=U, U>=0, B=:=2*W, P1=:=W, W>=0, 
          Q1=:=R1-S1, R1=:=V, V>=0, S1=:=1, T1>=U1, T1=:=Q, Q>=0, U1=:=P1, 
          P1>=0, V1=:=W1-X1, W1=:=Q, Q>=0, X1=:=P1, P1>=0, Y1=:=Q1, Q1>=0, 
          Z1=:=1, 
          lin17(A,H1,C,D,E,F,I1,H,I,J,K,L,M,N,O,P,V1,P1,R,Y1,Z1,U,Q1,W,X,Y,Z,A1,B1,C1,D1,E1).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1+1, F1=:=B, B>=0, G1=:=F, F>=0, B=:=2*H, H1=:=H, H>=0, 
          I1=:=J1-K1, J1=:=G, G>=0, K1=:=1, L1+1=<M1, L1=:=A, A>=0, M1=:=H1, 
          H1>=0, N1>=O1+1, N1=:=B, B>=0, O1=:=U, U>=0, B=:=2*W, P1=:=W, W>=0, 
          Q1=:=R1-S1, R1=:=V, V>=0, S1=:=1, T1+1=<U1, T1=:=Q, Q>=0, U1=:=P1, 
          P1>=0, 
          lin18(A,H1,C,D,E,F,I1,H,I,J,K,L,M,N,O,P,Q,P1,R,S,T,U,Q1,W,X,Y,Z,A1,B1,C1,D1,E1).
lin9(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=<Z, 
          Y=:=B, B>=0, Z=:=F, F>=0, A1>=B1, A1=:=I, I>=0, B1=:=J, J>=0, 
          C1=:=D1+E1, D1=:=J, J>=0, E1=:=J, J>=0, F1=:=G1+H1, G1=:=O, O>=0, 
          H1=:=1, lin47(I,C1,K,L,M,N,F1,P,Q,R,S,T,U,V,W,X).
lin9(A,B,C,D,E,F,G,H,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y=<Z, 
          Y=:=B, B>=0, Z=:=F, F>=0, A1+1=<B1, A1=:=I, I>=0, B1=:=J, J>=0, 
          lin12(I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X).
lin9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1>=N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1=:=P1-Q1, P1=:=A, A>=0, Q1=:=I1, I1>=0, R1=:=J1, J1>=0, 
          S1=:=1, T1>=U1, T1=:=Q, Q>=0, U1=:=R, R>=0, V1=:=W1+X1, W1=:=R, R>=0, 
          X1=:=R, R>=0, Y1=:=Z1+A2, Z1=:=W, W>=0, A2=:=1, 
          lin49(O1,I1,C,R1,S1,F,J1,H,I,J,K,L,M,N,O,P,Q,V1,S,T,U,V,Y1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1>=N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1=:=P1-Q1, P1=:=A, A>=0, Q1=:=I1, I1>=0, R1=:=J1, J1>=0, 
          S1=:=1, T1+1=<U1, T1=:=Q, Q>=0, U1=:=R, R>=0, 
          lin15(O1,I1,C,R1,S1,F,J1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1+1=<N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1>=P1, O1=:=Q, Q>=0, P1=:=R, R>=0, Q1=:=R1+S1, R1=:=R, R>=0, 
          S1=:=R, R>=0, T1=:=U1+V1, U1=:=W, W>=0, V1=:=1, 
          lin9(A,I1,C,D,E,F,J1,H,I,J,K,L,M,N,O,P,Q,Q1,S,T,U,V,T1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1+1, G1=:=B, B>=0, H1=:=F, F>=0, B=:=2*H, I1=:=H, H>=0, 
          J1=:=K1-L1, K1=:=G, G>=0, L1=:=1, M1+1=<N1, M1=:=A, A>=0, N1=:=I1, 
          I1>=0, O1+1=<P1, O1=:=Q, Q>=0, P1=:=R, R>=0, 
          lin18(A,I1,C,D,E,F,J1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Q,R,S,T,U,V,W,X) :- Y>=Z, 
          Y=:=A, A>=0, Z=:=B, B>=0, A1=:=B1+C1, B1=:=B, B>=0, C1=:=B, B>=0, 
          D1=:=E1+F1, E1=:=G, G>=0, F1=:=1, G1=<H1, G1=:=R, R>=0, H1=:=V, V>=0, 
          lin47(A,A1,C,D,E,F,D1,H,I,J,K,L,M,N,O,P).
lin8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=A, A>=0, H1=:=B, B>=0, I1=:=J1+K1, J1=:=B, B>=0, K1=:=B, 
          B>=0, L1=:=M1+N1, M1=:=G, G>=0, N1=:=1, O1>=P1+1, O1=:=R, R>=0, 
          P1=:=V, V>=0, R=:=2*X, Q1=:=X, X>=0, R1=:=S1-T1, S1=:=W, W>=0, 
          T1=:=1, U1>=V1, U1=:=Q, Q>=0, V1=:=Q1, Q1>=0, W1=:=X1-Y1, X1=:=Q, 
          Q>=0, Y1=:=Q1, Q1>=0, Z1=:=R1, R1>=0, A2=:=1, 
          lin60(A,I1,C,D,E,F,L1,H,I,J,K,L,M,N,O,P,W1,Q1,S,Z1,A2,V,R1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=A, A>=0, H1=:=B, B>=0, I1=:=J1+K1, J1=:=B, B>=0, K1=:=B, 
          B>=0, L1=:=M1+N1, M1=:=G, G>=0, N1=:=1, O1>=P1+1, O1=:=R, R>=0, 
          P1=:=V, V>=0, R=:=2*X, Q1=:=X, X>=0, R1=:=S1-T1, S1=:=W, W>=0, 
          T1=:=1, U1+1=<V1, U1=:=Q, Q>=0, V1=:=Q1, Q1>=0, 
          lin8(A,I1,C,D,E,F,L1,H,I,J,K,L,M,N,O,P,Q,Q1,S,T,U,V,R1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Q,R,S,T,U,V,W,X) :- 
          Y+1=<Z, Y=:=A, A>=0, Z=:=B, B>=0, A1=<B1, A1=:=R, R>=0, B1=:=V, V>=0, 
          lin12(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P).
lin8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=A, A>=0, H1=:=B, B>=0, I1>=J1+1, I1=:=R, R>=0, J1=:=V, 
          V>=0, R=:=2*X, K1=:=X, X>=0, L1=:=M1-N1, M1=:=W, W>=0, N1=:=1, 
          O1>=P1, O1=:=Q, Q>=0, P1=:=K1, K1>=0, Q1=:=R1-S1, R1=:=Q, Q>=0, 
          S1=:=K1, K1>=0, T1=:=L1, L1>=0, U1=:=1, 
          lin17(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q1,K1,S,T1,U1,V,L1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin8(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=A, A>=0, H1=:=B, B>=0, I1>=J1+1, I1=:=R, R>=0, J1=:=V, 
          V>=0, R=:=2*X, K1=:=X, X>=0, L1=:=M1-N1, M1=:=W, W>=0, N1=:=1, 
          O1+1=<P1, O1=:=Q, Q>=0, P1=:=K1, K1>=0, 
          lin18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1,S,T,U,V,L1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=A, A>=0, H1=:=B, B>=0, I1=:=J1+K1, J1=:=B, B>=0, K1=:=B, 
          B>=0, L1=:=M1+N1, M1=:=G, G>=0, N1=:=1, O1>=P1, O1=:=Q, Q>=0, P1=:=R, 
          R>=0, Q1=:=R1+S1, R1=:=R, R>=0, S1=:=R, R>=0, T1=:=U1+V1, U1=:=W, 
          W>=0, V1=:=1, 
          lin7(A,I1,C,D,E,F,L1,H,I,J,K,L,M,N,O,P,Q,Q1,S,T,U,V,T1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1>=H1, G1=:=A, A>=0, H1=:=B, B>=0, I1=:=J1+K1, J1=:=B, B>=0, K1=:=B, 
          B>=0, L1=:=M1+N1, M1=:=G, G>=0, N1=:=1, O1+1=<P1, O1=:=Q, Q>=0, 
          P1=:=R, R>=0, 
          lin8(A,I1,C,D,E,F,L1,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=A, A>=0, H1=:=B, B>=0, I1>=J1, I1=:=Q, Q>=0, J1=:=R, 
          R>=0, K1=:=L1+M1, L1=:=R, R>=0, M1=:=R, R>=0, N1=:=O1+P1, O1=:=W, 
          W>=0, P1=:=1, 
          lin9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,K1,S,T,U,V,N1,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1) :- 
          G1+1=<H1, G1=:=A, A>=0, H1=:=B, B>=0, I1+1=<J1, I1=:=Q, Q>=0, J1=:=R, 
          R>=0, 
          lin18(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1, F1=:=A, A>=0, G1=:=B, B>=0, H1=:=I1+J1, I1=:=B, B>=0, J1=:=B, 
          B>=0, K1=:=L1+M1, L1=:=G, G>=0, M1=:=1, N1>=O1, N1=:=Q, Q>=0, O1=:=B, 
          B>=0, P1=:=Q1+R1, Q1=:=B, B>=0, R1=:=B, B>=0, S1=:=T1+U1, T1=:=V, 
          V>=0, U1=:=1, 
          lin7(A,H1,C,D,E,F,K1,H,I,J,K,L,M,N,O,P,Q,P1,R,S,T,U,S1,W,X,Y,Z,A1,B1,C1,D1,E1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1>=G1, F1=:=A, A>=0, G1=:=B, B>=0, H1=:=I1+J1, I1=:=B, B>=0, J1=:=B, 
          B>=0, K1=:=L1+M1, L1=:=G, G>=0, M1=:=1, N1+1=<O1, N1=:=Q, Q>=0, 
          O1=:=B, B>=0, 
          lin8(A,H1,C,D,E,F,K1,H,I,J,K,L,M,N,O,P,Q,B,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=A, A>=0, G1=:=B, B>=0, H1>=I1, H1=:=Q, Q>=0, I1=:=B, 
          B>=0, J1=:=K1+L1, K1=:=B, B>=0, L1=:=B, B>=0, M1=:=N1+O1, N1=:=V, 
          V>=0, O1=:=1, 
          lin9(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,J1,R,S,T,U,M1,W,X,Y,Z,A1,B1,C1,D1,E1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1) :- 
          F1+1=<G1, F1=:=A, A>=0, G1=:=B, B>=0, H1+1=<I1, H1=:=Q, Q>=0, I1=:=B, 
          B>=0, 
          lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1).
lin2(A,B,C,D,E,F,G) :- H=:=0, I=:=B, B>=0, J=:=0, K=:=0, L=:=B, B>=0, M=:=0, 
          lin6(A,B,H,N,O,I,J,P,D,Q,C,R,S,T,U,V,E,K,W,X,L,M,Y,G,Z,F,A1,B1,C1,D1,E1).
lin1 :- A>=B+1, C=:=A-B, D>=E+2, lin2(A,B,D,F,C,E,G).
lin1 :- A>=B+1, C=:=A-B, D=<E, lin2(A,B,D,F,C,E,G).
lin1 :- A>=B+1, C=:=A-B, D>=E+1, lin2(A,B,F,D,C,G,E).
lin1 :- A>=B+1, C=:=A-B, D=<E-1, lin2(A,B,F,D,C,G,E).
inv1 :- \+lin1.
