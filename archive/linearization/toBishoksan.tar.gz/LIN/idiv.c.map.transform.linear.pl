incorrect :- A>=0, A+1=<B, C>=1, new1(A,B,C).
incorrect :- A>=0, A+1=<B, C=< -1, new1(A,B,C).
inv1 :- \+incorrect.
new1(A,B,C) :- D=:=0, new2(A,B,D,E,F,C).
new2(A,B,C,A,B,C) :- D+1=<E, D=:=A, A>=0, E=:=B, B>=0.
new2(A,B,C,D,E,F) :- G>=H, G=:=A, A>=0, H=:=B, B>=0, I=:=J+K, J=:=C, C>=0, 
          K=:=1, L=:=M-N, M=:=A, A>=0, N=:=B, B>=0, new2(L,B,I,D,E,F).
