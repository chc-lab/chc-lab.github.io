lin7(A,B,C,D,A,B,C,D,E,F,G,H,E,F,G,H) :- B=:=F, C=:=D, C=:=G, C=:=H, D=:=G, 
          D=:=H, G=:=H, I=<J, I=:=A, A>=0, J=:=0, K=<L, K=:=E, E>=0, L=:=0.
lin7(A,B,C,D,A,B,C,D,E,F,G,H,I,J,K,L) :- B=:=F, C=:=D, C=:=G, C=:=H, D=:=G, 
          D=:=H, G=:=H, M=<N, M=:=A, A>=0, N=:=0, O>=P+1, O=:=E, E>=0, P=:=0, 
          Q=:=F, F>=0, R=:=S+T, S=:=F, F>=0, T=:=G, G>=0, U=:=Q, Q>=0, V=:=W-X, 
          W=:=E, E>=0, X=:=1, lin5(V,R,U,Q,I,J,K,L).
lin7(A,B,C,D,E,F,G,H,I,J,K,L,I,J,K,L) :- B=:=J, C=:=D, C=:=K, C=:=L, D=:=K, 
          D=:=L, K=:=L, M>=N+1, M=:=A, A>=0, N=:=0, O=:=B, B>=0, P=:=Q+R, 
          Q=:=B, B>=0, R=:=C, C>=0, S=:=O, O>=0, T=:=U-V, U=:=A, A>=0, V=:=1, 
          W=<X, W=:=I, I>=0, X=:=0, lin5(T,P,S,O,E,F,G,H).
lin7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P) :- B=:=J, C=:=D, C=:=K, C=:=L, D=:=K, 
          D=:=L, K=:=L, Q>=R+1, Q=:=A, A>=0, R=:=0, S=:=B, B>=0, T=:=U+V, 
          U=:=B, B>=0, V=:=C, C>=0, W=:=S, S>=0, X=:=Y-Z, Y=:=A, A>=0, Z=:=1, 
          A1>=B1+1, A1=:=I, I>=0, B1=:=0, C1=:=J, J>=0, D1=:=E1+F1, E1=:=J, 
          J>=0, F1=:=K, K>=0, G1=:=C1, C1>=0, H1=:=I1-J1, I1=:=I, I>=0, J1=:=1, 
          lin7(X,T,W,S,E,F,G,H,H1,D1,G1,C1,M,N,O,P).
lin5(A,B,C,D,A,B,C,D) :- C=:=D, E=<F, E=:=A, A>=0, F=:=0.
lin5(A,B,C,D,E,F,G,H) :- C=:=D, I>=J+1, I=:=A, A>=0, J=:=0, K=:=B, B>=0, 
          L=:=M+N, M=:=B, B>=0, N=:=C, C>=0, O=:=K, K>=0, P=:=Q-R, Q=:=A, A>=0, 
          R=:=1, lin5(P,L,O,K,E,F,G,H).
lin4(A,B,C,D,A,B,C,D,E,F,G,H,E,F,G,H,I,J,K,L,I,J,K,L) :- B=:=F, B=:=J, C=:=D, 
          C=:=G, C=:=H, C=:=K, C=:=L, D=:=G, D=:=H, D=:=K, D=:=L, F=:=J, G=:=H, 
          G=:=K, G=:=L, H=:=K, H=:=L, K=:=L, M=<N, M=:=A, A>=0, N=:=0, O=<P, 
          O=:=E, E>=0, P=:=0, Q=<R, Q=:=I, I>=0, R=:=0.
lin4(A,B,C,D,A,B,C,D,E,F,G,H,E,F,G,H,I,J,K,L,M,N,O,P) :- B=:=F, B=:=J, C=:=D, 
          C=:=G, C=:=H, C=:=K, C=:=L, D=:=G, D=:=H, D=:=K, D=:=L, F=:=J, G=:=H, 
          G=:=K, G=:=L, H=:=K, H=:=L, K=:=L, Q=<R, Q=:=A, A>=0, R=:=0, S=<T, 
          S=:=E, E>=0, T=:=0, U>=V+1, U=:=I, I>=0, V=:=0, W=:=J, J>=0, X=:=Y+Z, 
          Y=:=J, J>=0, Z=:=K, K>=0, A1=:=W, W>=0, B1=:=C1-D1, C1=:=I, I>=0, 
          D1=:=1, lin5(B1,X,A1,W,M,N,O,P).
lin4(A,B,C,D,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,M,N,O,P) :- B=:=F, B=:=N, C=:=D, 
          C=:=G, C=:=H, C=:=O, C=:=P, D=:=G, D=:=H, D=:=O, D=:=P, F=:=N, G=:=H, 
          G=:=O, G=:=P, H=:=O, H=:=P, O=:=P, Q=<R, Q=:=A, A>=0, R=:=0, S>=T+1, 
          S=:=E, E>=0, T=:=0, U=:=F, F>=0, V=:=W+X, W=:=F, F>=0, X=:=G, G>=0, 
          Y=:=U, U>=0, Z=:=A1-B1, A1=:=E, E>=0, B1=:=1, C1=<D1, C1=:=M, M>=0, 
          D1=:=0, lin5(Z,V,Y,U,I,J,K,L).
lin4(A,B,C,D,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- B=:=F, B=:=N, C=:=D, 
          C=:=G, C=:=H, C=:=O, C=:=P, D=:=G, D=:=H, D=:=O, D=:=P, F=:=N, G=:=H, 
          G=:=O, G=:=P, H=:=O, H=:=P, O=:=P, U=<V, U=:=A, A>=0, V=:=0, W>=X+1, 
          W=:=E, E>=0, X=:=0, Y=:=F, F>=0, Z=:=A1+B1, A1=:=F, F>=0, B1=:=G, 
          G>=0, C1=:=Y, Y>=0, D1=:=E1-F1, E1=:=E, E>=0, F1=:=1, G1>=H1+1, 
          G1=:=M, M>=0, H1=:=0, I1=:=N, N>=0, J1=:=K1+L1, K1=:=N, N>=0, L1=:=O, 
          O>=0, M1=:=I1, I1>=0, N1=:=O1-P1, O1=:=M, M>=0, P1=:=1, 
          lin7(D1,Z,C1,Y,I,J,K,L,N1,J1,M1,I1,Q,R,S,T).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,I,J,K,L,M,N,O,P,M,N,O,P) :- B=:=J, B=:=N, C=:=D, 
          C=:=K, C=:=L, C=:=O, C=:=P, D=:=K, D=:=L, D=:=O, D=:=P, J=:=N, K=:=L, 
          K=:=O, K=:=P, L=:=O, L=:=P, O=:=P, Q>=R+1, Q=:=A, A>=0, R=:=0, S=:=B, 
          B>=0, T=:=U+V, U=:=B, B>=0, V=:=C, C>=0, W=:=S, S>=0, X=:=Y-Z, Y=:=A, 
          A>=0, Z=:=1, A1=<B1, A1=:=I, I>=0, B1=:=0, C1=<D1, C1=:=M, M>=0, 
          D1=:=0, lin5(X,T,W,S,E,F,G,H).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,I,J,K,L,M,N,O,P,Q,R,S,T) :- B=:=J, B=:=N, C=:=D, 
          C=:=K, C=:=L, C=:=O, C=:=P, D=:=K, D=:=L, D=:=O, D=:=P, J=:=N, K=:=L, 
          K=:=O, K=:=P, L=:=O, L=:=P, O=:=P, U>=V+1, U=:=A, A>=0, V=:=0, W=:=B, 
          B>=0, X=:=Y+Z, Y=:=B, B>=0, Z=:=C, C>=0, A1=:=W, W>=0, B1=:=C1-D1, 
          C1=:=A, A>=0, D1=:=1, E1=<F1, E1=:=I, I>=0, F1=:=0, G1>=H1+1, G1=:=M, 
          M>=0, H1=:=0, I1=:=N, N>=0, J1=:=K1+L1, K1=:=N, N>=0, L1=:=O, O>=0, 
          M1=:=I1, I1>=0, N1=:=O1-P1, O1=:=M, M>=0, P1=:=1, 
          lin7(B1,X,A1,W,E,F,G,H,N1,J1,M1,I1,Q,R,S,T).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,Q,R,S,T) :- B=:=J, B=:=R, C=:=D, 
          C=:=K, C=:=L, C=:=S, C=:=T, D=:=K, D=:=L, D=:=S, D=:=T, J=:=R, K=:=L, 
          K=:=S, K=:=T, L=:=S, L=:=T, S=:=T, U>=V+1, U=:=A, A>=0, V=:=0, W=:=B, 
          B>=0, X=:=Y+Z, Y=:=B, B>=0, Z=:=C, C>=0, A1=:=W, W>=0, B1=:=C1-D1, 
          C1=:=A, A>=0, D1=:=1, E1>=F1+1, E1=:=I, I>=0, F1=:=0, G1=:=J, J>=0, 
          H1=:=I1+J1, I1=:=J, J>=0, J1=:=K, K>=0, K1=:=G1, G1>=0, L1=:=M1-N1, 
          M1=:=I, I>=0, N1=:=1, O1=<P1, O1=:=Q, Q>=0, P1=:=0, 
          lin7(B1,X,A1,W,E,F,G,H,L1,H1,K1,G1,M,N,O,P).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- B=:=J, B=:=R, C=:=D, 
          C=:=K, C=:=L, C=:=S, C=:=T, D=:=K, D=:=L, D=:=S, D=:=T, J=:=R, K=:=L, 
          K=:=S, K=:=T, L=:=S, L=:=T, S=:=T, Y>=Z+1, Y=:=A, A>=0, Z=:=0, 
          A1=:=B, B>=0, B1=:=C1+D1, C1=:=B, B>=0, D1=:=C, C>=0, E1=:=A1, A1>=0, 
          F1=:=G1-H1, G1=:=A, A>=0, H1=:=1, I1>=J1+1, I1=:=I, I>=0, J1=:=0, 
          K1=:=J, J>=0, L1=:=M1+N1, M1=:=J, J>=0, N1=:=K, K>=0, O1=:=K1, K1>=0, 
          P1=:=Q1-R1, Q1=:=I, I>=0, R1=:=1, S1>=T1+1, S1=:=Q, Q>=0, T1=:=0, 
          U1=:=R, R>=0, V1=:=W1+X1, W1=:=R, R>=0, X1=:=S, S>=0, Y1=:=U1, U1>=0, 
          Z1=:=A2-B2, A2=:=Q, Q>=0, B2=:=1, 
          lin4(F1,B1,E1,A1,E,F,G,H,P1,L1,O1,K1,M,N,O,P,Z1,V1,Y1,U1,U,V,W,X).
lin2(A,B,C,D,E,F) :- G=:=1, H=:=0, I=:=0, J=:=1, K=:=0, L=:=0, M=:=1, N=:=0, 
          O=:=0, lin4(A,G,H,I,P,B,Q,R,C,J,K,L,S,D,T,U,E,M,N,O,V,F,W,X).
lin1 :- A>=0, B=A+1, C=B+1, D>=E+F+1, lin2(A,E,B,F,C,D).
lin1 :- A>=0, B=A+1, C=B+1, D+1=<E+F, lin2(A,E,B,F,C,D).
inv1 :- \+lin1.
