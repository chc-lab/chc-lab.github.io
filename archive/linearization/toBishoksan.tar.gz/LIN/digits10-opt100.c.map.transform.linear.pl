incorrect :- A>=0, A=<9, B>=2, new1(A,B).
incorrect :- A>=0, A=<9, B=<0, new1(A,B).
inv1 :- \+incorrect.
new1(A,B) :- C=:=1, new2(A,C,D,E,B,F).
new1(A,B) :- C=:=1, new3(A,C,D,E,B,F).
new2(A,B,C,A,B,C) :- D>=E+1, D=:=1, E=:=0, F+1=<G, F=:=A, A>=0, G=:=10.
new2(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=0, I>=J, I=:=A, A>=0, J=:=10, K>=L, 
          K=:=A, A>=0, L=:=100, M=:=A, A>=0, M=:=100*N+O, N>=0, O>=0, O=<99, 
          P=:=Q+R, Q=:=B, B>=0, R=:=2, new2(N,P,M,D,E,F).
new3(A,B,C,A,D,C) :- E>=F+1, E=:=1, F=:=0, G>=H, G=:=A, A>=0, H=:=10, I+1=<J, 
          I=:=A, A>=0, J=:=100, D=:=K+L, K=:=B, B>=0, L=:=1.
new3(A,B,C,D,E,F) :- G>=H+1, G=:=1, H=:=0, I>=J, I=:=A, A>=0, J=:=10, K>=L, 
          K=:=A, A>=0, L=:=100, M=:=A, A>=0, M=:=100*N+O, N>=0, O>=0, O=<99, 
          P=:=Q+R, Q=:=B, B>=0, R=:=2, new3(N,P,M,D,E,F).
