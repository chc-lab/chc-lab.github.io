lin7(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,F,G,H,I,J) :- K=<L, K=:=A, L=:=0, M=<N, 
          M=:=F, N=:=0.
lin7(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O) :- P=<Q, P=:=A, Q=:=0, R>=S+1, 
          R=:=F, S=:=0, T=:=G, U=:=V+W, V=:=G, W=:=H, X=:=T, Y=:=Z-A1, Z=:=F, 
          A1=:=1, lin5(Y,U,X,T,J,K,L,M,N,O).
lin7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O) :- P>=Q+1, P=:=A, Q=:=0, R=:=B, 
          S=:=T+U, T=:=B, U=:=C, V=:=R, W=:=X-Y, X=:=A, Y=:=1, Z=<A1, Z=:=K, 
          A1=:=0, lin5(W,S,V,R,E,F,G,H,I,J).
lin7(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U>=V+1, U=:=A, V=:=0, W=:=B, 
          X=:=Y+Z, Y=:=B, Z=:=C, A1=:=W, B1=:=C1-D1, C1=:=A, D1=:=1, E1>=F1+1, 
          E1=:=K, F1=:=0, G1=:=L, H1=:=I1+J1, I1=:=L, J1=:=M, K1=:=G1, 
          L1=:=M1-N1, M1=:=K, N1=:=1, 
          lin7(B1,X,A1,W,E,F,G,H,I,J,L1,H1,K1,G1,O,P,Q,R,S,T).
lin5(A,B,C,D,E,A,B,C,D,E) :- F=<G, F=:=A, G=:=0.
lin5(A,B,C,D,E,F,G,H,I,J) :- K>=L+1, K=:=A, L=:=0, M=:=B, N=:=O+P, O=:=B, 
          P=:=C, Q=:=M, R=:=S-T, S=:=A, T=:=1, lin5(R,N,Q,M,E,F,G,H,I,J).
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O) :- P=<Q, 
          P=:=A, Q=:=0, R=<S, R=:=F, S=:=0, T=<U, T=:=K, U=:=0.
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T) :- U=<V, 
          U=:=A, V=:=0, W=<X, W=:=F, X=:=0, Y>=Z+1, Y=:=K, Z=:=0, A1=:=L, 
          B1=:=C1+D1, C1=:=L, D1=:=M, E1=:=A1, F1=:=G1-H1, G1=:=K, H1=:=1, 
          lin5(F1,B1,E1,A1,O,P,Q,R,S,T).
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,P,Q,R,S,T) :- U=<V, 
          U=:=A, V=:=0, W>=X+1, W=:=F, X=:=0, Y=:=G, Z=:=A1+B1, A1=:=G, B1=:=H, 
          C1=:=Y, D1=:=E1-F1, E1=:=F, F1=:=1, G1=<H1, G1=:=P, H1=:=0, 
          lin5(D1,Z,C1,Y,J,K,L,M,N,O).
lin4(A,B,C,D,E,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z=<A1, 
          Z=:=A, A1=:=0, B1>=C1+1, B1=:=F, C1=:=0, D1=:=G, E1=:=F1+G1, F1=:=G, 
          G1=:=H, H1=:=D1, I1=:=J1-K1, J1=:=F, K1=:=1, L1>=M1+1, L1=:=P, 
          M1=:=0, N1=:=Q, O1=:=P1+Q1, P1=:=Q, Q1=:=R, R1=:=N1, S1=:=T1-U1, 
          T1=:=P, U1=:=1, lin7(I1,E1,H1,D1,J,K,L,M,N,O,S1,O1,R1,N1,T,U,V,W,X,Y).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O,P,Q,R,S,T,P,Q,R,S,T) :- U>=V+1, 
          U=:=A, V=:=0, W=:=B, X=:=Y+Z, Y=:=B, Z=:=C, A1=:=W, B1=:=C1-D1, 
          C1=:=A, D1=:=1, E1=<F1, E1=:=K, F1=:=0, G1=<H1, G1=:=P, H1=:=0, 
          lin5(B1,X,A1,W,E,F,G,H,I,J).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y) :- Z>=A1+1, 
          Z=:=A, A1=:=0, B1=:=B, C1=:=D1+E1, D1=:=B, E1=:=C, F1=:=B1, 
          G1=:=H1-I1, H1=:=A, I1=:=1, J1=<K1, J1=:=K, K1=:=0, L1>=M1+1, L1=:=P, 
          M1=:=0, N1=:=Q, O1=:=P1+Q1, P1=:=Q, Q1=:=R, R1=:=N1, S1=:=T1-U1, 
          T1=:=P, U1=:=1, lin7(G1,C1,F1,B1,E,F,G,H,I,J,S1,O1,R1,N1,T,U,V,W,X,Y).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,U,V,W,X,Y) :- Z>=A1+1, 
          Z=:=A, A1=:=0, B1=:=B, C1=:=D1+E1, D1=:=B, E1=:=C, F1=:=B1, 
          G1=:=H1-I1, H1=:=A, I1=:=1, J1>=K1+1, J1=:=K, K1=:=0, L1=:=L, 
          M1=:=N1+O1, N1=:=L, O1=:=M, P1=:=L1, Q1=:=R1-S1, R1=:=K, S1=:=1, 
          T1=<U1, T1=:=U, U1=:=0, 
          lin7(G1,C1,F1,B1,E,F,G,H,I,J,Q1,M1,P1,L1,O,P,Q,R,S,T).
lin4(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=A, F1=:=0, G1=:=B, H1=:=I1+J1, I1=:=B, J1=:=C, 
          K1=:=G1, L1=:=M1-N1, M1=:=A, N1=:=1, O1>=P1+1, O1=:=K, P1=:=0, 
          Q1=:=L, R1=:=S1+T1, S1=:=L, T1=:=M, U1=:=Q1, V1=:=W1-X1, W1=:=K, 
          X1=:=1, Y1>=Z1+1, Y1=:=U, Z1=:=0, A2=:=V, B2=:=C2+D2, C2=:=V, D2=:=W, 
          E2=:=A2, F2=:=G2-H2, G2=:=U, H2=:=1, 
          lin4(L1,H1,K1,G1,E,F,G,H,I,J,V1,R1,U1,Q1,O,P,Q,R,S,T,F2,B2,E2,A2,Y,Z,A1,B1,C1,D1).
lin2(A,B,C,D,E,F) :- G=:=2, H=:= -1, I=:=0, J=:=0, K=:=2, L=:= -1, M=:=0, 
          N=:=0, O=:=2, P=:= -1, Q=:=0, R=:=0, 
          lin4(A,G,H,I,J,S,B,T,U,V,C,K,L,M,N,W,D,X,Y,Z,E,O,P,Q,R,A1,F,B1,C1,D1).
lin1 :- A>=2, B=:=A-1, C=:=A-2, D>=E+F+1, lin2(A,D,B,E,C,F).
lin1 :- A>=2, B=:=A-1, C=:=A-2, D=<E+F-1, lin2(A,D,B,E,C,F).
inv1 :- \+lin1.
