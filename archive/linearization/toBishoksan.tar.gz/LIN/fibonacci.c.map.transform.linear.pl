incorrect :- A=:=0, B>=2, new1(A,B).
incorrect :- A=:=0, B=<0, new1(A,B).
incorrect :- A=:=1, B>=2, new1(A,B).
incorrect :- A=:=1, B=<0, new1(A,B).
inv1 :- \+incorrect.
new1(A,B) :- C=:=1, D=:=0, E=:=0, new2(A,C,D,E,F,B,G,H).
new2(A,B,C,D,A,B,C,D) :- E=<F, E=:=A, A>=0, F=:=0.
new2(A,B,C,D,E,F,G,H) :- I>=J+1, I=:=A, A>=0, J=:=0, K=:=B, B>=0, L=:=M+N, 
          M=:=B, B>=0, N=:=C, C>=0, O=:=K, K>=0, P=:=Q-R, Q=:=A, A>=0, R=:=1, 
          new2(P,L,O,K,E,F,G,H).
