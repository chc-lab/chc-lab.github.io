lin10(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,G,H,I,J,K,L) :- M=<N, M=:=D, D>=0, 
          N=:=0, O=<P, O=:=J, J>=0, P=:=0.
lin10(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=<T, S=:=D, D>=0, 
          T=:=0, U>=V+1, U=:=J, J>=0, V=:=0, W=0, J=:=2*X, Y=<Z, Y=:=W, W>=0, 
          Z=:=0, A1=:=B1+C1, B1=:=H, H>=0, C1=:=I, I>=0, J=:=2*L, D1=:=L, L>=0, 
          lin7(G,H,A1,D1,W,L,M,N,O,P,Q,R).
lin10(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R) :- S=<T, S=:=D, D>=0, 
          T=:=0, U>=V+1, U=:=J, J>=0, V=:=0, W=1, J=:=2*X+1, Y>=Z+1, Y=:=W, 
          W>=0, Z=:=0, A1=:=B1+C1, B1=:=H, H>=0, C1=:=I, I>=0, D1=:=E1-F1, 
          E1=:=J, J>=0, F1=:=1, D1=:=2*L, G1=:=L, L>=0, 
          lin7(G,A1,I,G1,W,L,M,N,O,P,Q,R).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,M,N,O,P,Q,R) :- S>=T+1, S=:=D, D>=0, 
          T=:=0, U=0, D=:=2*V, W=<X, W=:=U, U>=0, X=:=0, Y=:=Z+A1, Z=:=B, B>=0, 
          A1=:=C, C>=0, D=:=2*F, B1=:=F, F>=0, C1=<D1, C1=:=P, P>=0, D1=:=0, 
          lin7(A,B,Y,B1,U,F,G,H,I,J,K,L).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=D, D>=0, 
          Z=:=0, A1=0, D=:=2*B1, C1=<D1, C1=:=A1, A1>=0, D1=:=0, E1=:=F1+G1, 
          F1=:=B, B>=0, G1=:=C, C>=0, D=:=2*F, H1=:=F, F>=0, I1>=J1+1, I1=:=P, 
          P>=0, J1=:=0, K1=0, P=:=2*L1, M1=<N1, M1=:=K1, K1>=0, N1=:=0, 
          O1=:=P1+Q1, P1=:=N, N>=0, Q1=:=O, O>=0, P=:=2*R, R1=:=R, R>=0, 
          lin10(A,B,E1,H1,A1,F,G,H,I,J,K,L,M,N,O1,R1,K1,R,S,T,U,V,W,X).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=D, D>=0, 
          Z=:=0, A1=0, D=:=2*B1, C1=<D1, C1=:=A1, A1>=0, D1=:=0, E1=:=F1+G1, 
          F1=:=B, B>=0, G1=:=C, C>=0, D=:=2*F, H1=:=F, F>=0, I1>=J1+1, I1=:=P, 
          P>=0, J1=:=0, K1=1, P=:=2*L1+1, M1>=N1+1, M1=:=K1, K1>=0, N1=:=0, 
          O1=:=P1+Q1, P1=:=N, N>=0, Q1=:=O, O>=0, R1=:=S1-T1, S1=:=P, P>=0, 
          T1=:=1, R1=:=2*R, U1=:=R, R>=0, 
          lin10(A,B,E1,H1,A1,F,G,H,I,J,K,L,M,O1,O,U1,K1,R,S,T,U,V,W,X).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,M,N,O,P,Q,R) :- S>=T+1, S=:=D, D>=0, 
          T=:=0, U=1, D=:=2*V+1, W>=X+1, W=:=U, U>=0, X=:=0, Y=:=Z+A1, Z=:=B, 
          B>=0, A1=:=C, C>=0, B1=:=C1-D1, C1=:=D, D>=0, D1=:=1, B1=:=2*F, 
          E1=:=F, F>=0, F1=<G1, F1=:=P, P>=0, G1=:=0, 
          lin7(A,Y,C,E1,U,F,G,H,I,J,K,L).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=D, D>=0, 
          Z=:=0, A1=1, D=:=2*B1+1, C1>=D1+1, C1=:=A1, A1>=0, D1=:=0, 
          E1=:=F1+G1, F1=:=B, B>=0, G1=:=C, C>=0, H1=:=I1-J1, I1=:=D, D>=0, 
          J1=:=1, H1=:=2*F, K1=:=F, F>=0, L1>=M1+1, L1=:=P, P>=0, M1=:=0, N1=0, 
          P=:=2*O1, P1=<Q1, P1=:=N1, N1>=0, Q1=:=0, R1=:=S1+T1, S1=:=N, N>=0, 
          T1=:=O, O>=0, P=:=2*R, U1=:=R, R>=0, 
          lin10(A,E1,C,K1,A1,F,G,H,I,J,K,L,M,N,R1,U1,N1,R,S,T,U,V,W,X).
lin10(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- Y>=Z+1, Y=:=D, D>=0, 
          Z=:=0, A1=1, D=:=2*B1+1, C1>=D1+1, C1=:=A1, A1>=0, D1=:=0, 
          E1=:=F1+G1, F1=:=B, B>=0, G1=:=C, C>=0, H1=:=I1-J1, I1=:=D, D>=0, 
          J1=:=1, H1=:=2*F, K1=:=F, F>=0, L1>=M1+1, L1=:=P, P>=0, M1=:=0, N1=1, 
          P=:=2*O1+1, P1>=Q1+1, P1=:=N1, N1>=0, Q1=:=0, R1=:=S1+T1, S1=:=N, 
          N>=0, T1=:=O, O>=0, U1=:=V1-W1, V1=:=P, P>=0, W1=:=1, U1=:=2*R, 
          X1=:=R, R>=0, 
          lin10(A,E1,C,K1,A1,F,G,H,I,J,K,L,M,R1,O,X1,N1,R,S,T,U,V,W,X).
lin7(A,B,C,D,E,F,A,B,C,D,E,F) :- G=<H, G=:=D, D>=0, H=:=0.
lin7(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=D, D>=0, N=:=0, O=0, D=:=2*P, 
          Q=<R, Q=:=O, O>=0, R=:=0, S=:=T+U, T=:=B, B>=0, U=:=C, C>=0, D=:=2*F, 
          V=:=F, F>=0, lin7(A,B,S,V,O,F,G,H,I,J,K,L).
lin7(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=D, D>=0, N=:=0, O=1, D=:=2*P+1, 
          Q>=R+1, Q=:=O, O>=0, R=:=0, S=:=T+U, T=:=B, B>=0, U=:=C, C>=0, 
          V=:=W-X, W=:=D, D>=0, X=:=1, V=:=2*F, Y=:=F, F>=0, 
          lin7(A,S,C,Y,O,F,G,H,I,J,K,L).
lin6(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,G,H,I,J,K,L,M,N,O,P,Q,R,M,N,O,P,Q,R) :- 
          S=<T, S=:=D, D>=0, T=:=0, U=<V, U=:=J, J>=0, V=:=0, W=<X, W=:=P, 
          P>=0, X=:=0.
lin6(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          Y=<Z, Y=:=D, D>=0, Z=:=0, A1=<B1, A1=:=J, J>=0, B1=:=0, C1>=D1+1, 
          C1=:=P, P>=0, D1=:=0, E1=0, P=:=2*F1, G1=<H1, G1=:=E1, E1>=0, H1=:=0, 
          I1=:=J1+K1, J1=:=N, N>=0, K1=:=O, O>=0, P=:=2*R, L1=:=R, R>=0, 
          lin7(M,N,I1,L1,E1,R,S,T,U,V,W,X).
lin6(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X) :- 
          Y=<Z, Y=:=D, D>=0, Z=:=0, A1=<B1, A1=:=J, J>=0, B1=:=0, C1>=D1+1, 
          C1=:=P, P>=0, D1=:=0, E1=1, P=:=2*F1+1, G1>=H1+1, G1=:=E1, E1>=0, 
          H1=:=0, I1=:=J1+K1, J1=:=N, N>=0, K1=:=O, O>=0, L1=:=M1-N1, M1=:=P, 
          P>=0, N1=:=1, L1=:=2*R, O1=:=R, R>=0, 
          lin7(M,I1,O,O1,E1,R,S,T,U,V,W,X).
lin6(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,S,T,U,V,W,X) :- 
          Y=<Z, Y=:=D, D>=0, Z=:=0, A1>=B1+1, A1=:=J, J>=0, B1=:=0, C1=0, 
          J=:=2*D1, E1=<F1, E1=:=C1, C1>=0, F1=:=0, G1=:=H1+I1, H1=:=H, H>=0, 
          I1=:=I, I>=0, J=:=2*L, J1=:=L, L>=0, K1=<L1, K1=:=V, V>=0, L1=:=0, 
          lin7(G,H,G1,J1,C1,L,M,N,O,P,Q,R).
lin6(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=<F1, E1=:=D, D>=0, F1=:=0, G1>=H1+1, G1=:=J, J>=0, H1=:=0, I1=0, 
          J=:=2*J1, K1=<L1, K1=:=I1, I1>=0, L1=:=0, M1=:=N1+O1, N1=:=H, H>=0, 
          O1=:=I, I>=0, J=:=2*L, P1=:=L, L>=0, Q1>=R1+1, Q1=:=V, V>=0, R1=:=0, 
          S1=0, V=:=2*T1, U1=<V1, U1=:=S1, S1>=0, V1=:=0, W1=:=X1+Y1, X1=:=T, 
          T>=0, Y1=:=U, U>=0, V=:=2*X, Z1=:=X, X>=0, 
          lin10(G,H,M1,P1,I1,L,M,N,O,P,Q,R,S,T,W1,Z1,S1,X,Y,Z,A1,B1,C1,D1).
lin6(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=<F1, E1=:=D, D>=0, F1=:=0, G1>=H1+1, G1=:=J, J>=0, H1=:=0, I1=0, 
          J=:=2*J1, K1=<L1, K1=:=I1, I1>=0, L1=:=0, M1=:=N1+O1, N1=:=H, H>=0, 
          O1=:=I, I>=0, J=:=2*L, P1=:=L, L>=0, Q1>=R1+1, Q1=:=V, V>=0, R1=:=0, 
          S1=1, V=:=2*T1+1, U1>=V1+1, U1=:=S1, S1>=0, V1=:=0, W1=:=X1+Y1, 
          X1=:=T, T>=0, Y1=:=U, U>=0, Z1=:=A2-B2, A2=:=V, V>=0, B2=:=1, 
          Z1=:=2*X, C2=:=X, X>=0, 
          lin10(G,H,M1,P1,I1,L,M,N,O,P,Q,R,S,W1,U,C2,S1,X,Y,Z,A1,B1,C1,D1).
lin6(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,S,T,U,V,W,X) :- 
          Y=<Z, Y=:=D, D>=0, Z=:=0, A1>=B1+1, A1=:=J, J>=0, B1=:=0, C1=1, 
          J=:=2*D1+1, E1>=F1+1, E1=:=C1, C1>=0, F1=:=0, G1=:=H1+I1, H1=:=H, 
          H>=0, I1=:=I, I>=0, J1=:=K1-L1, K1=:=J, J>=0, L1=:=1, J1=:=2*L, 
          M1=:=L, L>=0, N1=<O1, N1=:=V, V>=0, O1=:=0, 
          lin7(G,G1,I,M1,C1,L,M,N,O,P,Q,R).
lin6(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=<F1, E1=:=D, D>=0, F1=:=0, G1>=H1+1, G1=:=J, J>=0, H1=:=0, I1=1, 
          J=:=2*J1+1, K1>=L1+1, K1=:=I1, I1>=0, L1=:=0, M1=:=N1+O1, N1=:=H, 
          H>=0, O1=:=I, I>=0, P1=:=Q1-R1, Q1=:=J, J>=0, R1=:=1, P1=:=2*L, 
          S1=:=L, L>=0, T1>=U1+1, T1=:=V, V>=0, U1=:=0, V1=0, V=:=2*W1, X1=<Y1, 
          X1=:=V1, V1>=0, Y1=:=0, Z1=:=A2+B2, A2=:=T, T>=0, B2=:=U, U>=0, 
          V=:=2*X, C2=:=X, X>=0, 
          lin10(G,M1,I,S1,I1,L,M,N,O,P,Q,R,S,T,Z1,C2,V1,X,Y,Z,A1,B1,C1,D1).
lin6(A,B,C,D,E,F,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1=<F1, E1=:=D, D>=0, F1=:=0, G1>=H1+1, G1=:=J, J>=0, H1=:=0, I1=1, 
          J=:=2*J1+1, K1>=L1+1, K1=:=I1, I1>=0, L1=:=0, M1=:=N1+O1, N1=:=H, 
          H>=0, O1=:=I, I>=0, P1=:=Q1-R1, Q1=:=J, J>=0, R1=:=1, P1=:=2*L, 
          S1=:=L, L>=0, T1>=U1+1, T1=:=V, V>=0, U1=:=0, V1=1, V=:=2*W1+1, 
          X1>=Y1+1, X1=:=V1, V1>=0, Y1=:=0, Z1=:=A2+B2, A2=:=T, T>=0, B2=:=U, 
          U>=0, C2=:=D2-E2, D2=:=V, V>=0, E2=:=1, C2=:=2*X, F2=:=X, X>=0, 
          lin10(G,M1,I,S1,I1,L,M,N,O,P,Q,R,S,Z1,U,F2,V1,X,Y,Z,A1,B1,C1,D1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,M,N,O,P,Q,R,S,T,U,V,W,X,S,T,U,V,W,X) :- 
          Y>=Z+1, Y=:=D, D>=0, Z=:=0, A1=0, D=:=2*B1, C1=<D1, C1=:=A1, A1>=0, 
          D1=:=0, E1=:=F1+G1, F1=:=B, B>=0, G1=:=C, C>=0, D=:=2*F, H1=:=F, 
          F>=0, I1=<J1, I1=:=P, P>=0, J1=:=0, K1=<L1, K1=:=V, V>=0, L1=:=0, 
          lin7(A,B,E1,H1,A1,F,G,H,I,J,K,L).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, D>=0, F1=:=0, G1=0, D=:=2*H1, I1=<J1, I1=:=G1, 
          G1>=0, J1=:=0, K1=:=L1+M1, L1=:=B, B>=0, M1=:=C, C>=0, D=:=2*F, 
          N1=:=F, F>=0, O1=<P1, O1=:=P, P>=0, P1=:=0, Q1>=R1+1, Q1=:=V, V>=0, 
          R1=:=0, S1=0, V=:=2*T1, U1=<V1, U1=:=S1, S1>=0, V1=:=0, W1=:=X1+Y1, 
          X1=:=T, T>=0, Y1=:=U, U>=0, V=:=2*X, Z1=:=X, X>=0, 
          lin10(A,B,K1,N1,G1,F,G,H,I,J,K,L,S,T,W1,Z1,S1,X,Y,Z,A1,B1,C1,D1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, D>=0, F1=:=0, G1=0, D=:=2*H1, I1=<J1, I1=:=G1, 
          G1>=0, J1=:=0, K1=:=L1+M1, L1=:=B, B>=0, M1=:=C, C>=0, D=:=2*F, 
          N1=:=F, F>=0, O1=<P1, O1=:=P, P>=0, P1=:=0, Q1>=R1+1, Q1=:=V, V>=0, 
          R1=:=0, S1=1, V=:=2*T1+1, U1>=V1+1, U1=:=S1, S1>=0, V1=:=0, 
          W1=:=X1+Y1, X1=:=T, T>=0, Y1=:=U, U>=0, Z1=:=A2-B2, A2=:=V, V>=0, 
          B2=:=1, Z1=:=2*X, C2=:=X, X>=0, 
          lin10(A,B,K1,N1,G1,F,G,H,I,J,K,L,S,W1,U,C2,S1,X,Y,Z,A1,B1,C1,D1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, D>=0, F1=:=0, G1=0, D=:=2*H1, I1=<J1, I1=:=G1, 
          G1>=0, J1=:=0, K1=:=L1+M1, L1=:=B, B>=0, M1=:=C, C>=0, D=:=2*F, 
          N1=:=F, F>=0, O1>=P1+1, O1=:=P, P>=0, P1=:=0, Q1=0, P=:=2*R1, S1=<T1, 
          S1=:=Q1, Q1>=0, T1=:=0, U1=:=V1+W1, V1=:=N, N>=0, W1=:=O, O>=0, 
          P=:=2*R, X1=:=R, R>=0, Y1=<Z1, Y1=:=B1, B1>=0, Z1=:=0, 
          lin10(A,B,K1,N1,G1,F,G,H,I,J,K,L,M,N,U1,X1,Q1,R,S,T,U,V,W,X).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, D>=0, L1=:=0, M1=0, D=:=2*N1, O1=<P1, O1=:=M1, 
          M1>=0, P1=:=0, Q1=:=R1+S1, R1=:=B, B>=0, S1=:=C, C>=0, D=:=2*F, 
          T1=:=F, F>=0, U1>=V1+1, U1=:=P, P>=0, V1=:=0, W1=0, P=:=2*X1, Y1=<Z1, 
          Y1=:=W1, W1>=0, Z1=:=0, A2=:=B2+C2, B2=:=N, N>=0, C2=:=O, O>=0, 
          P=:=2*R, D2=:=R, R>=0, E2>=F2+1, E2=:=B1, B1>=0, F2=:=0, G2=0, 
          B1=:=2*H2, I2=<J2, I2=:=G2, G2>=0, J2=:=0, K2=:=L2+M2, L2=:=Z, Z>=0, 
          M2=:=A1, A1>=0, B1=:=2*D1, N2=:=D1, D1>=0, 
          lin6(A,B,Q1,T1,M1,F,G,H,I,J,K,L,M,N,A2,D2,W1,R,S,T,U,V,W,X,Y,Z,K2,N2,G2,D1,E1,F1,G1,H1,I1,J1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, D>=0, L1=:=0, M1=0, D=:=2*N1, O1=<P1, O1=:=M1, 
          M1>=0, P1=:=0, Q1=:=R1+S1, R1=:=B, B>=0, S1=:=C, C>=0, D=:=2*F, 
          T1=:=F, F>=0, U1>=V1+1, U1=:=P, P>=0, V1=:=0, W1=0, P=:=2*X1, Y1=<Z1, 
          Y1=:=W1, W1>=0, Z1=:=0, A2=:=B2+C2, B2=:=N, N>=0, C2=:=O, O>=0, 
          P=:=2*R, D2=:=R, R>=0, E2>=F2+1, E2=:=B1, B1>=0, F2=:=0, G2=1, 
          B1=:=2*H2+1, I2>=J2+1, I2=:=G2, G2>=0, J2=:=0, K2=:=L2+M2, L2=:=Z, 
          Z>=0, M2=:=A1, A1>=0, N2=:=O2-P2, O2=:=B1, B1>=0, P2=:=1, N2=:=2*D1, 
          Q2=:=D1, D1>=0, 
          lin6(A,B,Q1,T1,M1,F,G,H,I,J,K,L,M,N,A2,D2,W1,R,S,T,U,V,W,X,Y,K2,A1,Q2,G2,D1,E1,F1,G1,H1,I1,J1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, D>=0, F1=:=0, G1=0, D=:=2*H1, I1=<J1, I1=:=G1, 
          G1>=0, J1=:=0, K1=:=L1+M1, L1=:=B, B>=0, M1=:=C, C>=0, D=:=2*F, 
          N1=:=F, F>=0, O1>=P1+1, O1=:=P, P>=0, P1=:=0, Q1=1, P=:=2*R1+1, 
          S1>=T1+1, S1=:=Q1, Q1>=0, T1=:=0, U1=:=V1+W1, V1=:=N, N>=0, W1=:=O, 
          O>=0, X1=:=Y1-Z1, Y1=:=P, P>=0, Z1=:=1, X1=:=2*R, A2=:=R, R>=0, 
          B2=<C2, B2=:=B1, B1>=0, C2=:=0, 
          lin10(A,B,K1,N1,G1,F,G,H,I,J,K,L,M,U1,O,A2,Q1,R,S,T,U,V,W,X).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, D>=0, L1=:=0, M1=0, D=:=2*N1, O1=<P1, O1=:=M1, 
          M1>=0, P1=:=0, Q1=:=R1+S1, R1=:=B, B>=0, S1=:=C, C>=0, D=:=2*F, 
          T1=:=F, F>=0, U1>=V1+1, U1=:=P, P>=0, V1=:=0, W1=1, P=:=2*X1+1, 
          Y1>=Z1+1, Y1=:=W1, W1>=0, Z1=:=0, A2=:=B2+C2, B2=:=N, N>=0, C2=:=O, 
          O>=0, D2=:=E2-F2, E2=:=P, P>=0, F2=:=1, D2=:=2*R, G2=:=R, R>=0, 
          H2>=I2+1, H2=:=B1, B1>=0, I2=:=0, J2=0, B1=:=2*K2, L2=<M2, L2=:=J2, 
          J2>=0, M2=:=0, N2=:=O2+P2, O2=:=Z, Z>=0, P2=:=A1, A1>=0, B1=:=2*D1, 
          Q2=:=D1, D1>=0, 
          lin6(A,B,Q1,T1,M1,F,G,H,I,J,K,L,M,A2,O,G2,W1,R,S,T,U,V,W,X,Y,Z,N2,Q2,J2,D1,E1,F1,G1,H1,I1,J1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, D>=0, L1=:=0, M1=0, D=:=2*N1, O1=<P1, O1=:=M1, 
          M1>=0, P1=:=0, Q1=:=R1+S1, R1=:=B, B>=0, S1=:=C, C>=0, D=:=2*F, 
          T1=:=F, F>=0, U1>=V1+1, U1=:=P, P>=0, V1=:=0, W1=1, P=:=2*X1+1, 
          Y1>=Z1+1, Y1=:=W1, W1>=0, Z1=:=0, A2=:=B2+C2, B2=:=N, N>=0, C2=:=O, 
          O>=0, D2=:=E2-F2, E2=:=P, P>=0, F2=:=1, D2=:=2*R, G2=:=R, R>=0, 
          H2>=I2+1, H2=:=B1, B1>=0, I2=:=0, J2=1, B1=:=2*K2+1, L2>=M2+1, 
          L2=:=J2, J2>=0, M2=:=0, N2=:=O2+P2, O2=:=Z, Z>=0, P2=:=A1, A1>=0, 
          Q2=:=R2-S2, R2=:=B1, B1>=0, S2=:=1, Q2=:=2*D1, T2=:=D1, D1>=0, 
          lin6(A,B,Q1,T1,M1,F,G,H,I,J,K,L,M,A2,O,G2,W1,R,S,T,U,V,W,X,Y,N2,A1,T2,J2,D1,E1,F1,G1,H1,I1,J1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,M,N,O,P,Q,R,S,T,U,V,W,X,S,T,U,V,W,X) :- 
          Y>=Z+1, Y=:=D, D>=0, Z=:=0, A1=1, D=:=2*B1+1, C1>=D1+1, C1=:=A1, 
          A1>=0, D1=:=0, E1=:=F1+G1, F1=:=B, B>=0, G1=:=C, C>=0, H1=:=I1-J1, 
          I1=:=D, D>=0, J1=:=1, H1=:=2*F, K1=:=F, F>=0, L1=<M1, L1=:=P, P>=0, 
          M1=:=0, N1=<O1, N1=:=V, V>=0, O1=:=0, 
          lin7(A,E1,C,K1,A1,F,G,H,I,J,K,L).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, D>=0, F1=:=0, G1=1, D=:=2*H1+1, I1>=J1+1, I1=:=G1, 
          G1>=0, J1=:=0, K1=:=L1+M1, L1=:=B, B>=0, M1=:=C, C>=0, N1=:=O1-P1, 
          O1=:=D, D>=0, P1=:=1, N1=:=2*F, Q1=:=F, F>=0, R1=<S1, R1=:=P, P>=0, 
          S1=:=0, T1>=U1+1, T1=:=V, V>=0, U1=:=0, V1=0, V=:=2*W1, X1=<Y1, 
          X1=:=V1, V1>=0, Y1=:=0, Z1=:=A2+B2, A2=:=T, T>=0, B2=:=U, U>=0, 
          V=:=2*X, C2=:=X, X>=0, 
          lin10(A,K1,C,Q1,G1,F,G,H,I,J,K,L,S,T,Z1,C2,V1,X,Y,Z,A1,B1,C1,D1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, D>=0, F1=:=0, G1=1, D=:=2*H1+1, I1>=J1+1, I1=:=G1, 
          G1>=0, J1=:=0, K1=:=L1+M1, L1=:=B, B>=0, M1=:=C, C>=0, N1=:=O1-P1, 
          O1=:=D, D>=0, P1=:=1, N1=:=2*F, Q1=:=F, F>=0, R1=<S1, R1=:=P, P>=0, 
          S1=:=0, T1>=U1+1, T1=:=V, V>=0, U1=:=0, V1=1, V=:=2*W1+1, X1>=Y1+1, 
          X1=:=V1, V1>=0, Y1=:=0, Z1=:=A2+B2, A2=:=T, T>=0, B2=:=U, U>=0, 
          C2=:=D2-E2, D2=:=V, V>=0, E2=:=1, C2=:=2*X, F2=:=X, X>=0, 
          lin10(A,K1,C,Q1,G1,F,G,H,I,J,K,L,S,Z1,U,F2,V1,X,Y,Z,A1,B1,C1,D1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, D>=0, F1=:=0, G1=1, D=:=2*H1+1, I1>=J1+1, I1=:=G1, 
          G1>=0, J1=:=0, K1=:=L1+M1, L1=:=B, B>=0, M1=:=C, C>=0, N1=:=O1-P1, 
          O1=:=D, D>=0, P1=:=1, N1=:=2*F, Q1=:=F, F>=0, R1>=S1+1, R1=:=P, P>=0, 
          S1=:=0, T1=0, P=:=2*U1, V1=<W1, V1=:=T1, T1>=0, W1=:=0, X1=:=Y1+Z1, 
          Y1=:=N, N>=0, Z1=:=O, O>=0, P=:=2*R, A2=:=R, R>=0, B2=<C2, B2=:=B1, 
          B1>=0, C2=:=0, 
          lin10(A,K1,C,Q1,G1,F,G,H,I,J,K,L,M,N,X1,A2,T1,R,S,T,U,V,W,X).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, D>=0, L1=:=0, M1=1, D=:=2*N1+1, O1>=P1+1, O1=:=M1, 
          M1>=0, P1=:=0, Q1=:=R1+S1, R1=:=B, B>=0, S1=:=C, C>=0, T1=:=U1-V1, 
          U1=:=D, D>=0, V1=:=1, T1=:=2*F, W1=:=F, F>=0, X1>=Y1+1, X1=:=P, P>=0, 
          Y1=:=0, Z1=0, P=:=2*A2, B2=<C2, B2=:=Z1, Z1>=0, C2=:=0, D2=:=E2+F2, 
          E2=:=N, N>=0, F2=:=O, O>=0, P=:=2*R, G2=:=R, R>=0, H2>=I2+1, H2=:=B1, 
          B1>=0, I2=:=0, J2=0, B1=:=2*K2, L2=<M2, L2=:=J2, J2>=0, M2=:=0, 
          N2=:=O2+P2, O2=:=Z, Z>=0, P2=:=A1, A1>=0, B1=:=2*D1, Q2=:=D1, D1>=0, 
          lin6(A,Q1,C,W1,M1,F,G,H,I,J,K,L,M,N,D2,G2,Z1,R,S,T,U,V,W,X,Y,Z,N2,Q2,J2,D1,E1,F1,G1,H1,I1,J1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, D>=0, L1=:=0, M1=1, D=:=2*N1+1, O1>=P1+1, O1=:=M1, 
          M1>=0, P1=:=0, Q1=:=R1+S1, R1=:=B, B>=0, S1=:=C, C>=0, T1=:=U1-V1, 
          U1=:=D, D>=0, V1=:=1, T1=:=2*F, W1=:=F, F>=0, X1>=Y1+1, X1=:=P, P>=0, 
          Y1=:=0, Z1=0, P=:=2*A2, B2=<C2, B2=:=Z1, Z1>=0, C2=:=0, D2=:=E2+F2, 
          E2=:=N, N>=0, F2=:=O, O>=0, P=:=2*R, G2=:=R, R>=0, H2>=I2+1, H2=:=B1, 
          B1>=0, I2=:=0, J2=1, B1=:=2*K2+1, L2>=M2+1, L2=:=J2, J2>=0, M2=:=0, 
          N2=:=O2+P2, O2=:=Z, Z>=0, P2=:=A1, A1>=0, Q2=:=R2-S2, R2=:=B1, B1>=0, 
          S2=:=1, Q2=:=2*D1, T2=:=D1, D1>=0, 
          lin6(A,Q1,C,W1,M1,F,G,H,I,J,K,L,M,N,D2,G2,Z1,R,S,T,U,V,W,X,Y,N2,A1,T2,J2,D1,E1,F1,G1,H1,I1,J1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,Y,Z,A1,B1,C1,D1) :- 
          E1>=F1+1, E1=:=D, D>=0, F1=:=0, G1=1, D=:=2*H1+1, I1>=J1+1, I1=:=G1, 
          G1>=0, J1=:=0, K1=:=L1+M1, L1=:=B, B>=0, M1=:=C, C>=0, N1=:=O1-P1, 
          O1=:=D, D>=0, P1=:=1, N1=:=2*F, Q1=:=F, F>=0, R1>=S1+1, R1=:=P, P>=0, 
          S1=:=0, T1=1, P=:=2*U1+1, V1>=W1+1, V1=:=T1, T1>=0, W1=:=0, 
          X1=:=Y1+Z1, Y1=:=N, N>=0, Z1=:=O, O>=0, A2=:=B2-C2, B2=:=P, P>=0, 
          C2=:=1, A2=:=2*R, D2=:=R, R>=0, E2=<F2, E2=:=B1, B1>=0, F2=:=0, 
          lin10(A,K1,C,Q1,G1,F,G,H,I,J,K,L,M,X1,O,D2,T1,R,S,T,U,V,W,X).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, D>=0, L1=:=0, M1=1, D=:=2*N1+1, O1>=P1+1, O1=:=M1, 
          M1>=0, P1=:=0, Q1=:=R1+S1, R1=:=B, B>=0, S1=:=C, C>=0, T1=:=U1-V1, 
          U1=:=D, D>=0, V1=:=1, T1=:=2*F, W1=:=F, F>=0, X1>=Y1+1, X1=:=P, P>=0, 
          Y1=:=0, Z1=1, P=:=2*A2+1, B2>=C2+1, B2=:=Z1, Z1>=0, C2=:=0, 
          D2=:=E2+F2, E2=:=N, N>=0, F2=:=O, O>=0, G2=:=H2-I2, H2=:=P, P>=0, 
          I2=:=1, G2=:=2*R, J2=:=R, R>=0, K2>=L2+1, K2=:=B1, B1>=0, L2=:=0, 
          M2=0, B1=:=2*N2, O2=<P2, O2=:=M2, M2>=0, P2=:=0, Q2=:=R2+S2, R2=:=Z, 
          Z>=0, S2=:=A1, A1>=0, B1=:=2*D1, T2=:=D1, D1>=0, 
          lin6(A,Q1,C,W1,M1,F,G,H,I,J,K,L,M,D2,O,J2,Z1,R,S,T,U,V,W,X,Y,Z,Q2,T2,M2,D1,E1,F1,G1,H1,I1,J1).
lin6(A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,A1,B1,C1,D1,E1,F1,G1,H1,I1,J1) :- 
          K1>=L1+1, K1=:=D, D>=0, L1=:=0, M1=1, D=:=2*N1+1, O1>=P1+1, O1=:=M1, 
          M1>=0, P1=:=0, Q1=:=R1+S1, R1=:=B, B>=0, S1=:=C, C>=0, T1=:=U1-V1, 
          U1=:=D, D>=0, V1=:=1, T1=:=2*F, W1=:=F, F>=0, X1>=Y1+1, X1=:=P, P>=0, 
          Y1=:=0, Z1=1, P=:=2*A2+1, B2>=C2+1, B2=:=Z1, Z1>=0, C2=:=0, 
          D2=:=E2+F2, E2=:=N, N>=0, F2=:=O, O>=0, G2=:=H2-I2, H2=:=P, P>=0, 
          I2=:=1, G2=:=2*R, J2=:=R, R>=0, K2>=L2+1, K2=:=B1, B1>=0, L2=:=0, 
          M2=1, B1=:=2*N2+1, O2>=P2+1, O2=:=M2, M2>=0, P2=:=0, Q2=:=R2+S2, 
          R2=:=Z, Z>=0, S2=:=A1, A1>=0, T2=:=U2-V2, U2=:=B1, B1>=0, V2=:=1, 
          T2=:=2*D1, W2=:=D1, D1>=0, 
          lin6(A,Q1,C,W1,M1,F,G,H,I,J,K,L,M,D2,O,J2,Z1,R,S,T,U,V,W,X,Y,Q2,A1,W2,M2,D1,E1,F1,G1,H1,I1,J1).
lin4(A,B,C,D,E,F) :- G=:=0, H=:=1, I=:=A, A>=0, J=:=0, K=:=1, L=:=C, C>=0, 
          M=:=0, N=:=1, O=:=E, E>=0, 
          lin6(A,G,H,I,P,Q,R,B,S,T,U,V,C,J,K,L,W,X,Y,D,Z,A1,B1,C1,E,M,N,O,D1,E1,F1,F,G1,H1,I1,J1).
lin2(A,B,C,D) :- E=:=0, F=:=1, G=:=A, A>=0, H=:=0, I=:=1, J=:=C, C>=0, 
          lin10(A,E,F,G,K,L,M,B,N,O,P,Q,C,H,I,J,R,S,T,D,U,V,W,X).
lin1 :- A>=2, A=:=B+B, B>=1, C>=D+1, lin2(A,C,B,D).
lin1 :- A>=2, A=:=B+B, B>=1, C=<D-1, lin2(A,C,B,D).
lin1 :- A>=2, A=:=B+B+1, B>=1, C=B+1, D>=E+F+1, lin4(A,D,B,E,C,F).
lin1 :- A>=2, A=:=B+B+1, B>=1, C=B+1, D=<E+F-1, lin4(A,D,B,E,C,F).
inv1 :- \+lin1.
