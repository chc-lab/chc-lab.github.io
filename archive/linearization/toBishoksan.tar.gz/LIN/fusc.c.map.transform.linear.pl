incorrect :- A=:=0, B>=1, new1(A,B).
incorrect :- A=:=0, B=< -1, new1(A,B).
incorrect :- A=:=1, B>=2, new1(A,B).
incorrect :- A=:=1, B=<0, new1(A,B).
inv1 :- \+incorrect.
new1(A,B) :- C=:=0, D=:=1, E=:=A, A>=0, new2(A,C,D,E,F,G,H,B,I,J,K,L).
new2(A,B,C,D,E,F,A,B,C,D,E,F) :- G=<H, G=:=D, D>=0, H=:=0.
new2(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=D, D>=0, N=:=0, O=0, D=:=2*P, 
          Q=<R, Q=:=O, O>=0, R=:=0, S=:=T+U, T=:=B, B>=0, U=:=C, C>=0, D=:=2*F, 
          V=:=F, F>=0, new2(A,B,S,V,O,F,G,H,I,J,K,L).
new2(A,B,C,D,E,F,G,H,I,J,K,L) :- M>=N+1, M=:=D, D>=0, N=:=0, O=1, D=:=2*P+1, 
          Q>=R+1, Q=:=O, O>=0, R=:=0, S=:=T+U, T=:=B, B>=0, U=:=C, C>=0, 
          V=:=W-X, W=:=D, D>=0, X=:=1, V=:=2*F, Y=:=F, F>=0, 
          new2(A,S,C,Y,O,F,G,H,I,J,K,L).
