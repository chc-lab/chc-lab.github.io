lin5(A,B,A,B) :- C+1=<D, C=:=B, B>=0, D=:=A, A>=0.
lin5(A,B,C,D) :- E>=F, E=:=B, B>=0, F=:=A, A>=0, G=:=H-I, H=:=B, B>=0, I=:=A, 
          A>=0, lin5(A,G,C,D).
lin4(A,B,A,B,C,D,C,D) :- E+1=<F, E=:=B, B>=0, F=:=A, A>=0, G+1=<H, G=:=D, D>=0, 
          H=:=C, C>=0.
lin4(A,B,A,B,C,D,E,F) :- G+1=<H, G=:=B, B>=0, H=:=A, A>=0, I>=J, I=:=D, D>=0, 
          J=:=C, C>=0, K=:=L-M, L=:=D, D>=0, M=:=C, C>=0, lin5(C,K,E,F).
lin4(A,B,C,D,E,F,E,F) :- G>=H, G=:=B, B>=0, H=:=A, A>=0, I=:=J-K, J=:=B, B>=0, 
          K=:=A, A>=0, L+1=<M, L=:=F, F>=0, M=:=E, E>=0, lin5(A,I,C,D).
lin4(A,B,C,D,E,F,G,H) :- I>=J, I=:=B, B>=0, J=:=A, A>=0, K=:=L-M, L=:=B, B>=0, 
          M=:=A, A>=0, N>=O, N=:=F, F>=0, O=:=E, E>=0, P=:=Q-R, Q=:=F, F>=0, 
          R=:=E, E>=0, lin4(A,K,C,D,E,P,G,H).
lin2(A,B,C,D,E,F) :- lin4(B,A,G,C,E,D,H,F).
lin1 :- A>=B+1, C=:=A-B, D=:=B, E>=F+1, lin2(A,B,F,C,D,E).
lin1 :- A>=B+1, C=:=A-B, D=:=B, E=<F-1, lin2(A,B,F,C,D,E).
inv1 :- \+lin1.
